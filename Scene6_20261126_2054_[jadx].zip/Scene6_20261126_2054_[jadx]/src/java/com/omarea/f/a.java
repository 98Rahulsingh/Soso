package com.omarea.f;

import java.util.ArrayList;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public String f549a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public String f550b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public ArrayList<b> f551c;
}
