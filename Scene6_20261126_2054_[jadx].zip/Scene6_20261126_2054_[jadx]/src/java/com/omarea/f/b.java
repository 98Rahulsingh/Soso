package com.omarea.f;

import java.util.HashMap;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public String f552a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public String f553b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public String f554c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public String f555d;
    public double g;
    public double h;
    public c[] k;
    public HashMap<String, String> l;
    public String e = "";
    public String f = "string";
    public String i = "1";
    public String j = "0";
}
