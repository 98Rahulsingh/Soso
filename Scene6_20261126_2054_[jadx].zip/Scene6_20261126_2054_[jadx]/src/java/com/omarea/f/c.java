package com.omarea.f;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public String f556a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public String f557b;
}
