package com.omarea.c.m;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Environment;
import android.webkit.URLUtil;
import android.widget.Toast;
import com.omarea.c.h;
import com.omarea.common.shared.d;
import com.omarea.common.ui.e;
import java.io.File;
import java.nio.charset.Charset;
import kotlin.jvm.internal.o;
import kotlin.jvm.internal.r;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class a {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private static final String f403b = "kr_downloader";

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private Context f404a;

    public a(Context context, Activity activity) {
        r.d(context, "context");
        this.f404a = context;
    }

    public /* synthetic */ a(Context context, Activity activity, int i, o oVar) {
        this(context, (i & 2) != 0 ? null : activity);
    }

    private final void a(long j, String str, String str2) throws JSONException {
        SharedPreferences sharedPreferences = this.f404a.getSharedPreferences(f403b, 0);
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("url", str2);
        jSONObject.put("taskAliasId", str);
        sharedPreferences.edit().putString(String.valueOf(j), jSONObject.toString(2)).apply();
    }

    public static /* synthetic */ Long c(a aVar, String str, String str2, String str3, String str4, String str5, int i, Object obj) {
        if ((i & 16) != 0) {
            str5 = null;
        }
        return aVar.b(str, str2, str3, str4, str5);
    }

    public final Long b(String str, String str2, String str3, String str4, String str5) {
        r.d(str, "url");
        r.d(str4, "taskAliasId");
        try {
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(str));
            request.allowScanningByMediaScanner();
            boolean z = true;
            request.setNotificationVisibility(1);
            request.setAllowedOverMetered(true);
            request.setVisibleInDownloadsUi(true);
            request.setAllowedOverRoaming(true);
            if (str5 == null || str5.length() == 0) {
                str5 = URLUtil.guessFileName(str, str2, str3);
            }
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, str5);
            Object systemService = this.f404a.getSystemService("download");
            if (systemService == null) {
                throw new NullPointerException("null cannot be cast to non-null type android.app.DownloadManager");
            }
            long jEnqueue = ((DownloadManager) systemService).enqueue(request);
            if (str4.length() <= 0) {
                z = false;
            }
            if (z) {
                a(jEnqueue, str4, str);
            }
            Toast.makeText(this.f404a, this.f404a.getString(h.kr_download_create_success), 0).show();
            b.a(this.f404a.getApplicationContext());
            return Long.valueOf(jEnqueue);
        } catch (Exception e) {
            e.a aVar = e.f492b;
            Context context = this.f404a;
            String string = context.getString(h.kr_download_create_fail);
            r.c(string, "context.getString(R.stri….kr_download_create_fail)");
            e.a.A(aVar, context, string, "" + e.getMessage(), null, 8, null);
            return null;
        }
    }

    public final void d(long j, String str) throws JSONException {
        String string;
        r.d(str, "absPath");
        SharedPreferences sharedPreferences = this.f404a.getSharedPreferences(f403b, 0);
        String string2 = sharedPreferences.getString(String.valueOf(j), null);
        if (string2 != null) {
            JSONObject jSONObject = new JSONObject(string2);
            jSONObject.put("absPath", str);
            sharedPreferences.edit().putString(String.valueOf(j), jSONObject.toString(2)).apply();
            string = jSONObject.getString("taskAliasId");
        } else {
            string = "";
        }
        try {
            File file = new File(str);
            if (file.exists() && file.canRead()) {
                String strB = new c().b(file);
                r.c(strB, "FileMD5().getFileMD5(file)");
                if (strB == null) {
                    throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                }
                String lowerCase = strB.toLowerCase();
                r.c(lowerCase, "(this as java.lang.String).toLowerCase()");
                d dVar = d.f450b;
                Charset charsetDefaultCharset = Charset.defaultCharset();
                r.c(charsetDefaultCharset, "Charset.defaultCharset()");
                byte[] bytes = str.getBytes(charsetDefaultCharset);
                r.c(bytes, "(this as java.lang.String).getBytes(charset)");
                dVar.h(bytes, "downloader/path/" + lowerCase, this.f404a);
                if (string != null) {
                    d dVar2 = d.f450b;
                    Charset charsetDefaultCharset2 = Charset.defaultCharset();
                    r.c(charsetDefaultCharset2, "Charset.defaultCharset()");
                    byte[] bytes2 = str.getBytes(charsetDefaultCharset2);
                    r.c(bytes2, "(this as java.lang.String).getBytes(charset)");
                    dVar2.h(bytes2, "downloader/result/" + string, this.f404a);
                }
            }
        } catch (Exception unused) {
        }
    }

    public final void e(String str, int i) {
        r.d(str, "taskAliasId");
        d dVar = d.f450b;
        String strValueOf = String.valueOf(i);
        Charset charsetDefaultCharset = Charset.defaultCharset();
        r.c(charsetDefaultCharset, "Charset.defaultCharset()");
        if (strValueOf == null) {
            throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
        }
        byte[] bytes = strValueOf.getBytes(charsetDefaultCharset);
        r.c(bytes, "(this as java.lang.String).getBytes(charset)");
        dVar.h(bytes, "downloader/status/" + str, this.f404a);
    }
}
