package com.omarea.c.m;

import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.text.TextUtils;
import android.widget.Toast;
import com.omarea.c.h;
import com.omarea.common.ui.e;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class b extends BroadcastReceiver {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private static b f405a;

    public static void a(Context context) {
        if (f405a == null) {
            f405a = new b();
            IntentFilter intentFilter = new IntentFilter();
            intentFilter.addAction("android.intent.action.DOWNLOAD_COMPLETE");
            context.registerReceiver(f405a, intentFilter);
        }
    }

    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) throws Throwable {
        if (intent == null || !"android.intent.action.DOWNLOAD_COMPLETE".equals(intent.getAction())) {
            return;
        }
        try {
            long longExtra = intent.getLongExtra("extra_download_id", -1L);
            DownloadManager downloadManager = (DownloadManager) context.getSystemService("download");
            TextUtils.isEmpty(downloadManager.getMimeTypeForDownloadedFile(longExtra));
            String strF = new com.omarea.common.shared.c().f(context, downloadManager.getUriForDownloadedFile(longExtra));
            if (strF != null && !strF.isEmpty()) {
                new a(context, null).d(longExtra, strF);
                try {
                    e.f492b.x(context, context.getString(h.kr_download_completed), "" + strF, null);
                } catch (Exception unused) {
                    Toast.makeText(context, context.getString(h.kr_download_completed) + "\n" + strF, 1).show();
                }
            }
        } catch (Exception unused2) {
        }
    }
}
