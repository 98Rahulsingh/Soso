package com.omarea.c;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Build;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;
import com.omarea.krscript.model.NodeInfoBase;
import com.omarea.krscript.ui.p;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Iterator;
import java.util.UUID;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class k {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private WebView f381a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private Context f382b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private p.a f383c;

    class a implements DownloadListener {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final /* synthetic */ Activity f384a;

        /* JADX INFO: renamed from: com.omarea.c.k$a$a, reason: collision with other inner class name */
        class DialogInterfaceOnClickListenerC0036a implements DialogInterface.OnClickListener {
            DialogInterfaceOnClickListenerC0036a(a aVar) {
            }

            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i) {
            }
        }

        class b implements DialogInterface.OnClickListener {
            final /* synthetic */ String f;
            final /* synthetic */ String g;
            final /* synthetic */ String h;

            b(String str, String str2, String str3) {
                this.f = str;
                this.g = str2;
                this.h = str3;
            }

            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i) {
                new com.omarea.c.m.a(k.this.f382b, null).b(this.f, this.g, this.h, UUID.randomUUID().toString(), null);
            }
        }

        a(Activity activity) {
            this.f384a = activity;
        }

        @Override // android.webkit.DownloadListener
        public void onDownloadStart(String str, String str2, String str3, String str4, long j) {
            if (Build.VERSION.SDK_INT >= 23 && k.this.f382b.checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") != 0) {
                this.f384a.requestPermissions(new String[]{"android.permission.READ_EXTERNAL_STORAGE", "android.permission.WRITE_EXTERNAL_STORAGE"}, 2);
                Toast.makeText(k.this.f382b, h.kr_write_external_storage, 1).show();
                return;
            }
            com.omarea.common.ui.e.f492b.c(new AlertDialog.Builder(k.this.f382b).setTitle(h.kr_download_confirm).setMessage("" + str + "\n\n" + str4 + "\n" + j + "Bytes").setPositiveButton(h.btn_confirm, new b(str, str3, str4)).setNegativeButton(h.btn_cancel, new DialogInterfaceOnClickListenerC0036a(this))).g(false);
        }
    }

    private class b {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final Context f386a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private final NodeInfoBase f387b;

        class a implements Runnable {
            a(b bVar) {
            }

            @Override // java.lang.Runnable
            public void run() {
            }
        }

        /* JADX INFO: renamed from: com.omarea.c.k$b$b, reason: collision with other inner class name */
        class C0037b implements p.b {

            /* JADX INFO: renamed from: b, reason: collision with root package name */
            final /* synthetic */ String f389b;

            /* JADX INFO: renamed from: com.omarea.c.k$b$b$a */
            class a implements Runnable {
                final /* synthetic */ JSONObject f;

                /* JADX INFO: renamed from: com.omarea.c.k$b$b$a$a, reason: collision with other inner class name */
                class C0038a implements ValueCallback<String> {
                    C0038a(a aVar) {
                    }

                    @Override // android.webkit.ValueCallback
                    /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
                    public void onReceiveValue(String str) {
                    }
                }

                a(JSONObject jSONObject) {
                    this.f = jSONObject;
                }

                @Override // java.lang.Runnable
                public void run() {
                    k.this.f381a.evaluateJavascript(C0037b.this.f389b + "(" + this.f.toString() + ")", new C0038a(this));
                }
            }

            C0037b(String str) {
                this.f389b = str;
            }

            @Override // com.omarea.krscript.ui.p.b
            public void a(String str) {
                try {
                    JSONObject jSONObject = new JSONObject();
                    if (str == null || str.isEmpty()) {
                        jSONObject.put("absPath", (Object) null);
                    } else {
                        jSONObject.put("absPath", str);
                    }
                    k.this.f381a.post(new a(jSONObject));
                } catch (Exception unused) {
                }
            }

            @Override // com.omarea.krscript.ui.p.b
            public String b() {
                return "*/*";
            }

            @Override // com.omarea.krscript.ui.p.b
            public String c() {
                return null;
            }

            @Override // com.omarea.krscript.ui.p.b
            public int d() {
                return p.b.f609a.a();
            }
        }

        class c implements Runnable {
            final /* synthetic */ InputStream f;
            final /* synthetic */ String g;

            class a implements Runnable {
                final /* synthetic */ JSONObject f;

                /* JADX INFO: renamed from: com.omarea.c.k$b$c$a$a, reason: collision with other inner class name */
                class C0039a implements ValueCallback<String> {
                    C0039a(a aVar) {
                    }

                    @Override // android.webkit.ValueCallback
                    /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
                    public void onReceiveValue(String str) {
                    }
                }

                a(JSONObject jSONObject) {
                    this.f = jSONObject;
                }

                @Override // java.lang.Runnable
                public void run() {
                    k.this.f381a.evaluateJavascript(c.this.g + "(" + this.f.toString() + ")", new C0039a(this));
                }
            }

            c(InputStream inputStream, String str) {
                this.f = inputStream;
                this.g = str;
            }

            @Override // java.lang.Runnable
            public void run() {
                try {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(this.f, "UTF-8"));
                    while (true) {
                        String line = bufferedReader.readLine();
                        if (line == null) {
                            return;
                        }
                        try {
                            JSONObject jSONObject = new JSONObject();
                            jSONObject.put("type", 2);
                            jSONObject.put("message", line + "\n");
                            k.this.f381a.post(new a(jSONObject));
                        } catch (Exception unused) {
                        }
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        class d implements Runnable {
            final /* synthetic */ InputStream f;
            final /* synthetic */ String g;

            class a implements Runnable {
                final /* synthetic */ JSONObject f;

                /* JADX INFO: renamed from: com.omarea.c.k$b$d$a$a, reason: collision with other inner class name */
                class C0040a implements ValueCallback<String> {
                    C0040a(a aVar) {
                    }

                    @Override // android.webkit.ValueCallback
                    /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
                    public void onReceiveValue(String str) {
                    }
                }

                a(JSONObject jSONObject) {
                    this.f = jSONObject;
                }

                @Override // java.lang.Runnable
                public void run() {
                    k.this.f381a.evaluateJavascript(d.this.g + "(" + this.f.toString() + ")", new C0040a(this));
                }
            }

            d(InputStream inputStream, String str) {
                this.f = inputStream;
                this.g = str;
            }

            @Override // java.lang.Runnable
            public void run() {
                try {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(this.f, "UTF-8"));
                    while (true) {
                        String line = bufferedReader.readLine();
                        if (line == null) {
                            return;
                        }
                        try {
                            JSONObject jSONObject = new JSONObject();
                            jSONObject.put("type", 4);
                            jSONObject.put("message", line + "\n");
                            k.this.f381a.post(new a(jSONObject));
                        } catch (Exception unused) {
                        }
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        class e implements Runnable {
            final /* synthetic */ Process f;
            final /* synthetic */ String g;
            final /* synthetic */ Thread h;
            final /* synthetic */ Thread i;
            final /* synthetic */ Runnable j;

            class a implements Runnable {
                final /* synthetic */ JSONObject f;

                /* JADX INFO: renamed from: com.omarea.c.k$b$e$a$a, reason: collision with other inner class name */
                class C0041a implements ValueCallback<String> {
                    C0041a(a aVar) {
                    }

                    @Override // android.webkit.ValueCallback
                    /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
                    public void onReceiveValue(String str) {
                    }
                }

                a(JSONObject jSONObject) {
                    this.f = jSONObject;
                }

                @Override // java.lang.Runnable
                public void run() {
                    k.this.f381a.evaluateJavascript(e.this.g + "(" + this.f.toString() + ")", new C0041a(this));
                }
            }

            e(Process process, String str, Thread thread, Thread thread2, Runnable runnable) {
                this.f = process;
                this.g = str;
                this.h = thread;
                this.i = thread2;
                this.j = runnable;
            }

            /* JADX WARN: Multi-variable type inference failed */
            /* JADX WARN: Type inference failed for: r0v0, types: [java.lang.String] */
            /* JADX WARN: Type inference failed for: r0v11, types: [android.webkit.WebView] */
            /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.String] */
            /* JADX WARN: Type inference failed for: r0v24 */
            /* JADX WARN: Type inference failed for: r0v36, types: [android.webkit.WebView] */
            /* JADX WARN: Type inference failed for: r0v39 */
            /* JADX WARN: Type inference failed for: r0v40 */
            /* JADX WARN: Type inference failed for: r0v41 */
            /* JADX WARN: Type inference failed for: r1v0, types: [java.lang.String] */
            /* JADX WARN: Type inference failed for: r1v1 */
            /* JADX WARN: Type inference failed for: r1v10, types: [com.omarea.c.k$b$e$a, java.lang.Runnable] */
            /* JADX WARN: Type inference failed for: r1v11 */
            /* JADX WARN: Type inference failed for: r1v12 */
            /* JADX WARN: Type inference failed for: r1v13 */
            /* JADX WARN: Type inference failed for: r1v14 */
            /* JADX WARN: Type inference failed for: r1v15 */
            /* JADX WARN: Type inference failed for: r1v2 */
            /* JADX WARN: Type inference failed for: r1v3, types: [com.omarea.c.k$b$e$a, java.lang.Runnable] */
            /* JADX WARN: Type inference failed for: r1v4, types: [java.lang.String] */
            /* JADX WARN: Type inference failed for: r1v6 */
            /* JADX WARN: Type inference failed for: r1v7 */
            /* JADX WARN: Type inference failed for: r1v8 */
            /* JADX WARN: Type inference failed for: r1v9 */
            /* JADX WARN: Type inference failed for: r2v0, types: [java.lang.String] */
            /* JADX WARN: Type inference failed for: r2v1 */
            /* JADX WARN: Type inference failed for: r2v10, types: [java.lang.StringBuilder] */
            /* JADX WARN: Type inference failed for: r2v11 */
            /* JADX WARN: Type inference failed for: r2v12 */
            /* JADX WARN: Type inference failed for: r2v13 */
            /* JADX WARN: Type inference failed for: r2v14 */
            /* JADX WARN: Type inference failed for: r2v15 */
            /* JADX WARN: Type inference failed for: r2v2 */
            /* JADX WARN: Type inference failed for: r2v3, types: [java.lang.StringBuilder] */
            /* JADX WARN: Type inference failed for: r2v4, types: [java.lang.String] */
            /* JADX WARN: Type inference failed for: r2v5, types: [java.lang.StringBuilder] */
            /* JADX WARN: Type inference failed for: r2v6 */
            /* JADX WARN: Type inference failed for: r2v7 */
            /* JADX WARN: Type inference failed for: r2v8 */
            /* JADX WARN: Type inference failed for: r2v9 */
            /* JADX WARN: Type inference failed for: r6v0, types: [org.json.JSONObject] */
            @Override // java.lang.Runnable
            public void run() {
                ?? r2;
                ?? r1;
                Runnable runnable;
                ?? r0 = "";
                ?? aVar = "message";
                ?? sb = "type";
                int iWaitFor = -1;
                try {
                    try {
                        iWaitFor = this.f.waitFor();
                        try {
                            JSONObject jSONObject = new JSONObject();
                            jSONObject.put("type", -2);
                            sb = new StringBuilder();
                            sb.append("");
                            sb.append(iWaitFor);
                            jSONObject.put("message", sb.toString());
                            ?? r3 = k.this.f381a;
                            aVar = new a(jSONObject);
                            r3.post(aVar);
                        } catch (Exception unused) {
                        }
                        if (this.h.isAlive()) {
                            this.h.interrupt();
                        }
                        if (this.i.isAlive()) {
                            this.i.interrupt();
                        }
                        Runnable runnable2 = this.j;
                        runnable = runnable2;
                        r1 = aVar;
                        r2 = sb;
                        r0 = runnable2;
                        aVar = aVar;
                        sb = sb;
                        if (runnable2 != null) {
                            runnable.run();
                            r0 = runnable;
                            aVar = r1;
                            sb = r2;
                        }
                    } catch (Throwable th) {
                        try {
                            ?? jSONObject2 = new JSONObject();
                            jSONObject2.put(sb, -2);
                            ?? sb2 = new StringBuilder();
                            sb2.append(r0);
                            sb2.append(iWaitFor);
                            jSONObject2.put(aVar, sb2.toString());
                            k.this.f381a.post(new a(jSONObject2));
                        } catch (Exception unused2) {
                        }
                        if (this.h.isAlive()) {
                            this.h.interrupt();
                        }
                        if (this.i.isAlive()) {
                            this.i.interrupt();
                        }
                        Runnable runnable3 = this.j;
                        if (runnable3 == null) {
                            throw th;
                        }
                        runnable3.run();
                        throw th;
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                    try {
                        JSONObject jSONObject3 = new JSONObject();
                        jSONObject3.put("type", -2);
                        sb = new StringBuilder();
                        sb.append("");
                        sb.append(-1);
                        jSONObject3.put("message", sb.toString());
                        ?? r4 = k.this.f381a;
                        aVar = new a(jSONObject3);
                        r4.post(aVar);
                    } catch (Exception unused3) {
                    }
                    if (this.h.isAlive()) {
                        this.h.interrupt();
                    }
                    if (this.i.isAlive()) {
                        this.i.interrupt();
                    }
                    Runnable runnable4 = this.j;
                    runnable = runnable4;
                    r1 = aVar;
                    r2 = sb;
                    r0 = runnable4;
                    aVar = aVar;
                    sb = sb;
                    if (runnable4 != null) {
                    }
                }
            }
        }

        private b(Context context) {
            this.f387b = new NodeInfoBase("");
            this.f386a = context;
        }

        /* synthetic */ b(k kVar, Context context, a aVar) {
            this(context);
        }

        private void a(Process process, String str, Runnable runnable) {
            InputStream inputStream = process.getInputStream();
            InputStream errorStream = process.getErrorStream();
            Thread thread = new Thread(new c(inputStream, str));
            Thread thread2 = new Thread(new d(errorStream, str));
            Thread thread3 = new Thread(new e(process, str, thread, thread2, runnable));
            thread.start();
            thread2.start();
            thread3.start();
        }

        @JavascriptInterface
        public String executeShell(String str) {
            return (str == null || str.isEmpty()) ? "" : com.omarea.c.n.b.c(this.f386a, str, this.f387b);
        }

        @JavascriptInterface
        public boolean executeShellAsync(String str, String str2, String str3) {
            Process processE;
            HashMap map = new HashMap();
            if (str3 != null) {
                try {
                    if (!str3.isEmpty()) {
                        JSONObject jSONObject = new JSONObject(str3);
                        Iterator<String> itKeys = jSONObject.keys();
                        while (itKeys.hasNext()) {
                            String next = itKeys.next();
                            map.put(next, jSONObject.getString(next));
                        }
                    }
                } catch (Exception e2) {
                    Toast.makeText(this.f386a, e2.getMessage(), 0).show();
                    processE = null;
                }
            }
            processE = com.omarea.common.shell.i.e();
            if (processE == null) {
                return false;
            }
            DataOutputStream dataOutputStream = new DataOutputStream(processE.getOutputStream());
            a(processE, str2, new a(this));
            com.omarea.c.n.b.d(this.f386a, dataOutputStream, str, map, null, null);
            return true;
        }

        @JavascriptInterface
        public String extractAssets(String str) {
            return new com.omarea.c.n.a(this.f386a).d(str);
        }

        @JavascriptInterface
        public boolean fileChooser(String str) {
            if (k.this.f383c != null) {
                return k.this.f383c.openFileChooser(new C0037b(str));
            }
            return false;
        }

        @JavascriptInterface
        public boolean rootCheck() {
            return com.omarea.common.shell.e.f469b.a();
        }
    }

    @SuppressLint({"SetJavaScriptEnabled"})
    public k(WebView webView, p.a aVar) {
        this.f381a = webView;
        this.f382b = webView.getContext();
        this.f383c = aVar;
    }

    @SuppressLint({"JavascriptInterface", "SetJavaScriptEnabled"})
    public void d(Activity activity, boolean z) {
        WebView webView = this.f381a;
        if (webView != null) {
            WebSettings settings = webView.getSettings();
            settings.setJavaScriptEnabled(true);
            settings.setAllowFileAccess(z);
            settings.setAllowUniversalAccessFromFileURLs(z);
            settings.setAllowFileAccessFromFileURLs(z);
            settings.setAllowContentAccess(true);
            settings.setUseWideViewPort(true);
            this.f381a.addJavascriptInterface(new b(this, this.f382b, null), "KrScriptCore");
            this.f381a.setDownloadListener(new a(activity));
        }
    }
}
