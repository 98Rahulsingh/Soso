package com.omarea.c.n;

import android.content.Context;
import com.omarea.krscript.model.RunnableNode;
import com.omarea.krscript.model.ShellHandlerBase;
import java.nio.channels.SocketChannel;
import java.util.HashMap;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private boolean f414a = false;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final String f415b = "pio_" + System.currentTimeMillis();

    static class a implements com.omarea.common.net.b {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        ShellHandlerBase f416a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        Runnable f417b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        boolean f418c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        private int f419d = -1;

        /* JADX INFO: renamed from: com.omarea.c.n.c$a$a, reason: collision with other inner class name */
        class RunnableC0044a implements Runnable {
            final /* synthetic */ com.omarea.common.net.c f;

            RunnableC0044a(a aVar, com.omarea.common.net.c cVar) {
                this.f = cVar;
            }

            @Override // java.lang.Runnable
            public void run() {
                this.f.a();
            }
        }

        public a(Context context, ShellHandlerBase shellHandlerBase, Runnable runnable, boolean z) {
            this.f416a = shellHandlerBase;
            this.f417b = runnable;
            this.f418c = z;
        }

        @Override // com.omarea.common.net.b
        public void a(SocketChannel socketChannel) {
        }

        @Override // com.omarea.common.net.b
        public void b(String str, String str2) {
            ShellHandlerBase shellHandlerBase = this.f416a;
            shellHandlerBase.sendMessage(shellHandlerBase.obtainMessage(2, str2 + "\n"));
        }

        @Override // com.omarea.common.net.b
        public void c(SocketChannel socketChannel, com.omarea.common.net.c cVar) {
            this.f416a.onStart((Runnable) (this.f418c ? new RunnableC0044a(this, cVar) : null));
            this.f416a.obtainMessage(0, "shell@daemon:\n");
        }

        @Override // com.omarea.common.net.b
        public void d(SocketChannel socketChannel) {
            ShellHandlerBase shellHandlerBase = this.f416a;
            shellHandlerBase.sendMessage(shellHandlerBase.obtainMessage(-2, Integer.valueOf(this.f419d)));
            Runnable runnable = this.f417b;
            if (runnable != null) {
                runnable.run();
            }
        }

        @Override // com.omarea.common.net.b
        public void e(String str, String str2) {
            ShellHandlerBase shellHandlerBase = this.f416a;
            shellHandlerBase.sendMessage(shellHandlerBase.obtainMessage(4, str2 + "\n"));
        }

        @Override // com.omarea.common.net.b
        public void f(int i) {
            this.f419d = i;
        }
    }

    public void a(Context context, RunnableNode runnableNode, String str, Runnable runnable, HashMap<String, String> map, ShellHandlerBase shellHandlerBase) {
        if (this.f414a) {
            return;
        }
        this.f414a = b.e(context, new a(context, shellHandlerBase, runnable, runnableNode.getInterruptable() || runnableNode.getShell().equals(RunnableNode.Companion.getShellModeBgTask())), str, map, runnableNode, this.f415b);
    }
}
