package com.omarea.c.n;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.os.Build;
import android.os.Environment;
import com.omarea.common.net.Daemon;
import com.omarea.common.shared.MagiskExtend;
import com.omarea.common.shared.d;
import com.omarea.common.shell.e;
import com.omarea.krscript.model.NodeInfoBase;
import java.io.DataOutputStream;
import java.io.File;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HashMap;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private static boolean f410a = false;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private static String f411b = "";

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private static String f412c = "";

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private static final com.omarea.common.shell.b f413d = e.f469b.g();
    private static String e = "kr-script/executor.sh";
    private static String f = "kr-script/toolkit";

    static class a implements Runnable {
        final /* synthetic */ boolean[] f;
        final /* synthetic */ StringBuilder g;
        final /* synthetic */ com.omarea.common.net.b h;

        a(boolean[] zArr, StringBuilder sb, com.omarea.common.net.b bVar) {
            this.f = zArr;
            this.g = sb;
            this.h = bVar;
        }

        @Override // java.lang.Runnable
        public void run() {
            this.f[0] = Daemon.E.a().o0(this.g.toString(), this.h);
            synchronized (this.h) {
                this.h.notify();
            }
        }
    }

    private static boolean a() {
        return e.f469b.a();
    }

    private static String b(Context context, String str) {
        String str2 = "kr-script/cache/" + n(str) + ".sh";
        if (new File(str2).exists()) {
            return str2;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("#!/system/bin/sh\n\n");
        sb.append(str);
        return d.f450b.h(sb.toString().replaceAll("\r\n", "\n").replaceAll("\r\t", "\t").replaceAll("\r", "\n").getBytes(), str2, context) ? d.f450b.b(context, str2) : "";
    }

    public static String c(Context context, String str, NodeInfoBase nodeInfoBase) {
        if (!f410a) {
            k(context);
        }
        if (str == null || str.isEmpty()) {
            return "";
        }
        String strTrim = str.trim();
        String strF = strTrim.startsWith("file:///android_asset/") ? f(context, strTrim) : b(context, str);
        if (!f410a) {
            k(context);
        }
        StringBuilder sb = new StringBuilder();
        sb.append("\n");
        if (nodeInfoBase == null || nodeInfoBase.getCurrentPageConfigPath().isEmpty()) {
            sb.append("export PAGE_CONFIG_DIR=''\n");
            sb.append("export PAGE_CONFIG_FILE=''\n");
            sb.append("export PAGE_WORK_DIR=''\n");
            sb.append("export PAGE_WORK_DIR=''\n");
        } else {
            String pageConfigDir = nodeInfoBase.getPageConfigDir();
            String currentPageConfigPath = nodeInfoBase.getCurrentPageConfigPath();
            sb.append("export PAGE_CONFIG_DIR='");
            sb.append(pageConfigDir);
            sb.append("'\n");
            sb.append("export PAGE_CONFIG_FILE='");
            sb.append(currentPageConfigPath);
            sb.append("'\n");
            boolean zStartsWith = currentPageConfigPath.startsWith("file:///android_asset/");
            sb.append("export PAGE_WORK_DIR='");
            if (zStartsWith) {
                sb.append(new com.omarea.c.n.a(context).j(pageConfigDir, pageConfigDir));
                sb.append("'\n");
                sb.append("export PAGE_WORK_FILE='");
                sb.append(new com.omarea.c.n.a(context).j(currentPageConfigPath, currentPageConfigPath));
            } else {
                sb.append(pageConfigDir);
                sb.append("'\n");
                sb.append("export PAGE_WORK_FILE='");
                sb.append(currentPageConfigPath);
            }
            sb.append("'\n");
        }
        sb.append("\n\n");
        sb.append(f411b + " \"" + strF + "\"");
        return f413d.c(sb.toString());
    }

    public static void d(Context context, DataOutputStream dataOutputStream, String str, HashMap<String, String> map, NodeInfoBase nodeInfoBase, String str2) {
        String currentPageConfigPath;
        if (map == null) {
            map = new HashMap<>();
        }
        if (nodeInfoBase != null) {
            String pageConfigDir = nodeInfoBase.getPageConfigDir();
            currentPageConfigPath = nodeInfoBase.getCurrentPageConfigPath();
            map.put("PAGE_CONFIG_DIR", pageConfigDir);
            map.put("PAGE_CONFIG_FILE", currentPageConfigPath);
            if (currentPageConfigPath.startsWith("file:///android_asset/")) {
                map.put("PAGE_WORK_DIR", new com.omarea.c.n.a(context).j(pageConfigDir, pageConfigDir));
                currentPageConfigPath = new com.omarea.c.n.a(context).j(currentPageConfigPath, currentPageConfigPath);
            } else {
                map.put("PAGE_WORK_DIR", pageConfigDir);
            }
        } else {
            currentPageConfigPath = "";
            map.put("PAGE_CONFIG_DIR", "");
            map.put("PAGE_CONFIG_FILE", "");
            map.put("PAGE_WORK_DIR", "");
        }
        map.put("PAGE_WORK_FILE", currentPageConfigPath);
        ArrayList<String> arrayListJ = j(map);
        StringBuilder sb = new StringBuilder();
        if (arrayListJ.size() > 0) {
            for (String str3 : arrayListJ) {
                sb.append("export ");
                sb.append(str3);
                sb.append("\n");
            }
        }
        try {
            dataOutputStream.write(sb.toString().getBytes("UTF-8"));
            dataOutputStream.write(h(context, str, str2).getBytes("UTF-8"));
            dataOutputStream.writeBytes("\n\n");
            dataOutputStream.writeBytes("sleep 0.2;\n");
            dataOutputStream.writeBytes("exit\n");
            dataOutputStream.writeBytes("exit\n");
            dataOutputStream.flush();
        } catch (Exception unused) {
        }
    }

    public static boolean e(Context context, com.omarea.common.net.b bVar, String str, HashMap<String, String> map, NodeInfoBase nodeInfoBase, String str2) {
        boolean z;
        String str3;
        if (map == null) {
            map = new HashMap<>();
        }
        if (nodeInfoBase != null) {
            String pageConfigDir = nodeInfoBase.getPageConfigDir();
            String currentPageConfigPath = nodeInfoBase.getCurrentPageConfigPath();
            map.put("PAGE_CONFIG_DIR", pageConfigDir);
            map.put("PAGE_CONFIG_FILE", currentPageConfigPath);
            if (currentPageConfigPath.startsWith("file:///android_asset/")) {
                map.put("PAGE_WORK_DIR", new com.omarea.c.n.a(context).j(pageConfigDir, pageConfigDir));
                str3 = "PAGE_WORK_FILE";
                currentPageConfigPath = new com.omarea.c.n.a(context).j(currentPageConfigPath, currentPageConfigPath);
            } else {
                map.put("PAGE_WORK_DIR", pageConfigDir);
                str3 = "PAGE_WORK_FILE";
            }
            map.put(str3, currentPageConfigPath);
        } else {
            map.put("PAGE_CONFIG_DIR", "");
            map.put("PAGE_CONFIG_FILE", "");
            map.put("PAGE_WORK_DIR", "");
            map.put("PAGE_WORK_FILE", "");
        }
        ArrayList<String> arrayListJ = j(map);
        StringBuilder sb = new StringBuilder();
        if (arrayListJ.size() > 0) {
            for (String str4 : arrayListJ) {
                sb.append("export ");
                sb.append(str4);
                sb.append("\n");
            }
        }
        StringBuilder sb2 = new StringBuilder();
        sb2.append(sb.toString());
        sb2.append(h(context, str, str2));
        sb2.append("\nexit\nexit\n");
        boolean[] zArr = new boolean[1];
        new Thread(new a(zArr, sb2, bVar)).start();
        synchronized (bVar) {
            try {
                bVar.wait();
            } catch (Exception unused) {
            }
            z = zArr[0];
        }
        return z;
    }

    private static String f(Context context, String str) {
        if (str.startsWith("file:///android_asset/")) {
            str = str.substring(22);
        }
        return d.f450b.i(str, str, context);
    }

    private static HashMap<String, String> g(Context context) {
        StringBuilder sb;
        String strSubstring;
        HashMap<String, String> map = new HashMap<>();
        map.put("TOOLKIT", f412c);
        if (MagiskExtend.e()) {
            if (MagiskExtend.f446c.endsWith("/")) {
                String str = MagiskExtend.f446c;
                strSubstring = str.substring(0, str.length() - 1);
            } else {
                strSubstring = MagiskExtend.f446c;
            }
            map.put("MAGISK_PATH", strSubstring);
        } else {
            map.put("MAGISK_PATH", "");
        }
        map.put("START_DIR", i(context));
        map.put("TEMP_DIR", context.getCacheDir().getAbsolutePath());
        com.omarea.c.b bVar = new com.omarea.c.b(context);
        map.put("ANDROID_UID", "" + bVar.b());
        try {
            map.put("APP_USER_ID", bVar.a());
        } catch (Exception unused) {
        }
        map.put("ANDROID_SDK", "" + Build.VERSION.SDK_INT);
        map.put("ROOT_PERMISSION", a() ? "true" : "false");
        map.put("SDCARD_PATH", Environment.getExternalStorageDirectory().getAbsolutePath());
        String strB = d.f450b.b(context, "busybox");
        if (new File(d.f450b.b(context, "busybox")).exists()) {
            map.put("BUSYBOX", strB);
        } else {
            map.put("BUSYBOX", "busybox");
        }
        try {
            PackageInfo packageInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
            map.put("PACKAGE_NAME", context.getPackageName());
            map.put("PACKAGE_VERSION_NAME", packageInfo.versionName);
            if (Build.VERSION.SDK_INT >= 28) {
                sb = new StringBuilder();
                sb.append("");
                sb.append(packageInfo.getLongVersionCode());
            } else {
                sb = new StringBuilder();
                sb.append("");
                sb.append(packageInfo.versionCode);
            }
            map.put("PACKAGE_VERSION_CODE", sb.toString());
        } catch (Exception unused2) {
        }
        return map;
    }

    private static String h(Context context, String str, String str2) {
        if (!f410a) {
            k(context);
        }
        if (str == null || str.isEmpty()) {
            return "";
        }
        String strTrim = str.trim();
        if (strTrim.startsWith("file:///android_asset/")) {
            String strF = f(context, strTrim);
            if (strF != null) {
                str = strF;
            }
        } else {
            str = b(context, str);
        }
        return f411b + " \"" + str + "\" \"" + str2 + "\"";
    }

    private static String i(Context context) {
        String strA = d.f450b.a(context);
        return strA.endsWith("/") ? strA.substring(0, strA.length() - 1) : strA;
    }

    private static ArrayList<String> j(HashMap<String, String> map) {
        ArrayList<String> arrayList = new ArrayList<>();
        if (map != null) {
            for (String str : map.keySet()) {
                String str2 = map.get(str);
                if (str2 == null) {
                    str2 = "";
                }
                arrayList.add(str + "='" + str2.replaceAll("'", "'\\\\''") + "'");
            }
        }
        return arrayList;
    }

    private static boolean k(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences("kr-script-config", 0);
        return l(context, sharedPreferences.getString("executor", e), sharedPreferences.getString("toolkitDir", f));
    }

    public static boolean l(Context context, String str, String str2) {
        if (f410a) {
            return true;
        }
        if (str2 != null) {
            try {
                if (!str2.isEmpty()) {
                    f412c = new com.omarea.c.n.a(context).f(str2);
                }
            } catch (Exception unused) {
                return false;
            }
        }
        String strSubstring = str.startsWith("file:///android_asset/") ? str.substring(22) : str;
        InputStream inputStreamOpen = context.getAssets().open(strSubstring);
        int iAvailable = inputStreamOpen.available();
        byte[] bArr = new byte[iAvailable];
        inputStreamOpen.read(bArr, 0, iAvailable);
        String strReplaceAll = new String(bArr, Charset.defaultCharset()).replaceAll("\r", "");
        HashMap<String, String> mapG = g(context);
        for (String str3 : mapG.keySet()) {
            String str4 = mapG.get(str3);
            if (str4 == null) {
                str4 = "";
            }
            strReplaceAll = strReplaceAll.replace("$({" + str3 + "})", str4);
        }
        String strB = d.f450b.b(context, strSubstring);
        boolean zH = d.f450b.h(strReplaceAll.replace("$({EXECUTOR_PATH})", strB).getBytes(Charset.defaultCharset()), strSubstring, context);
        f410a = zH;
        if (zH) {
            f411b = strB;
        }
        SharedPreferences.Editor editorEdit = context.getSharedPreferences("kr-script-config", 0).edit();
        if (!str.equals(e)) {
            editorEdit.putString("executor", str);
        }
        if (!str2.equals(f)) {
            editorEdit.putString("toolkitDir", str2);
        }
        editorEdit.apply();
        return f410a;
    }

    public static boolean m() {
        return f410a;
    }

    private static String n(String str) {
        if (str.isEmpty()) {
            return "";
        }
        try {
            byte[] bArrDigest = MessageDigest.getInstance("MD5").digest(str.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b2 : bArrDigest) {
                String hexString = Integer.toHexString(b2 & 255);
                if (hexString.length() == 1) {
                    hexString = "0" + hexString;
                }
                sb.append(hexString);
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e2) {
            e2.printStackTrace();
            return "";
        }
    }
}
