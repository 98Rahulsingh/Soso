package com.omarea.c.n;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;
import com.omarea.common.shared.d;
import java.util.HashMap;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class a {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private static final HashMap<String, String> f406d = new HashMap<>();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final Context f407a;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private boolean f409c = true;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final boolean f408b = false;

    /* JADX INFO: renamed from: com.omarea.c.n.a$a, reason: collision with other inner class name */
    class RunnableC0043a implements Runnable {
        final /* synthetic */ String f;

        RunnableC0043a(String str) {
            this.f = str;
        }

        @Override // java.lang.Runnable
        public void run() {
            Toast.makeText(a.this.f407a, "ExtractFail " + this.f, 1).show();
        }
    }

    public a(Context context) {
        this.f407a = context;
    }

    private String b(String str) {
        return str.startsWith("file:///android_asset/") ? str.substring(22) : str;
    }

    private void c(String str) {
        new Handler(Looper.getMainLooper()).post(new RunnableC0043a(str));
    }

    private String e(String str, String str2) {
        if (str == null || str.isEmpty()) {
            return null;
        }
        if (this.f409c && f406d.containsKey(str)) {
            return f406d.get(str);
        }
        if (str.endsWith(".sh")) {
            return h(str, str2);
        }
        if (str.startsWith("file:///android_asset/")) {
            str = str.substring(22);
        }
        String strG = d.f450b.g(this.f407a.getAssets(), str, i(str, str2), this.f407a);
        if (strG == null) {
            c(str);
        } else if (!f406d.containsKey(str)) {
            f406d.put(str, strG);
        }
        return strG;
    }

    private String g(String str, String str2) {
        if (str == null || str.isEmpty()) {
            return null;
        }
        if (this.f409c && f406d.containsKey(str)) {
            return f406d.get(str);
        }
        if (str.startsWith("file:///android_asset/")) {
            str = str.substring(22);
        } else if (str.endsWith("/")) {
            str = str.substring(0, str.length() - 1);
        }
        try {
            String[] list = this.f407a.getAssets().list(str);
            if (list == null || list.length <= 0) {
                return d(str);
            }
            for (String str3 : list) {
                g(str + "/" + str3, str2);
            }
            String strJ = j(str, str2);
            if (!f406d.containsKey(str)) {
                f406d.put(str, strJ);
            }
            return strJ;
        } catch (Exception e) {
            c(str + "\n" + e.getMessage());
            return "";
        }
    }

    private String h(String str, String str2) {
        if (str == null || str.isEmpty()) {
            return null;
        }
        if (this.f409c && f406d.containsKey(str)) {
            return f406d.get(str);
        }
        if (str.startsWith("file:///android_asset/")) {
            str = str.substring(22);
        }
        String strI = d.f450b.i(str, i(str, str2), this.f407a);
        if (strI != null && !f406d.containsKey(str)) {
            f406d.put(str, strI);
        }
        return strI;
    }

    private String i(String str, String str2) {
        if (str.startsWith("file:///android_asset/")) {
            str = str.substring(22);
        }
        return (this.f408b && str.contains(str2)) ? str.substring(str2.length()) : str;
    }

    public String d(String str) {
        String strB = b(str);
        return strB.contains("/") ? e(strB, strB.substring(0, strB.lastIndexOf("/") + 1)) : e(strB, strB);
    }

    public String f(String str) {
        return g(str, str);
    }

    public String j(String str, String str2) {
        return d.f450b.b(this.f407a, i(str, str2));
    }
}
