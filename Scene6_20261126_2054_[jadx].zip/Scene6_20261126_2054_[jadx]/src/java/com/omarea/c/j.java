package com.omarea.c;

import android.content.Context;
import android.content.Intent;
import android.widget.Toast;
import java.util.List;
import kotlin.collections.q;
import kotlin.jvm.internal.r;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class j {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final Context f379a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final String f380b;

    public j(Context context, String str) {
        r.d(context, "context");
        r.d(str, "activity");
        this.f379a = context;
        this.f380b = str;
    }

    private final Intent a() {
        Intent intent;
        try {
            if (kotlin.text.k.y(this.f380b, "/", false, 2, (Object) null)) {
                intent = new Intent("android.intent.action.VIEW");
                List listW = kotlin.text.k.W(this.f380b, new String[]{"/"}, false, 0, 6, (Object) null);
                String str = (String) q.t(listW);
                String str2 = (String) q.B(listW);
                if (kotlin.text.k.t(str2, ".", false, 2, (Object) null)) {
                    str2 = str + str2;
                }
                intent.setClassName(str, str2);
            } else {
                intent = new Intent(this.f380b);
            }
            intent.addFlags(268435456);
            return intent;
        } catch (Exception unused) {
            return null;
        }
    }

    public final boolean b() {
        com.omarea.common.shell.e eVar;
        StringBuilder sb;
        String str;
        if (kotlin.text.k.t(this.f380b, "am ", false, 2, (Object) null)) {
            return kotlin.text.k.y(com.omarea.common.shell.e.f469b.c(this.f380b), "Start", false, 2, (Object) null);
        }
        try {
            this.f379a.startActivity(a());
            return true;
        } catch (SecurityException unused) {
            if (kotlin.text.k.y(this.f380b, "/", false, 2, (Object) null)) {
                eVar = com.omarea.common.shell.e.f469b;
                sb = new StringBuilder();
                str = "am start-activity -W -n ";
            } else {
                eVar = com.omarea.common.shell.e.f469b;
                sb = new StringBuilder();
                str = "am start-activity -W -a ";
            }
            sb.append(str);
            sb.append(this.f380b);
            if (kotlin.text.k.y(eVar.e(sb.toString()), "ok", false, 2, (Object) null)) {
                return true;
            }
            Context context = this.f379a;
            Toast.makeText(context, context.getString(h.kr_slice_activity_fail), 0).show();
            return false;
        } catch (Exception unused2) {
            Context context2 = this.f379a;
            Toast.makeText(context2, context2.getString(h.kr_slice_activity_fail), 0).show();
            return false;
        }
    }
}
