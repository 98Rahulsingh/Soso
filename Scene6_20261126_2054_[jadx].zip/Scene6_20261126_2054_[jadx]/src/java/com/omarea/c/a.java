package com.omarea.c;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Bundle;
import android.text.SpannableString;
import android.widget.RemoteViews;
import com.omarea.krscript.model.RunnableNode;
import com.omarea.krscript.model.ShellHandlerBase;
import java.util.ArrayList;
import java.util.HashMap;
import kotlin.collections.q;
import kotlin.jvm.b.l;
import kotlin.jvm.internal.o;
import kotlin.jvm.internal.r;
import kotlin.s;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class a extends Thread {
    private static boolean f = false;
    private static final String g = "kr_script_task_notification";
    private static int h = 34050;
    public static final C0032a i = new C0032a(null);

    /* JADX INFO: renamed from: com.omarea.c.a$a, reason: collision with other inner class name */
    public static final class C0032a {

        /* JADX INFO: renamed from: com.omarea.c.a$a$a, reason: collision with other inner class name */
        static final class RunnableC0033a implements Runnable {
            final /* synthetic */ Runnable f;
            final /* synthetic */ Runnable g;

            RunnableC0033a(Runnable runnable, Runnable runnable2) {
                this.f = runnable;
                this.g = runnable2;
            }

            @Override // java.lang.Runnable
            public final void run() {
                try {
                    this.f.run();
                    this.g.run();
                } catch (Exception unused) {
                }
            }
        }

        private C0032a() {
        }

        public /* synthetic */ C0032a(o oVar) {
            this();
        }

        public final void a(Context context, String str, HashMap<String, String> map, RunnableNode runnableNode, Runnable runnable, Runnable runnable2) {
            r.d(context, "context");
            r.d(str, "script");
            r.d(runnableNode, "nodeInfo");
            r.d(runnable, "onExit");
            r.d(runnable2, "onDismiss");
            Context applicationContext = context.getApplicationContext();
            a.h++;
            r.c(applicationContext, "applicationContext");
            new com.omarea.c.n.c().a(context, runnableNode, str, new RunnableC0033a(runnable, runnable2), map, new b(applicationContext, runnableNode, a.h));
            Bundle bundle = new Bundle();
            if (map != null) {
                bundle.putSerializable("params", map);
            }
            com.omarea.common.ui.e.a aVar = com.omarea.common.ui.e.f492b;
            String string = context.getString(h.kr_bg_task_start);
            r.c(string, "context.getString(R.string.kr_bg_task_start)");
            String string2 = context.getString(h.kr_bg_task_start_desc);
            r.c(string2, "context.getString(R.string.kr_bg_task_start_desc)");
            com.omarea.common.ui.e.a.A(aVar, context, string, string2, null, 8, null);
        }
    }

    public static final class b extends ShellHandlerBase {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private NotificationManager f371a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private final String f372b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private ArrayList<String> f373c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        private String f374d;
        private int e;
        private int f;
        private boolean g;
        private Runnable h;
        private boolean i;
        private String j;
        private final PendingIntent k;
        private final C0034a l;
        private final Context m;
        private final RunnableNode n;
        private final int o;

        /* JADX INFO: renamed from: com.omarea.c.a$b$a, reason: collision with other inner class name */
        public static final class C0034a extends BroadcastReceiver {
            C0034a() {
            }

            @Override // android.content.BroadcastReceiver
            public void onReceive(Context context, Intent intent) {
                Runnable runnable;
                if (intent == null || !intent.hasExtra("id") || intent.getIntExtra("id", 0) != b.this.o || (runnable = b.this.h) == null) {
                    return;
                }
                runnable.run();
            }
        }

        public b(Context context, RunnableNode runnableNode, int i) {
            r.d(context, "context");
            r.d(runnableNode, "runnableNode");
            this.m = context;
            this.n = runnableNode;
            this.o = i;
            Object systemService = context.getSystemService("notification");
            if (systemService == null) {
                throw new NullPointerException("null cannot be cast to non-null type android.app.NotificationManager");
            }
            this.f371a = (NotificationManager) systemService;
            this.f372b = this.n.getTitle();
            this.f373c = new ArrayList<>();
            this.f374d = "";
            this.j = this.m.getPackageName() + ".TaskStop.N" + this.o;
            Context context2 = this.m;
            Intent intent = new Intent(this.j);
            intent.putExtra("id", this.o);
            s sVar = s.a;
            this.k = PendingIntent.getBroadcast(context2, 0, intent, 134217728);
            this.l = new C0034a();
        }

        private final void c() {
            int i = 8;
            if (this.f373c.size() > 8) {
                synchronized (this.f373c) {
                    this.f373c.remove(q.t(this.f373c));
                    this.g = true;
                    s sVar = s.a;
                }
            }
            RemoteViews remoteViews = new RemoteViews(this.m.getPackageName(), g.kr_task_notification);
            remoteViews.setTextViewText(f.kr_task_title, this.f372b + "(" + this.o + ")");
            int i2 = f.kr_task_log;
            String strA = q.A(this.f373c, "", this.g ? "……\n" : "", (CharSequence) null, 0, (CharSequence) null, (l) null, 60, (Object) null);
            if (strA == null) {
                throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
            }
            remoteViews.setTextViewText(i2, kotlin.text.k.k0(strA).toString());
            int i3 = f.kr_task_progress;
            int i4 = this.f;
            remoteViews.setProgressBar(i3, i4, this.e, i4 < 0);
            remoteViews.setViewVisibility(f.kr_task_progress, this.f == this.e ? 8 : 0);
            int i5 = f.kr_task_stop;
            if ((this.h != null || this.n.getInterruptable()) && !this.i) {
                i = 0;
            }
            remoteViews.setViewVisibility(i5, i);
            if (this.n.getInterruptable() && this.h != null && !this.i) {
                remoteViews.setOnClickPendingIntent(f.kr_task_stop, this.k);
            }
            Notification.Builder contentTitle = new Notification.Builder(this.m).setContentTitle("" + this.f372b + "(" + this.o + ")");
            StringBuilder sb = new StringBuilder();
            sb.append("");
            sb.append(this.f374d);
            sb.append(" >> ");
            sb.append((String) q.C(this.f373c));
            Notification.Builder when = contentTitle.setContentText(sb.toString()).setSmallIcon(e.kr_run).setAutoCancel(true).setWhen(System.currentTimeMillis());
            int i6 = this.f;
            int i7 = this.e;
            if (i6 != i7) {
                when.setProgress(i6, i7, i6 < 0);
            }
            if (Build.VERSION.SDK_INT >= 24) {
                when.setCustomBigContentView(remoteViews);
            }
            if (Build.VERSION.SDK_INT >= 26) {
                if (!a.f) {
                    NotificationChannel notificationChannel = new NotificationChannel(a.g, this.m.getString(h.kr_script_task_notification), 3);
                    notificationChannel.enableLights(false);
                    notificationChannel.enableVibration(false);
                    notificationChannel.setSound(null, null);
                    this.f371a.createNotificationChannel(notificationChannel);
                }
                a.f = true;
                when.setChannelId(a.g);
            } else {
                when.setSound(null);
                when.setVibrate(null);
            }
            Notification notificationBuild = when.build();
            if (Build.VERSION.SDK_INT < 24) {
                notificationBuild.bigContentView = remoteViews;
            }
            if (!this.i) {
                r.b(notificationBuild);
                notificationBuild.flags = 34;
            }
            this.f371a.notify(this.o, notificationBuild);
        }

        @Override // com.omarea.krscript.model.ShellHandlerBase
        protected void onError(Object obj) {
            String string = this.m.getString(h.kr_script_task_has_error);
            r.c(string, "context.getString(R.stri…kr_script_task_has_error)");
            this.f374d = string;
            synchronized (this.f373c) {
                ArrayList<String> arrayList = this.f373c;
                com.omarea.common.shared.g gVar = new com.omarea.common.shared.g(this.m);
                StringBuilder sb = new StringBuilder();
                sb.append("");
                sb.append(obj != null ? obj.toString() : null);
                arrayList.add(gVar.a(sb.toString()));
                c();
                s sVar = s.a;
            }
        }

        @Override // com.omarea.krscript.model.ShellHandlerBase
        protected void onExit(Object obj) {
            this.i = true;
            String string = this.m.getString(h.kr_script_task_finished);
            r.c(string, "context.getString(R.stri….kr_script_task_finished)");
            this.f374d = string;
            synchronized (this.f373c) {
                if (r.a(obj, 0)) {
                    this.f373c.add("\n" + this.m.getString(h.kr_shell_completed));
                } else {
                    ArrayList<String> arrayList = this.f373c;
                    StringBuilder sb = new StringBuilder();
                    sb.append("\n");
                    sb.append(this.m.getString(h.kr_shell_finish_error));
                    sb.append(" ");
                    sb.append(obj != null ? obj.toString() : null);
                    arrayList.add(sb.toString());
                }
                c();
                s sVar = s.a;
            }
        }

        @Override // com.omarea.krscript.model.ShellHandlerBase
        protected void onProgress(int i, int i2) {
            this.e = i;
            this.f = i2;
            c();
        }

        @Override // com.omarea.krscript.model.ShellHandlerBase
        protected void onReader(Object obj) {
            synchronized (this.f373c) {
                ArrayList<String> arrayList = this.f373c;
                StringBuilder sb = new StringBuilder();
                sb.append("");
                sb.append(obj != null ? obj.toString() : null);
                arrayList.add(sb.toString());
                c();
                s sVar = s.a;
            }
        }

        @Override // com.omarea.krscript.model.ShellHandlerBase
        protected void onStart(Object obj) {
            String string = this.m.getString(h.kr_script_task_running);
            r.c(string, "context.getString(R.string.kr_script_task_running)");
            this.f374d = string;
        }

        @Override // com.omarea.krscript.model.ShellHandlerBase
        public void onStart(Runnable runnable) {
            this.h = runnable;
            this.m.registerReceiver(this.l, new IntentFilter(this.j));
            c();
        }

        @Override // com.omarea.krscript.model.ShellHandlerBase
        protected void onWrite(Object obj) {
        }

        @Override // com.omarea.krscript.model.ShellHandlerBase
        protected void updateLog(SpannableString spannableString) {
        }
    }
}
