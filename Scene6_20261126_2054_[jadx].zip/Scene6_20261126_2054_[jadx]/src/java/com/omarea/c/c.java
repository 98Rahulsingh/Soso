package com.omarea.c;

import android.content.Context;
import android.os.Bundle;
import android.text.SpannableString;
import android.widget.Toast;
import com.omarea.krscript.model.RunnableNode;
import com.omarea.krscript.model.ShellHandlerBase;
import java.util.ArrayList;
import java.util.HashMap;
import kotlin.jvm.internal.o;
import kotlin.jvm.internal.r;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class c extends Thread {
    private static int f = 34050;
    public static final a g = new a(null);

    public static final class a {

        /* JADX INFO: renamed from: com.omarea.c.c$a$a, reason: collision with other inner class name */
        static final class RunnableC0035a implements Runnable {
            final /* synthetic */ Runnable f;
            final /* synthetic */ Runnable g;

            RunnableC0035a(Runnable runnable, Runnable runnable2) {
                this.f = runnable;
                this.g = runnable2;
            }

            @Override // java.lang.Runnable
            public final void run() {
                try {
                    this.f.run();
                    this.g.run();
                } catch (Exception unused) {
                }
            }
        }

        private a() {
        }

        public /* synthetic */ a(o oVar) {
            this();
        }

        public final void a(Context context, String str, HashMap<String, String> map, RunnableNode runnableNode, Runnable runnable, Runnable runnable2) {
            r.d(context, "context");
            r.d(str, "script");
            r.d(runnableNode, "nodeInfo");
            r.d(runnable, "onExit");
            r.d(runnable2, "onDismiss");
            Context applicationContext = context.getApplicationContext();
            c.f++;
            r.c(applicationContext, "applicationContext");
            new com.omarea.c.n.c().a(context, runnableNode, str, new RunnableC0035a(runnable, runnable2), map, new b(applicationContext));
            Bundle bundle = new Bundle();
            if (map != null) {
                bundle.putSerializable("params", map);
            }
        }
    }

    public static final class b extends ShellHandlerBase {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private ArrayList<String> f377a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private final Context f378b;

        public b(Context context) {
            r.d(context, "context");
            this.f378b = context;
            this.f377a = new ArrayList<>();
        }

        @Override // com.omarea.krscript.model.ShellHandlerBase
        protected void onError(Object obj) {
            r.c(this.f378b.getString(h.kr_script_task_has_error), "context.getString(R.stri…kr_script_task_has_error)");
            synchronized (this.f377a) {
                ArrayList<String> arrayList = this.f377a;
                StringBuilder sb = new StringBuilder();
                sb.append("");
                sb.append(obj != null ? obj.toString() : null);
                arrayList.add(sb.toString());
            }
        }

        @Override // com.omarea.krscript.model.ShellHandlerBase
        protected void onExit(Object obj) {
            if (this.f377a.size() > 0) {
                Toast.makeText(this.f378b, this.f378b.getString(h.kr_script_task_has_error) + "\n\n" + new com.omarea.common.shared.g(this.f378b).b(this.f377a), 1).show();
            }
        }

        @Override // com.omarea.krscript.model.ShellHandlerBase
        protected void onProgress(int i, int i2) {
        }

        @Override // com.omarea.krscript.model.ShellHandlerBase
        protected void onReader(Object obj) {
        }

        @Override // com.omarea.krscript.model.ShellHandlerBase
        protected void onStart(Object obj) {
        }

        @Override // com.omarea.krscript.model.ShellHandlerBase
        public void onStart(Runnable runnable) {
        }

        @Override // com.omarea.krscript.model.ShellHandlerBase
        protected void onWrite(Object obj) {
        }

        @Override // com.omarea.krscript.model.ShellHandlerBase
        protected void updateLog(SpannableString spannableString) {
        }
    }
}
