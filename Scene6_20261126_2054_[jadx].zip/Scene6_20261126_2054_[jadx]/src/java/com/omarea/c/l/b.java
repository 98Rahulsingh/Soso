package com.omarea.c.l;

import android.content.Context;
import android.graphics.Color;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.text.Layout;
import android.util.Log;
import android.util.Xml;
import android.widget.Toast;
import com.omarea.common.shared.g;
import com.omarea.krscript.model.ActionNode;
import com.omarea.krscript.model.ActionParamInfo;
import com.omarea.krscript.model.ClickableNode;
import com.omarea.krscript.model.GroupNode;
import com.omarea.krscript.model.NodeInfoBase;
import com.omarea.krscript.model.PageMenuOption;
import com.omarea.krscript.model.PageNode;
import com.omarea.krscript.model.PickerNode;
import com.omarea.krscript.model.RunnableNode;
import com.omarea.krscript.model.SwitchNode;
import com.omarea.krscript.model.TextNode;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.Locale;
import kotlin.collections.q;
import kotlin.jvm.internal.r;
import kotlin.text.k;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private Context f391a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private String f392b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private g f393c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private String f394d;
    private InputStream e;
    private String f;
    private ArrayList<ActionParamInfo> g;
    private ActionParamInfo h;
    private NodeInfoBase i;

    static final class a implements Runnable {
        final /* synthetic */ Exception g;

        a(Exception exc) {
            this.g = exc;
        }

        @Override // java.lang.Runnable
        public final void run() {
            Toast.makeText(b.this.f391a, "Page configuration parsing error!\n" + this.g.getMessage(), 1).show();
        }
    }

    /* JADX INFO: renamed from: com.omarea.c.l.b$b, reason: collision with other inner class name */
    static final class RunnableC0042b implements Runnable {
        final /* synthetic */ Exception g;

        RunnableC0042b(Exception exc) {
            this.g = exc;
        }

        @Override // java.lang.Runnable
        public final void run() {
            Toast.makeText(b.this.f391a, "解析配置文件失败\n" + this.g.getMessage(), 1).show();
        }
    }

    public b(Context context, InputStream inputStream) {
        r.d(context, "context");
        r.d(inputStream, "pageConfigStream");
        this.f392b = "";
        this.f394d = "";
        this.f = "";
        this.f391a = context;
        this.e = inputStream;
        this.f393c = new g(context);
    }

    public b(Context context, String str, String str2) {
        r.d(context, "context");
        r.d(str, "pageConfig");
        this.f392b = "";
        this.f394d = "";
        this.f = "";
        this.f391a = context;
        this.f392b = str;
        this.f = str2 == null ? "" : str2;
        this.f393c = new g(context);
    }

    /* JADX WARN: Code duplicated, block: B:107:0x0069 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:108:0x008a A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:109:0x00b4 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:110:0x0112 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:111:0x012e A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:23:0x0056 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:24:0x0058  */
    /* JADX WARN: Code duplicated, block: B:29:0x0077 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:30:0x0079  */
    /* JADX WARN: Code duplicated, block: B:38:0x00a1 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:39:0x00a3  */
    /* JADX WARN: Code duplicated, block: B:56:0x00e4  */
    /* JADX WARN: Code duplicated, block: B:58:0x00ea  */
    /* JADX WARN: Code duplicated, block: B:67:0x0104 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:68:0x0106  */
    /* JADX WARN: Code duplicated, block: B:73:0x0120 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:74:0x0122  */
    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    private final ClickableNode b(ClickableNode clickableNode, XmlPullParser xmlPullParser) {
        ClickableNode clickableNode2 = (ClickableNode) f(clickableNode, xmlPullParser);
        if (clickableNode2 == null) {
            return null;
        }
        int attributeCount = xmlPullParser.getAttributeCount();
        int i = 0;
        while (true) {
            boolean z = true;
            if (i >= attributeCount) {
                if (!(clickableNode2.getKey().length() > 0) || !k.t(clickableNode2.getKey(), "@", false, 2, (Object) null) || clickableNode2.getAllowShortcut() != null) {
                    return clickableNode2;
                }
                clickableNode2.setAllowShortcut(Boolean.FALSE);
                return clickableNode2;
            }
            g gVar = this.f393c;
            if (gVar == null) {
                r.q("resourceStringResolver");
                throw null;
            }
            String attributeValue = xmlPullParser.getAttributeValue(i);
            r.c(attributeValue, "parser.getAttributeValue(i)");
            String strA = gVar.a(attributeValue);
            String attributeName = xmlPullParser.getAttributeName(i);
            if (attributeName != null) {
                switch (attributeName.hashCode()) {
                    case -1943249334:
                        if (attributeName.equals("allow-shortcut")) {
                            if (!r.a(strA, "allow") && !r.a(strA, "allow-shortcut") && !r.a(strA, "true") && !r.a(strA, "1")) {
                                z = false;
                            }
                            clickableNode2.setAllowShortcut(Boolean.valueOf(z));
                        }
                        break;
                    case -1606708473:
                        if (!attributeName.equals("logo-path")) {
                            continue;
                        } else {
                            if (strA != null) {
                                throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
                            }
                            clickableNode2.setLogoPath(k.k0(strA).toString());
                        }
                        break;
                    case -1436734215:
                        if (!attributeName.equals("icon-path")) {
                            continue;
                        } else {
                            if (strA != null) {
                                throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
                            }
                            clickableNode2.setIconPath(k.k0(strA).toString());
                        }
                        break;
                    case -1097452790:
                        if (attributeName.equals("locked")) {
                            if (!r.a(strA, "1") && !r.a(strA, "true") && !r.a(strA, "locked")) {
                                z = false;
                            }
                            clickableNode2.setLocked(z);
                        }
                        break;
                    case -196357777:
                        if (attributeName.equals("lock-state")) {
                            if (!r.a(strA, "1")) {
                                z = false;
                            }
                            clickableNode2.setLocked(z);
                        }
                        break;
                    case 3226745:
                        if (!attributeName.equals("icon")) {
                            continue;
                        } else {
                            if (strA != null) {
                                throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
                            }
                            clickableNode2.setIconPath(k.k0(strA).toString());
                        }
                        break;
                    case 3327275:
                        if (attributeName.equals("lock")) {
                            if (!r.a(strA, "1")) {
                                z = false;
                            }
                            clickableNode2.setLocked(z);
                        }
                        break;
                    case 3327403:
                        if (!attributeName.equals("logo")) {
                            continue;
                        } else {
                            if (strA != null) {
                                throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
                            }
                            clickableNode2.setLogoPath(k.k0(strA).toString());
                        }
                        break;
                    case 485454334:
                        if (!attributeName.equals("target-sdk")) {
                            continue;
                        } else {
                            if (strA != null) {
                                throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
                            }
                            clickableNode2.setTargetSdkVersion(Integer.parseInt(k.k0(strA).toString()));
                        }
                        break;
                    case 718129796:
                        if (!attributeName.equals("sdk-target")) {
                            continue;
                        } else {
                            if (strA != null) {
                                throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
                            }
                            clickableNode2.setTargetSdkVersion(Integer.parseInt(k.k0(strA).toString()));
                        }
                        break;
                    case 842957905:
                        if (!attributeName.equals("max-sdk")) {
                            continue;
                        } else {
                            if (strA != null) {
                                throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
                            }
                            clickableNode2.setMaxSdkVersion(Integer.parseInt(k.k0(strA).toString()));
                        }
                        break;
                    case 1062755903:
                        if (!attributeName.equals("min-sdk")) {
                            continue;
                        } else {
                            if (strA != null) {
                                throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
                            }
                            clickableNode2.setMinSdkVersion(Integer.parseInt(k.k0(strA).toString()));
                        }
                        break;
                    case 1946888529:
                        if (!attributeName.equals("sdk-max")) {
                            continue;
                        } else {
                            if (strA != null) {
                                throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
                            }
                            clickableNode2.setMaxSdkVersion(Integer.parseInt(k.k0(strA).toString()));
                        }
                        break;
                    case 1946888767:
                        if (!attributeName.equals("sdk-min")) {
                            continue;
                        } else {
                            if (strA != null) {
                                throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
                            }
                            clickableNode2.setMinSdkVersion(Integer.parseInt(k.k0(strA).toString()));
                        }
                        break;
                    default:
                        continue;
                }
            }
            i++;
        }
    }

    private final void c(NodeInfoBase nodeInfoBase, XmlPullParser xmlPullParser) throws XmlPullParserException, IOException {
        int attributeCount = xmlPullParser.getAttributeCount();
        for (int i = 0; i < attributeCount; i++) {
            String attributeName = xmlPullParser.getAttributeName(i);
            g gVar = this.f393c;
            if (gVar == null) {
                r.q("resourceStringResolver");
                throw null;
            }
            String attributeValue = xmlPullParser.getAttributeValue(i);
            r.c(attributeValue, "parser.getAttributeValue(i)");
            String strA = gVar.a(attributeValue);
            if (r.a(attributeName, "su") || r.a(attributeName, "sh") || r.a(attributeName, "desc-sh")) {
                nodeInfoBase.setDescSh(strA);
                nodeInfoBase.setDesc(d(this.f391a, nodeInfoBase.getDescSh()));
            }
        }
        if (nodeInfoBase.getDesc().length() == 0) {
            String strNextText = xmlPullParser.nextText();
            r.c(strNextText, "parser.nextText()");
            nodeInfoBase.setDesc(strNextText);
        }
    }

    private final String d(Context context, String str) {
        if (this.i == null) {
            this.i = new NodeInfoBase(this.f394d);
        }
        String strC = com.omarea.c.n.b.c(context, str, this.i);
        r.c(strC, "ScriptEnvironmen.execute…scriptIn, vitualRootNode)");
        return strC;
    }

    /* JADX WARN: Code duplicated, block: B:32:0x0077 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:33:0x0079  */
    /* JADX WARN: Code duplicated, block: B:38:0x0095  */
    /* JADX WARN: Code duplicated, block: B:46:0x0085 A[SYNTHETIC] */
    private final GroupNode e(XmlPullParser xmlPullParser) {
        boolean zG;
        GroupNode groupNode = new GroupNode(this.f394d);
        int attributeCount = xmlPullParser.getAttributeCount();
        for (int i = 0; i < attributeCount; i++) {
            String attributeName = xmlPullParser.getAttributeName(i);
            g gVar = this.f393c;
            if (gVar == null) {
                r.q("resourceStringResolver");
                throw null;
            }
            String attributeValue = xmlPullParser.getAttributeValue(i);
            r.c(attributeValue, "parser.getAttributeValue(i)");
            String strA = gVar.a(attributeValue);
            if (attributeName != null) {
                switch (attributeName) {
                    case "support":
                        zG = r.a(d(this.f391a, strA), "1");
                        groupNode.setSupported(zG);
                        break;
                    case "id":
                    case "key":
                        if (strA == null) {
                            throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
                        }
                    case "exist":
                        zG = com.omarea.common.shell.g.f472a.g(strA);
                        groupNode.setSupported(zG);
                        break;
                    case "index":
                        if (strA == null) {
                            throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
                        }
                    case "title":
                        groupNode.setTitle(strA);
                        break;
                    case "visible":
                    case "visible-sh":
                        zG = r.a(d(this.f391a, strA), "1");
                        groupNode.setSupported(zG);
                        break;
                    default:
                        continue;
                        break;
                }
            }
        }
        return groupNode;
    }

    /* JADX WARN: Code duplicated, block: B:40:0x0098 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:41:0x009a  */
    /* JADX WARN: Code duplicated, block: B:49:0x00cc  */
    /* JADX WARN: Code duplicated, block: B:62:0x00a6 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:63:0x00dc A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:80:0x00e8 A[SYNTHETIC] */
    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    private final NodeInfoBase f(NodeInfoBase nodeInfoBase, XmlPullParser xmlPullParser) {
        int attributeCount = xmlPullParser.getAttributeCount();
        for (int i = 0; i < attributeCount; i++) {
            g gVar = this.f393c;
            if (gVar == null) {
                r.q("resourceStringResolver");
                throw null;
            }
            String attributeValue = xmlPullParser.getAttributeValue(i);
            r.c(attributeValue, "parser.getAttributeValue(i)");
            String strA = gVar.a(attributeValue);
            String attributeName = xmlPullParser.getAttributeName(i);
            if (attributeName != null) {
                switch (attributeName.hashCode()) {
                    case -1857640538:
                        if (attributeName.equals("summary")) {
                            nodeInfoBase.setSummary(strA);
                        }
                        break;
                    case -1854767153:
                        if (!attributeName.equals("support")) {
                            continue;
                        } else {
                            if (!r.a(d(this.f391a, strA), "1")) {
                                return null;
                            }
                        }
                        break;
                    case -315611684:
                        if (attributeName.equals("summary-sh")) {
                            nodeInfoBase.setSummarySh(strA);
                            strA = d(this.f391a, nodeInfoBase.getSummarySh());
                            nodeInfoBase.setSummary(strA);
                        }
                        break;
                    case 3355:
                        if (attributeName.equals("id")) {
                            if (strA == null) {
                                throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
                            }
                            nodeInfoBase.setKey(k.k0(strA).toString());
                        } else {
                            continue;
                        }
                        break;
                    case 106079:
                        if (attributeName.equals("key")) {
                            if (strA == null) {
                                throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
                            }
                            nodeInfoBase.setKey(k.k0(strA).toString());
                        } else {
                            continue;
                        }
                        break;
                    case 3079825:
                        if (attributeName.equals("desc")) {
                            nodeInfoBase.setDesc(strA);
                        }
                        break;
                    case 96955127:
                        if (attributeName.equals("exist") && !com.omarea.common.shell.g.f472a.g(strA)) {
                            return null;
                        }
                        break;
                        break;
                    case 100346066:
                        if (attributeName.equals("index")) {
                            if (strA == null) {
                                throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
                            }
                            nodeInfoBase.setKey(k.k0(strA).toString());
                        } else {
                            continue;
                        }
                        break;
                    case 110371416:
                        if (attributeName.equals("title")) {
                            nodeInfoBase.setTitle(strA);
                        }
                        break;
                    case 466743410:
                        if (!attributeName.equals("visible")) {
                            continue;
                        } else {
                            if (!r.a(d(this.f391a, strA), "1")) {
                                return null;
                            }
                        }
                        break;
                    case 1556800273:
                        if (attributeName.equals("desc-sh")) {
                            nodeInfoBase.setDescSh(strA);
                            strA = d(this.f391a, nodeInfoBase.getDescSh());
                            nodeInfoBase.setDesc(strA);
                        }
                        break;
                    case 1943837072:
                        if (!attributeName.equals("visible-sh")) {
                            continue;
                        } else {
                            if (!r.a(d(this.f391a, strA), "1")) {
                                return null;
                            }
                        }
                        break;
                    default:
                        continue;
                }
            }
        }
        return nodeInfoBase;
    }

    /* JADX WARN: Code duplicated, block: B:29:0x0060  */
    /* JADX WARN: Code duplicated, block: B:32:0x006d  */
    /* JADX WARN: Code duplicated, block: B:44:0x0096  */
    /* JADX WARN: Code duplicated, block: B:53:0x00b9  */
    /* JADX WARN: Code duplicated, block: B:65:0x00e4  */
    /* JADX WARN: Code duplicated, block: B:71:0x00f9  */
    /* JADX WARN: Code duplicated, block: B:77:0x010e  */
    /* JADX WARN: Code duplicated, block: B:83:0x0126  */
    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    private final PageNode g(PageNode pageNode, XmlPullParser xmlPullParser) {
        int attributeCount = xmlPullParser.getAttributeCount();
        for (int i = 0; i < attributeCount; i++) {
            String attributeName = xmlPullParser.getAttributeName(i);
            g gVar = this.f393c;
            if (gVar == null) {
                r.q("resourceStringResolver");
                throw null;
            }
            String attributeValue = xmlPullParser.getAttributeValue(i);
            r.c(attributeValue, "parser.getAttributeValue(i)");
            String strA = gVar.a(attributeValue);
            if (attributeName != null) {
                switch (attributeName.hashCode()) {
                    case -1655966961:
                        if (attributeName.equals("activity")) {
                            pageNode.setActivity(strA);
                        }
                        break;
                    case -1354792126:
                        if (attributeName.equals("config")) {
                            pageNode.setPageConfigPath(strA);
                        }
                        break;
                    case -1317542303:
                        if (attributeName.equals("load-error")) {
                            pageNode.setLoadFail(strA);
                        }
                        break;
                    case -1183762788:
                        if (attributeName.equals("intent")) {
                            pageNode.setActivity(strA);
                        }
                        break;
                    case -1141277068:
                        if (attributeName.equals("before-load")) {
                            pageNode.setBeforeRead(strA);
                        }
                        break;
                    case -1141107932:
                        if (attributeName.equals("before-read")) {
                            pageNode.setBeforeRead(strA);
                        }
                        break;
                    case -907685685:
                        if (attributeName.equals("script")) {
                            pageNode.setPageHandlerSh(strA);
                        }
                        break;
                    case -804498240:
                        if (attributeName.equals("config-sh")) {
                            pageNode.setPageConfigSh(strA);
                        }
                        break;
                    case 97:
                        if (attributeName.equals("a")) {
                            pageNode.setActivity(strA);
                        }
                        break;
                    case 113762:
                        if (attributeName.equals("set")) {
                            pageNode.setPageHandlerSh(strA);
                        }
                        break;
                    case 3211051:
                        if (attributeName.equals("href")) {
                            pageNode.setLink(strA);
                        }
                        break;
                    case 3213227:
                        if (attributeName.equals("html")) {
                            pageNode.setOnlineHtmlPage(strA);
                        }
                        break;
                    case 3321850:
                        if (attributeName.equals("link")) {
                            pageNode.setLink(strA);
                        }
                        break;
                    case 336592931:
                        if (attributeName.equals("load-ok")) {
                            pageNode.setLoadSuccess(strA);
                        }
                        break;
                    case 469017116:
                        if (attributeName.equals("load-success")) {
                            pageNode.setLoadSuccess(strA);
                        }
                        break;
                    case 692803402:
                        if (attributeName.equals("handler")) {
                            pageNode.setPageHandlerSh(strA);
                        }
                        break;
                    case 1342985125:
                        if (attributeName.equals("load-fail")) {
                            pageNode.setLoadFail(strA);
                        }
                        break;
                    case 1374438372:
                        if (attributeName.equals("options-sh")) {
                            pageNode.setPageMenuOptionsSh(strA);
                        }
                        break;
                    case 1496001079:
                        if (attributeName.equals("after-load")) {
                            pageNode.setAfterRead(strA);
                        }
                        break;
                    case 1496170215:
                        if (attributeName.equals("after-read")) {
                            pageNode.setAfterRead(strA);
                        }
                        break;
                    case 1845386925:
                        if (attributeName.equals("option-sh")) {
                            pageNode.setPageMenuOptionsSh(strA);
                        }
                        break;
                    case 1845386938:
                        if (attributeName.equals("option-su")) {
                            pageNode.setPageMenuOptionsSh(strA);
                        }
                        break;
                    case 1988338616:
                        if (attributeName.equals("handler-sh")) {
                            pageNode.setPageHandlerSh(strA);
                        }
                        break;
                    case 1995135739:
                        if (attributeName.equals("getstate")) {
                            pageNode.setPageHandlerSh(strA);
                        }
                        break;
                }
            }
        }
        return pageNode;
    }

    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    private final void h(PickerNode pickerNode, XmlPullParser xmlPullParser) {
        int attributeCount = xmlPullParser.getAttributeCount();
        for (int i = 0; i < attributeCount; i++) {
            String attributeName = xmlPullParser.getAttributeName(i);
            g gVar = this.f393c;
            if (gVar == null) {
                r.q("resourceStringResolver");
                throw null;
            }
            String attributeValue = xmlPullParser.getAttributeValue(i);
            r.c(attributeValue, "parser.getAttributeValue(i)");
            String strA = gVar.a(attributeValue);
            if (attributeName != null) {
                switch (attributeName.hashCode()) {
                    case 653829648:
                        if (attributeName.equals("multiple")) {
                            pickerNode.setMultiple(r.a(strA, "multiple") || r.a(strA, "true") || r.a(strA, "1"));
                            continue;
                        }
                        break;
                    case 1374438372:
                        if (!attributeName.equals("options-sh")) {
                            break;
                        }
                        break;
                    case 1374438385:
                        if (!attributeName.equals("options-su")) {
                            break;
                        }
                        break;
                    case 1732829925:
                        if (attributeName.equals("separator")) {
                            pickerNode.setSeparator(strA);
                        } else {
                            continue;
                        }
                        break;
                    case 1845386925:
                        if (!attributeName.equals("option-sh")) {
                            break;
                        }
                        break;
                    default:
                        continue;
                }
                if (pickerNode.getOptions() == null) {
                    pickerNode.setOptions(new ArrayList<>());
                }
                pickerNode.setOptionsSh(strA);
            }
        }
    }

    private final ArrayList<NodeInfoBase> j(InputStream inputStream) {
        TextNode textNode;
        try {
            XmlPullParser xmlPullParserNewPullParser = Xml.newPullParser();
            xmlPullParserNewPullParser.setInput(inputStream, "utf-8");
            r.c(xmlPullParserNewPullParser, "parser");
            int eventType = xmlPullParserNewPullParser.getEventType();
            ArrayList<NodeInfoBase> arrayList = new ArrayList<>();
            boolean z = true;
            GroupNode groupNodeE = null;
            PageNode pageNode = null;
            ActionNode actionNode = null;
            SwitchNode switchNode = null;
            PickerNode pickerNode = null;
            TextNode textNode2 = null;
            for (int i = 1; eventType != i; i = 1) {
                boolean z2 = z;
                TextNode textNode3 = textNode2;
                if (eventType == 2) {
                    if (r.a("group", xmlPullParserNewPullParser.getName())) {
                        if (groupNodeE != null && groupNodeE.getSupported()) {
                            arrayList.add(groupNodeE);
                        }
                        groupNodeE = e(xmlPullParserNewPullParser);
                    } else {
                        if (groupNodeE == null || groupNodeE.getSupported()) {
                            if (r.a("page", xmlPullParserNewPullParser.getName())) {
                                if (!z2) {
                                    PageNode pageNode2 = (PageNode) b(new PageNode(this.f394d), xmlPullParserNewPullParser);
                                    if (pageNode2 != null) {
                                        g(pageNode2, xmlPullParserNewPullParser);
                                    }
                                    pageNode = pageNode2;
                                }
                            } else if (r.a("action", xmlPullParserNewPullParser.getName())) {
                                actionNode = (ActionNode) m(new ActionNode(this.f394d), xmlPullParserNewPullParser);
                            } else if (r.a("switch", xmlPullParserNewPullParser.getName())) {
                                switchNode = (SwitchNode) m(new SwitchNode(this.f394d), xmlPullParserNewPullParser);
                            } else if (r.a("picker", xmlPullParserNewPullParser.getName())) {
                                PickerNode pickerNode2 = (PickerNode) m(new PickerNode(this.f394d), xmlPullParserNewPullParser);
                                if (pickerNode2 != null) {
                                    h(pickerNode2, xmlPullParserNewPullParser);
                                }
                                pickerNode = pickerNode2;
                            } else if (r.a("text", xmlPullParserNewPullParser.getName())) {
                                textNode2 = (TextNode) f(new TextNode(this.f394d), xmlPullParserNewPullParser);
                            } else if (pageNode != null) {
                                u(pageNode, xmlPullParserNewPullParser);
                            } else if (actionNode != null) {
                                t(actionNode, xmlPullParserNewPullParser);
                            } else if (switchNode != null) {
                                w(switchNode, xmlPullParserNewPullParser);
                            } else if (pickerNode != null) {
                                v(pickerNode, xmlPullParserNewPullParser);
                            } else if (textNode3 != null) {
                                x(textNode3, xmlPullParserNewPullParser);
                            } else if (r.a("resource", xmlPullParserNewPullParser.getName())) {
                                k(xmlPullParserNewPullParser);
                            }
                        }
                        z = false;
                    }
                    textNode2 = textNode3;
                    z = false;
                } else if (eventType != 3) {
                    z = z2;
                    textNode2 = textNode3;
                } else if (r.a("group", xmlPullParserNewPullParser.getName())) {
                    if (groupNodeE != null && groupNodeE.getSupported()) {
                        arrayList.add(groupNodeE);
                    }
                    z = z2;
                    textNode2 = textNode3;
                    groupNodeE = null;
                } else if (groupNodeE == null) {
                    textNode = textNode3;
                    if (r.a("page", xmlPullParserNewPullParser.getName())) {
                        p(pageNode, xmlPullParserNewPullParser);
                        if (pageNode != null) {
                            arrayList.add(pageNode);
                        }
                        textNode2 = textNode;
                        pageNode = null;
                    } else if (r.a("action", xmlPullParserNewPullParser.getName())) {
                        o(actionNode, xmlPullParserNewPullParser);
                        if (actionNode != null) {
                            arrayList.add(actionNode);
                        }
                        textNode2 = textNode;
                        actionNode = null;
                    } else if (r.a("switch", xmlPullParserNewPullParser.getName())) {
                        r(switchNode, xmlPullParserNewPullParser);
                        if (switchNode != null) {
                            arrayList.add(switchNode);
                        }
                        textNode2 = textNode;
                        switchNode = null;
                    } else if (r.a("picker", xmlPullParserNewPullParser.getName())) {
                        q(pickerNode, xmlPullParserNewPullParser);
                        if (pickerNode != null) {
                            arrayList.add(pickerNode);
                        }
                        textNode2 = textNode;
                        pickerNode = null;
                    } else if (r.a("text", xmlPullParserNewPullParser.getName())) {
                        s(textNode, xmlPullParserNewPullParser);
                        if (textNode != null) {
                            arrayList.add(textNode);
                        }
                        textNode2 = null;
                    } else {
                        textNode2 = textNode;
                    }
                    z = z2;
                } else if (r.a("page", xmlPullParserNewPullParser.getName())) {
                    p(pageNode, xmlPullParserNewPullParser);
                    if (pageNode != null) {
                        groupNodeE.getChildren().add(pageNode);
                    }
                    z = z2;
                    textNode2 = textNode3;
                    pageNode = null;
                } else if (r.a("action", xmlPullParserNewPullParser.getName())) {
                    o(actionNode, xmlPullParserNewPullParser);
                    if (actionNode != null) {
                        groupNodeE.getChildren().add(actionNode);
                    }
                    z = z2;
                    textNode2 = textNode3;
                    actionNode = null;
                } else if (r.a("switch", xmlPullParserNewPullParser.getName())) {
                    r(switchNode, xmlPullParserNewPullParser);
                    if (switchNode != null) {
                        groupNodeE.getChildren().add(switchNode);
                    }
                    z = z2;
                    textNode2 = textNode3;
                    switchNode = null;
                } else if (r.a("picker", xmlPullParserNewPullParser.getName())) {
                    q(pickerNode, xmlPullParserNewPullParser);
                    if (pickerNode != null) {
                        groupNodeE.getChildren().add(pickerNode);
                    }
                    z = z2;
                    textNode2 = textNode3;
                    pickerNode = null;
                } else if (r.a("text", xmlPullParserNewPullParser.getName())) {
                    s(textNode3, xmlPullParserNewPullParser);
                    if (textNode3 != null) {
                        groupNodeE.getChildren().add(textNode3);
                    }
                    textNode2 = null;
                    z = z2;
                } else {
                    textNode = textNode3;
                    textNode2 = textNode;
                    z = z2;
                }
                eventType = xmlPullParserNewPullParser.next();
            }
            return arrayList;
        } catch (Exception e) {
            new Handler(Looper.getMainLooper()).post(new RunnableC0042b(e));
            Log.e("KrConfig Fail！", "" + e.getMessage());
            return null;
        }
    }

    private final void k(XmlPullParser xmlPullParser) {
        int attributeCount = xmlPullParser.getAttributeCount();
        for (int i = 0; i < attributeCount; i++) {
            String attributeName = xmlPullParser.getAttributeName(i);
            g gVar = this.f393c;
            if (gVar == null) {
                r.q("resourceStringResolver");
                throw null;
            }
            String attributeValue = xmlPullParser.getAttributeValue(i);
            r.c(attributeValue, "parser.getAttributeValue(i)");
            String strA = gVar.a(attributeValue);
            if (r.a(attributeName, "file")) {
                if (strA == null) {
                    throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
                }
                new com.omarea.c.n.a(this.f391a).d(k.k0(strA).toString());
            } else if (!r.a(attributeName, "dir")) {
                continue;
            } else {
                if (strA == null) {
                    throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
                }
                new com.omarea.c.n.a(this.f391a).f(k.k0(strA).toString());
            }
        }
    }

    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    private final void l(TextNode textNode, XmlPullParser xmlPullParser) {
        Layout.Alignment alignment;
        TextNode.TextRow textRow = new TextNode.TextRow();
        int attributeCount = xmlPullParser.getAttributeCount();
        for (int i = 0; i < attributeCount; i++) {
            String attributeName = xmlPullParser.getAttributeName(i);
            r.c(attributeName, "parser.getAttributeName(i)");
            if (attributeName == null) {
                throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
            }
            String lowerCase = attributeName.toLowerCase();
            r.c(lowerCase, "(this as java.lang.String).toLowerCase()");
            g gVar = this.f393c;
            if (gVar == null) {
                r.q("resourceStringResolver");
                throw null;
            }
            String attributeValue = xmlPullParser.getAttributeValue(i);
            r.c(attributeValue, "parser.getAttributeValue(i)");
            String strA = gVar.a(attributeValue);
            try {
                boolean z = true;
                switch (lowerCase.hashCode()) {
                    case -1655966961:
                        if (lowerCase.equals("activity")) {
                            textRow.setActivity$krscript_release_mini(strA);
                        }
                        break;
                    case -1332194002:
                        if (lowerCase.equals("background")) {
                            textRow.setBgColor$krscript_release_mini(Color.parseColor(strA));
                        }
                        break;
                    case -1183762788:
                        if (lowerCase.equals("intent")) {
                            textRow.setActivity$krscript_release_mini(strA);
                        }
                        break;
                    case -1178781136:
                        if (lowerCase.equals("italic")) {
                            if (!r.a(strA, "1") && !r.a(strA, "true") && !r.a(strA, "italic")) {
                                z = false;
                            }
                            textRow.setItalic$krscript_release_mini(z);
                        }
                        break;
                    case -1026963764:
                        if (lowerCase.equals("underline")) {
                            if (!r.a(strA, "1") && !r.a(strA, "true") && !r.a(strA, "underline")) {
                                z = false;
                            }
                            textRow.setUnderline$krscript_release_mini(z);
                        }
                        break;
                    case -907685685:
                        if (lowerCase.equals("script")) {
                            textRow.setOnClickScript$krscript_release_mini(strA);
                        }
                        break;
                    case -175307202:
                        if (lowerCase.equals("bgcolor")) {
                            textRow.setBgColor$krscript_release_mini(Color.parseColor(strA));
                        }
                        break;
                    case 97:
                        if (lowerCase.equals("a")) {
                            textRow.setActivity$krscript_release_mini(strA);
                        }
                        break;
                    case 98:
                        if (lowerCase.equals("b")) {
                            if (!r.a(strA, "1") && !r.a(strA, "true") && !r.a(strA, "bold")) {
                                z = false;
                            }
                            textRow.setBold$krscript_release_mini(z);
                        }
                        break;
                    case 105:
                        if (lowerCase.equals("i")) {
                            if (!r.a(strA, "1")) {
                                z = false;
                            }
                            textRow.setItalic$krscript_release_mini(z);
                        }
                        break;
                    case 117:
                        if (lowerCase.equals("u")) {
                            if (!r.a(strA, "1")) {
                                z = false;
                            }
                            textRow.setUnderline$krscript_release_mini(z);
                        }
                        break;
                    case 3141:
                        if (lowerCase.equals("bg")) {
                            textRow.setBgColor$krscript_release_mini(Color.parseColor(strA));
                        }
                        break;
                    case 3669:
                        if (lowerCase.equals("sh")) {
                            textRow.setDynamicTextSh$krscript_release_mini(strA);
                        }
                        break;
                    case 113291:
                        if (lowerCase.equals("run")) {
                            textRow.setOnClickScript$krscript_release_mini(strA);
                        }
                        break;
                    case 3029637:
                        if (lowerCase.equals("bold")) {
                            if (!r.a(strA, "1")) {
                                z = false;
                            }
                            textRow.setBold$krscript_release_mini(z);
                        }
                        break;
                    case 3211051:
                        if (lowerCase.equals("href")) {
                            textRow.setLink$krscript_release_mini(strA);
                        }
                        break;
                    case 3321850:
                        if (lowerCase.equals("link")) {
                            textRow.setLink$krscript_release_mini(strA);
                        }
                        break;
                    case 3530753:
                        if (lowerCase.equals("size")) {
                            textRow.setSize$krscript_release_mini(Integer.parseInt(strA));
                        }
                        break;
                    case 92903173:
                        if (lowerCase.equals("align")) {
                            switch (strA.hashCode()) {
                                case -1364013995:
                                    if (strA.equals("center")) {
                                        alignment = Layout.Alignment.ALIGN_CENTER;
                                    }
                                    break;
                                case -1039745817:
                                    if (strA.equals("normal")) {
                                        alignment = Layout.Alignment.ALIGN_NORMAL;
                                    }
                                    break;
                                case 3317767:
                                    if (strA.equals("left") && Build.VERSION.SDK_INT >= 28) {
                                        alignment = Layout.Alignment.ALIGN_LEFT;
                                    }
                                    break;
                                case 108511772:
                                    if (strA.equals("right") && Build.VERSION.SDK_INT >= 28) {
                                        alignment = Layout.Alignment.ALIGN_RIGHT;
                                    }
                                    break;
                                default:
                                    continue;
                            }
                            textRow.setAlign$krscript_release_mini(alignment);
                        }
                        break;
                    case 94001407:
                        if (lowerCase.equals("break")) {
                            if (!r.a(strA, "1") && !r.a(strA, "true") && !r.a(strA, "break")) {
                                z = false;
                            }
                            textRow.setBreakRow$krscript_release_mini(z);
                        }
                        break;
                    case 94842723:
                        if (lowerCase.equals("color")) {
                            textRow.setColor$krscript_release_mini(Color.parseColor(strA));
                        }
                        break;
                    case 1984457027:
                        if (lowerCase.equals("foreground")) {
                            textRow.setColor$krscript_release_mini(Color.parseColor(strA));
                        }
                        break;
                }
            } catch (Exception unused) {
            }
        }
        textRow.setText$krscript_release_mini("" + xmlPullParser.nextText());
        textNode.getRows().add(textRow);
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code duplicated, block: B:136:0x0205  */
    /* JADX WARN: Code duplicated, block: B:148:0x022d  */
    /* JADX WARN: Code duplicated, block: B:50:0x00bf  */
    /* JADX WARN: Code duplicated, block: B:52:0x00c5  */
    /* JADX WARN: Code duplicated, block: B:53:0x00c7  */
    /* JADX WARN: Code duplicated, block: B:71:0x00fe  */
    /* JADX WARN: Code duplicated, block: B:87:0x0132  */
    private final RunnableNode m(RunnableNode runnableNode, XmlPullParser xmlPullParser) {
        int i;
        Object obj;
        boolean z;
        List listE;
        boolean z2;
        RunnableNode runnableNode2 = (RunnableNode) b(runnableNode, xmlPullParser);
        if (runnableNode2 != null) {
            int i2 = 0;
            for (int attributeCount = xmlPullParser.getAttributeCount(); i2 < attributeCount; attributeCount = i) {
                g gVar = this.f393c;
                if (gVar == null) {
                    r.q("resourceStringResolver");
                    throw null;
                }
                String attributeValue = xmlPullParser.getAttributeValue(i2);
                r.c(attributeValue, "parser.getAttributeValue(i)");
                String strA = gVar.a(attributeValue);
                String attributeName = xmlPullParser.getAttributeName(i2);
                if (attributeName != null) {
                    i = attributeCount;
                    boolean z3 = true;
                    switch (attributeName.hashCode()) {
                        case -1486450598:
                            obj = "auto-close";
                            z = false;
                            if (attributeName.equals(obj)) {
                                if (!r.a(strA, obj) && !r.a(strA, "auto-off") && !r.a(strA, "true") && !r.a(strA, "1")) {
                                    z3 = z;
                                }
                                runnableNode2.setAutoOff(z3);
                            }
                            i2++;
                            break;
                        case -1433566666:
                            if (attributeName.equals("async-task")) {
                                if (r.a(strA, "async-task") || r.a(strA, "async") || r.a(strA, "bg-task") || r.a(strA, "background") || r.a(strA, "background-task") || r.a(strA, "true") || r.a(strA, "1")) {
                                    runnableNode2.setShell(RunnableNode.Companion.getShellModeBgTask());
                                }
                            }
                            i2++;
                            break;
                        case -934641255:
                            if (attributeName.equals("reload")) {
                                if (r.a(strA, "reload-page") || r.a(strA, "reload") || r.a(strA, "page") || r.a(strA, "true") || r.a(strA, "1")) {
                                    runnableNode2.setReloadPage(true);
                                } else if (strA.length() > 0) {
                                    List<String> listW = k.W(strA, new String[]{","}, false, 0, 6, (Object) null);
                                    ArrayList arrayList = new ArrayList(q.k(listW, 10));
                                    for (String str : listW) {
                                        if (str == null) {
                                            throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
                                        }
                                        arrayList.add(k.k0(str).toString());
                                    }
                                    if (arrayList.isEmpty()) {
                                        listE = q.e();
                                    } else {
                                        ListIterator listIterator = arrayList.listIterator(arrayList.size());
                                        while (true) {
                                            if (!listIterator.hasPrevious()) {
                                                listE = q.e();
                                            } else if (!(((String) listIterator.previous()).length() == 0)) {
                                                listE = q.Q(arrayList, listIterator.nextIndex() + 1);
                                            }
                                        }
                                    }
                                    Object[] array = listE.toArray(new String[0]);
                                    if (array == null) {
                                        throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T>");
                                    }
                                    runnableNode2.setUpdateBlocks((String[]) array);
                                }
                            }
                            i2++;
                            break;
                        case -225038835:
                            if (attributeName.equals("bg-task")) {
                                if (r.a(strA, "async-task")) {
                                    runnableNode2.setShell(RunnableNode.Companion.getShellModeBgTask());
                                } else {
                                    runnableNode2.setShell(RunnableNode.Companion.getShellModeBgTask());
                                }
                            }
                            i2++;
                            break;
                        case -18736573:
                            if (attributeName.equals("reload-page") && (r.a(strA, "reload-page") || r.a(strA, "reload") || r.a(strA, "page") || r.a(strA, "true") || r.a(strA, "1"))) {
                                runnableNode2.setReloadPage(true);
                            }
                            break;
                        case 3641990:
                            if (attributeName.equals("warn")) {
                                runnableNode2.setWarning(strA);
                            }
                            break;
                        case 109403696:
                            if (attributeName.equals("shell")) {
                                runnableNode2.setShell(strA);
                            }
                            break;
                        case 911530557:
                            if (attributeName.equals("interruptable")) {
                                if (strA.length() == 0) {
                                    z2 = true;
                                } else {
                                    z2 = false;
                                }
                                if (!z2 && !r.a(strA, "interruptable") && !r.a(strA, "interruptable") && !r.a(strA, "true") && !r.a(strA, "1")) {
                                    z3 = false;
                                }
                                runnableNode2.setInterruptable(z3);
                            }
                            break;
                        case 911768885:
                            if (attributeName.equals("interruptible")) {
                                if (strA.length() == 0) {
                                    z2 = true;
                                } else {
                                    z2 = false;
                                }
                                if (!z2) {
                                    z3 = false;
                                }
                                runnableNode2.setInterruptable(z3);
                            }
                            break;
                        case 951117504:
                            if (attributeName.equals("confirm")) {
                                if (!r.a(strA, "confirm") && !r.a(strA, "true") && !r.a(strA, "1")) {
                                    z3 = false;
                                }
                                runnableNode2.setConfirm(z3);
                            }
                            break;
                        case 1124446108:
                            if (attributeName.equals("warning")) {
                                runnableNode2.setWarning(strA);
                            }
                            break;
                        case 1247749745:
                            if (attributeName.equals("auto-finish")) {
                                if (!r.a(strA, "auto-finish") && !r.a(strA, "true") && !r.a(strA, "1")) {
                                    z3 = false;
                                }
                                runnableNode2.setAutoFinish(z3);
                            }
                            break;
                        case 1266945732:
                            if (attributeName.equals("background-task")) {
                                if (r.a(strA, "async-task")) {
                                    runnableNode2.setShell(RunnableNode.Companion.getShellModeBgTask());
                                } else {
                                    runnableNode2.setShell(RunnableNode.Companion.getShellModeBgTask());
                                }
                            }
                            i2++;
                            break;
                        case 1437569105:
                            if (attributeName.equals("auto-off")) {
                                obj = "auto-close";
                                z = false;
                                if (!r.a(strA, obj)) {
                                    z3 = z;
                                }
                                runnableNode2.setAutoOff(z3);
                            }
                            i2++;
                            break;
                    }
                } else {
                    i = attributeCount;
                }
                i2++;
            }
        }
        return runnableNode2;
    }

    private final void n(NodeInfoBase nodeInfoBase, XmlPullParser xmlPullParser) throws XmlPullParserException, IOException {
        int attributeCount = xmlPullParser.getAttributeCount();
        for (int i = 0; i < attributeCount; i++) {
            String attributeName = xmlPullParser.getAttributeName(i);
            g gVar = this.f393c;
            if (gVar == null) {
                r.q("resourceStringResolver");
                throw null;
            }
            String attributeValue = xmlPullParser.getAttributeValue(i);
            r.c(attributeValue, "parser.getAttributeValue(i)");
            String strA = gVar.a(attributeValue);
            if (r.a(attributeName, "su") || r.a(attributeName, "sh") || r.a(attributeName, "summary-sh")) {
                nodeInfoBase.setSummarySh(strA);
                nodeInfoBase.setSummary(d(this.f391a, nodeInfoBase.getSummarySh()));
            }
        }
        if (nodeInfoBase.getSummary().length() == 0) {
            String strNextText = xmlPullParser.nextText();
            r.c(strNextText, "parser.nextText()");
            nodeInfoBase.setSummary(strNextText);
        }
    }

    private final void o(ActionNode actionNode, XmlPullParser xmlPullParser) {
        if (actionNode != null) {
            if (actionNode.getSetState() == null) {
                actionNode.setSetState("");
            }
            actionNode.setParams(this.g);
            this.g = null;
        }
    }

    private final void p(PageNode pageNode, XmlPullParser xmlPullParser) {
    }

    private final void q(PickerNode pickerNode, XmlPullParser xmlPullParser) {
        if (pickerNode != null) {
            if (pickerNode.getGetState() == null) {
                pickerNode.setGetState("");
            } else {
                pickerNode.setValue(d(this.f391a, "" + pickerNode.getGetState()));
            }
            if (pickerNode.getSetState() == null) {
                pickerNode.setSetState("");
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:13:0x003a  */
    private final void r(SwitchNode switchNode, XmlPullParser xmlPullParser) {
        if (switchNode != null) {
            String strD = d(this.f391a, switchNode.getGetState());
            boolean z = true;
            if (!(!r.a(strD, "error"))) {
                z = false;
            } else if (!r.a(strD, "1")) {
                if (strD == null) {
                    throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                }
                String lowerCase = strD.toLowerCase();
                r.c(lowerCase, "(this as java.lang.String).toLowerCase()");
                if (!r.a(lowerCase, "true")) {
                    z = false;
                }
            }
            switchNode.setChecked(z);
            if (switchNode.getSetState() == null) {
                switchNode.setSetState("");
            }
        }
    }

    private final void s(TextNode textNode, XmlPullParser xmlPullParser) {
    }

    private final void t(ActionNode actionNode, XmlPullParser xmlPullParser) throws XmlPullParserException, IOException {
        String str;
        String str2;
        int i;
        String str3 = "title";
        if (r.a("title", xmlPullParser.getName())) {
            String strNextText = xmlPullParser.nextText();
            r.c(strNextText, "parser.nextText()");
            actionNode.setTitle(strNextText);
            return;
        }
        String str4 = "desc";
        if (r.a("desc", xmlPullParser.getName())) {
            c(actionNode, xmlPullParser);
            return;
        }
        if (r.a("summary", xmlPullParser.getName())) {
            n(actionNode, xmlPullParser);
            return;
        }
        if (r.a("script", xmlPullParser.getName()) || r.a("set", xmlPullParser.getName()) || r.a("setstate", xmlPullParser.getName())) {
            String strNextText2 = xmlPullParser.nextText();
            r.c(strNextText2, "parser.nextText()");
            if (strNextText2 == null) {
                throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
            }
            actionNode.setSetState(k.k0(strNextText2).toString());
            return;
        }
        if (r.a("lock", xmlPullParser.getName()) || r.a("lock-state", xmlPullParser.getName())) {
            String strNextText3 = xmlPullParser.nextText();
            r.c(strNextText3, "parser.nextText()");
            actionNode.setLockShell(strNextText3);
            return;
        }
        if (!r.a("param", xmlPullParser.getName())) {
            if (this.h == null || !r.a("option", xmlPullParser.getName())) {
                if (r.a("resource", xmlPullParser.getName())) {
                    k(xmlPullParser);
                    return;
                }
                return;
            }
            ActionParamInfo actionParamInfo = this.h;
            r.b(actionParamInfo);
            if (actionParamInfo.getOptions() == null) {
                actionParamInfo.setOptions(new ArrayList<>());
            }
            com.omarea.a.f.a aVar = new com.omarea.a.f.a();
            int attributeCount = xmlPullParser.getAttributeCount();
            for (int i2 = 0; i2 < attributeCount; i2++) {
                String attributeName = xmlPullParser.getAttributeName(i2);
                g gVar = this.f393c;
                if (gVar == null) {
                    r.q("resourceStringResolver");
                    throw null;
                }
                String attributeValue = xmlPullParser.getAttributeValue(i2);
                r.c(attributeValue, "parser.getAttributeValue(i)");
                String strA = gVar.a(attributeValue);
                if (r.a(attributeName, "val") || r.a(attributeName, "value")) {
                    aVar.f(strA);
                }
            }
            aVar.e(xmlPullParser.nextText());
            if (aVar.c() == null) {
                aVar.f(aVar.b());
            }
            ArrayList<com.omarea.a.f.a> options = actionParamInfo.getOptions();
            r.b(options);
            options.add(aVar);
            return;
        }
        if (this.g == null) {
            this.g = new ArrayList<>();
        }
        ActionParamInfo actionParamInfo2 = new ActionParamInfo();
        this.h = actionParamInfo2;
        r.b(actionParamInfo2);
        int attributeCount2 = xmlPullParser.getAttributeCount();
        int i3 = 0;
        while (i3 < attributeCount2) {
            String attributeName2 = xmlPullParser.getAttributeName(i3);
            g gVar2 = this.f393c;
            if (gVar2 == null) {
                r.q("resourceStringResolver");
                throw null;
            }
            String attributeValue2 = xmlPullParser.getAttributeValue(i3);
            r.c(attributeValue2, "parser.getAttributeValue(i)");
            String strA2 = gVar2.a(attributeValue2);
            if (r.a(attributeName2, "name")) {
                actionParamInfo2.setName(strA2);
            } else if (r.a(attributeName2, "label")) {
                actionParamInfo2.setLabel(strA2);
            } else if (r.a(attributeName2, "placeholder")) {
                actionParamInfo2.setPlaceholder(strA2);
            } else if (r.a(attributeName2, str3)) {
                actionParamInfo2.setTitle(strA2);
            } else if (r.a(attributeName2, str4)) {
                actionParamInfo2.setDesc(strA2);
            } else if (r.a(attributeName2, "value")) {
                actionParamInfo2.setValue(strA2);
            } else if (r.a(attributeName2, "type")) {
                if (strA2 == null) {
                    throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                }
                String lowerCase = strA2.toLowerCase();
                r.c(lowerCase, "(this as java.lang.String).toLowerCase()");
                int length = lowerCase.length() - 1;
                int i4 = 0;
                boolean z = false;
                while (i4 <= length) {
                    boolean z2 = r.e(lowerCase.charAt(!z ? i4 : length), 32) <= 0;
                    if (z) {
                        if (!z2) {
                            break;
                        } else {
                            length--;
                        }
                    } else if (z2) {
                        i4++;
                    } else {
                        z = true;
                    }
                }
                actionParamInfo2.setType(lowerCase.subSequence(i4, length + 1).toString());
            } else if (!r.a(attributeName2, "suffix")) {
                if (!r.a(attributeName2, "mime")) {
                    str = str3;
                    str2 = str4;
                    if (!r.a(attributeName2, "readonly")) {
                        i = attributeCount2;
                        if (r.a(attributeName2, "maxlength")) {
                            actionParamInfo2.setMaxLength(Integer.parseInt(strA2));
                        } else if (r.a(attributeName2, "min")) {
                            actionParamInfo2.setMin(Integer.parseInt(strA2));
                        } else if (r.a(attributeName2, "max")) {
                            actionParamInfo2.setMax(Integer.parseInt(strA2));
                        } else if (r.a(attributeName2, "min-sh")) {
                            try {
                                actionParamInfo2.setMin(Integer.parseInt(d(this.f391a, strA2)));
                            } catch (Exception unused) {
                            }
                        } else if (r.a(attributeName2, "max-sh")) {
                            actionParamInfo2.setMax(Integer.parseInt(d(this.f391a, strA2)));
                        } else if (r.a(attributeName2, "required")) {
                            actionParamInfo2.setRequired(r.a(strA2, "true") || r.a(strA2, "1") || r.a(strA2, "required"));
                        } else if (r.a(attributeName2, "value-sh") || r.a(attributeName2, "value-su")) {
                            actionParamInfo2.setValueShell(strA2);
                        } else if (r.a(attributeName2, "options-sh") || r.a(attributeName2, "option-sh") || r.a(attributeName2, "options-su")) {
                            if (actionParamInfo2.getOptions() == null) {
                                actionParamInfo2.setOptions(new ArrayList<>());
                            }
                            actionParamInfo2.setOptionsSh(strA2);
                        } else if (r.a(attributeName2, "exist")) {
                            actionParamInfo2.setSupported(com.omarea.common.shell.g.f472a.g(strA2));
                        } else if (r.a(attributeName2, "support") || r.a(attributeName2, "visible") || r.a(attributeName2, "visible-sh")) {
                            if (!r.a(d(this.f391a, strA2), "1")) {
                                actionParamInfo2.setSupported(false);
                            }
                        } else if (r.a(attributeName2, "multiple")) {
                            actionParamInfo2.setMultiple(r.a(strA2, "multiple") || r.a(strA2, "true") || r.a(strA2, "1"));
                        } else if (r.a(attributeName2, "editable")) {
                            actionParamInfo2.setEditable(r.a(strA2, "editable") || r.a(strA2, "true") || r.a(strA2, "1"));
                        } else if (r.a(attributeName2, "separator")) {
                            actionParamInfo2.setSeparator(strA2);
                        }
                    } else {
                        if (strA2 == null) {
                            throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                        }
                        String lowerCase2 = strA2.toLowerCase();
                        r.c(lowerCase2, "(this as java.lang.String).toLowerCase()");
                        int length2 = lowerCase2.length() - 1;
                        boolean z3 = false;
                        int i5 = 0;
                        while (true) {
                            if (i5 > length2) {
                                i = attributeCount2;
                                break;
                            }
                            i = attributeCount2;
                            boolean z4 = r.e(lowerCase2.charAt(!z3 ? i5 : length2), 32) <= 0;
                            if (z3) {
                                if (!z4) {
                                    break;
                                } else {
                                    length2--;
                                }
                            } else if (z4) {
                                i5++;
                            } else {
                                z3 = true;
                            }
                            attributeCount2 = i;
                        }
                        String string = lowerCase2.subSequence(i5, length2 + 1).toString();
                        actionParamInfo2.setReadonly(r.a(string, "readonly") || r.a(string, "true") || r.a(string, "1"));
                    }
                } else {
                    if (strA2 == null) {
                        throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                    }
                    String lowerCase3 = strA2.toLowerCase();
                    r.c(lowerCase3, "(this as java.lang.String).toLowerCase()");
                    actionParamInfo2.setMime(lowerCase3);
                }
                i3++;
                str3 = str;
                str4 = str2;
                attributeCount2 = i;
            } else {
                if (strA2 == null) {
                    throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                }
                String lowerCase4 = strA2.toLowerCase();
                r.c(lowerCase4, "(this as java.lang.String).toLowerCase()");
                int length3 = lowerCase4.length() - 1;
                boolean z5 = false;
                int i6 = 0;
                while (i6 <= length3) {
                    boolean z6 = r.e(lowerCase4.charAt(!z5 ? i6 : length3), 32) <= 0;
                    if (z5) {
                        if (!z6) {
                            break;
                        } else {
                            length3--;
                        }
                    } else if (z6) {
                        i6++;
                    } else {
                        z5 = true;
                    }
                }
                String string2 = lowerCase4.subSequence(i6, length3 + 1).toString();
                if (actionParamInfo2.getMime().length() == 0) {
                    actionParamInfo2.setMime(new e().a(string2));
                }
                actionParamInfo2.setSuffix(string2);
            }
            str = str3;
            str2 = str4;
            i = attributeCount2;
            i3++;
            str3 = str;
            str4 = str2;
            attributeCount2 = i;
        }
        if (!actionParamInfo2.getSupported() || actionParamInfo2.getName() == null) {
            return;
        }
        String name = actionParamInfo2.getName();
        r.b(name);
        if (name.length() > 0) {
            ArrayList<ActionParamInfo> arrayList = this.g;
            r.b(arrayList);
            arrayList.add(actionParamInfo2);
        }
    }

    /* JADX WARN: Code duplicated, block: B:100:0x01a6  */
    /* JADX WARN: Code duplicated, block: B:104:0x01be  */
    /* JADX WARN: Code duplicated, block: B:106:0x01c1  */
    /* JADX WARN: Code duplicated, block: B:115:0x01f6  */
    /* JADX WARN: Code duplicated, block: B:117:0x01f9  */
    /* JADX WARN: Code duplicated, block: B:120:0x0206  */
    /* JADX WARN: Code duplicated, block: B:123:0x0214  */
    /* JADX WARN: Code duplicated, block: B:128:0x0161 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:129:0x01d1 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:130:0x01e2 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:131:0x01db A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:132:0x01d7 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:134:0x01d7 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:136:0x01d7 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:138:0x01d7 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:140:0x01d7 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:141:0x01d7 A[DONT_GENERATE, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:143:0x01a3 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:144:0x01a0 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:145:0x019e A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:146:0x01a9 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:147:0x019c A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:175:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:176:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:57:0x00f5  */
    /* JADX WARN: Code duplicated, block: B:60:0x00fe  */
    /* JADX WARN: Code duplicated, block: B:62:0x0102  */
    /* JADX WARN: Code duplicated, block: B:65:0x0117  */
    /* JADX WARN: Code duplicated, block: B:68:0x0126  */
    /* JADX WARN: Code duplicated, block: B:70:0x012e  */
    /* JADX WARN: Code duplicated, block: B:71:0x0139  */
    /* JADX WARN: Code duplicated, block: B:73:0x0141  */
    /* JADX WARN: Code duplicated, block: B:74:0x0146  */
    /* JADX WARN: Code duplicated, block: B:76:0x014e  */
    /* JADX WARN: Code duplicated, block: B:78:0x0155  */
    /* JADX WARN: Code duplicated, block: B:81:0x0167  */
    /* JADX WARN: Code duplicated, block: B:83:0x016f  */
    /* JADX WARN: Code duplicated, block: B:85:0x0176  */
    /* JADX WARN: Code duplicated, block: B:87:0x0186 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:88:0x0188  */
    /* JADX WARN: Code duplicated, block: B:89:0x018a  */
    /* JADX WARN: Code duplicated, block: B:92:0x0197  */
    /* JADX WARN: Code duplicated, block: B:93:0x0199  */
    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    /* JADX WARN: Instruction removed from duplicated block: B:57:0x00f5, please report this as an issue */
    private final void u(PageNode pageNode, XmlPullParser xmlPullParser) throws XmlPullParserException, IOException {
        String string;
        int i;
        boolean z;
        String name = xmlPullParser.getName();
        if (name == null) {
            return;
        }
        switch (name) {
            case "summary":
                n(pageNode, xmlPullParser);
                return;
            case "menu-item":
                if (!name.equals("menu-item")) {
                    return;
                }
                PageMenuOption pageMenuOption = (PageMenuOption) m(new PageMenuOption(this.f394d), xmlPullParser);
                if (pageMenuOption != null) {
                    return;
                }
                int attributeCount = xmlPullParser.getAttributeCount();
                int i2 = 0;
                while (true) {
                    if (i2 < attributeCount) {
                        String strNextText = xmlPullParser.nextText();
                        r.c(strNextText, "parser.nextText()");
                        pageMenuOption.setTitle(strNextText);
                        if (pageMenuOption.getKey().length() == 0) {
                            pageMenuOption.setKey(pageMenuOption.getTitle());
                        }
                        if (pageNode.getPageMenuOptions() == null) {
                            pageNode.setPageMenuOptions(new ArrayList<>());
                        }
                        ArrayList<PageMenuOption> pageMenuOptions = pageNode.getPageMenuOptions();
                        if (pageMenuOptions != null) {
                            pageMenuOptions.add(pageMenuOption);
                            return;
                        }
                        return;
                    }
                    g gVar = this.f393c;
                    if (gVar != null) {
                        r.q("resourceStringResolver");
                        throw null;
                    }
                    String attributeValue = xmlPullParser.getAttributeValue(i2);
                    r.c(attributeValue, "parser.getAttributeValue(i)");
                    String strA = gVar.a(attributeValue);
                    String attributeName = xmlPullParser.getAttributeName(i2);
                    if (attributeName == null) {
                        switch (attributeName.hashCode()) {
                            case -891422895:
                                if (attributeName.equals("suffix")) {
                                    continue;
                                } else {
                                    Locale locale = Locale.ENGLISH;
                                    r.c(locale, "Locale.ENGLISH");
                                    if (strA != null) {
                                        throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                                    }
                                    String lowerCase = strA.toLowerCase(locale);
                                    r.c(lowerCase, "(this as java.lang.String).toLowerCase(locale)");
                                    int length = lowerCase.length() - 1;
                                    int i3 = 0;
                                    boolean z2 = false;
                                    while (i3 <= length) {
                                        if (z2) {
                                            i = length;
                                        } else {
                                            i = i3;
                                        }
                                        if (r.e(lowerCase.charAt(i), 32) <= 0) {
                                            z = true;
                                        } else {
                                            z = false;
                                        }
                                        if (z2) {
                                            if (!z) {
                                                string = lowerCase.subSequence(i3, length + 1).toString();
                                                if (pageMenuOption.getMime().length() == 0) {
                                                    pageMenuOption.setMime(new e().a(string));
                                                }
                                                pageMenuOption.setSuffix(string);
                                            } else {
                                                length--;
                                            }
                                            break;
                                        } else if (z) {
                                            i3++;
                                        } else {
                                            z2 = true;
                                        }
                                    }
                                    string = lowerCase.subSequence(i3, length + 1).toString();
                                    if (pageMenuOption.getMime().length() == 0) {
                                        pageMenuOption.setMime(new e().a(string));
                                    }
                                    pageMenuOption.setSuffix(string);
                                }
                                break;
                            case 3351604:
                                if (attributeName.equals("mime")) {
                                    continue;
                                } else {
                                    Locale locale2 = Locale.ENGLISH;
                                    r.c(locale2, "Locale.ENGLISH");
                                    if (strA != null) {
                                        throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                                    }
                                    String lowerCase2 = strA.toLowerCase(locale2);
                                    r.c(lowerCase2, "(this as java.lang.String).toLowerCase(locale)");
                                    pageMenuOption.setMime(lowerCase2);
                                }
                                break;
                            case 3575610:
                                if (!attributeName.equals("type")) {
                                    pageMenuOption.setType(strA);
                                }
                                break;
                            case 109780401:
                                if (!attributeName.equals("style")) {
                                    pageMenuOption.setFab(r.a(strA, "fab"));
                                }
                                break;
                        }
                    }
                    i2++;
                }
                break;
            case "config":
                String strNextText2 = xmlPullParser.nextText();
                r.c(strNextText2, "parser.nextText()");
                pageNode.setPageConfigPath(strNextText2);
                return;
            case "option":
                if (!name.equals("menu-item")) {
                    return;
                }
                PageMenuOption pageMenuOption2 = (PageMenuOption) m(new PageMenuOption(this.f394d), xmlPullParser);
                if (pageMenuOption2 != null) {
                    return;
                }
                int attributeCount2 = xmlPullParser.getAttributeCount();
                int i4 = 0;
                while (true) {
                    if (i4 < attributeCount2) {
                        String strNextText3 = xmlPullParser.nextText();
                        r.c(strNextText3, "parser.nextText()");
                        pageMenuOption2.setTitle(strNextText3);
                        if (pageMenuOption2.getKey().length() == 0) {
                            pageMenuOption2.setKey(pageMenuOption2.getTitle());
                        }
                        if (pageNode.getPageMenuOptions() == null) {
                            pageNode.setPageMenuOptions(new ArrayList<>());
                        }
                        ArrayList<PageMenuOption> pageMenuOptions2 = pageNode.getPageMenuOptions();
                        if (pageMenuOptions2 != null) {
                            pageMenuOptions2.add(pageMenuOption2);
                            return;
                        }
                        return;
                    }
                    g gVar2 = this.f393c;
                    if (gVar2 != null) {
                        r.q("resourceStringResolver");
                        throw null;
                    }
                    String attributeValue2 = xmlPullParser.getAttributeValue(i4);
                    r.c(attributeValue2, "parser.getAttributeValue(i)");
                    String strA2 = gVar2.a(attributeValue2);
                    String attributeName2 = xmlPullParser.getAttributeName(i4);
                    if (attributeName2 == null) {
                        switch (attributeName2.hashCode()) {
                            case -891422895:
                                if (attributeName2.equals("suffix")) {
                                    continue;
                                } else {
                                    Locale locale3 = Locale.ENGLISH;
                                    r.c(locale3, "Locale.ENGLISH");
                                    if (strA2 != null) {
                                        throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                                    }
                                    String lowerCase3 = strA2.toLowerCase(locale3);
                                    r.c(lowerCase3, "(this as java.lang.String).toLowerCase(locale)");
                                    int length2 = lowerCase3.length() - 1;
                                    int i5 = 0;
                                    boolean z3 = false;
                                    while (i5 <= length2) {
                                        if (z3) {
                                            i = length2;
                                        } else {
                                            i = i5;
                                        }
                                        if (r.e(lowerCase3.charAt(i), 32) <= 0) {
                                            z = true;
                                        } else {
                                            z = false;
                                        }
                                        if (z3) {
                                            if (!z) {
                                                string = lowerCase3.subSequence(i5, length2 + 1).toString();
                                                if (pageMenuOption2.getMime().length() == 0) {
                                                    pageMenuOption2.setMime(new e().a(string));
                                                }
                                                pageMenuOption2.setSuffix(string);
                                            } else {
                                                length2--;
                                            }
                                            break;
                                        } else if (z) {
                                            i5++;
                                        } else {
                                            z3 = true;
                                        }
                                    }
                                    string = lowerCase3.subSequence(i5, length2 + 1).toString();
                                    if (pageMenuOption2.getMime().length() == 0) {
                                        pageMenuOption2.setMime(new e().a(string));
                                    }
                                    pageMenuOption2.setSuffix(string);
                                }
                                break;
                            case 3351604:
                                if (attributeName2.equals("mime")) {
                                    continue;
                                } else {
                                    Locale locale4 = Locale.ENGLISH;
                                    r.c(locale4, "Locale.ENGLISH");
                                    if (strA2 != null) {
                                        throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                                    }
                                    String lowerCase4 = strA2.toLowerCase(locale4);
                                    r.c(lowerCase4, "(this as java.lang.String).toLowerCase(locale)");
                                    pageMenuOption2.setMime(lowerCase4);
                                }
                                break;
                            case 3575610:
                                if (!attributeName2.equals("type")) {
                                    pageMenuOption2.setType(strA2);
                                }
                                break;
                            case 109780401:
                                if (!attributeName2.equals("style")) {
                                    pageMenuOption2.setFab(r.a(strA2, "fab"));
                                }
                                break;
                        }
                    }
                    i4++;
                }
                break;
            case "script":
                if (!name.equals("script")) {
                    return;
                }
                String strNextText4 = xmlPullParser.nextText();
                r.c(strNextText4, "parser.nextText()");
                pageNode.setPageHandlerSh(strNextText4);
                return;
            case "resource":
                k(xmlPullParser);
                return;
            case "lock-state":
                if (!name.equals("lock-state")) {
                    return;
                }
                String strNextText5 = xmlPullParser.nextText();
                r.c(strNextText5, "parser.nextText()");
                pageNode.setLockShell(strNextText5);
                return;
            case "set":
                if (!name.equals("script")) {
                    return;
                }
                String strNextText6 = xmlPullParser.nextText();
                r.c(strNextText6, "parser.nextText()");
                pageNode.setPageHandlerSh(strNextText6);
                return;
            case "desc":
                c(pageNode, xmlPullParser);
                return;
            case "html":
                String strNextText7 = xmlPullParser.nextText();
                r.c(strNextText7, "parser.nextText()");
                pageNode.setOnlineHtmlPage(strNextText7);
                return;
            case "lock":
                if (!name.equals("lock-state")) {
                    return;
                }
                String strNextText8 = xmlPullParser.nextText();
                r.c(strNextText8, "parser.nextText()");
                pageNode.setLockShell(strNextText8);
                return;
            case "menu":
                if (!name.equals("menu-item")) {
                    return;
                }
                PageMenuOption pageMenuOption3 = (PageMenuOption) m(new PageMenuOption(this.f394d), xmlPullParser);
                if (pageMenuOption3 != null) {
                    return;
                }
                int attributeCount3 = xmlPullParser.getAttributeCount();
                int i6 = 0;
                while (true) {
                    if (i6 < attributeCount3) {
                        String strNextText9 = xmlPullParser.nextText();
                        r.c(strNextText9, "parser.nextText()");
                        pageMenuOption3.setTitle(strNextText9);
                        if (pageMenuOption3.getKey().length() == 0) {
                            pageMenuOption3.setKey(pageMenuOption3.getTitle());
                        }
                        if (pageNode.getPageMenuOptions() == null) {
                            pageNode.setPageMenuOptions(new ArrayList<>());
                        }
                        ArrayList<PageMenuOption> pageMenuOptions3 = pageNode.getPageMenuOptions();
                        if (pageMenuOptions3 != null) {
                            pageMenuOptions3.add(pageMenuOption3);
                            return;
                        }
                        return;
                    }
                    g gVar3 = this.f393c;
                    if (gVar3 != null) {
                        r.q("resourceStringResolver");
                        throw null;
                    }
                    String attributeValue3 = xmlPullParser.getAttributeValue(i6);
                    r.c(attributeValue3, "parser.getAttributeValue(i)");
                    String strA3 = gVar3.a(attributeValue3);
                    String attributeName3 = xmlPullParser.getAttributeName(i6);
                    if (attributeName3 == null) {
                        switch (attributeName3.hashCode()) {
                            case -891422895:
                                if (attributeName3.equals("suffix")) {
                                    continue;
                                } else {
                                    Locale locale5 = Locale.ENGLISH;
                                    r.c(locale5, "Locale.ENGLISH");
                                    if (strA3 != null) {
                                        throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                                    }
                                    String lowerCase5 = strA3.toLowerCase(locale5);
                                    r.c(lowerCase5, "(this as java.lang.String).toLowerCase(locale)");
                                    int length3 = lowerCase5.length() - 1;
                                    int i7 = 0;
                                    boolean z4 = false;
                                    while (i7 <= length3) {
                                        if (z4) {
                                            i = length3;
                                        } else {
                                            i = i7;
                                        }
                                        if (r.e(lowerCase5.charAt(i), 32) <= 0) {
                                            z = true;
                                        } else {
                                            z = false;
                                        }
                                        if (z4) {
                                            if (!z) {
                                                string = lowerCase5.subSequence(i7, length3 + 1).toString();
                                                if (pageMenuOption3.getMime().length() == 0) {
                                                    pageMenuOption3.setMime(new e().a(string));
                                                }
                                                pageMenuOption3.setSuffix(string);
                                            } else {
                                                length3--;
                                            }
                                            break;
                                        } else if (z) {
                                            i7++;
                                        } else {
                                            z4 = true;
                                        }
                                    }
                                    string = lowerCase5.subSequence(i7, length3 + 1).toString();
                                    if (pageMenuOption3.getMime().length() == 0) {
                                        pageMenuOption3.setMime(new e().a(string));
                                    }
                                    pageMenuOption3.setSuffix(string);
                                }
                                break;
                            case 3351604:
                                if (attributeName3.equals("mime")) {
                                    continue;
                                } else {
                                    Locale locale6 = Locale.ENGLISH;
                                    r.c(locale6, "Locale.ENGLISH");
                                    if (strA3 != null) {
                                        throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                                    }
                                    String lowerCase6 = strA3.toLowerCase(locale6);
                                    r.c(lowerCase6, "(this as java.lang.String).toLowerCase(locale)");
                                    pageMenuOption3.setMime(lowerCase6);
                                }
                                break;
                            case 3575610:
                                if (!attributeName3.equals("type")) {
                                    pageMenuOption3.setType(strA3);
                                }
                                break;
                            case 109780401:
                                if (!attributeName3.equals("style")) {
                                    pageMenuOption3.setFab(r.a(strA3, "fab"));
                                }
                                break;
                        }
                    }
                    i6++;
                }
                break;
            case "title":
                String strNextText10 = xmlPullParser.nextText();
                r.c(strNextText10, "parser.nextText()");
                pageNode.setTitle(strNextText10);
                return;
            case "handler":
                if (!name.equals("script")) {
                    return;
                }
                String strNextText11 = xmlPullParser.nextText();
                r.c(strNextText11, "parser.nextText()");
                pageNode.setPageHandlerSh(strNextText11);
                return;
            case "page-option":
                if (!name.equals("menu-item")) {
                    return;
                }
                PageMenuOption pageMenuOption4 = (PageMenuOption) m(new PageMenuOption(this.f394d), xmlPullParser);
                if (pageMenuOption4 != null) {
                    return;
                }
                int attributeCount4 = xmlPullParser.getAttributeCount();
                int i8 = 0;
                while (true) {
                    if (i8 < attributeCount4) {
                        String strNextText12 = xmlPullParser.nextText();
                        r.c(strNextText12, "parser.nextText()");
                        pageMenuOption4.setTitle(strNextText12);
                        if (pageMenuOption4.getKey().length() == 0) {
                            pageMenuOption4.setKey(pageMenuOption4.getTitle());
                        }
                        if (pageNode.getPageMenuOptions() == null) {
                            pageNode.setPageMenuOptions(new ArrayList<>());
                        }
                        ArrayList<PageMenuOption> pageMenuOptions4 = pageNode.getPageMenuOptions();
                        if (pageMenuOptions4 != null) {
                            pageMenuOptions4.add(pageMenuOption4);
                            return;
                        }
                        return;
                    }
                    g gVar4 = this.f393c;
                    if (gVar4 != null) {
                        r.q("resourceStringResolver");
                        throw null;
                    }
                    String attributeValue4 = xmlPullParser.getAttributeValue(i8);
                    r.c(attributeValue4, "parser.getAttributeValue(i)");
                    String strA4 = gVar4.a(attributeValue4);
                    String attributeName4 = xmlPullParser.getAttributeName(i8);
                    if (attributeName4 == null) {
                        switch (attributeName4.hashCode()) {
                            case -891422895:
                                if (attributeName4.equals("suffix")) {
                                    continue;
                                } else {
                                    Locale locale7 = Locale.ENGLISH;
                                    r.c(locale7, "Locale.ENGLISH");
                                    if (strA4 != null) {
                                        throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                                    }
                                    String lowerCase7 = strA4.toLowerCase(locale7);
                                    r.c(lowerCase7, "(this as java.lang.String).toLowerCase(locale)");
                                    int length4 = lowerCase7.length() - 1;
                                    int i9 = 0;
                                    boolean z5 = false;
                                    while (i9 <= length4) {
                                        if (z5) {
                                            i = length4;
                                        } else {
                                            i = i9;
                                        }
                                        if (r.e(lowerCase7.charAt(i), 32) <= 0) {
                                            z = true;
                                        } else {
                                            z = false;
                                        }
                                        if (z5) {
                                            if (!z) {
                                                string = lowerCase7.subSequence(i9, length4 + 1).toString();
                                                if (pageMenuOption4.getMime().length() == 0) {
                                                    pageMenuOption4.setMime(new e().a(string));
                                                }
                                                pageMenuOption4.setSuffix(string);
                                            } else {
                                                length4--;
                                            }
                                            break;
                                        } else if (z) {
                                            i9++;
                                        } else {
                                            z5 = true;
                                        }
                                    }
                                    string = lowerCase7.subSequence(i9, length4 + 1).toString();
                                    if (pageMenuOption4.getMime().length() == 0) {
                                        pageMenuOption4.setMime(new e().a(string));
                                    }
                                    pageMenuOption4.setSuffix(string);
                                }
                                break;
                            case 3351604:
                                if (attributeName4.equals("mime")) {
                                    continue;
                                } else {
                                    Locale locale8 = Locale.ENGLISH;
                                    r.c(locale8, "Locale.ENGLISH");
                                    if (strA4 != null) {
                                        throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                                    }
                                    String lowerCase8 = strA4.toLowerCase(locale8);
                                    r.c(lowerCase8, "(this as java.lang.String).toLowerCase(locale)");
                                    pageMenuOption4.setMime(lowerCase8);
                                }
                                break;
                            case 3575610:
                                if (!attributeName4.equals("type")) {
                                    pageMenuOption4.setType(strA4);
                                }
                                break;
                            case 109780401:
                                if (!attributeName4.equals("style")) {
                                    pageMenuOption4.setFab(r.a(strA4, "fab"));
                                }
                                break;
                        }
                    }
                    i8++;
                }
                break;
            case "handler-sh":
            case "getstate":
                if (!name.equals("script")) {
                    return;
                }
                String strNextText13 = xmlPullParser.nextText();
                r.c(strNextText13, "parser.nextText()");
                pageNode.setPageHandlerSh(strNextText13);
                return;
            default:
                return;
        }
    }

    private final void v(PickerNode pickerNode, XmlPullParser xmlPullParser) throws XmlPullParserException, IOException {
        if (r.a("title", xmlPullParser.getName())) {
            String strNextText = xmlPullParser.nextText();
            r.c(strNextText, "parser.nextText()");
            pickerNode.setTitle(strNextText);
            return;
        }
        if (r.a("desc", xmlPullParser.getName())) {
            c(pickerNode, xmlPullParser);
            return;
        }
        if (r.a("summary", xmlPullParser.getName())) {
            n(pickerNode, xmlPullParser);
            return;
        }
        if (!r.a("option", xmlPullParser.getName())) {
            if (r.a("getstate", xmlPullParser.getName()) || r.a("get", xmlPullParser.getName())) {
                pickerNode.setGetState(xmlPullParser.nextText());
                return;
            }
            if (r.a("setstate", xmlPullParser.getName()) || r.a("set", xmlPullParser.getName())) {
                pickerNode.setSetState(xmlPullParser.nextText());
                return;
            }
            if (r.a("resource", xmlPullParser.getName())) {
                k(xmlPullParser);
                return;
            } else {
                if (r.a("lock", xmlPullParser.getName()) || r.a("lock-state", xmlPullParser.getName())) {
                    String strNextText2 = xmlPullParser.nextText();
                    r.c(strNextText2, "parser.nextText()");
                    pickerNode.setLockShell(strNextText2);
                    return;
                }
                return;
            }
        }
        if (pickerNode.getOptions() == null) {
            pickerNode.setOptions(new ArrayList<>());
        }
        com.omarea.a.f.a aVar = new com.omarea.a.f.a();
        int attributeCount = xmlPullParser.getAttributeCount();
        for (int i = 0; i < attributeCount; i++) {
            String attributeName = xmlPullParser.getAttributeName(i);
            g gVar = this.f393c;
            if (gVar == null) {
                r.q("resourceStringResolver");
                throw null;
            }
            String attributeValue = xmlPullParser.getAttributeValue(i);
            r.c(attributeValue, "parser.getAttributeValue(i)");
            String strA = gVar.a(attributeValue);
            if (r.a(attributeName, "val") || r.a(attributeName, "value")) {
                aVar.f(strA);
            }
        }
        aVar.e(xmlPullParser.nextText());
        if (aVar.c() == null) {
            aVar.f(aVar.b());
        }
        ArrayList<com.omarea.a.f.a> options = pickerNode.getOptions();
        r.b(options);
        options.add(aVar);
    }

    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    private final void w(SwitchNode switchNode, XmlPullParser xmlPullParser) throws XmlPullParserException, IOException {
        String name = xmlPullParser.getName();
        if (name == null) {
            return;
        }
        switch (name.hashCode()) {
            case -1857640538:
                if (name.equals("summary")) {
                    n(switchNode, xmlPullParser);
                }
                break;
            case -341064690:
                if (name.equals("resource")) {
                    k(xmlPullParser);
                }
                break;
            case -196357777:
                if (!name.equals("lock-state")) {
                }
                String strNextText = xmlPullParser.nextText();
                r.c(strNextText, "parser.nextText()");
                switchNode.setLockShell(strNextText);
                break;
            case 102230:
                if (!name.equals("get")) {
                }
                String strNextText2 = xmlPullParser.nextText();
                r.c(strNextText2, "parser.nextText()");
                switchNode.setGetState(strNextText2);
                break;
            case 113762:
                if (!name.equals("set")) {
                }
                switchNode.setSetState(xmlPullParser.nextText());
                break;
            case 3079825:
                if (name.equals("desc")) {
                    c(switchNode, xmlPullParser);
                }
                break;
            case 3327275:
                if (!name.equals("lock")) {
                }
                String strNextText3 = xmlPullParser.nextText();
                r.c(strNextText3, "parser.nextText()");
                switchNode.setLockShell(strNextText3);
                break;
            case 110371416:
                if (name.equals("title")) {
                    String strNextText4 = xmlPullParser.nextText();
                    r.c(strNextText4, "parser.nextText()");
                    switchNode.setTitle(strNextText4);
                }
                break;
            case 1434023279:
                if (!name.equals("setstate")) {
                }
                switchNode.setSetState(xmlPullParser.nextText());
                break;
            case 1995135739:
                if (!name.equals("getstate")) {
                }
                String strNextText5 = xmlPullParser.nextText();
                r.c(strNextText5, "parser.nextText()");
                switchNode.setGetState(strNextText5);
                break;
        }
    }

    private final void x(TextNode textNode, XmlPullParser xmlPullParser) throws XmlPullParserException, IOException {
        if (r.a("title", xmlPullParser.getName())) {
            String strNextText = xmlPullParser.nextText();
            r.c(strNextText, "parser.nextText()");
            textNode.setTitle(strNextText);
        } else {
            if (r.a("desc", xmlPullParser.getName())) {
                c(textNode, xmlPullParser);
                return;
            }
            if (r.a("summary", xmlPullParser.getName())) {
                n(textNode, xmlPullParser);
            } else if (r.a("slice", xmlPullParser.getName())) {
                l(textNode, xmlPullParser);
            } else if (r.a("resource", xmlPullParser.getName())) {
                k(xmlPullParser);
            }
        }
    }

    public final ArrayList<NodeInfoBase> i() {
        InputStream inputStream = this.e;
        if (inputStream != null) {
            r.b(inputStream);
            return j(inputStream);
        }
        try {
            d dVar = new d(this.f391a, this.f);
            InputStream inputStreamE = dVar.e(this.f392b);
            if (inputStreamE == null) {
                return new ArrayList<>();
            }
            this.f394d = dVar.c();
            return j(inputStreamE);
        } catch (Exception e) {
            new Handler(Looper.getMainLooper()).post(new a(e));
            Log.e("KrConfig Fail！", "" + e.getMessage());
            return null;
        }
    }
}
