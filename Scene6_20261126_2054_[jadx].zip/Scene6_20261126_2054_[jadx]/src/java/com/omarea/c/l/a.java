package com.omarea.c.l;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import com.omarea.krscript.model.ClickableNode;
import java.io.InputStream;
import kotlin.jvm.internal.r;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class a {
    public final Drawable a(Bitmap bitmap) {
        r.d(bitmap, "bitmap");
        return new BitmapDrawable(bitmap);
    }

    public final Drawable b(Context context, ClickableNode clickableNode) {
        r.d(context, "context");
        r.d(clickableNode, "clickableNode");
        if (clickableNode.getIconPath().length() == 0) {
            return null;
        }
        String pageConfigDir = clickableNode.getPageConfigDir();
        r.c(pageConfigDir, "clickableNode.pageConfigDir");
        InputStream inputStreamE = new d(context, pageConfigDir).e(clickableNode.getIconPath());
        if (inputStreamE == null) {
            return null;
        }
        Bitmap bitmapDecodeStream = BitmapFactory.decodeStream(inputStreamE);
        r.c(bitmapDecodeStream, "BitmapFactory.decodeStream(this)");
        return a(bitmapDecodeStream);
    }

    public final Drawable c(Context context, ClickableNode clickableNode) {
        r.d(context, "context");
        r.d(clickableNode, "clickableNode");
        Drawable drawableD = d(context, clickableNode, true);
        r.b(drawableD);
        return drawableD;
    }

    /* JADX WARN: Code duplicated, block: B:13:0x0041  */
    /* JADX WARN: Code duplicated, block: B:16:0x004c  */
    /* JADX WARN: Code duplicated, block: B:18:0x004f  */
    /* JADX WARN: Code duplicated, block: B:20:0x0065  */
    /* JADX WARN: Code duplicated, block: B:22:0x006c  */
    /* JADX WARN: Code duplicated, block: B:23:0x0076 A[ORIG_RETURN, RETURN] */
    public final Drawable d(Context context, ClickableNode clickableNode, boolean z) {
        InputStream inputStreamE;
        Bitmap bitmapDecodeStream;
        r.d(context, "context");
        r.d(clickableNode, "clickableNode");
        if (clickableNode.getLogoPath().length() == 0) {
            if (!(clickableNode.getIconPath().length() == 0)) {
                String pageConfigDir = clickableNode.getPageConfigDir();
                r.c(pageConfigDir, "clickableNode.pageConfigDir");
                inputStreamE = new d(context, pageConfigDir).e(clickableNode.getIconPath());
                if (inputStreamE != null) {
                    bitmapDecodeStream = BitmapFactory.decodeStream(inputStreamE);
                }
            }
            if (z) {
                return null;
            }
            Drawable drawable = context.getDrawable(com.omarea.c.e.kr_shortcut_logo);
            r.b(drawable);
            return drawable;
        }
        String pageConfigDir2 = clickableNode.getPageConfigDir();
        r.c(pageConfigDir2, "clickableNode.pageConfigDir");
        InputStream inputStreamE2 = new d(context, pageConfigDir2).e(clickableNode.getLogoPath());
        if (inputStreamE2 == null) {
            if (!(clickableNode.getIconPath().length() == 0)) {
                String pageConfigDir3 = clickableNode.getPageConfigDir();
                r.c(pageConfigDir3, "clickableNode.pageConfigDir");
                inputStreamE = new d(context, pageConfigDir3).e(clickableNode.getIconPath());
                if (inputStreamE != null) {
                    bitmapDecodeStream = BitmapFactory.decodeStream(inputStreamE);
                }
            }
            if (z) {
                return null;
            }
            Drawable drawable2 = context.getDrawable(com.omarea.c.e.kr_shortcut_logo);
            r.b(drawable2);
            return drawable2;
        }
        bitmapDecodeStream = BitmapFactory.decodeStream(inputStreamE2);
        r.c(bitmapDecodeStream, "BitmapFactory.decodeStream(this)");
        return a(bitmapDecodeStream);
    }
}
