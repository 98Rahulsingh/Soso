package com.omarea.c.l;

import android.app.Activity;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;
import com.omarea.c.h;
import com.omarea.krscript.model.NodeInfoBase;
import com.omarea.krscript.model.PageNode;
import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import kotlin.jvm.internal.r;
import kotlin.text.k;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private Handler f395a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private Activity f396b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private String f397c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private PageNode f398d;

    static final class a implements Runnable {
        a() {
        }

        @Override // java.lang.Runnable
        public final void run() {
            Toast.makeText(c.this.f396b, c.this.f396b.getString(h.kr_page_sh_file_permission), 1).show();
        }
    }

    static final class b implements Runnable {
        final /* synthetic */ String g;

        b(String str) {
            this.g = str;
        }

        @Override // java.lang.Runnable
        public final void run() {
            Toast.makeText(c.this.f396b, c.this.f396b.getString(h.kr_page_sh_invalid) + "\n" + this.g, 1).show();
        }
    }

    public c(Activity activity, String str, PageNode pageNode) {
        r.d(activity, "activity");
        r.d(str, "pageConfigSh");
        this.f396b = activity;
        this.f397c = str;
        this.f398d = pageNode;
        this.f395a = new Handler(Looper.getMainLooper());
    }

    private final void c() {
        this.f395a.post(new a());
    }

    private final void d(String str) {
        this.f395a.post(new b(str));
    }

    public final ArrayList<NodeInfoBase> b() {
        String string;
        String strC = com.omarea.c.n.b.c(this.f396b, this.f397c, this.f398d);
        if (strC == null) {
            string = null;
        } else {
            if (strC == null) {
                throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
            }
            string = k.k0(strC).toString();
        }
        if (string == null) {
            return null;
        }
        if (k.m(string, ".xml", false, 2, (Object) null)) {
            Activity activity = this.f396b;
            PageNode pageNode = this.f398d;
            ArrayList<NodeInfoBase> arrayListI = new com.omarea.c.l.b(activity, string, pageNode != null ? pageNode.getPageConfigDir() : null).i();
            if (arrayListI != null) {
                return arrayListI;
            }
            c();
            return arrayListI;
        }
        if (k.t(string, "<?xml", false, 2, (Object) null) && k.m(string, ">", false, 2, (Object) null)) {
            byte[] bytes = string.getBytes(kotlin.text.d.a);
            r.c(bytes, "(this as java.lang.String).getBytes(charset)");
            return new com.omarea.c.l.b(this.f396b, new ByteArrayInputStream(bytes)).i();
        }
        if (!(string.length() > 0)) {
            return null;
        }
        d(string);
        return null;
    }
}
