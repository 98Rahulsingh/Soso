package com.omarea.c.l;

import android.content.Context;
import android.content.res.AssetManager;
import com.omarea.common.shell.g;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import kotlin.collections.q;
import kotlin.jvm.b.l;
import kotlin.jvm.internal.r;
import kotlin.text.k;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final String f399a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private String f400b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private Context f401c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private String f402d;

    public d(Context context, String str) {
        r.d(context, "context");
        r.d(str, "parentDir");
        this.f401c = context;
        this.f402d = str;
        this.f399a = "file:///android_asset/";
        this.f400b = "";
    }

    private final InputStream a(String str) {
        String strF = f(this.f402d, str);
        try {
            try {
                int length = this.f399a.length();
                if (strF == null) {
                    throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                }
                String strSubstring = strF.substring(length);
                r.c(strSubstring, "(this as java.lang.String).substring(startIndex)");
                InputStream inputStreamOpen = this.f401c.getAssets().open(strSubstring);
                this.f400b = strF;
                return inputStreamOpen;
            } catch (Exception unused) {
                InputStream inputStreamOpen2 = this.f401c.getAssets().open(str);
                this.f400b = this.f399a + str;
                return inputStreamOpen2;
            }
        } catch (Exception unused2) {
            return null;
        }
    }

    private final InputStream b(String str) {
        if (this.f402d.length() > 0) {
            String strF = f(this.f402d, str);
            File file = new File(strF);
            if (file.exists() && file.canRead()) {
                String absolutePath = file.getAbsolutePath();
                r.c(absolutePath, "absolutePath");
                this.f400b = absolutePath;
                return new FileInputStream(file);
            }
            InputStream inputStreamG = g(strF);
            if (inputStreamG != null) {
                return inputStreamG;
            }
        }
        String absolutePath2 = new File(f(com.omarea.common.shared.d.f450b.a(this.f401c), str)).getAbsolutePath();
        File file2 = new File(absolutePath2);
        if (file2.exists() && file2.canRead()) {
            String absolutePath3 = file2.getAbsolutePath();
            r.c(absolutePath3, "absolutePath");
            this.f400b = absolutePath3;
            return new FileInputStream(file2);
        }
        r.c(absolutePath2, "privatePath");
        InputStream inputStreamG2 = g(absolutePath2);
        if (inputStreamG2 != null) {
            return inputStreamG2;
        }
        return null;
    }

    private final InputStream d(String str) {
        try {
            if (!k.t(str, "/", false, 2, (Object) null)) {
                return ((this.f402d.length() > 0) && k.t(this.f402d, this.f399a, false, 2, (Object) null)) ? a(str) : b(str);
            }
            this.f400b = str;
            File file = new File(str);
            return (file.exists() && file.canRead()) ? new FileInputStream(file) : g(str);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private final String f(String str, String str2) {
        String strSubstring;
        String strSubstring2 = str;
        boolean zT = k.t(strSubstring2, this.f399a, false, 2, (Object) null);
        if (zT) {
            int length = this.f399a.length();
            if (strSubstring2 == null) {
                throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
            }
            strSubstring2 = strSubstring2.substring(length);
            r.c(strSubstring2, "(this as java.lang.String).substring(startIndex)");
        }
        ArrayList arrayList = new ArrayList(k.W(strSubstring2, new String[]{"/"}, false, 0, 6, (Object) null));
        if (k.t(str2, "../", false, 2, (Object) null) && arrayList.size() > 0) {
            ArrayList arrayList2 = new ArrayList(k.W(str2, new String[]{"/"}, false, 0, 6, (Object) null));
            while (true) {
                String str3 = (String) q.u(arrayList2);
                if (str3 == null || !r.a(str3, "..") || arrayList.size() <= 0) {
                    break;
                }
                arrayList.remove(arrayList.size() - 1);
                arrayList2.remove(0);
            }
            StringBuilder sb = new StringBuilder();
            sb.append(zT ? this.f399a : "");
            sb.append(q.A(arrayList, "/", (CharSequence) null, (CharSequence) null, 0, (CharSequence) null, (l) null, 62, (Object) null));
            return f(sb.toString(), q.A(arrayList2, "/", (CharSequence) null, (CharSequence) null, 0, (CharSequence) null, (l) null, 62, (Object) null));
        }
        StringBuilder sb2 = new StringBuilder();
        sb2.append(zT ? this.f399a : "");
        if (!(strSubstring2.length() == 0) && !k.m(strSubstring2, "/", false, 2, (Object) null)) {
            strSubstring2 = strSubstring2 + "/";
        }
        sb2.append(strSubstring2);
        if (!k.t(str2, "./", false, 2, (Object) null)) {
            strSubstring = str2;
        } else {
            if (str2 == null) {
                throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
            }
            strSubstring = str2.substring(2);
            r.c(strSubstring, "(this as java.lang.String).substring(startIndex)");
        }
        sb2.append(strSubstring);
        return sb2.toString();
    }

    private final InputStream g(String str) {
        if (!g.f472a.d(str)) {
            return null;
        }
        File file = new File(com.omarea.common.shared.d.f450b.b(this.f401c, "kr-script"));
        if (!file.exists()) {
            file.mkdirs();
        }
        String strB = com.omarea.common.shared.d.f450b.b(this.f401c, "kr-script/outside_file.cache");
        String strA = new com.omarea.c.b(this.f401c).a();
        com.omarea.common.shell.e.f469b.c("cp -f \"" + str + "\" \"" + strB + "\"\nchmod 777 \"" + strB + "\"\nchown " + strA + ':' + strA + " \"" + strB + "\"\n");
        File file2 = new File(strB);
        if (file2.exists() && file2.canRead()) {
            return new FileInputStream(file2);
        }
        return null;
    }

    public final String c() {
        return this.f400b;
    }

    public final InputStream e(String str) {
        r.d(str, "filePath");
        try {
            if (!k.t(str, this.f399a, false, 2, (Object) null)) {
                return d(str);
            }
            this.f400b = str;
            AssetManager assets = this.f401c.getAssets();
            String strSubstring = str.substring(this.f399a.length());
            r.c(strSubstring, "(this as java.lang.String).substring(startIndex)");
            return assets.open(strSubstring);
        } catch (Exception unused) {
            return null;
        }
    }
}
