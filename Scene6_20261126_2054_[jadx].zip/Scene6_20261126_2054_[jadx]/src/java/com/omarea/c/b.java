package com.omarea.c;

import android.content.Context;
import android.os.Process;
import android.os.UserManager;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final Context f376a;

    public b(Context context) {
        this.f376a = context;
    }

    public String a() {
        int iB = b();
        StringBuilder sb = new StringBuilder();
        sb.append("u");
        sb.append(iB);
        sb.append("_a");
        sb.append((Process.myUid() % 100000) - 10000);
        return sb.toString();
    }

    public int b() {
        try {
            return (int) ((UserManager) this.f376a.getSystemService("user")).getSerialNumberForUser(Process.myUserHandle());
        } catch (Exception unused) {
            return 0;
        }
    }
}
