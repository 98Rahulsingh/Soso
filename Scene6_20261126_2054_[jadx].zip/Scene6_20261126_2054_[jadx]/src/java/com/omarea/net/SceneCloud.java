package com.omarea.net;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.util.Log;
import com.omarea.common.net.Daemon;
import com.omarea.library.shell.CpuFrequencyUtils;
import java.io.IOException;
import java.io.Serializable;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.FutureTask;
import kotlin.coroutines.CoroutineContext;
import kotlinx.coroutines.CoroutineStart;
import kotlinx.coroutines.i0;
import kotlinx.coroutines.w0;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class SceneCloud extends com.omarea.common.net.g {
    private static final String g = "http://vtools-api.omarea.com";
    private static boolean h;
    public static final a i = new a(null);
    private final o e;
    private final Context f;

    public static final class AccountIntegral implements Serializable {
        private int integral;
        private String remark = "";
        private long time;

        public final int getIntegral() {
            return this.integral;
        }

        public final String getRemark() {
            return this.remark;
        }

        public final long getTime() {
            return this.time;
        }

        public final void setIntegral(int i) {
            this.integral = i;
        }

        public final void setRemark(String str) {
            kotlin.jvm.internal.r.d(str, "<set-?>");
            this.remark = str;
        }

        public final void setTime(long j) {
            this.time = j;
        }
    }

    public static final class AccountIntegralResponse implements Serializable {
        private int consume;
        private int free;
        private int total;
        private boolean unbind;
        private String error = "";
        private AccountIntegral[] records = new AccountIntegral[0];
        private String detail = "";

        public final int getConsume() {
            return this.consume;
        }

        public final String getDetail() {
            return this.detail;
        }

        public final String getError() {
            return this.error;
        }

        public final int getFree() {
            return this.free;
        }

        public final AccountIntegral[] getRecords() {
            return this.records;
        }

        public final int getTotal() {
            return this.total;
        }

        public final boolean getUnbind() {
            return this.unbind;
        }

        public final void setConsume(int i) {
            this.consume = i;
        }

        public final void setDetail(String str) {
            kotlin.jvm.internal.r.d(str, "<set-?>");
            this.detail = str;
        }

        public final void setError(String str) {
            kotlin.jvm.internal.r.d(str, "<set-?>");
            this.error = str;
        }

        public final void setFree(int i) {
            this.free = i;
        }

        public final void setRecords(AccountIntegral[] accountIntegralArr) {
            kotlin.jvm.internal.r.d(accountIntegralArr, "<set-?>");
            this.records = accountIntegralArr;
        }

        public final void setTotal(int i) {
            this.total = i;
        }

        public final void setUnbind(boolean z) {
            this.unbind = z;
        }
    }

    public static final class ActivationCodeResponse implements Serializable {
        private boolean expired;
        private boolean pass;
        private String error = "";
        private String code = "";
        private String type = "";
        private String detail = "";
        private String account = "";

        public final String getAccount() {
            return this.account;
        }

        public final String getCode() {
            return this.code;
        }

        public final String getDetail() {
            return this.detail;
        }

        public final String getError() {
            return this.error;
        }

        public final boolean getExpired() {
            return this.expired;
        }

        public final boolean getPass() {
            return this.pass;
        }

        public final String getType() {
            return this.type;
        }

        public final void setAccount(String str) {
            kotlin.jvm.internal.r.d(str, "<set-?>");
            this.account = str;
        }

        public final void setCode(String str) {
            kotlin.jvm.internal.r.d(str, "<set-?>");
            this.code = str;
        }

        public final void setDetail(String str) {
            kotlin.jvm.internal.r.d(str, "<set-?>");
            this.detail = str;
        }

        public final void setError(String str) {
            kotlin.jvm.internal.r.d(str, "<set-?>");
            this.error = str;
        }

        public final void setExpired(boolean z) {
            this.expired = z;
        }

        public final void setPass(boolean z) {
            this.pass = z;
        }

        public final void setType(String str) {
            kotlin.jvm.internal.r.d(str, "<set-?>");
            this.type = str;
        }
    }

    public static final class ExchangeResponse implements Serializable {
        private boolean activated;
        private boolean exchanged;
        private boolean found;
        private int number;
        private int used;
        private String devices = "";
        private String error = "";
        private String deviceCode = "";
        private String detail = "";

        public final boolean getActivated() {
            return this.activated;
        }

        public final String getDetail() {
            return this.detail;
        }

        public final String getDeviceCode() {
            return this.deviceCode;
        }

        public final String getDevices() {
            return this.devices;
        }

        public final String getError() {
            return this.error;
        }

        public final boolean getExchanged() {
            return this.exchanged;
        }

        public final boolean getFound() {
            return this.found;
        }

        public final int getNumber() {
            return this.number;
        }

        public final int getUsed() {
            return this.used;
        }

        public final void setActivated(boolean z) {
            this.activated = z;
        }

        public final void setDetail(String str) {
            kotlin.jvm.internal.r.d(str, "<set-?>");
            this.detail = str;
        }

        public final void setDeviceCode(String str) {
            kotlin.jvm.internal.r.d(str, "<set-?>");
            this.deviceCode = str;
        }

        public final void setDevices(String str) {
            kotlin.jvm.internal.r.d(str, "<set-?>");
            this.devices = str;
        }

        public final void setError(String str) {
            kotlin.jvm.internal.r.d(str, "<set-?>");
            this.error = str;
        }

        public final void setExchanged(boolean z) {
            this.exchanged = z;
        }

        public final void setFound(boolean z) {
            this.found = z;
        }

        public final void setNumber(int i) {
            this.number = i;
        }

        public final void setUsed(int i) {
            this.used = i;
        }
    }

    public static final class LoginResponse implements Serializable {
        private boolean activated;
        private boolean pass;
        private String error = "";
        private String detail = "";

        public final boolean getActivated() {
            return this.activated;
        }

        public final String getDetail() {
            return this.detail;
        }

        public final String getError() {
            return this.error;
        }

        public final boolean getPass() {
            return this.pass;
        }

        public final void setActivated(boolean z) {
            this.activated = z;
        }

        public final void setDetail(String str) {
            kotlin.jvm.internal.r.d(str, "<set-?>");
            this.detail = str;
        }

        public final void setError(String str) {
            kotlin.jvm.internal.r.d(str, "<set-?>");
            this.error = str;
        }

        public final void setPass(boolean z) {
            this.pass = z;
        }
    }

    public static final class MagiskModuleUnofficial extends com.omarea.store.g.b implements Serializable {
        private long uploadTime;
        private String downloadUrl = "";
        private String detailUrl = "";
        private String detailContent = "";
        private String uid = "";

        public final String getDetailContent() {
            return this.detailContent;
        }

        public final String getDetailUrl() {
            return this.detailUrl;
        }

        public final String getDownloadUrl() {
            return this.downloadUrl;
        }

        public final String getUid() {
            return this.uid;
        }

        public final long getUploadTime() {
            return this.uploadTime;
        }

        public final void setDetailContent(String str) {
            kotlin.jvm.internal.r.d(str, "<set-?>");
            this.detailContent = str;
        }

        public final void setDetailUrl(String str) {
            kotlin.jvm.internal.r.d(str, "<set-?>");
            this.detailUrl = str;
        }

        public final void setDownloadUrl(String str) {
            kotlin.jvm.internal.r.d(str, "<set-?>");
            this.downloadUrl = str;
        }

        public final void setUid(String str) {
            kotlin.jvm.internal.r.d(str, "<set-?>");
            this.uid = str;
        }

        public final void setUploadTime(long j) {
            this.uploadTime = j;
        }
    }

    public static final class ResetResponse implements Serializable {
        private boolean pass;
        private String error = "";
        private String uid = "";

        public final String getError() {
            return this.error;
        }

        public final boolean getPass() {
            return this.pass;
        }

        public final String getUid() {
            return this.uid;
        }

        public final void setError(String str) {
            kotlin.jvm.internal.r.d(str, "<set-?>");
            this.error = str;
        }

        public final void setPass(boolean z) {
            this.pass = z;
        }

        public final void setUid(String str) {
            kotlin.jvm.internal.r.d(str, "<set-?>");
            this.uid = str;
        }
    }

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(kotlin.jvm.internal.o oVar) {
            this();
        }

        public final String a() {
            return SceneCloud.g;
        }
    }

    public static final class b {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public String f791a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public JSONObject f792b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private boolean f793c;

        public final boolean a() {
            return this.f793c;
        }

        public final JSONObject b() {
            JSONObject jSONObject = this.f792b;
            if (jSONObject != null) {
                return jSONObject;
            }
            kotlin.jvm.internal.r.q("item");
            throw null;
        }

        public final String c() {
            String str = this.f791a;
            if (str != null) {
                return str;
            }
            kotlin.jvm.internal.r.q("name");
            throw null;
        }

        public final void d(boolean z) {
            this.f793c = z;
        }

        public final void e(String str) {
            kotlin.jvm.internal.r.d(str, "<set-?>");
        }

        public final void f(JSONObject jSONObject) {
            kotlin.jvm.internal.r.d(jSONObject, "<set-?>");
            this.f792b = jSONObject;
        }

        public final void g(String str) {
            kotlin.jvm.internal.r.d(str, "<set-?>");
            this.f791a = str;
        }
    }

    static final class c<V> implements Callable<AccountIntegralResponse> {

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final /* synthetic */ String f795b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        final /* synthetic */ String f796c;

        c(String str, String str2) {
            this.f795b = str;
            this.f796c = str2;
        }

        @Override // java.util.concurrent.Callable
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public final AccountIntegralResponse call() {
            try {
                SceneCloud sceneCloud = SceneCloud.this;
                String str = SceneCloud.i.a() + "/account-integral";
                JSONObject jSONObject = new JSONObject();
                Locale localeG = SceneCloud.this.G();
                if (localeG != null) {
                    jSONObject.put("locale", localeG.getLanguage());
                }
                jSONObject.put("uid", this.f795b);
                jSONObject.put("password", SceneCloud.this.M(this.f796c));
                kotlin.s sVar = kotlin.s.a;
                String strM = sceneCloud.m(str, jSONObject);
                if (strM == null) {
                    throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
                }
                String string = kotlin.text.k.k0(strM).toString();
                if (string.length() > 0) {
                    try {
                        Object objP = new com.omarea.net.a().p(string, new AccountIntegralResponse().getClass());
                        ((AccountIntegralResponse) objP).setDetail(string);
                        return (AccountIntegralResponse) objP;
                    } catch (Exception unused) {
                        return null;
                    }
                }
                return null;
            } catch (Exception unused2) {
                Log.e("Scene", "Cloud Request(exchangeCode), Fail!");
            }
        }
    }

    static final class d<V> implements Callable<String> {
        d() {
        }

        @Override // java.util.concurrent.Callable
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public final String call() {
            return SceneCloud.this.n(SceneCloud.i.a() + "/scene-announcement", "");
        }
    }

    static final class e<V> implements Callable<Boolean> {

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final /* synthetic */ String f799b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        final /* synthetic */ String f800c;

        e(String str, String str2) {
            this.f799b = str;
            this.f800c = str2;
        }

        @Override // java.util.concurrent.Callable
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public final Boolean call() throws JSONException, IOException {
            SceneCloud sceneCloud = SceneCloud.this;
            String str = SceneCloud.i.a() + "/scene-magisk-delete";
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("dbId", this.f799b);
            jSONObject.put("uid", this.f800c);
            kotlin.s sVar = kotlin.s.a;
            String strM = sceneCloud.m(str, jSONObject);
            if (!(strM.length() == 0)) {
                if (!(strM.length() == 0)) {
                    return Boolean.valueOf(kotlin.text.k.y(strM, "true", false, 2, (Object) null));
                }
            }
            return Boolean.FALSE;
        }
    }

    static final class f<V> implements Callable<ExchangeResponse> {

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final /* synthetic */ String f802b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        final /* synthetic */ boolean f803c;

        f(String str, boolean z) {
            this.f802b = str;
            this.f803c = z;
        }

        @Override // java.util.concurrent.Callable
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public final ExchangeResponse call() throws JSONException {
            JSONObject jSONObjectA = SceneCloud.this.A();
            if (jSONObjectA != null) {
                try {
                    SceneCloud sceneCloud = SceneCloud.this;
                    String str = SceneCloud.i.a() + "/release-exchange";
                    JSONObject jSONObject = new JSONObject();
                    Locale localeG = SceneCloud.this.G();
                    if (localeG != null) {
                        jSONObject.put("locale", localeG.getLanguage());
                    }
                    jSONObject.put("key", this.f802b);
                    jSONObject.put("confirm", this.f803c);
                    jSONObject.put("device_info", jSONObjectA);
                    kotlin.s sVar = kotlin.s.a;
                    String strM = sceneCloud.m(str, jSONObject);
                    if (strM == null) {
                        throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
                    }
                    String string = kotlin.text.k.k0(strM).toString();
                    if (string.length() > 0) {
                        try {
                            Object objP = new com.omarea.net.a().p(string, new ExchangeResponse().getClass());
                            ((ExchangeResponse) objP).setDetail(string);
                            return (ExchangeResponse) objP;
                        } catch (Exception unused) {
                            return null;
                        }
                    }
                } catch (Exception unused2) {
                    Log.e("Scene", "Cloud Request(exchangeCode), Fail!");
                }
            }
            return null;
        }
    }

    static final class g<V> implements Callable<Boolean> {

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final /* synthetic */ String f805b;

        g(String str) {
            this.f805b = str;
        }

        @Override // java.util.concurrent.Callable
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public final Boolean call() {
            try {
                long time = new Date().getTime();
                SceneCloud sceneCloud = SceneCloud.this;
                String str = SceneCloud.i.a() + "/account-exist?t=" + time;
                JSONObject jSONObject = new JSONObject();
                Locale localeG = SceneCloud.this.G();
                if (localeG != null) {
                    jSONObject.put("locale", localeG.getLanguage());
                }
                jSONObject.put("uid", this.f805b);
                jSONObject.put("request_time", time);
                kotlin.s sVar = kotlin.s.a;
                String strM = sceneCloud.m(str, jSONObject);
                if (strM == null) {
                    throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
                }
                String string = kotlin.text.k.k0(strM).toString();
                if ((string.length() > 0) && kotlin.jvm.internal.r.a(string, "true")) {
                    return Boolean.TRUE;
                }
                return Boolean.FALSE;
            } catch (Exception unused) {
                Log.e("Scene", "Cloud Request(account exist), Fail!");
            }
        }
    }

    static final class h<V> implements Callable<ActivationCodeResponse> {
        h() {
        }

        @Override // java.util.concurrent.Callable
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public final ActivationCodeResponse call() throws JSONException {
            JSONObject jSONObjectA = SceneCloud.this.A();
            String strR0 = Daemon.E.a().r0();
            long time = new Date().getTime();
            if (jSONObjectA == null) {
                return null;
            }
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("device", jSONObjectA);
            Locale localeG = SceneCloud.this.G();
            if (localeG != null) {
                jSONObject.put("locale", localeG.getLanguage());
            }
            if (strR0 != null) {
                jSONObject.put("scene_version", strR0);
            }
            jSONObject.put("request_time", time);
            try {
                String strM = SceneCloud.this.m(SceneCloud.i.a() + "/release-activate2?t=" + time, jSONObject);
                if (strM == null) {
                    throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
                }
                String strL = SceneCloud.this.l(kotlin.text.k.k0(strM).toString());
                Object objP = new com.omarea.net.a().p(strL, new ActivationCodeResponse().getClass());
                ((ActivationCodeResponse) objP).setDetail(strL);
                return (ActivationCodeResponse) objP;
            } catch (Exception unused) {
                Log.e("Scene", "Cloud Sync(getActivationCode), Fail!");
                return null;
            }
        }
    }

    static final class i<V> implements Callable<String> {
        i() {
        }

        @Override // java.util.concurrent.Callable
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public final String call() throws JSONException {
            JSONObject jSONObjectA = SceneCloud.this.A();
            if (jSONObjectA == null) {
                return "";
            }
            try {
                SceneCloud sceneCloud = SceneCloud.this;
                String str = SceneCloud.i.a() + "/payment-alipay";
                JSONObject jSONObject = new JSONObject();
                Locale localeG = SceneCloud.this.G();
                if (localeG != null) {
                    jSONObject.put("locale", localeG.getLanguage());
                }
                jSONObject.put("device_info", jSONObjectA);
                kotlin.s sVar = kotlin.s.a;
                String strM = sceneCloud.m(str, jSONObject);
                if (strM == null) {
                    throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
                }
                String string = kotlin.text.k.k0(strM).toString();
                if (string.length() > 0) {
                    return string;
                }
                return null;
            } catch (Exception unused) {
                Log.e("Scene", "Cloud Request(alipay), Fail!");
                return null;
            }
        }
    }

    static final class j<V> implements Callable<ArrayList<b>> {

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final /* synthetic */ String f809b;

        j(String str) {
            this.f809b = str;
        }

        @Override // java.util.concurrent.Callable
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public final ArrayList<b> call() {
            String string;
            try {
                JSONObject jSONObjectA = SceneCloud.this.A();
                SceneCloud sceneCloud = SceneCloud.this;
                String str = SceneCloud.i.a() + "/account-devices";
                JSONObject jSONObject = new JSONObject();
                Locale localeG = SceneCloud.this.G();
                if (localeG != null) {
                    jSONObject.put("locale", localeG.getLanguage());
                }
                jSONObject.put("device_info", jSONObjectA);
                jSONObject.put("uid", this.f809b);
                jSONObject.put("password", "");
                kotlin.s sVar = kotlin.s.a;
                String strM = sceneCloud.m(str, jSONObject);
                if (strM == null) {
                    throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
                }
                String string2 = kotlin.text.k.k0(strM).toString();
                if (string2.length() > 0) {
                    try {
                        ArrayList<b> arrayList = new ArrayList<>();
                        JSONArray jSONArray = new JSONArray(string2);
                        int length = jSONArray.length();
                        for (int i = 0; i < length; i++) {
                            JSONObject jSONObject2 = jSONArray.getJSONObject(i);
                            b bVar = new b();
                            kotlin.jvm.internal.r.c(jSONObject2, "obj");
                            bVar.f(jSONObject2);
                            String string3 = jSONObject2.getString("device_id");
                            if (jSONObject2.has("product_model")) {
                                string = jSONObject2.getString("product_model");
                                kotlin.jvm.internal.r.c(string, "obj.getString(\"product_model\")");
                            } else {
                                string = "";
                            }
                            if (string.length() == 0) {
                                kotlin.jvm.internal.r.c(string3, "id");
                                string = string3;
                            }
                            bVar.d(jSONObject2.getBoolean("current"));
                            bVar.g(string);
                            kotlin.jvm.internal.r.c(string3, "id");
                            bVar.e(string3);
                            arrayList.add(bVar);
                        }
                        return arrayList;
                    } catch (Exception e) {
                        e.toString();
                        return null;
                    }
                }
                return null;
            } catch (Exception unused) {
                Log.e("Scene", "Cloud Request(exchangeCode), Fail!");
            }
        }
    }

    static final class k<V> implements Callable<MagiskModuleUnofficial> {

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final /* synthetic */ String f811b;

        k(String str) {
            this.f811b = str;
        }

        @Override // java.util.concurrent.Callable
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public final MagiskModuleUnofficial call() throws JSONException, IOException {
            JSONObject jSONObjectQ;
            SceneCloud sceneCloud = SceneCloud.this;
            String str = SceneCloud.i.a() + "/scene-magisk-detail";
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("dbId", this.f811b);
            kotlin.s sVar = kotlin.s.a;
            String strM = sceneCloud.m(str, jSONObject);
            if ((strM.length() == 0) || (jSONObjectQ = SceneCloud.this.q(strM)) == null) {
                return null;
            }
            return SceneCloud.this.O(jSONObjectQ);
        }
    }

    static final class l<V> implements Callable<ArrayList<MagiskModuleUnofficial>> {
        l() {
        }

        @Override // java.util.concurrent.Callable
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public final ArrayList<MagiskModuleUnofficial> call() throws JSONException {
            String strN = SceneCloud.this.n(SceneCloud.i.a() + "/scene-magisk-modules", "");
            if (strN.length() == 0) {
                return null;
            }
            JSONArray jSONArrayR = SceneCloud.this.r(strN);
            int length = jSONArrayR != null ? jSONArrayR.length() : 0;
            if (length <= 0) {
                return null;
            }
            ArrayList<MagiskModuleUnofficial> arrayList = new ArrayList<>();
            for (int i = 0; i < length; i++) {
                kotlin.jvm.internal.r.b(jSONArrayR);
                JSONObject jSONObject = jSONArrayR.getJSONObject(i);
                SceneCloud sceneCloud = SceneCloud.this;
                kotlin.jvm.internal.r.c(jSONObject, "item");
                arrayList.add(sceneCloud.O(jSONObject));
            }
            return arrayList;
        }
    }

    static final class m<V> implements Callable<LoginResponse> {

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final /* synthetic */ String f814b;

        m(String str) {
            this.f814b = str;
        }

        @Override // java.util.concurrent.Callable
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public final LoginResponse call() throws JSONException {
            JSONObject jSONObjectA = SceneCloud.this.A();
            if (jSONObjectA == null) {
                LoginResponse loginResponse = new LoginResponse();
                loginResponse.setError("无法获取设备标识");
                return loginResponse;
            }
            try {
                SceneCloud sceneCloud = SceneCloud.this;
                String str = SceneCloud.i.a() + "/account-unbind";
                JSONObject jSONObject = new JSONObject();
                Locale localeG = SceneCloud.this.G();
                if (localeG != null) {
                    jSONObject.put("locale", localeG.getLanguage());
                }
                jSONObject.put("uid", this.f814b);
                jSONObject.put("password", "");
                jSONObject.put("device_info", jSONObjectA);
                kotlin.s sVar = kotlin.s.a;
                String strM = sceneCloud.m(str, jSONObject);
                if (strM == null) {
                    throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
                }
                String string = kotlin.text.k.k0(strM).toString();
                if (string.length() > 0) {
                    try {
                        Object objP = new com.omarea.net.a().p(string, new LoginResponse().getClass());
                        ((LoginResponse) objP).setDetail(string);
                        return (LoginResponse) objP;
                    } catch (Exception unused) {
                        return null;
                    }
                }
                return null;
            } catch (Exception unused2) {
                Log.e("Scene", "Cloud Request(login), Fail!");
            }
        }
    }

    static final class n<V> implements Callable<LoginResponse> {

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final /* synthetic */ String f816b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        final /* synthetic */ String f817c;

        n(String str, String str2) {
            this.f816b = str;
            this.f817c = str2;
        }

        @Override // java.util.concurrent.Callable
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public final LoginResponse call() throws JSONException {
            JSONObject jSONObjectA = SceneCloud.this.A();
            String strR0 = Daemon.E.a().r0();
            if (jSONObjectA == null) {
                LoginResponse loginResponse = new LoginResponse();
                loginResponse.setError("无法获取设备标识");
                return loginResponse;
            }
            try {
                long time = new Date().getTime();
                SceneCloud sceneCloud = SceneCloud.this;
                String str = SceneCloud.i.a() + "/account-bind?t=" + time;
                JSONObject jSONObject = new JSONObject();
                Locale localeG = SceneCloud.this.G();
                if (localeG != null) {
                    jSONObject.put("locale", localeG.getLanguage());
                }
                if (strR0 != null) {
                    jSONObject.put("scene_version", strR0);
                }
                jSONObject.put("uid", this.f816b);
                jSONObject.put("password", SceneCloud.this.M(this.f817c));
                jSONObject.put("device_info", jSONObjectA);
                jSONObject.put("request_time", time);
                kotlin.s sVar = kotlin.s.a;
                String strM = sceneCloud.m(str, jSONObject);
                if (strM == null) {
                    throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
                }
                String string = kotlin.text.k.k0(strM).toString();
                if (string.length() > 0) {
                    try {
                        Object objP = new com.omarea.net.a().p(string, new LoginResponse().getClass());
                        ((LoginResponse) objP).setDetail(string);
                        return (LoginResponse) objP;
                    } catch (Exception unused) {
                        return null;
                    }
                }
                return null;
            } catch (Exception unused2) {
                Log.e("Scene", "Cloud Request(login), Fail!");
            }
        }
    }

    public static final class o extends com.omarea.library.shell.d {
        o(SceneCloud sceneCloud, Context context, String str) {
            super(context, str);
        }

        @Override // com.omarea.library.shell.d
        public String c() {
            if (kotlin.jvm.internal.r.a(Daemon.E.c(), "root")) {
                return com.omarea.common.shell.f.f471b.a("/sys/devices/soc0/machine");
            }
            return null;
        }
    }

    static final class p<V> implements Callable<Boolean> {

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final /* synthetic */ String f819b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        final /* synthetic */ String f820c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ int f821d;
        final /* synthetic */ String e;

        p(String str, String str2, int i, String str3) {
            this.f819b = str;
            this.f820c = str2;
            this.f821d = i;
            this.e = str3;
        }

        @Override // java.util.concurrent.Callable
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public final Boolean call() throws JSONException, IOException {
            SceneCloud sceneCloud = SceneCloud.this;
            String str = SceneCloud.i.a() + "/scene-magisk-like";
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("moduleId", this.f819b);
            jSONObject.put("uid", this.f820c);
            jSONObject.put("rank", this.f821d);
            jSONObject.put("message", this.e);
            kotlin.s sVar = kotlin.s.a;
            String strM = sceneCloud.m(str, jSONObject);
            if (!(strM.length() == 0)) {
                if (!(strM.length() == 0)) {
                    return Boolean.valueOf(kotlin.text.k.y(strM, "true", false, 2, (Object) null));
                }
            }
            return Boolean.FALSE;
        }
    }

    static final class q<V> implements Callable<LoginResponse> {

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final /* synthetic */ String f823b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        final /* synthetic */ String f824c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ JSONObject f825d;

        q(String str, String str2, JSONObject jSONObject) {
            this.f823b = str;
            this.f824c = str2;
            this.f825d = jSONObject;
        }

        @Override // java.util.concurrent.Callable
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public final LoginResponse call() {
            String strR0 = Daemon.E.a().r0();
            try {
                SceneCloud sceneCloud = SceneCloud.this;
                String str = SceneCloud.i.a() + "/account-unbind";
                JSONObject jSONObject = new JSONObject();
                Locale localeG = SceneCloud.this.G();
                if (localeG != null) {
                    jSONObject.put("locale", localeG.getLanguage());
                }
                if (strR0 != null) {
                    jSONObject.put("scene_version", strR0);
                }
                jSONObject.put("uid", this.f823b);
                jSONObject.put("password", SceneCloud.this.M(this.f824c));
                jSONObject.put("device_info", this.f825d);
                kotlin.s sVar = kotlin.s.a;
                String strM = sceneCloud.m(str, jSONObject);
                if (strM == null) {
                    throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
                }
                String string = kotlin.text.k.k0(strM).toString();
                if (string.length() > 0) {
                    try {
                        Object objP = new com.omarea.net.a().p(string, new LoginResponse().getClass());
                        ((LoginResponse) objP).setDetail(string);
                        return (LoginResponse) objP;
                    } catch (Exception unused) {
                        return null;
                    }
                }
                return null;
            } catch (Exception unused2) {
                Log.e("Scene", "Cloud Request(login), Fail!");
            }
        }
    }

    static final class r<V> implements Callable<ResetResponse> {

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final /* synthetic */ String f827b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        final /* synthetic */ String f828c;

        r(String str, String str2) {
            this.f827b = str;
            this.f828c = str2;
        }

        @Override // java.util.concurrent.Callable
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public final ResetResponse call() {
            try {
                SceneCloud sceneCloud = SceneCloud.this;
                String str = SceneCloud.i.a() + "/account-reset-pwd";
                JSONObject jSONObject = new JSONObject();
                Locale localeG = SceneCloud.this.G();
                if (localeG != null) {
                    jSONObject.put("locale", localeG.getLanguage());
                }
                jSONObject.put("token", this.f827b);
                jSONObject.put("password", SceneCloud.this.M(this.f828c));
                kotlin.s sVar = kotlin.s.a;
                String strM = sceneCloud.m(str, jSONObject);
                if (strM == null) {
                    throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
                }
                String string = kotlin.text.k.k0(strM).toString();
                if (string.length() > 0) {
                    try {
                        return (ResetResponse) new com.omarea.net.a().p(string, new ResetResponse().getClass());
                    } catch (Exception unused) {
                        return null;
                    }
                }
                return null;
            } catch (Exception unused2) {
                Log.e("Scene", "Cloud Request(ResetPWD), Fail!");
            }
        }
    }

    static final class s<V> implements Callable<LoginResponse> {

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final /* synthetic */ JSONObject f830b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        final /* synthetic */ String f831c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ String f832d;
        final /* synthetic */ boolean e;

        s(JSONObject jSONObject, String str, String str2, boolean z) {
            this.f830b = jSONObject;
            this.f831c = str;
            this.f832d = str2;
            this.e = z;
        }

        @Override // java.util.concurrent.Callable
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public final LoginResponse call() throws JSONException {
            JSONObject jSONObjectA = this.f830b;
            if (jSONObjectA == null) {
                jSONObjectA = SceneCloud.this.A();
            }
            String strR0 = Daemon.E.a().r0();
            if (jSONObjectA == null) {
                LoginResponse loginResponse = new LoginResponse();
                loginResponse.setError("无法获取设备标识");
                return loginResponse;
            }
            try {
                SceneCloud sceneCloud = SceneCloud.this;
                String str = SceneCloud.i.a() + "/account-set-main";
                JSONObject jSONObject = new JSONObject();
                Locale localeG = SceneCloud.this.G();
                if (localeG != null) {
                    jSONObject.put("locale", localeG.getLanguage());
                }
                if (strR0 != null) {
                    jSONObject.put("scene_version", strR0);
                }
                jSONObject.put("uid", this.f831c);
                jSONObject.put("password", SceneCloud.this.M(this.f832d));
                jSONObject.put("device_info", jSONObjectA);
                jSONObject.put("complement", this.e);
                kotlin.s sVar = kotlin.s.a;
                String strM = sceneCloud.m(str, jSONObject);
                if (strM == null) {
                    throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
                }
                String string = kotlin.text.k.k0(strM).toString();
                if (string.length() > 0) {
                    try {
                        Object objP = new com.omarea.net.a().p(string, new LoginResponse().getClass());
                        ((LoginResponse) objP).setDetail(string);
                        return (LoginResponse) objP;
                    } catch (Exception unused) {
                        return null;
                    }
                }
                return null;
            } catch (Exception unused2) {
                Log.e("Scene", "Cloud Request(login), Fail!");
            }
        }
    }

    static final class t<V> implements Callable<Boolean> {

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final /* synthetic */ JSONObject f834b;

        t(JSONObject jSONObject) {
            this.f834b = jSONObject;
        }

        @Override // java.util.concurrent.Callable
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public final Boolean call() throws JSONException, IOException {
            String strM = SceneCloud.this.m(SceneCloud.i.a() + "/scene-magisk-share", this.f834b);
            return !(strM.length() == 0) ? Boolean.valueOf(kotlin.text.k.y(strM, "true", false, 2, (Object) null)) : Boolean.FALSE;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public SceneCloud(Context context) {
        super(null, 1, null);
        kotlin.jvm.internal.r.d(context, "context");
        this.f = context;
        this.e = new o(this, this.f, "machine");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final JSONObject A() throws JSONException {
        JSONObject jSONObjectS0 = Daemon.E.a().s0();
        if (jSONObjectS0 != null) {
            jSONObjectS0.put("product_model", Build.MODEL);
            jSONObjectS0.put("product_name", Build.PRODUCT);
            jSONObjectS0.put("product_brand", Build.BRAND);
            jSONObjectS0.put("product_manufacturer", Build.MANUFACTURER);
            jSONObjectS0.put("product_device", Build.DEVICE);
            jSONObjectS0.put("machine", this.e);
        }
        return jSONObjectS0;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final Locale G() {
        if (Build.VERSION.SDK_INT < 24) {
            Resources resources = this.f.getResources();
            kotlin.jvm.internal.r.c(resources, "context.resources");
            return resources.getConfiguration().locale;
        }
        Resources resources2 = this.f.getResources();
        kotlin.jvm.internal.r.c(resources2, "context.resources");
        Configuration configuration = resources2.getConfiguration();
        kotlin.jvm.internal.r.c(configuration, "context.resources.configuration");
        return configuration.getLocales().get(0);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    public final MagiskModuleUnofficial O(JSONObject jSONObject) {
        MagiskModuleUnofficial magiskModuleUnofficial = new MagiskModuleUnofficial();
        try {
            Iterator<String> itKeys = jSONObject.keys();
            kotlin.jvm.internal.r.c(itKeys, "item.keys()");
            while (itKeys.hasNext()) {
                String next = itKeys.next();
                if (next != null) {
                    switch (next.hashCode()) {
                        case -1973090466:
                            if (!next.equals("detailUrl")) {
                                continue;
                            } else {
                                String string = jSONObject.getString(next);
                                kotlin.jvm.internal.r.c(string, "item.getString(it)");
                                magiskModuleUnofficial.setDetailUrl(string);
                            }
                            break;
                        case -1724546052:
                            if (!next.equals("description")) {
                                continue;
                            } else {
                                magiskModuleUnofficial.setDescription(jSONObject.getString(next));
                            }
                            break;
                        case -1406328437:
                            if (!next.equals("author")) {
                                continue;
                            } else {
                                magiskModuleUnofficial.setAuthor(jSONObject.getString(next));
                            }
                            break;
                        case -1211148345:
                            if (!next.equals("downloadUrl")) {
                                continue;
                            } else {
                                String string2 = jSONObject.getString(next);
                                kotlin.jvm.internal.r.c(string2, "item.getString(it)");
                                magiskModuleUnofficial.setDownloadUrl(string2);
                            }
                            break;
                        case -980226692:
                            if (!next.equals("praise")) {
                                continue;
                            } else {
                                magiskModuleUnofficial.setPraise(jSONObject.getInt(next));
                            }
                            break;
                        case -896505829:
                            if (!next.equals("source")) {
                                continue;
                            } else {
                                magiskModuleUnofficial.setSource(jSONObject.getString(next));
                            }
                            break;
                        case 3355:
                            if (!next.equals("id")) {
                                continue;
                            } else {
                                String string3 = jSONObject.getString(next);
                                kotlin.jvm.internal.r.c(string3, "item.getString(it)");
                                magiskModuleUnofficial.setId(string3);
                            }
                            break;
                        case 115792:
                            if (!next.equals("uid")) {
                                continue;
                            } else {
                                String string4 = jSONObject.getString(next);
                                kotlin.jvm.internal.r.c(string4, "item.getString(it)");
                                magiskModuleUnofficial.setUid(string4);
                            }
                            break;
                        case 3075641:
                            if (!next.equals("dbId")) {
                                continue;
                            } else {
                                magiskModuleUnofficial.setDbId(jSONObject.getString(next));
                            }
                            break;
                        case 3321751:
                            if (!next.equals("like")) {
                                continue;
                            } else {
                                magiskModuleUnofficial.setLike(jSONObject.getInt(next));
                            }
                            break;
                        case 3373707:
                            if (!next.equals("name")) {
                                continue;
                            } else {
                                magiskModuleUnofficial.setName(jSONObject.getString(next));
                            }
                            break;
                        case 3492908:
                            if (!next.equals("rank")) {
                                continue;
                            } else {
                                magiskModuleUnofficial.setRank(jSONObject.getDouble(next));
                            }
                            break;
                        case 688591589:
                            if (next.equals("versionCode")) {
                                try {
                                    magiskModuleUnofficial.setVersionCode(String.valueOf(jSONObject.getLong(next)));
                                } catch (Exception unused) {
                                    magiskModuleUnofficial.setVersionCode(jSONObject.getString(next));
                                }
                            }
                            break;
                        case 688906115:
                            if (!next.equals("versionName")) {
                                continue;
                            } else {
                                magiskModuleUnofficial.setVersionName(jSONObject.getString(next));
                            }
                            break;
                        case 1312704747:
                            if (!next.equals("downloads")) {
                                continue;
                            } else {
                                magiskModuleUnofficial.setDownloads(jSONObject.getInt(next));
                            }
                            break;
                        case 1671642405:
                            if (!next.equals("dislike")) {
                                continue;
                            } else {
                                magiskModuleUnofficial.setDislike(jSONObject.getInt(next));
                            }
                            break;
                        case 2059003624:
                            if (!next.equals("detailContent")) {
                                continue;
                            } else {
                                String string5 = jSONObject.getString(next);
                                kotlin.jvm.internal.r.c(string5, "item.getString(it)");
                                magiskModuleUnofficial.setDetailContent(string5);
                            }
                            break;
                        default:
                            continue;
                    }
                    MagiskModuleUnofficial magiskModuleUnofficial2 = new MagiskModuleUnofficial();
                    magiskModuleUnofficial2.setName("Parse failure");
                    magiskModuleUnofficial2.setDescription(jSONObject.toString());
                    return magiskModuleUnofficial2;
                }
            }
            return magiskModuleUnofficial;
        } catch (Exception unused2) {
            MagiskModuleUnofficial magiskModuleUnofficial3 = new MagiskModuleUnofficial();
            magiskModuleUnofficial3.setName("Parse failure");
            magiskModuleUnofficial3.setDescription(jSONObject.toString());
            return magiskModuleUnofficial3;
        }
    }

    public static /* synthetic */ FutureTask S(SceneCloud sceneCloud, String str, String str2, boolean z, JSONObject jSONObject, int i2, Object obj) {
        if ((i2 & 4) != 0) {
            z = false;
        }
        if ((i2 & 8) != 0) {
            jSONObject = null;
        }
        return sceneCloud.R(str, str2, z, jSONObject);
    }

    public final FutureTask<ExchangeResponse> B(String str, boolean z) {
        kotlin.jvm.internal.r.d(str, "key");
        FutureTask<ExchangeResponse> futureTask = new FutureTask<>(new f(str, z));
        kotlinx.coroutines.f.d(i0.a(w0.b()), (CoroutineContext) null, (CoroutineStart) null, new SceneCloud$exchangeCode$1(futureTask, null), 3, (Object) null);
        return futureTask;
    }

    public final FutureTask<Boolean> C(String str) {
        kotlin.jvm.internal.r.d(str, "uid");
        FutureTask<Boolean> futureTask = new FutureTask<>(new g(str));
        kotlinx.coroutines.f.d(i0.a(w0.b()), (CoroutineContext) null, (CoroutineStart) null, new SceneCloud$exist$1(futureTask, null), 3, (Object) null);
        return futureTask;
    }

    public final FutureTask<ActivationCodeResponse> D() {
        FutureTask<ActivationCodeResponse> futureTask = new FutureTask<>(new h());
        kotlinx.coroutines.f.d(i0.a(w0.b()), (CoroutineContext) null, (CoroutineStart) null, new SceneCloud$getActivationCode$1(futureTask, null), 3, (Object) null);
        return futureTask;
    }

    public final FutureTask<String> E() {
        FutureTask<String> futureTask = new FutureTask<>(new i());
        kotlinx.coroutines.f.d(i0.a(w0.b()), (CoroutineContext) null, (CoroutineStart) null, new SceneCloud$getAlipayStr$1(futureTask, null), 3, (Object) null);
        return futureTask;
    }

    public final FutureTask<ArrayList<b>> F(String str) {
        kotlin.jvm.internal.r.d(str, "uid");
        FutureTask<ArrayList<b>> futureTask = new FutureTask<>(new j(str));
        kotlinx.coroutines.f.d(i0.a(w0.b()), (CoroutineContext) null, (CoroutineStart) null, new SceneCloud$getDevices$1(futureTask, null), 3, (Object) null);
        return futureTask;
    }

    public final FutureTask<MagiskModuleUnofficial> H(String str) {
        kotlin.jvm.internal.r.d(str, "dbId");
        FutureTask<MagiskModuleUnofficial> futureTask = new FutureTask<>(new k(str));
        kotlinx.coroutines.f.d(i0.a(w0.b()), (CoroutineContext) null, (CoroutineStart) null, new SceneCloud$getModuleDetail$1(futureTask, null), 3, (Object) null);
        return futureTask;
    }

    public final FutureTask<ArrayList<MagiskModuleUnofficial>> I() {
        FutureTask<ArrayList<MagiskModuleUnofficial>> futureTask = new FutureTask<>(new l());
        kotlinx.coroutines.f.d(i0.a(w0.b()), (CoroutineContext) null, (CoroutineStart) null, new SceneCloud$getModules$1(futureTask, null), 3, (Object) null);
        return futureTask;
    }

    /* JADX WARN: Code duplicated, block: B:14:0x0030  */
    /* JADX WARN: Code duplicated, block: B:16:0x0045  */
    /* JADX WARN: Code duplicated, block: B:19:0x005a  */
    /* JADX WARN: Code duplicated, block: B:22:0x0064  */
    /* JADX WARN: Code duplicated, block: B:24:0x006c  */
    /* JADX WARN: Code duplicated, block: B:27:0x00c8 A[LOOP:1: B:25:0x00c2->B:27:0x00c8, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:33:0x0105  */
    /* JADX WARN: Code duplicated, block: B:35:0x0166  */
    /* JADX WARN: Code duplicated, block: B:37:0x0170  */
    /* JADX WARN: Code duplicated, block: B:38:0x0179  */
    /* JADX WARN: Code duplicated, block: B:40:0x0183  */
    /* JADX WARN: Code duplicated, block: B:43:0x01a5  */
    /* JADX WARN: Code duplicated, block: B:45:0x01af  */
    /* JADX WARN: Code duplicated, block: B:49:0x00fa A[SYNTHETIC] */
    public final void J() throws JSONException, IOException {
        JSONObject jSONObject;
        Locale localeG;
        ArrayList<String[]> arrayListH;
        String str;
        String strM;
        Object objI;
        int i2;
        JSONObject jSONObject2;
        if (h) {
            return;
        }
        CpuFrequencyUtils cpuFrequencyUtils = new CpuFrequencyUtils();
        String string = this.e.toString();
        String strB = new com.omarea.library.shell.r().b();
        int i3 = 0;
        if (string.length() > 0) {
            jSONObject = new JSONObject();
            jSONObject.put("machine", string);
            jSONObject.put("platform", strB);
            localeG = G();
            if (localeG != null) {
                jSONObject.put("locale", localeG.getLanguage());
            }
            arrayListH = cpuFrequencyUtils.h();
            if (arrayListH != null) {
                for (Object obj : arrayListH) {
                    i2 = i3 + 1;
                    if (i3 >= 0) {
                        kotlin.collections.q.j();
                        throw null;
                    }
                    JSONObject jSONObject3 = new JSONObject();
                    jSONObject3.put("governor", cpuFrequencyUtils.q(Integer.valueOf(i3)));
                    jSONObject3.put("governors", new JSONArray(cpuFrequencyUtils.g(Integer.valueOf(i3))));
                    jSONObject3.put("related_cpus", new JSONArray((String[]) obj));
                    jSONObject3.put("frequencies", new JSONArray(cpuFrequencyUtils.f(Integer.valueOf(i3))));
                    jSONObject2 = new JSONObject();
                    HashMap<String, String> mapJ = cpuFrequencyUtils.j(Integer.valueOf(i3));
                    kotlin.jvm.internal.r.c(mapJ, "cpuUtils.getCoreGovernorParams(index)");
                    for (Map.Entry<String, String> entry : mapJ.entrySet()) {
                        jSONObject2.put(entry.getKey(), entry.getValue());
                    }
                    kotlin.s sVar = kotlin.s.a;
                    jSONObject3.put("governor-params", jSONObject2);
                    jSONObject.put("cluster" + i3, jSONObject3);
                    i3 = i2;
                }
            }
            if (com.omarea.library.shell.n.x()) {
                JSONObject jSONObject4 = new JSONObject();
                jSONObject4.put("max_power_level", com.omarea.library.shell.n.k());
                jSONObject4.put("min_power_level", com.omarea.library.shell.n.l());
                jSONObject4.put("def_power_level", com.omarea.library.shell.n.j());
                jSONObject4.put("power_levels", new JSONArray(com.omarea.library.shell.n.m()));
                jSONObject4.put("frequencies", new JSONArray(com.omarea.library.shell.n.n()));
                jSONObject4.put("governors", new JSONArray(com.omarea.library.shell.n.q()));
                jSONObject4.put("governor", com.omarea.library.shell.n.p());
                jSONObject4.put("freq_table_mhz", new JSONArray(com.omarea.library.shell.n.o()));
                str = "adreno-gpu";
                objI = jSONObject4;
            } else if (com.omarea.common.shell.g.f472a.d("/proc/gpufreq/gpufreq_opp_dump")) {
                str = "mali-gpu";
                objI = com.omarea.common.shell.g.f472a.i("/proc/gpufreq/gpufreq_opp_dump");
            } else {
                if (com.omarea.common.shell.g.f472a.d("/proc/gpufreqv2/stack_signed_opp_table")) {
                    str = "mali-gpu-v2";
                    objI = com.omarea.common.shell.g.f472a.i("/proc/gpufreqv2/stack_signed_opp_table");
                }
                strM = m(g + "/hardware-properties", jSONObject);
                if (strM != null) {
                    throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
                }
                kotlin.text.k.k0(strM).toString();
            }
            jSONObject.put(str, objI);
            strM = m(g + "/hardware-properties", jSONObject);
            if (strM != null) {
                throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
            }
            kotlin.text.k.k0(strM).toString();
        } else if (strB.length() > 0) {
            jSONObject = new JSONObject();
            jSONObject.put("machine", string);
            jSONObject.put("platform", strB);
            localeG = G();
            if (localeG != null) {
                jSONObject.put("locale", localeG.getLanguage());
            }
            arrayListH = cpuFrequencyUtils.h();
            if (arrayListH != null) {
                while (r1.hasNext()) {
                    i2 = i3 + 1;
                    if (i3 >= 0) {
                        kotlin.collections.q.j();
                        throw null;
                    }
                    JSONObject jSONObject5 = new JSONObject();
                    jSONObject5.put("governor", cpuFrequencyUtils.q(Integer.valueOf(i3)));
                    jSONObject5.put("governors", new JSONArray(cpuFrequencyUtils.g(Integer.valueOf(i3))));
                    jSONObject5.put("related_cpus", new JSONArray((String[]) obj));
                    jSONObject5.put("frequencies", new JSONArray(cpuFrequencyUtils.f(Integer.valueOf(i3))));
                    jSONObject2 = new JSONObject();
                    HashMap<String, String> mapJ2 = cpuFrequencyUtils.j(Integer.valueOf(i3));
                    kotlin.jvm.internal.r.c(mapJ2, "cpuUtils.getCoreGovernorParams(index)");
                    while (r11.hasNext()) {
                        jSONObject2.put(entry.getKey(), entry.getValue());
                    }
                    kotlin.s sVar2 = kotlin.s.a;
                    jSONObject5.put("governor-params", jSONObject2);
                    jSONObject.put("cluster" + i3, jSONObject5);
                    i3 = i2;
                }
            }
            if (com.omarea.library.shell.n.x()) {
                JSONObject jSONObject6 = new JSONObject();
                jSONObject6.put("max_power_level", com.omarea.library.shell.n.k());
                jSONObject6.put("min_power_level", com.omarea.library.shell.n.l());
                jSONObject6.put("def_power_level", com.omarea.library.shell.n.j());
                jSONObject6.put("power_levels", new JSONArray(com.omarea.library.shell.n.m()));
                jSONObject6.put("frequencies", new JSONArray(com.omarea.library.shell.n.n()));
                jSONObject6.put("governors", new JSONArray(com.omarea.library.shell.n.q()));
                jSONObject6.put("governor", com.omarea.library.shell.n.p());
                jSONObject6.put("freq_table_mhz", new JSONArray(com.omarea.library.shell.n.o()));
                str = "adreno-gpu";
                objI = jSONObject6;
            } else if (com.omarea.common.shell.g.f472a.d("/proc/gpufreq/gpufreq_opp_dump")) {
                str = "mali-gpu";
                objI = com.omarea.common.shell.g.f472a.i("/proc/gpufreq/gpufreq_opp_dump");
            } else {
                if (com.omarea.common.shell.g.f472a.d("/proc/gpufreqv2/stack_signed_opp_table")) {
                    str = "mali-gpu-v2";
                    objI = com.omarea.common.shell.g.f472a.i("/proc/gpufreqv2/stack_signed_opp_table");
                }
                strM = m(g + "/hardware-properties", jSONObject);
                if (strM != null) {
                    throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
                }
                kotlin.text.k.k0(strM).toString();
            }
            jSONObject.put(str, objI);
            strM = m(g + "/hardware-properties", jSONObject);
            if (strM != null) {
                throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
            }
            kotlin.text.k.k0(strM).toString();
        }
        h = true;
    }

    public final FutureTask<LoginResponse> K(String str, String str2) {
        kotlin.jvm.internal.r.d(str, "uid");
        kotlin.jvm.internal.r.d(str2, "password");
        FutureTask<LoginResponse> futureTask = new FutureTask<>(new m(str));
        kotlinx.coroutines.f.d(i0.a(w0.b()), (CoroutineContext) null, (CoroutineStart) null, new SceneCloud$logOut$1(futureTask, null), 3, (Object) null);
        return futureTask;
    }

    public final FutureTask<LoginResponse> L(String str, String str2) {
        kotlin.jvm.internal.r.d(str, "uid");
        kotlin.jvm.internal.r.d(str2, "password");
        FutureTask<LoginResponse> futureTask = new FutureTask<>(new n(str, str2));
        kotlinx.coroutines.f.d(i0.a(w0.b()), (CoroutineContext) null, (CoroutineStart) null, new SceneCloud$login$1(futureTask, null), 3, (Object) null);
        return futureTask;
    }

    public final String M(String str) {
        kotlin.jvm.internal.r.d(str, "password");
        try {
            MessageDigest messageDigest = MessageDigest.getInstance("MD5");
            kotlin.jvm.internal.r.c(messageDigest, "MessageDigest.getInstance(\"MD5\")");
            byte[] bytes = str.getBytes(kotlin.text.d.a);
            kotlin.jvm.internal.r.c(bytes, "(this as java.lang.String).getBytes(charset)");
            byte[] bArrDigest = messageDigest.digest(bytes);
            kotlin.jvm.internal.r.c(bArrDigest, "instance.digest(password.toByteArray())");
            StringBuffer stringBuffer = new StringBuffer();
            for (byte b2 : bArrDigest) {
                String hexString = Integer.toHexString(b2 & 255);
                if (hexString.length() < 2) {
                    hexString = "0" + hexString;
                }
                stringBuffer.append(hexString);
            }
            String string = stringBuffer.toString();
            kotlin.jvm.internal.r.c(string, "sb.toString()");
            return string;
        } catch (NoSuchAlgorithmException e2) {
            e2.printStackTrace();
            return "";
        }
    }

    public final FutureTask<Boolean> N(String str, String str2, int i2, String str3) {
        kotlin.jvm.internal.r.d(str, "dbId");
        kotlin.jvm.internal.r.d(str2, "uid");
        kotlin.jvm.internal.r.d(str3, "message");
        FutureTask<Boolean> futureTask = new FutureTask<>(new p(str, str2, i2, str3));
        kotlinx.coroutines.f.d(i0.a(w0.b()), (CoroutineContext) null, (CoroutineStart) null, new SceneCloud$moduleRankSend$1(futureTask, null), 3, (Object) null);
        return futureTask;
    }

    public final FutureTask<LoginResponse> P(String str, String str2, JSONObject jSONObject) {
        kotlin.jvm.internal.r.d(str, "uid");
        kotlin.jvm.internal.r.d(str2, "password");
        kotlin.jvm.internal.r.d(jSONObject, "deviceInfo");
        FutureTask<LoginResponse> futureTask = new FutureTask<>(new q(str, str2, jSONObject));
        kotlinx.coroutines.f.d(i0.a(w0.b()), (CoroutineContext) null, (CoroutineStart) null, new SceneCloud$removeDevice$1(futureTask, null), 3, (Object) null);
        return futureTask;
    }

    public final FutureTask<ResetResponse> Q(String str, String str2) {
        kotlin.jvm.internal.r.d(str, "token");
        kotlin.jvm.internal.r.d(str2, "password");
        FutureTask<ResetResponse> futureTask = new FutureTask<>(new r(str, str2));
        kotlinx.coroutines.f.d(i0.a(w0.b()), (CoroutineContext) null, (CoroutineStart) null, new SceneCloud$resetPwd$1(futureTask, null), 3, (Object) null);
        return futureTask;
    }

    public final FutureTask<LoginResponse> R(String str, String str2, boolean z, JSONObject jSONObject) {
        kotlin.jvm.internal.r.d(str, "uid");
        kotlin.jvm.internal.r.d(str2, "password");
        FutureTask<LoginResponse> futureTask = new FutureTask<>(new s(jSONObject, str, str2, z));
        kotlinx.coroutines.f.d(i0.a(w0.b()), (CoroutineContext) null, (CoroutineStart) null, new SceneCloud$setMainDevice$1(futureTask, null), 3, (Object) null);
        return futureTask;
    }

    public final FutureTask<Boolean> T(MagiskModuleUnofficial magiskModuleUnofficial) throws JSONException {
        kotlin.jvm.internal.r.d(magiskModuleUnofficial, "moduleInfo");
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("id", magiskModuleUnofficial.getId());
        jSONObject.put("dbId", magiskModuleUnofficial.getDbId());
        jSONObject.put("name", magiskModuleUnofficial.getName());
        try {
            String versionCode = magiskModuleUnofficial.getVersionCode();
            kotlin.jvm.internal.r.b(versionCode);
            jSONObject.put("versionCode", Integer.parseInt(versionCode));
        } catch (Exception unused) {
        }
        jSONObject.put("versionName", magiskModuleUnofficial.getVersionName());
        jSONObject.put("downloadUrl", magiskModuleUnofficial.getDownloadUrl());
        jSONObject.put("author", magiskModuleUnofficial.getAuthor());
        jSONObject.put("description", magiskModuleUnofficial.getDescription());
        jSONObject.put("detailContent", magiskModuleUnofficial.getDetailContent());
        jSONObject.put("uid", magiskModuleUnofficial.getUid());
        FutureTask<Boolean> futureTask = new FutureTask<>(new t(jSONObject));
        kotlinx.coroutines.f.d(i0.a(w0.b()), (CoroutineContext) null, (CoroutineStart) null, new SceneCloud$uploadModule$1(futureTask, null), 3, (Object) null);
        return futureTask;
    }

    public final FutureTask<AccountIntegralResponse> x(String str, String str2) {
        kotlin.jvm.internal.r.d(str, "uid");
        kotlin.jvm.internal.r.d(str2, "password");
        FutureTask<AccountIntegralResponse> futureTask = new FutureTask<>(new c(str, str2));
        kotlinx.coroutines.f.d(i0.a(w0.b()), (CoroutineContext) null, (CoroutineStart) null, new SceneCloud$accountIntegral$1(futureTask, null), 3, (Object) null);
        return futureTask;
    }

    public final FutureTask<String> y() {
        FutureTask<String> futureTask = new FutureTask<>(new d());
        kotlinx.coroutines.f.d(i0.a(w0.b()), (CoroutineContext) null, (CoroutineStart) null, new SceneCloud$announcement$1(futureTask, null), 3, (Object) null);
        return futureTask;
    }

    public final FutureTask<Boolean> z(String str, String str2) {
        kotlin.jvm.internal.r.d(str, "dbId");
        kotlin.jvm.internal.r.d(str2, "uid");
        FutureTask<Boolean> futureTask = new FutureTask<>(new e(str, str2));
        kotlinx.coroutines.f.d(i0.a(w0.b()), (CoroutineContext) null, (CoroutineStart) null, new SceneCloud$deleteModule$1(futureTask, null), 3, (Object) null);
        return futureTask;
    }
}
