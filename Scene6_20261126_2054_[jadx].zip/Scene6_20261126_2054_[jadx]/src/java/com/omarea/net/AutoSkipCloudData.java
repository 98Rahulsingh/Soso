package com.omarea.net;

import android.content.Context;
import kotlin.jvm.internal.r;
import kotlinx.coroutines.CoroutineStart;
import kotlinx.coroutines.f;
import kotlinx.coroutines.h1;
import kotlinx.coroutines.w0;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class AutoSkipCloudData {
    public final void a(Context context, boolean z) {
        r.d(context, "context");
        f.d(h1.f, w0.b(), (CoroutineStart) null, new AutoSkipCloudData$updateConfig$1(z, context, null), 2, (Object) null);
    }
}
