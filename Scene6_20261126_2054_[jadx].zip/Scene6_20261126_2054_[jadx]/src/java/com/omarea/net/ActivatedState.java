package com.omarea.net;

import android.content.Context;
import android.content.SharedPreferences;
import com.omarea.Scene;
import com.omarea.common.net.Daemon;
import com.omarea.library.shell.d;
import com.omarea.store.j;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import kotlin.h;
import kotlin.jvm.internal.r;
import kotlin.s;
import kotlin.text.k;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class ActivatedState {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final d f785a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final Context f786b;

    public interface a {
        Object a(kotlin.coroutines.c<? super s> cVar);

        Object b(boolean z, String str, kotlin.coroutines.c<? super s> cVar);
    }

    public static final class b {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private boolean f787a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private String f788b = "";

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private String f789c = "";

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        private String f790d = "";

        public final boolean a() {
            return this.f787a;
        }

        public final String b() {
            return this.f788b;
        }

        public final String c() {
            return this.f789c;
        }

        public final String d() {
            return this.f790d;
        }

        public final void e(boolean z) {
            this.f787a = z;
        }

        public final void f(boolean z) {
        }

        public final void g(String str) {
            r.d(str, "<set-?>");
            this.f788b = str;
        }

        public final void h(String str) {
            r.d(str, "<set-?>");
            this.f789c = str;
        }

        public final void i(String str) {
            r.d(str, "<set-?>");
            this.f790d = str;
        }
    }

    public static final class c extends d {
        c(Context context, String str) {
            super(context, str);
        }

        @Override // com.omarea.library.shell.d
        public String c() {
            Daemon daemonA = Daemon.E.a();
            Scene.a aVar = Scene.l;
            String str = j.l;
            r.c(str, "SpfConfig.ACTIVATE_CODE");
            String strD = aVar.d(str, "");
            r.b(strD);
            return daemonA.W(strD);
        }
    }

    public ActivatedState(Context context) {
        r.d(context, "context");
        this.f786b = context;
        this.f785a = new c(Scene.l.b(), "pro_key_expire_date");
    }

    public static /* synthetic */ Object b(ActivatedState activatedState, a aVar, kotlin.coroutines.c cVar, int i, Object obj) {
        if ((i & 1) != 0) {
            aVar = null;
        }
        return activatedState.a(aVar, cVar);
    }

    private final b d(String str) {
        b bVar;
        String string;
        String str2;
        String string2 = this.f785a.toString();
        if (k.y(string2, "success@", false, 2, (Object) null)) {
            try {
                int iG = k.G(string2, '@', 0, false, 6, (Object) null) + 1;
                if (string2 == null) {
                    throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                }
                String strSubstring = string2.substring(iG);
                r.c(strSubstring, "(this as java.lang.String).substring(startIndex)");
                long j = Long.parseLong(strSubstring);
                if (j < 1000000000000L) {
                    j *= (long) 1000;
                }
                String str3 = new SimpleDateFormat("YYYY-MM-dd").format(new Date(j));
                b bVar2 = new b();
                bVar2.e(true);
                bVar2.g(str + str3);
                return bVar2;
            } catch (Exception unused) {
                b bVar3 = new b();
                bVar3.e(false);
                bVar3.g(str + "??");
                return bVar3;
            }
        }
        if (r.a(string2, "expired")) {
            Scene.l.c().edit().remove(j.l).remove(j.m).apply();
            bVar = new b();
            bVar.e(false);
            string = this.f786b.getString(2131886877);
            str2 = "context.getString(R.string.license_state_expired)";
        } else if (r.a(string2, "empty")) {
            bVar = new b();
            bVar.e(false);
            string = this.f786b.getString(2131886879);
            str2 = "context.getString(R.stri…ense_state_not_activated)";
        } else if (r.a(string2, "invalid") || r.a(string2, "not-you")) {
            bVar = new b();
            bVar.e(false);
            string = this.f786b.getString(2131886878);
            str2 = "context.getString(R.string.license_state_invalid)";
        } else {
            bVar = new b();
            bVar.e(false);
            string = this.f786b.getString(2131886880);
            str2 = "context.getString(R.string.license_state_unknown)";
        }
        r.c(string, str2);
        bVar.g(string);
        return bVar;
    }

    /* JADX WARN: Code duplicated, block: B:7:0x001b  */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r2v0, types: [com.omarea.net.ActivatedState$a, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r2v3 */
    public final Object a(a aVar, kotlin.coroutines.c<? super s> cVar) throws Throwable {
        ActivatedState$cloudSync$1 activatedState$cloudSync$1;
        boolean z;
        SceneCloud.ActivationCodeResponse activationCodeResponse;
        boolean z2;
        String string;
        ActivatedState activatedState;
        StringBuilder sb;
        ActivatedState activatedState2;
        ActivatedState activatedState3 = aVar;
        if (cVar instanceof ActivatedState$cloudSync$1) {
            activatedState$cloudSync$1 = (ActivatedState$cloudSync$1) cVar;
            int i = activatedState$cloudSync$1.label;
            if ((i & Integer.MIN_VALUE) != 0) {
                activatedState$cloudSync$1.label = i - Integer.MIN_VALUE;
            } else {
                activatedState$cloudSync$1 = new ActivatedState$cloudSync$1(this, cVar);
            }
        } else {
            activatedState$cloudSync$1 = new ActivatedState$cloudSync$1(this, cVar);
        }
        Object obj = activatedState$cloudSync$1.result;
        Object objD = kotlin.coroutines.intrinsics.a.d();
        int i2 = activatedState$cloudSync$1.label;
        boolean z3 = true;
        try {
            if (i2 != 0) {
                if (i2 != 1) {
                    if (i2 != 2) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    activatedState = (ActivatedState) activatedState$cloudSync$1.L$0;
                    h.b(obj);
                    activatedState.f785a.d();
                    return s.a;
                }
                activatedState2 = (ActivatedState) activatedState$cloudSync$1.L$0;
                h.b(obj);
                s sVar = s.a;
                activatedState2.f785a.d();
                return sVar;
            }
            h.b(obj);
            SharedPreferences sharedPreferencesC = Scene.l.c();
            String string2 = sharedPreferencesC.getString(j.l, "");
            String code = string2 != null ? string2 : "";
            r.c(code, "globalSPF.getString(SpfC…g.ACTIVATE_CODE, \"\")?: \"\"");
            try {
                try {
                    activationCodeResponse = new SceneCloud(Scene.l.b()).D().get(10L, TimeUnit.SECONDS);
                    z = false;
                } catch (Exception e) {
                    Scene.l.k(this.f786b.getString(2131886881) + e.getMessage());
                    z = true;
                    activationCodeResponse = null;
                }
                if (activationCodeResponse != null && (activationCodeResponse.getPass() || activationCodeResponse.getExpired())) {
                    code = activationCodeResponse.getCode();
                    Scene.l.c().edit().putString(j.l, code).putString(j.m, activationCodeResponse.getType()).apply();
                    if (activationCodeResponse.getAccount().length() > 0) {
                        Scene.l.c().edit().putString(j.n, activationCodeResponse.getAccount()).apply();
                    }
                }
                if (code.length() > 0) {
                    String strW = Daemon.E.a().W(code);
                    if (k.y(strW, "success", false, 2, (Object) null)) {
                        sharedPreferencesC.edit().putString(j.f918a, "root").apply();
                        if (activatedState3 != 0) {
                            activatedState$cloudSync$1.L$0 = this;
                            activatedState$cloudSync$1.L$1 = activatedState3;
                            activatedState$cloudSync$1.L$2 = sharedPreferencesC;
                            activatedState$cloudSync$1.L$3 = code;
                            activatedState$cloudSync$1.L$4 = null;
                            activatedState$cloudSync$1.L$5 = activationCodeResponse;
                            activatedState$cloudSync$1.L$6 = strW;
                            activatedState$cloudSync$1.label = 1;
                            if (activatedState3.a(activatedState$cloudSync$1) == objD) {
                                return objD;
                            }
                        }
                        activatedState2 = this;
                        s sVar2 = s.a;
                        activatedState2.f785a.d();
                        return sVar2;
                    }
                    if (k.y(strW, "expired", false, 2, (Object) null)) {
                        sharedPreferencesC.edit().remove(j.f918a).apply();
                        string = this.f786b.getString(2131886872);
                    } else {
                        if (k.y(strW, "not-you", false, 2, (Object) null) || k.y(strW, "invalid", false, 2, (Object) null) || k.y(strW, "expired", false, 2, (Object) null)) {
                            sharedPreferencesC.edit().remove(j.f918a).apply();
                            sb = new StringBuilder();
                            sb.append(this.f786b.getString(2131886873));
                            sb.append('\n');
                            sb.append(code);
                            sb.append('\n');
                            sb.append(strW);
                        } else if (r.a(strW, "error")) {
                            string = this.f786b.getString(2131886871);
                            z2 = true;
                        } else {
                            sb = new StringBuilder();
                            sb.append(this.f786b.getString(2131886884));
                            sb.append('\n');
                            sb.append(code);
                            sb.append('\n');
                            sb.append(strW);
                        }
                        string = sb.toString();
                    }
                    z2 = false;
                } else {
                    z2 = false;
                    string = null;
                }
                if (z) {
                    Scene.a aVar2 = Scene.l;
                    String string3 = this.f786b.getString(2131886882);
                    r.c(string3, "context.getString(R.string.license_sync_timeout)");
                    aVar2.l(string3, 1);
                } else if (string == null) {
                    String code2 = activationCodeResponse != null ? activationCodeResponse.getCode() : null;
                    if (code2 != null && code2.length() != 0) {
                        z3 = false;
                    }
                    if (z3) {
                        Scene.a aVar3 = Scene.l;
                        String string4 = this.f786b.getString(2131886875);
                        r.c(string4, "context.getString(R.string.license_no_response)");
                        aVar3.k(string4);
                    }
                } else {
                    Scene.l.k(string);
                }
                if (activatedState3 != 0) {
                    activatedState$cloudSync$1.L$0 = this;
                    activatedState$cloudSync$1.L$1 = activatedState3;
                    activatedState$cloudSync$1.L$2 = sharedPreferencesC;
                    activatedState$cloudSync$1.L$3 = code;
                    activatedState$cloudSync$1.L$4 = string;
                    activatedState$cloudSync$1.L$5 = activationCodeResponse;
                    activatedState$cloudSync$1.label = 2;
                    if (activatedState3.b(z2, code, activatedState$cloudSync$1) == objD) {
                        return objD;
                    }
                }
                activatedState = this;
                activatedState.f785a.d();
                return s.a;
            } catch (Throwable th) {
                th = th;
                activatedState3 = this;
                activatedState3.f785a.d();
                throw th;
            }
        } catch (Throwable th2) {
            th = th2;
        }
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code duplicated, block: B:20:0x00bb  */
    public final b c() {
        b bVarD;
        String string;
        String str;
        Scene.a aVar = Scene.l;
        String str2 = j.l;
        r.c(str2, "SpfConfig.ACTIVATE_CODE");
        aVar.d(str2, "");
        Scene.a aVar2 = Scene.l;
        String str3 = j.m;
        r.c(str3, "SpfConfig.ACTIVATE_CODE_TYPE");
        String strD = aVar2.d(str3, "trial");
        if (strD != null) {
            switch (strD) {
                case "account":
                    String string2 = this.f786b.getString(2131886874);
                    r.c(string2, "context.getString(R.string.license_next_cycle)");
                    bVarD = d(string2);
                    string = this.f786b.getString(2131886866);
                    str = "context.getString(R.string.license_account)";
                    break;
                case "alpha":
                    String string3 = this.f786b.getString(2131886868);
                    r.c(string3, "context.getString(R.string.license_expiry)");
                    bVarD = d(string3);
                    string = this.f786b.getString(2131886867);
                    str = "context.getString(R.string.license_alpha)";
                    break;
                case "trial":
                    String string4 = this.f786b.getString(2131886868);
                    r.c(string4, "context.getString(R.string.license_expiry)");
                    bVarD = d(string4);
                    string = this.f786b.getString(2131886883);
                    str = "context.getString(R.string.license_trial)";
                    break;
                case "perpetual":
                    String string5 = this.f786b.getString(2131886868);
                    r.c(string5, "context.getString(R.string.license_expiry)");
                    bVarD = d(string5);
                    bVarD.f(true);
                    string = this.f786b.getString(2131886876);
                    str = "context.getString(R.string.license_perpetual)";
                    break;
                default:
                    String string6 = this.f786b.getString(2131886868);
                    r.c(string6, "context.getString(R.string.license_expiry)");
                    bVarD = d(string6);
                    string = this.f786b.getString(2131886870);
                    str = "context.getString(R.string.license_free)";
                    break;
            }
        } else {
            String string7 = this.f786b.getString(2131886868);
            r.c(string7, "context.getString(R.string.license_expiry)");
            bVarD = d(string7);
            string = this.f786b.getString(2131886870);
            str = "context.getString(R.string.license_free)";
        }
        r.c(string, str);
        bVarD.i(string);
        bVarD.h("" + strD);
        bVarD.f(r.a(strD, "perpetual"));
        return bVarD;
    }
}
