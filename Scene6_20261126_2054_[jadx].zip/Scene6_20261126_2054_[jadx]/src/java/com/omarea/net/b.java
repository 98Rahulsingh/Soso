package com.omarea.net;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import com.omarea.Scene;
import com.omarea.common.net.Daemon;
import com.omarea.common.net.e;
import com.omarea.common.net.g;
import com.omarea.common.shared.d;
import com.omarea.library.shell.CpuFrequencyUtils;
import com.omarea.scene_mode.ModeSwitcher;
import com.omarea.scene_mode.f;
import java.io.File;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import kotlin.jvm.internal.r;
import kotlin.s;
import kotlin.text.k;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class b extends g {
    private final int e;
    private final int f;
    private final String g;
    private String h;
    private final Context i;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public b(Context context) {
        super(null, 1, null);
        r.d(context, "context");
        this.i = context;
        this.e = 8000;
        this.f = 15000;
        this.g = "https://vtools-1308535892.cos.ap-guangzhou.myqcloud.com/addin/";
        this.h = "core-v2.4.0";
    }

    private final String v() {
        StringBuilder sb;
        String str;
        CpuFrequencyUtils cpuFrequencyUtils = new CpuFrequencyUtils();
        Iterator<String[]> it = cpuFrequencyUtils.h().iterator();
        String str2 = "";
        while (it.hasNext()) {
            str2 = str2 + String.valueOf(it.next().length);
        }
        if (cpuFrequencyUtils.B()) {
            str = "dimensity-";
            if (cpuFrequencyUtils.a()) {
                sb = new StringBuilder();
                sb.append("dimensity-");
                sb.append(str2);
                sb.append("-ppm");
            } else {
                sb = new StringBuilder();
            }
            return sb.toString();
        }
        sb = new StringBuilder();
        str = "snapdragon-";
        sb.append(str);
        sb.append(str2);
        return sb.toString();
    }

    @Override // com.omarea.common.net.g
    protected int i() {
        return this.e;
    }

    @Override // com.omarea.common.net.g
    protected int j() {
        return this.f;
    }

    public final f s(boolean z) throws JSONException, PackageManager.NameNotFoundException {
        f fVar = new f();
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        com.omarea.library.shell.r rVar = new com.omarea.library.shell.r();
        String strB = rVar.b();
        String strA = rVar.a();
        PackageInfo packageInfo = this.i.getPackageManager().getPackageInfo(this.i.getPackageName(), 0);
        try {
            String str = SceneCloud.i.a() + "/cloud-scheduler2";
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("branch", z ? this.h + "-experimental" : this.h);
            jSONObject.put("versionName", packageInfo.versionName);
            jSONObject.put("osVersion", Build.VERSION.SDK_INT);
            jSONObject.put("platform", strB);
            jSONObject.put("machine", strA);
            jSONObject.put("scheme", v());
            s sVar = s.a;
            JSONObject jSONObject2 = new JSONObject(l(m(str, jSONObject)));
            fVar.m(0L);
            if (jSONObject2.has("files") && (!r.a(jSONObject2.get("files"), JSONObject.NULL))) {
                JSONObject jSONObject3 = jSONObject2.getJSONObject("files");
                com.omarea.library.basic.f fVar2 = new com.omarea.library.basic.f();
                Iterator<String> itKeys = jSONObject3.keys();
                r.c(itKeys, "files.keys()");
                while (itKeys.hasNext()) {
                    String next = itKeys.next();
                    String string = jSONObject3.getString(next);
                    r.c(string, "files.getString(key)");
                    String strA2 = fVar2.a(string);
                    r.c(next, "key");
                    linkedHashMap.put(next, strA2);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (linkedHashMap.containsKey("powercfg.sh") && linkedHashMap.containsKey("manifest.json")) {
            ArrayList<e> arrayListH = com.omarea.common.shell.g.f472a.h(d.f450b.a(this.i));
            ArrayList arrayList = new ArrayList();
            for (Object obj : arrayListH) {
                e eVar = (e) obj;
                if (!eVar.f() && k.t(eVar.c(), "_", false, 2, (Object) null) && k.m(eVar.c(), ".json", false, 2, (Object) null)) {
                    arrayList.add(obj);
                }
            }
            Iterator it = arrayList.iterator();
            while (it.hasNext()) {
                com.omarea.common.shell.g.f472a.a(((e) it.next()).a());
            }
            for (Map.Entry entry : linkedHashMap.entrySet()) {
                if (r.a((String) entry.getKey(), "manifest.json")) {
                    try {
                        fVar.l(new JSONObject((String) entry.getValue()));
                        ModeSwitcher.x.a();
                        Daemon.E.a().H0("version-update");
                    } catch (Exception unused) {
                    }
                }
                d dVar = d.f450b;
                String str2 = (String) entry.getValue();
                Charset charset = kotlin.text.d.a;
                if (str2 == null) {
                    throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                }
                byte[] bytes = str2.getBytes(charset);
                r.c(bytes, "(this as java.lang.String).getBytes(charset)");
                if (!dVar.h(bytes, (String) entry.getKey(), this.i)) {
                    Scene.l.k("Unable to save the profile: " + ((String) entry.getKey()));
                }
            }
        }
        return fVar;
    }

    public final long t(boolean z) throws PackageManager.NameNotFoundException {
        String str;
        String strB = new com.omarea.library.shell.r().b();
        String strA = new com.omarea.library.shell.r().a();
        PackageInfo packageInfo = this.i.getPackageManager().getPackageInfo(this.i.getPackageName(), 0);
        try {
            String str2 = SceneCloud.i.a() + "/cloud-scheduler-v2";
            JSONObject jSONObject = new JSONObject();
            if (z) {
                str = this.h + "-experimental";
            } else {
                str = this.h;
            }
            jSONObject.put("branch", str);
            jSONObject.put("versionName", packageInfo.versionName);
            jSONObject.put("osVersion", Build.VERSION.SDK_INT);
            jSONObject.put("platform", strB);
            jSONObject.put("machine", strA);
            jSONObject.put("scheme", v());
            s sVar = s.a;
            JSONObject jSONObject2 = new JSONObject(l(m(str2, jSONObject)));
            f fVar = new f();
            fVar.l(jSONObject2);
            return fVar.k();
        } catch (Exception e) {
            e.printStackTrace();
            return -1L;
        }
    }

    public final void u() {
        String str = Build.MANUFACTURER;
        r.c(str, "Build.MANUFACTURER");
        Locale locale = Locale.ENGLISH;
        r.c(locale, "Locale.ENGLISH");
        if (str == null) {
            throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
        }
        String lowerCase = str.toLowerCase(locale);
        r.c(lowerCase, "(this as java.lang.String).toLowerCase(locale)");
        if (r.a(lowerCase, "xiaomi")) {
            if (!new File(d.f450b.b(this.i, "toolkit/curl")).exists()) {
                d.f450b.h(g(this.g + "curl"), "toolkit/curl", this.i);
            }
            if (new File(d.f450b.b(this.i, "toolkit/sqlite3")).exists()) {
                return;
            }
            d.f450b.h(g(this.g + "sqlite3"), "toolkit/sqlite3", this.i);
        }
    }

    public final f w() throws JSONException, PackageManager.NameNotFoundException {
        f fVar = new f();
        if (!com.omarea.common.shell.g.f472a.d("scene-scheduler")) {
            try {
                d.f450b.h(g(this.g + "scene-scheduler"), "scene-scheduler", this.i);
            } catch (Exception unused) {
                Scene.l.k("download failed @_@!");
                return fVar;
            }
        }
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        com.omarea.library.shell.r rVar = new com.omarea.library.shell.r();
        String strB = rVar.b();
        String strA = rVar.a();
        PackageInfo packageInfo = this.i.getPackageManager().getPackageInfo(this.i.getPackageName(), 0);
        try {
            String str = SceneCloud.i.a() + "/cloud-scheduler2";
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("branch", "scene5");
            jSONObject.put("versionName", packageInfo.versionName);
            jSONObject.put("osVersion", Build.VERSION.SDK_INT);
            jSONObject.put("platform", strB);
            jSONObject.put("machine", strA);
            s sVar = s.a;
            JSONObject jSONObject2 = new JSONObject(l(m(str, jSONObject)));
            if (jSONObject2.has("files") && (!r.a(jSONObject2.get("files"), JSONObject.NULL))) {
                JSONObject jSONObject3 = jSONObject2.getJSONObject("files");
                com.omarea.library.basic.f fVar2 = new com.omarea.library.basic.f();
                Iterator<String> itKeys = jSONObject3.keys();
                r.c(itKeys, "files.keys()");
                while (itKeys.hasNext()) {
                    String next = itKeys.next();
                    String string = jSONObject3.getString(next);
                    r.c(string, "files.getString(key)");
                    String strA2 = fVar2.a(string);
                    r.c(next, "key");
                    linkedHashMap.put(next, strA2);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (linkedHashMap.containsKey("powercfg.sh") && linkedHashMap.containsKey("manifest.json")) {
            ArrayList<e> arrayListH = com.omarea.common.shell.g.f472a.h(d.f450b.a(this.i));
            ArrayList arrayList = new ArrayList();
            for (Object obj : arrayListH) {
                e eVar = (e) obj;
                if (!eVar.f() && k.t(eVar.c(), "_", false, 2, (Object) null) && k.m(eVar.c(), ".json", false, 2, (Object) null)) {
                    arrayList.add(obj);
                }
            }
            Iterator it = arrayList.iterator();
            while (it.hasNext()) {
                com.omarea.common.shell.g.f472a.a(((e) it.next()).a());
            }
            for (Map.Entry entry : linkedHashMap.entrySet()) {
                if (r.a((String) entry.getKey(), "manifest.json")) {
                    try {
                        fVar.l(new JSONObject((String) entry.getValue()));
                        ModeSwitcher.x.a();
                        Daemon.E.a().H0("version-update");
                    } catch (Exception unused2) {
                    }
                }
                d dVar = d.f450b;
                String str2 = (String) entry.getValue();
                Charset charset = kotlin.text.d.a;
                if (str2 == null) {
                    throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                }
                byte[] bytes = str2.getBytes(charset);
                r.c(bytes, "(this as java.lang.String).getBytes(charset)");
                if (!dVar.h(bytes, (String) entry.getKey(), this.i)) {
                    Scene.l.k("Unable to save the profile: " + ((String) entry.getKey()));
                }
            }
        }
        return fVar;
    }
}
