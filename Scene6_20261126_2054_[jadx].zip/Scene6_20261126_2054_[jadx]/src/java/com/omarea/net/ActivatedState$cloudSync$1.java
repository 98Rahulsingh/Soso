package com.omarea.net;

import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.coroutines.jvm.internal.d;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
@d(c = "com.omarea.net.ActivatedState", f = "ActivatedState.kt", l = {88, 116}, m = "cloudSync")
final class ActivatedState$cloudSync$1 extends ContinuationImpl {
    Object L$0;
    Object L$1;
    Object L$2;
    Object L$3;
    Object L$4;
    Object L$5;
    Object L$6;
    int label;
    /* synthetic */ Object result;
    final /* synthetic */ ActivatedState this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    ActivatedState$cloudSync$1(ActivatedState activatedState, kotlin.coroutines.c cVar) {
        super(cVar);
        this.this$0 = activatedState;
    }

    public final Object invokeSuspend(Object obj) {
        this.result = obj;
        this.label |= Integer.MIN_VALUE;
        return this.this$0.a(null, this);
    }
}
