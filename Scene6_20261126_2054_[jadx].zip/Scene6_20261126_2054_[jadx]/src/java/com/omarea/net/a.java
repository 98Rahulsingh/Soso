package com.omarea.net;

import android.util.Log;
import com.omarea.library.shell.CpuFrequencyUtils;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private String f835a = "JSONHelper";

    private boolean g(Object obj) {
        if (obj instanceof JSONObject) {
            return JSONObject.NULL.equals(obj);
        }
        return obj == null;
    }

    private boolean i(Class<?> cls) {
        return (cls == null || j(cls) || b(cls) || d(cls) || f(cls)) ? false : true;
    }

    private boolean j(Class<?> cls) {
        return c(cls) || h(cls) || k(cls);
    }

    private <T> T l(Class<T> cls) throws JSONException {
        if (cls == null) {
            return null;
        }
        if (!cls.isInterface()) {
            try {
                return cls.newInstance();
            } catch (Exception unused) {
                throw new JSONException("unknown class type: " + cls);
            }
        }
        if (cls.equals(Map.class)) {
            return (T) new HashMap();
        }
        if (cls.equals(List.class)) {
            return (T) new ArrayList();
        }
        if (cls.equals(Set.class)) {
            return (T) new HashSet();
        }
        throw new JSONException("unknown interface: " + cls);
    }

    private void s(Object obj, Method method, Field field, JSONObject jSONObject) {
        Object objQ;
        Type[] actualTypeArguments;
        String name = field.getName();
        Class<?> type = field.getType();
        try {
            if (b(type)) {
                Class<?> componentType = type.getComponentType();
                JSONArray jSONArrayOptJSONArray = jSONObject.optJSONArray(name);
                if (g(jSONArrayOptJSONArray)) {
                    return;
                } else {
                    objQ = m(jSONArrayOptJSONArray, componentType);
                }
            } else if (d(type)) {
                Class cls = null;
                Type genericType = field.getGenericType();
                if ((genericType instanceof ParameterizedType) && (actualTypeArguments = ((ParameterizedType) genericType).getActualTypeArguments()) != null && actualTypeArguments.length > 0) {
                    cls = (Class) actualTypeArguments[0];
                }
                JSONArray jSONArrayOptJSONArray2 = jSONObject.optJSONArray(name);
                if (g(jSONArrayOptJSONArray2)) {
                    return;
                } else {
                    objQ = n(jSONArrayOptJSONArray2, type, cls);
                }
            } else if (j(type)) {
                objQ = jSONObject.opt(name);
                if (objQ == null) {
                    return;
                }
            } else if (!i(type)) {
                if (!e(type)) {
                    throw new Exception("unknow type!");
                }
                return;
            } else {
                JSONObject jSONObjectOptJSONObject = jSONObject.optJSONObject(name);
                if (g(jSONObjectOptJSONObject)) {
                    return;
                } else {
                    objQ = q(jSONObjectOptJSONObject, type);
                }
            }
            r(obj, method, type.getSimpleName(), objQ);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void t(Object obj, JSONObject jSONObject) {
        try {
            Iterator<String> itKeys = jSONObject.keys();
            Map map = (Map) obj;
            while (itKeys.hasNext()) {
                String next = itKeys.next();
                map.put(next, jSONObject.get(next));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public boolean a(Method[] methodArr, String str) {
        for (Method method : methodArr) {
            if (str.equals(method.getName())) {
                return true;
            }
        }
        return false;
    }

    public boolean b(Class<?> cls) {
        return cls != null && cls.isArray();
    }

    public boolean c(Class<?> cls) {
        return cls != null && (Boolean.TYPE.isAssignableFrom(cls) || Boolean.class.isAssignableFrom(cls));
    }

    public boolean d(Class<?> cls) {
        return cls != null && Collection.class.isAssignableFrom(cls);
    }

    public boolean e(Class<?> cls) {
        return cls != null && List.class.isAssignableFrom(cls);
    }

    public boolean f(Class<?> cls) {
        return cls != null && Map.class.isAssignableFrom(cls);
    }

    public boolean h(Class<?> cls) {
        return cls != null && (Byte.TYPE.isAssignableFrom(cls) || Short.TYPE.isAssignableFrom(cls) || Integer.TYPE.isAssignableFrom(cls) || Long.TYPE.isAssignableFrom(cls) || Float.TYPE.isAssignableFrom(cls) || Double.TYPE.isAssignableFrom(cls) || Number.class.isAssignableFrom(cls));
    }

    public boolean k(Class<?> cls) {
        return cls != null && (String.class.isAssignableFrom(cls) || Character.TYPE.isAssignableFrom(cls) || Character.class.isAssignableFrom(cls));
    }

    /* JADX WARN: Multi-variable type inference failed */
    public <T> T[] m(JSONArray jSONArray, Class<T> cls) {
        if (cls == null || g(jSONArray)) {
            return null;
        }
        int length = jSONArray.length();
        T[] tArr = (T[]) ((Object[]) Array.newInstance((Class<?>) cls, length));
        for (int i = 0; i < length; i++) {
            try {
                tArr[i] = q(jSONArray.getJSONObject(i), cls);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return tArr;
    }

    public <T> Collection<T> n(JSONArray jSONArray, Class<?> cls, Class<T> cls2) {
        if (cls == null || cls2 == null || g(jSONArray)) {
            return null;
        }
        CpuFrequencyUtils.AnonymousClass2 anonymousClass2 = (Collection<T>) ((Collection) l(cls));
        for (int i = 0; i < jSONArray.length(); i++) {
            try {
                anonymousClass2.add(q(jSONArray.getJSONObject(i), cls2));
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return anonymousClass2;
    }

    public String o(String str, String str2) {
        if (str == null || "".equals(str)) {
            return null;
        }
        return str2 + str.substring(0, 1).toUpperCase() + str.substring(1);
    }

    public <T> T p(String str, Class<T> cls) {
        if (cls == null || str == null || str.length() == 0) {
            return null;
        }
        JSONObject jSONObject = new JSONObject(str);
        if (g(jSONObject)) {
            return null;
        }
        return (T) q(jSONObject, cls);
    }

    public <T> T q(JSONObject jSONObject, Class<T> cls) {
        T t;
        if (cls == null || g(jSONObject) || (t = (T) l(cls)) == null) {
            return null;
        }
        if (f(cls)) {
            t(t, jSONObject);
        } else {
            Method[] declaredMethods = cls.getDeclaredMethods();
            for (Field field : cls.getDeclaredFields()) {
                String strO = o(field.getName(), "set");
                if (a(declaredMethods, strO)) {
                    try {
                        s(t, cls.getMethod(strO, field.getType()), field, jSONObject);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        return t;
    }

    public void r(Object obj, Method method, String str, Object obj2) {
        if (obj2 != null) {
            try {
                if (!"".equals(obj2)) {
                    if ("String".equals(str)) {
                        method.invoke(obj, obj2.toString());
                    } else if ("Date".equals(str)) {
                        method.invoke(obj, new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINA).parse(obj2.toString()));
                    } else if ("Integer".equals(str) || "int".equals(str)) {
                        method.invoke(obj, Integer.valueOf(Integer.parseInt(obj2.toString())));
                    } else if ("Long".equalsIgnoreCase(str)) {
                        method.invoke(obj, Long.valueOf(Long.parseLong(obj2.toString())));
                    } else if ("Double".equalsIgnoreCase(str)) {
                        method.invoke(obj, Double.valueOf(Double.parseDouble(obj2.toString())));
                    } else if ("Boolean".equalsIgnoreCase(str)) {
                        method.invoke(obj, Boolean.valueOf(Boolean.parseBoolean(obj2.toString())));
                    } else {
                        method.invoke(obj, obj2);
                        Log.e(this.f835a, this.f835a + ">>>>setFiedlValue -> not supper type" + str);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
