package com.omarea.net;

import java.util.concurrent.FutureTask;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.coroutines.jvm.internal.d;
import kotlin.h;
import kotlin.jvm.b.p;
import kotlin.jvm.internal.r;
import kotlin.s;
import kotlinx.coroutines.h0;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
@d(c = "com.omarea.net.SceneCloud$getModuleDetail$1", f = "SceneCloud.kt", l = {}, m = "invokeSuspend")
final class SceneCloud$getModuleDetail$1 extends SuspendLambda implements p<h0, kotlin.coroutines.c<? super s>, Object> {
    final /* synthetic */ FutureTask $task;
    int label;
    private h0 p$;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    SceneCloud$getModuleDetail$1(FutureTask futureTask, kotlin.coroutines.c cVar) {
        super(2, cVar);
        this.$task = futureTask;
    }

    public final kotlin.coroutines.c<s> create(Object obj, kotlin.coroutines.c<?> cVar) {
        r.d(cVar, "completion");
        SceneCloud$getModuleDetail$1 sceneCloud$getModuleDetail$1 = new SceneCloud$getModuleDetail$1(this.$task, cVar);
        sceneCloud$getModuleDetail$1.p$ = (h0) obj;
        return sceneCloud$getModuleDetail$1;
    }

    public final Object invoke(Object obj, Object obj2) {
        return create(obj, (kotlin.coroutines.c) obj2).invokeSuspend(s.a);
    }

    public final Object invokeSuspend(Object obj) {
        kotlin.coroutines.intrinsics.a.d();
        if (this.label != 0) {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        h.b(obj);
        this.$task.run();
        return s.a;
    }
}
