package com.omarea.net;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;
import com.omarea.common.ui.e;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import kotlin.jvm.internal.r;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class c {

    static final class a implements Runnable {
        final /* synthetic */ int g;
        final /* synthetic */ Context h;
        final /* synthetic */ Handler i;

        /* JADX INFO: renamed from: com.omarea.net.c$a$a, reason: collision with other inner class name */
        static final class RunnableC0065a implements Runnable {
            final /* synthetic */ JSONObject g;

            RunnableC0065a(JSONObject jSONObject) {
                this.g = jSONObject;
            }

            @Override // java.lang.Runnable
            public final void run() {
                try {
                    c.this.f(a.this.h, this.g);
                } catch (Exception unused) {
                }
            }
        }

        a(int i, Context context, Handler handler) {
            this.g = i;
            this.h = context;
            this.i = handler;
        }

        @Override // java.lang.Runnable
        public final void run() {
            try {
                URLConnection uRLConnectionOpenConnection = new URL("https://vtools.oss-cn-beijing.aliyuncs.com/vi/" + (this.g == 6 ? "Scene7.json" : "Scene6.json")).openConnection();
                r.c(uRLConnectionOpenConnection, "connection");
                uRLConnectionOpenConnection.setConnectTimeout(15000);
                uRLConnectionOpenConnection.setReadTimeout(60000);
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(uRLConnectionOpenConnection.getInputStream()));
                StringBuilder sb = new StringBuilder();
                while (true) {
                    String line = bufferedReader.readLine();
                    if (line == null) {
                        break;
                    }
                    sb.append(line);
                    sb.append("\n");
                }
                String string = sb.toString();
                r.c(string, "stringBuilder.toString()");
                int length = string.length() - 1;
                int i = 0;
                boolean z = false;
                while (i <= length) {
                    boolean z2 = r.e(string.charAt(!z ? i : length), 32) <= 0;
                    if (z) {
                        if (!z2) {
                            break;
                        } else {
                            length--;
                        }
                    } else if (z2) {
                        i++;
                    } else {
                        z = true;
                    }
                }
                JSONObject jSONObject = new JSONObject(string.subSequence(i, length + 1).toString());
                if (!jSONObject.has("versionCode") || c.this.e(this.h) >= jSONObject.getInt("versionCode")) {
                    return;
                }
                this.i.post(new RunnableC0065a(jSONObject));
            } catch (Exception unused) {
            }
        }
    }

    static final class b implements Runnable {
        final /* synthetic */ JSONObject f;
        final /* synthetic */ Context g;

        b(JSONObject jSONObject, Context context) {
            this.f = jSONObject;
            this.g = context;
        }

        @Override // java.lang.Runnable
        public final void run() throws JSONException {
            String string = "http://vtools.oss-cn-beijing.aliyuncs.com/app-release" + this.f.getInt("versionCode") + ".apk";
            if (this.f.has("downloadUrl")) {
                string = this.f.getString("downloadUrl");
                r.c(string, "jsonObject.getString(\"downloadUrl\")");
            }
            try {
                Intent intent = new Intent();
                intent.setAction("android.intent.action.VIEW");
                intent.setData(Uri.parse(string));
                this.g.startActivity(intent);
            } catch (Exception unused) {
                Toast.makeText(this.g, "启动下载失败！", 0).show();
            }
        }
    }

    public static /* synthetic */ void d(c cVar, Context context, int i, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            i = 6;
        }
        cVar.c(context, i);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final int e(Context context) {
        try {
            return context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionCode;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
            return 0;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void f(Context context, JSONObject jSONObject) {
        e.f492b.i(context, (16 & 2) != 0 ? "" : "下载新版本" + jSONObject.getString("versionName") + " ？", (16 & 4) != 0 ? "" : "更新内容：\n\n" + jSONObject.getString("message"), (16 & 8) != 0 ? null : new b(jSONObject, context), (16 & 16) != 0 ? null : null).g(false);
    }

    public final void c(Context context, int i) {
        r.d(context, "context");
        new Thread(new a(i, context, new Handler(Looper.getMainLooper()))).start();
    }
}
