package com.omarea.net;

import android.content.Context;
import com.omarea.Scene;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.coroutines.jvm.internal.d;
import kotlin.h;
import kotlin.jvm.b.p;
import kotlin.jvm.internal.r;
import kotlin.s;
import kotlinx.coroutines.h0;
import org.json.JSONArray;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
@d(c = "com.omarea.net.AutoSkipCloudData$updateConfig$1", f = "AutoSkipCloudData.kt", l = {}, m = "invokeSuspend")
final class AutoSkipCloudData$updateConfig$1 extends SuspendLambda implements p<h0, kotlin.coroutines.c<? super s>, Object> {
    final /* synthetic */ Context $context;
    final /* synthetic */ boolean $showMsg;
    int label;
    private h0 p$;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    AutoSkipCloudData$updateConfig$1(boolean z, Context context, kotlin.coroutines.c cVar) {
        super(2, cVar);
        this.$showMsg = z;
        this.$context = context;
    }

    public final kotlin.coroutines.c<s> create(Object obj, kotlin.coroutines.c<?> cVar) {
        r.d(cVar, "completion");
        AutoSkipCloudData$updateConfig$1 autoSkipCloudData$updateConfig$1 = new AutoSkipCloudData$updateConfig$1(this.$showMsg, this.$context, cVar);
        autoSkipCloudData$updateConfig$1.p$ = (h0) obj;
        return autoSkipCloudData$updateConfig$1;
    }

    public final Object invoke(Object obj, Object obj2) {
        return create(obj, (kotlin.coroutines.c) obj2).invokeSuspend(s.a);
    }

    public final Object invokeSuspend(Object obj) {
        kotlin.coroutines.intrinsics.a.d();
        if (this.label != 0) {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        h.b(obj);
        try {
            URLConnection uRLConnectionOpenConnection = new URL("https://vtools.oss-cn-beijing.aliyuncs.com/addin/auto-skip-config-v1.json").openConnection();
            r.c(uRLConnectionOpenConnection, "connection");
            uRLConnectionOpenConnection.setConnectTimeout(15000);
            uRLConnectionOpenConnection.setReadTimeout(20000);
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(uRLConnectionOpenConnection.getInputStream()));
            StringBuilder sb = new StringBuilder();
            while (true) {
                String line = bufferedReader.readLine();
                if (line == null) {
                    break;
                }
                sb.append(line);
                sb.append("\n");
            }
            String string = sb.toString();
            r.c(string, "stringBuilder.toString()");
            int length = string.length() - 1;
            int i = 0;
            boolean z = false;
            while (i <= length) {
                boolean zBooleanValue = kotlin.coroutines.jvm.internal.a.a(r.e(kotlin.coroutines.jvm.internal.a.b(string.charAt(!z ? i : length)).charValue(), 32) <= 0).booleanValue();
                if (z) {
                    if (!zBooleanValue) {
                        break;
                    }
                    length--;
                } else if (zBooleanValue) {
                    i++;
                } else {
                    z = true;
                }
            }
            JSONArray jSONArray = new JSONArray(string.subSequence(i, length + 1).toString());
            if (this.$showMsg) {
                Scene.l.k("从云端获得 " + jSONArray.length() + " 条(自动跳过)数据");
            }
            com.omarea.store.b bVar = new com.omarea.store.b(this.$context);
            bVar.b();
            int length2 = jSONArray.length();
            for (int i2 = 0; i2 < length2; i2++) {
                JSONObject jSONObject = jSONArray.getJSONObject(i2);
                if (jSONObject != null) {
                    kotlin.coroutines.jvm.internal.a.a(bVar.a(jSONObject.getString("activity"), jSONObject.getString("viewId")));
                }
            }
        } catch (Exception unused) {
            if (this.$showMsg) {
                Scene.l.k("获取云端配置数据失败~");
            }
        }
        return s.a;
    }
}
