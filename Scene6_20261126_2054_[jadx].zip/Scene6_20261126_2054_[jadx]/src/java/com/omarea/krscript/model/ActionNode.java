package com.omarea.krscript.model;

import java.util.ArrayList;
import kotlin.jvm.internal.r;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class ActionNode extends RunnableNode {
    private ArrayList<ActionParamInfo> params;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public ActionNode(String str) {
        super(str);
        r.d(str, "currentConfigXml");
    }

    public final ArrayList<ActionParamInfo> getParams() {
        return this.params;
    }

    public final void setParams(ArrayList<ActionParamInfo> arrayList) {
        this.params = arrayList;
    }
}
