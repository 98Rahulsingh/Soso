package com.omarea.krscript.model;

import android.content.Intent;
import android.view.View;
import com.omarea.krscript.ui.p;
import kotlin.jvm.internal.r;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public interface KrScriptActionHandler {

    public interface AddToFavoritesHandler {
        void onAddToFavorites(ClickableNode clickableNode, Intent intent);
    }

    public static final class DefaultImpls {
        public static boolean openParamsPage(KrScriptActionHandler krScriptActionHandler, ActionNode actionNode, View view, Runnable runnable) {
            r.d(actionNode, "actionNode");
            r.d(view, "view");
            r.d(runnable, "onCompleted");
            return false;
        }
    }

    void addToFavorites(ClickableNode clickableNode, AddToFavoritesHandler addToFavoritesHandler);

    void onActionCompleted(RunnableNode runnableNode);

    void onSubPageClick(PageNode pageNode);

    boolean openFileChooser(p.b bVar);

    boolean openParamsPage(ActionNode actionNode, View view, Runnable runnable);
}
