package com.omarea.krscript.model;

import android.text.InputFilter;
import android.text.Spanned;
import java.util.regex.Pattern;
import kotlin.jvm.internal.r;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class ParamInfoFilter implements InputFilter {
    private final ActionParamInfo paramInfo;

    public ParamInfoFilter(ActionParamInfo actionParamInfo) {
        r.d(actionParamInfo, "paramInfo");
        this.paramInfo = actionParamInfo;
    }

    @Override // android.text.InputFilter
    public CharSequence filter(CharSequence charSequence, int i, int i2, Spanned spanned, int i3, int i4) {
        r.d(spanned, "dest");
        if (this.paramInfo.getMaxLength() >= 0 && this.paramInfo.getMaxLength() - (spanned.length() - (i4 - i3)) <= 0) {
            return "";
        }
        if (this.paramInfo.getType() == null || !(!r.a(this.paramInfo.getType(), "")) || charSequence == null) {
            return null;
        }
        if (r.a(this.paramInfo.getType(), "int")) {
            if (Pattern.compile("^[0-9]{0,}$").matcher(charSequence.toString()).matches()) {
                return null;
            }
            return "";
        }
        if (!r.a(this.paramInfo.getType(), "number") || Pattern.compile("^[\\-.,0-9]{0,}$").matcher(charSequence.toString()).matches()) {
            return null;
        }
        return "";
    }
}
