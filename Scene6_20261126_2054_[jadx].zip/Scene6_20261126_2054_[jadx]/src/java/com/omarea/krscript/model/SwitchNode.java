package com.omarea.krscript.model;

import kotlin.jvm.internal.r;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class SwitchNode extends RunnableNode {
    private boolean checked;
    private String getState;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public SwitchNode(String str) {
        super(str);
        r.d(str, "currentConfigXml");
        this.getState = "";
    }

    public final boolean getChecked() {
        return this.checked;
    }

    public final String getGetState() {
        return this.getState;
    }

    public final void setChecked(boolean z) {
        this.checked = z;
    }

    public final void setGetState(String str) {
        r.d(str, "<set-?>");
        this.getState = str;
    }
}
