package com.omarea.krscript.model;

import java.io.File;
import java.io.Serializable;
import java.util.UUID;
import kotlin.jvm.internal.r;
import kotlin.text.k;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class NodeInfoBase implements Serializable {
    private final String currentPageConfigPath;
    private String desc;
    private String descSh;
    private final String index;
    private String key;
    private final String pageConfigDir;
    private String summary;
    private String summarySh;
    private String title;

    public NodeInfoBase(String str) {
        String parent;
        r.d(str, "currentPageConfigPath");
        this.currentPageConfigPath = str;
        if (str.length() > 0) {
            parent = new File(this.currentPageConfigPath).getParent();
            r.c(parent, "dir");
            if (k.t(parent, "file:/android_asset/", false, 2, (Object) null)) {
                StringBuilder sb = new StringBuilder();
                sb.append("file:///android_asset/");
                String strSubstring = parent.substring(20);
                r.c(strSubstring, "(this as java.lang.String).substring(startIndex)");
                sb.append(strSubstring);
                parent = sb.toString();
            }
        } else {
            parent = "";
        }
        this.pageConfigDir = parent;
        this.key = "";
        String string = UUID.randomUUID().toString();
        r.c(string, "UUID.randomUUID().toString()");
        this.index = string;
        this.title = "";
        this.desc = "";
        this.descSh = "";
        this.summary = "";
        this.summarySh = "";
    }

    public final String getCurrentPageConfigPath() {
        return this.currentPageConfigPath;
    }

    public final String getDesc() {
        return this.desc;
    }

    public final String getDescSh() {
        return this.descSh;
    }

    public final String getIndex() {
        return this.index;
    }

    public final String getKey() {
        return this.key;
    }

    public final String getPageConfigDir() {
        return this.pageConfigDir;
    }

    public final String getSummary() {
        return this.summary;
    }

    public final String getSummarySh() {
        return this.summarySh;
    }

    public final String getTitle() {
        return this.title;
    }

    public final void setDesc(String str) {
        r.d(str, "<set-?>");
        this.desc = str;
    }

    public final void setDescSh(String str) {
        r.d(str, "<set-?>");
        this.descSh = str;
    }

    public final void setKey(String str) {
        r.d(str, "<set-?>");
        this.key = str;
    }

    public final void setSummary(String str) {
        r.d(str, "<set-?>");
        this.summary = str;
    }

    public final void setSummarySh(String str) {
        r.d(str, "<set-?>");
        this.summarySh = str;
    }

    public final void setTitle(String str) {
        r.d(str, "<set-?>");
        this.title = str;
    }
}
