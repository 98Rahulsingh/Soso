package com.omarea.krscript.model;

import java.util.ArrayList;
import kotlin.jvm.internal.r;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class GroupNode extends NodeInfoBase {
    private final ArrayList<NodeInfoBase> children;
    private boolean supported;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public GroupNode(String str) {
        super(str);
        r.d(str, "currentPageConfigPath");
        this.supported = true;
        this.children = new ArrayList<>();
    }

    public final ArrayList<NodeInfoBase> getChildren() {
        return this.children;
    }

    public final boolean getSupported() {
        return this.supported;
    }

    public final void setSupported(boolean z) {
        this.supported = z;
    }
}
