package com.omarea.krscript.ui;

import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlinx.coroutines.h0;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
@kotlin.coroutines.jvm.internal.d(c = "com.omarea.krscript.ui.DialogLogFragment$MyShellHandler$onStart$1", f = "DialogLogFragment.kt", l = {248}, m = "invokeSuspend")
final class DialogLogFragment$MyShellHandler$onStart$1 extends SuspendLambda implements kotlin.jvm.b.p<h0, kotlin.coroutines.c<? super kotlin.s>, Object> {
    Object L$0;
    int label;
    private h0 p$;
    final /* synthetic */ DialogLogFragment.MyShellHandler this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    DialogLogFragment$MyShellHandler$onStart$1(DialogLogFragment.MyShellHandler myShellHandler, kotlin.coroutines.c cVar) {
        super(2, cVar);
        this.this$0 = myShellHandler;
    }

    public final kotlin.coroutines.c<kotlin.s> create(Object obj, kotlin.coroutines.c<?> cVar) {
        kotlin.jvm.internal.r.d(cVar, "completion");
        DialogLogFragment$MyShellHandler$onStart$1 dialogLogFragment$MyShellHandler$onStart$1 = new DialogLogFragment$MyShellHandler$onStart$1(this.this$0, cVar);
        dialogLogFragment$MyShellHandler$onStart$1.p$ = (h0) obj;
        return dialogLogFragment$MyShellHandler$onStart$1;
    }

    public final Object invoke(Object obj, Object obj2) {
        return create(obj, (kotlin.coroutines.c) obj2).invokeSuspend(kotlin.s.a);
    }

    /* JADX WARN: Code duplicated, block: B:11:0x002b  */
    /* JADX WARN: Code duplicated, block: B:13:0x0037  */
    /* JADX WARN: Code duplicated, block: B:14:0x0039  */
    /* JADX WARN: Code duplicated, block: B:17:0x003d  */
    /* JADX WARN: Code duplicated, block: B:21:0x004c A[RETURN] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:20:0x004a -> B:22:0x004d). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions count limit reached at block B:11:0x002b
        	at jadx.core.utils.ErrorsCounter.addError(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:52)
        	at jadx.core.utils.ErrorsCounter.error(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:9)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:1)
        */
    public final java.lang.Object invokeSuspend(java.lang.Object r6) {
        /*
            r5 = this;
            java.lang.Object r0 = kotlin.coroutines.intrinsics.a.d()
            int r1 = r5.label
            r2 = 1
            if (r1 == 0) goto L1c
            if (r1 != r2) goto L14
            java.lang.Object r1 = r5.L$0
            kotlinx.coroutines.h0 r1 = (kotlinx.coroutines.h0) r1
            kotlin.h.b(r6)
            r6 = r5
            goto L4d
        L14:
            java.lang.IllegalStateException r6 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r6.<init>(r0)
            throw r6
        L1c:
            kotlin.h.b(r6)
            kotlinx.coroutines.h0 r6 = r5.p$
            r1 = r6
            r6 = r5
        L23:
            com.omarea.krscript.ui.DialogLogFragment$MyShellHandler r3 = r6.this$0
            boolean r3 = com.omarea.krscript.ui.DialogLogFragment.MyShellHandler.d(r3)
            if (r3 != 0) goto L40
            com.omarea.krscript.ui.DialogLogFragment$MyShellHandler r3 = r6.this$0
            java.lang.StringBuffer r3 = com.omarea.krscript.ui.DialogLogFragment.MyShellHandler.b(r3)
            int r3 = r3.length()
            if (r3 <= 0) goto L39
            r3 = r2
            goto L3a
        L39:
            r3 = 0
        L3a:
            if (r3 == 0) goto L3d
            goto L40
        L3d:
            kotlin.s r6 = kotlin.s.a
            return r6
        L40:
            r3 = 16
            r6.L$0 = r1
            r6.label = r2
            java.lang.Object r3 = kotlinx.coroutines.q0.a(r3, r6)
            if (r3 != r0) goto L4d
            return r0
        L4d:
            com.omarea.krscript.ui.DialogLogFragment$MyShellHandler r3 = r6.this$0
            com.omarea.krscript.ui.DialogLogFragment.MyShellHandler.a(r3)
            goto L23
        */
        throw new UnsupportedOperationException("Method not decompiled: com.omarea.krscript.ui.DialogLogFragment$MyShellHandler$onStart$1.invokeSuspend(java.lang.Object):java.lang.Object");
    }
}
