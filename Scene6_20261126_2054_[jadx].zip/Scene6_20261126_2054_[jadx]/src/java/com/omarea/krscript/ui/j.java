package com.omarea.krscript.ui;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;
import com.omarea.krscript.model.ActionNode;
import com.omarea.krscript.model.ClickableNode;
import com.omarea.krscript.model.GroupNode;
import com.omarea.krscript.model.NodeInfoBase;
import com.omarea.krscript.model.PageNode;
import com.omarea.krscript.model.PickerNode;
import com.omarea.krscript.model.RunnableNode;
import com.omarea.krscript.model.SwitchNode;
import com.omarea.krscript.model.TextNode;
import java.util.ArrayList;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class j {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final com.omarea.krscript.ui.c.InterfaceC0064c f583a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final d f584b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final Context f585c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private final ArrayList<NodeInfoBase> f586d;
    private final a e;
    private final com.omarea.krscript.ui.d f;

    public interface a {
        void a(ActionNode actionNode, Runnable runnable);

        void b(ClickableNode clickableNode);

        void c(PageNode pageNode, Runnable runnable);

        void d(SwitchNode switchNode, Runnable runnable);

        void e(PickerNode pickerNode, Runnable runnable);
    }

    static final class b implements Runnable {
        final /* synthetic */ Handler g;
        final /* synthetic */ com.omarea.krscript.ui.c h;
        final /* synthetic */ NodeInfoBase i;

        static final class a implements Runnable {
            a() {
            }

            @Override // java.lang.Runnable
            public final void run() {
                b.this.h.h();
                NodeInfoBase nodeInfoBase = b.this.i;
                if (!(nodeInfoBase instanceof RunnableNode) || ((RunnableNode) nodeInfoBase).getUpdateBlocks() == null) {
                    return;
                }
                com.omarea.krscript.ui.d dVar = j.this.f;
                String[] updateBlocks = ((RunnableNode) b.this.i).getUpdateBlocks();
                kotlin.jvm.internal.r.b(updateBlocks);
                dVar.m(updateBlocks);
            }
        }

        b(Handler handler, com.omarea.krscript.ui.c cVar, NodeInfoBase nodeInfoBase) {
            this.g = handler;
            this.h = cVar;
            this.i = nodeInfoBase;
        }

        @Override // java.lang.Runnable
        public final void run() {
            this.g.post(new a());
        }
    }

    public static final class c implements com.omarea.krscript.ui.c.InterfaceC0064c {
        c() {
        }

        @Override // com.omarea.krscript.ui.c.InterfaceC0064c
        public void a(com.omarea.krscript.ui.c cVar) {
            kotlin.jvm.internal.r.d(cVar, "listItemView");
            String strA = cVar.a();
            try {
                NodeInfoBase nodeInfoBaseM = j.this.m(strA, j.this.f586d);
                if (nodeInfoBaseM != null) {
                    j.this.p(nodeInfoBaseM, cVar);
                    return;
                }
                Log.e("onItemClick", "找不到指定ID的项 index: " + strA);
            } catch (Exception unused) {
            }
        }
    }

    public static final class d implements com.omarea.krscript.ui.c.d {
        d() {
        }

        @Override // com.omarea.krscript.ui.c.d
        public void a(com.omarea.krscript.ui.c cVar) {
            kotlin.jvm.internal.r.d(cVar, "listItemView");
            NodeInfoBase nodeInfoBaseM = j.this.m(cVar.a(), j.this.f586d);
            if (nodeInfoBaseM instanceof ClickableNode) {
                j.this.e.b((ClickableNode) nodeInfoBaseM);
            }
        }
    }

    public j(Context context, ArrayList<NodeInfoBase> arrayList, a aVar, com.omarea.krscript.ui.d dVar) {
        kotlin.jvm.internal.r.d(context, "mContext");
        kotlin.jvm.internal.r.d(arrayList, "itemConfigList");
        kotlin.jvm.internal.r.d(aVar, "clickListener");
        kotlin.jvm.internal.r.d(dVar, "rootGroup");
        this.f585c = context;
        this.f586d = arrayList;
        this.e = aVar;
        this.f = dVar;
        this.f583a = new c();
        this.f584b = new d();
        o(this.f, this.f586d);
    }

    private final i f(ActionNode actionNode) {
        return new com.omarea.krscript.ui.b(this.f585c, actionNode);
    }

    private final com.omarea.krscript.ui.d g(GroupNode groupNode) {
        return new com.omarea.krscript.ui.d(this.f585c, false, groupNode);
    }

    private final i h(PickerNode pickerNode) {
        return new f(this.f585c, pickerNode);
    }

    private final i i(PageNode pageNode) {
        return new e(this.f585c, pageNode);
    }

    private final i j(SwitchNode switchNode) {
        return new g(this.f585c, switchNode);
    }

    private final i k(TextNode textNode) {
        return new h(this.f585c, com.omarea.c.g.kr_text_list_item, textNode);
    }

    private final i l(TextNode textNode) {
        return new h(this.f585c, com.omarea.c.g.kr_text_list_item_white, textNode);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final NodeInfoBase m(String str, ArrayList<NodeInfoBase> arrayList) {
        NodeInfoBase nodeInfoBaseM;
        for (NodeInfoBase nodeInfoBase : arrayList) {
            if (kotlin.jvm.internal.r.a(nodeInfoBase.getIndex(), str)) {
                return nodeInfoBase;
            }
            if (nodeInfoBase instanceof GroupNode) {
                GroupNode groupNode = (GroupNode) nodeInfoBase;
                if (groupNode.getChildren().size() > 0 && (nodeInfoBaseM = m(str, groupNode.getChildren())) != null) {
                    return nodeInfoBaseM;
                }
            }
        }
        return null;
    }

    private final Runnable n(NodeInfoBase nodeInfoBase, com.omarea.krscript.ui.c cVar) {
        return new b(new Handler(Looper.getMainLooper()), cVar, nodeInfoBase);
    }

    private final void o(com.omarea.krscript.ui.d dVar, ArrayList<NodeInfoBase> arrayList) {
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            NodeInfoBase nodeInfoBase = arrayList.get(i);
            kotlin.jvm.internal.r.c(nodeInfoBase, "actionInfos[index]");
            NodeInfoBase nodeInfoBase2 = nodeInfoBase;
            i iVarK = null;
            try {
                if (nodeInfoBase2 instanceof PageNode) {
                    iVarK = i((PageNode) nodeInfoBase2);
                } else if (nodeInfoBase2 instanceof SwitchNode) {
                    iVarK = j((SwitchNode) nodeInfoBase2);
                } else if (nodeInfoBase2 instanceof ActionNode) {
                    iVarK = f((ActionNode) nodeInfoBase2);
                } else if (nodeInfoBase2 instanceof PickerNode) {
                    iVarK = h((PickerNode) nodeInfoBase2);
                } else if (nodeInfoBase2 instanceof TextNode) {
                    iVarK = dVar.j() ? k((TextNode) nodeInfoBase2) : l((TextNode) nodeInfoBase2);
                } else if (nodeInfoBase2 instanceof GroupNode) {
                    com.omarea.krscript.ui.d dVarG = g((GroupNode) nodeInfoBase2);
                    if (((GroupNode) nodeInfoBase2).getChildren().size() > 0) {
                        dVar.i(dVarG);
                        o(dVarG, ((GroupNode) nodeInfoBase2).getChildren());
                    }
                }
                if (iVarK != null) {
                    if (iVarK instanceof com.omarea.krscript.ui.c) {
                        ((com.omarea.krscript.ui.c) iVarK).k(this.f583a);
                        ((com.omarea.krscript.ui.c) iVarK).l(this.f584b);
                    }
                    dVar.i(iVarK);
                }
            } catch (Exception e) {
                Toast.makeText(this.f585c, nodeInfoBase2.getTitle() + "界面渲染异常" + e.getMessage(), 0).show();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void p(NodeInfoBase nodeInfoBase, com.omarea.krscript.ui.c cVar) {
        if (nodeInfoBase instanceof PageNode) {
            this.e.c((PageNode) nodeInfoBase, n(nodeInfoBase, cVar));
            return;
        }
        if (nodeInfoBase instanceof ActionNode) {
            this.e.a((ActionNode) nodeInfoBase, n(nodeInfoBase, cVar));
        } else if (nodeInfoBase instanceof PickerNode) {
            this.e.e((PickerNode) nodeInfoBase, n(nodeInfoBase, cVar));
        } else if (nodeInfoBase instanceof SwitchNode) {
            this.e.d((SwitchNode) nodeInfoBase, n(nodeInfoBase, cVar));
        }
    }
}
