package com.omarea.krscript.ui;

import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.TextView;
import com.omarea.common.ui.AdapterAppChooser;
import com.omarea.krscript.model.ActionParamInfo;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class l implements com.omarea.common.ui.c.a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final Integer f592a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private boolean f593b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private TextView f594c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private TextView f595d;
    private ArrayList<AdapterAppChooser.b> e;
    private ActionParamInfo f;
    private androidx.fragment.app.d g;

    static final class a implements View.OnClickListener {
        a() {
        }

        @Override // android.view.View.OnClickListener
        public final void onClick(View view) {
            l.this.d();
        }
    }

    static final class b implements View.OnClickListener {
        b() {
        }

        @Override // android.view.View.OnClickListener
        public final void onClick(View view) {
            l.this.d();
        }
    }

    public l(ActionParamInfo actionParamInfo, androidx.fragment.app.d dVar) {
        View decorView;
        kotlin.jvm.internal.r.d(actionParamInfo, "actionParamInfo");
        kotlin.jvm.internal.r.d(dVar, "context");
        this.f = actionParamInfo;
        this.g = dVar;
        Window window = dVar.getWindow();
        Integer numValueOf = (window == null || (decorView = window.getDecorView()) == null) ? null : Integer.valueOf(decorView.getSystemUiVisibility());
        this.f592a = numValueOf;
        this.f593b = numValueOf != null && (numValueOf.intValue() & 8192) == 0;
    }

    private final List<AdapterAppChooser.b> c(boolean z) {
        ArrayList arrayList;
        PackageManager packageManager = this.g.getPackageManager();
        ArrayList<com.omarea.a.f.a> optionsFromShell = this.f.getOptionsFromShell();
        if (optionsFromShell != null) {
            arrayList = new ArrayList(kotlin.collections.q.k(optionsFromShell, 10));
            Iterator<T> it = optionsFromShell.iterator();
            while (it.hasNext()) {
                arrayList.add(((com.omarea.a.f.a) it.next()).c());
            }
        } else {
            arrayList = null;
        }
        List<PackageInfo> installedPackages = packageManager.getInstalledPackages(8192);
        kotlin.jvm.internal.r.c(installedPackages, "pm.getInstalledPackages(…GET_UNINSTALLED_PACKAGES)");
        ArrayList<PackageInfo> arrayList2 = new ArrayList();
        for (Object obj : installedPackages) {
            if (arrayList == null || arrayList.contains(((PackageInfo) obj).packageName)) {
                arrayList2.add(obj);
            }
        }
        ArrayList arrayList3 = new ArrayList(kotlin.collections.q.k(arrayList2, 10));
        for (PackageInfo packageInfo : arrayList2) {
            AdapterAppChooser.b bVar = new AdapterAppChooser.b();
            bVar.setAppName("" + packageInfo.applicationInfo.loadLabel(packageManager));
            String str = packageInfo.packageName;
            kotlin.jvm.internal.r.c(str, "it.packageName");
            bVar.setPackageName(str);
            arrayList3.add(bVar);
        }
        ArrayList arrayList4 = new ArrayList(arrayList3);
        if (z && this.f.getOptionsFromShell() != null) {
            ArrayList<com.omarea.a.f.a> optionsFromShell2 = this.f.getOptionsFromShell();
            kotlin.jvm.internal.r.b(optionsFromShell2);
            for (com.omarea.a.f.a aVar : optionsFromShell2) {
                ArrayList arrayList5 = new ArrayList();
                for (Object obj2 : arrayList4) {
                    if (kotlin.jvm.internal.r.a(((AdapterAppChooser.b) obj2).getPackageName(), aVar.c())) {
                        arrayList5.add(obj2);
                    }
                }
                if (arrayList5.isEmpty()) {
                    AdapterAppChooser.b bVar2 = new AdapterAppChooser.b();
                    bVar2.setAppName("" + aVar.b());
                    bVar2.setPackageName("" + aVar.c());
                    kotlin.s sVar = kotlin.s.a;
                    arrayList4.add(bVar2);
                }
            }
        }
        return arrayList4;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void d() {
        f();
        boolean z = this.f593b;
        ArrayList<AdapterAppChooser.b> arrayList = this.e;
        if (arrayList != null) {
            new com.omarea.common.ui.c(z, arrayList, this.f.getMultiple(), this).E1(this.g.getSupportFragmentManager(), "app-chooser");
        } else {
            kotlin.jvm.internal.r.q("packages");
            throw null;
        }
    }

    private final void f() {
        Object next;
        int iIndexOf;
        Object next2;
        ArrayList<AdapterAppChooser.b> arrayList = this.e;
        if (arrayList == null) {
            kotlin.jvm.internal.r.q("packages");
            throw null;
        }
        Iterator<T> it = arrayList.iterator();
        while (it.hasNext()) {
            ((AdapterAppChooser.b) it.next()).setSelected(false);
        }
        TextView textView = this.f594c;
        if (textView == null) {
            kotlin.jvm.internal.r.q("valueView");
            throw null;
        }
        CharSequence text = textView.getText();
        if (this.f.getMultiple()) {
            kotlin.jvm.internal.r.c(text, "currentValue");
            for (String str : kotlin.text.k.W(text, new String[]{this.f.getSeparator()}, false, 0, 6, (Object) null)) {
                ArrayList<AdapterAppChooser.b> arrayList2 = this.e;
                if (arrayList2 == null) {
                    kotlin.jvm.internal.r.q("packages");
                    throw null;
                }
                Iterator<T> it2 = arrayList2.iterator();
                do {
                    if (!it2.hasNext()) {
                        next2 = null;
                        break;
                    }
                    next2 = it2.next();
                } while (!kotlin.jvm.internal.r.a(((AdapterAppChooser.b) next2).getPackageName(), str));
                AdapterAppChooser.b bVar = (AdapterAppChooser.b) next2;
                if (bVar != null) {
                    bVar.setSelected(true);
                }
            }
            return;
        }
        ArrayList<AdapterAppChooser.b> arrayList3 = this.e;
        if (arrayList3 == null) {
            kotlin.jvm.internal.r.q("packages");
            throw null;
        }
        Iterator<T> it3 = arrayList3.iterator();
        do {
            if (!it3.hasNext()) {
                next = null;
                break;
            }
            next = it3.next();
        } while (!kotlin.jvm.internal.r.a(((AdapterAppChooser.b) next).getPackageName(), text));
        AdapterAppChooser.b bVar2 = (AdapterAppChooser.b) next;
        if (bVar2 != null) {
            ArrayList<AdapterAppChooser.b> arrayList4 = this.e;
            if (arrayList4 == null) {
                kotlin.jvm.internal.r.q("packages");
                throw null;
            }
            iIndexOf = arrayList4.indexOf(bVar2);
        } else {
            iIndexOf = -1;
        }
        if (iIndexOf > -1) {
            ArrayList<AdapterAppChooser.b> arrayList5 = this.e;
            if (arrayList5 == null) {
                kotlin.jvm.internal.r.q("packages");
                throw null;
            }
            arrayList5.get(iIndexOf).setSelected(true);
        }
    }

    private final void g() {
        Object next;
        ArrayList<AdapterAppChooser.b> arrayList = new ArrayList<>(c(kotlin.jvm.internal.r.a(this.f.getType(), "packages")));
        this.e = arrayList;
        if (arrayList == null) {
            kotlin.jvm.internal.r.q("packages");
            throw null;
        }
        ArrayList arrayList2 = new ArrayList(kotlin.collections.q.k(arrayList, 10));
        Iterator<T> it = arrayList.iterator();
        while (it.hasNext()) {
            arrayList2.add(((AdapterAppChooser.b) it.next()).getAppName());
        }
        Object[] array = arrayList2.toArray(new String[0]);
        if (array == null) {
            throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T>");
        }
        String[] strArr = (String[]) array;
        ArrayList arrayList3 = new ArrayList(kotlin.collections.q.k(arrayList, 10));
        Iterator<T> it2 = arrayList.iterator();
        while (it2.hasNext()) {
            arrayList3.add(((AdapterAppChooser.b) it2.next()).getPackageName());
        }
        Object[] array2 = arrayList3.toArray(new String[0]);
        if (array2 == null) {
            throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T>");
        }
        String[] strArr2 = (String[]) array2;
        if (this.f.getMultiple()) {
            List<String> listC = com.omarea.krscript.ui.a.f575d.c(this.f);
            if (listC != null) {
                for (String str : listC) {
                    ArrayList<AdapterAppChooser.b> arrayList4 = this.e;
                    if (arrayList4 == null) {
                        kotlin.jvm.internal.r.q("packages");
                        throw null;
                    }
                    Iterator<T> it3 = arrayList4.iterator();
                    do {
                        if (!it3.hasNext()) {
                            next = null;
                            break;
                        }
                        next = it3.next();
                    } while (!kotlin.jvm.internal.r.a(((AdapterAppChooser.b) next).getPackageName(), str));
                    AdapterAppChooser.b bVar = (AdapterAppChooser.b) next;
                    if (bVar != null) {
                        bVar.setSelected(true);
                    }
                }
            }
            ArrayList<AdapterAppChooser.b> arrayList5 = this.e;
            if (arrayList5 == null) {
                kotlin.jvm.internal.r.q("packages");
                throw null;
            }
            ArrayList arrayList6 = new ArrayList();
            for (Object obj : arrayList5) {
                if (((AdapterAppChooser.b) obj).getSelected()) {
                    arrayList6.add(obj);
                }
            }
            a(arrayList6);
            return;
        }
        ArrayList<AdapterAppChooser.b> arrayList7 = this.e;
        if (arrayList7 == null) {
            kotlin.jvm.internal.r.q("packages");
            throw null;
        }
        ArrayList arrayList8 = new ArrayList(kotlin.collections.q.k(arrayList7, 10));
        for (AdapterAppChooser.b bVar2 : arrayList7) {
            com.omarea.a.f.a aVar = new com.omarea.a.f.a();
            aVar.e(bVar2.getAppName());
            aVar.f(bVar2.getPackageName());
            arrayList8.add(aVar);
        }
        int iA = com.omarea.krscript.ui.a.f575d.a(this.f, new ArrayList<>(kotlin.collections.q.U(arrayList8)));
        if (iA > -1) {
            TextView textView = this.f594c;
            if (textView == null) {
                kotlin.jvm.internal.r.q("valueView");
                throw null;
            }
            textView.setText(strArr2[iA]);
            TextView textView2 = this.f595d;
            if (textView2 != null) {
                textView2.setText(strArr[iA]);
                return;
            } else {
                kotlin.jvm.internal.r.q("nameView");
                throw null;
            }
        }
        TextView textView3 = this.f594c;
        if (textView3 == null) {
            kotlin.jvm.internal.r.q("valueView");
            throw null;
        }
        textView3.setText("");
        TextView textView4 = this.f595d;
        if (textView4 == null) {
            kotlin.jvm.internal.r.q("nameView");
            throw null;
        }
        textView4.setText("");
    }

    @Override // com.omarea.common.ui.c.a
    public void a(List<? extends AdapterAppChooser.b> list) {
        TextView textView;
        String appName;
        kotlin.jvm.internal.r.d(list, "apps");
        if (this.f.getMultiple()) {
            ArrayList arrayList = new ArrayList(kotlin.collections.q.k(list, 10));
            Iterator<T> it = list.iterator();
            while (it.hasNext()) {
                arrayList.add(((AdapterAppChooser.b) it.next()).getPackageName());
            }
            String strA = kotlin.collections.q.A(arrayList, this.f.getSeparator(), (CharSequence) null, (CharSequence) null, 0, (CharSequence) null, (kotlin.jvm.b.l) null, 62, (Object) null);
            ArrayList arrayList2 = new ArrayList(kotlin.collections.q.k(list, 10));
            Iterator<T> it2 = list.iterator();
            while (it2.hasNext()) {
                arrayList2.add(((AdapterAppChooser.b) it2.next()).getAppName());
            }
            appName = kotlin.collections.q.A(arrayList2, "，", (CharSequence) null, (CharSequence) null, 0, (CharSequence) null, (kotlin.jvm.b.l) null, 62, (Object) null);
            TextView textView2 = this.f594c;
            if (textView2 == null) {
                kotlin.jvm.internal.r.q("valueView");
                throw null;
            }
            textView2.setText(strA);
            textView = this.f595d;
            if (textView == null) {
                kotlin.jvm.internal.r.q("nameView");
                throw null;
            }
        } else {
            AdapterAppChooser.b bVar = (AdapterAppChooser.b) kotlin.collections.q.u(list);
            if (bVar == null) {
                TextView textView3 = this.f594c;
                if (textView3 == null) {
                    kotlin.jvm.internal.r.q("valueView");
                    throw null;
                }
                textView3.setText("");
                TextView textView4 = this.f595d;
                if (textView4 != null) {
                    textView4.setText("");
                    return;
                } else {
                    kotlin.jvm.internal.r.q("nameView");
                    throw null;
                }
            }
            TextView textView5 = this.f594c;
            if (textView5 == null) {
                kotlin.jvm.internal.r.q("valueView");
                throw null;
            }
            textView5.setText(bVar.getPackageName());
            textView = this.f595d;
            if (textView == null) {
                kotlin.jvm.internal.r.q("nameView");
                throw null;
            }
            appName = bVar.getAppName();
        }
        textView.setText(appName);
    }

    public final View e() {
        View viewInflate = LayoutInflater.from(this.g).inflate(com.omarea.c.g.kr_param_app, (ViewGroup) null);
        View viewFindViewById = viewInflate.findViewById(com.omarea.c.f.kr_param_app_package);
        kotlin.jvm.internal.r.c(viewFindViewById, "layout.findViewById(R.id.kr_param_app_package)");
        this.f594c = (TextView) viewFindViewById;
        View viewFindViewById2 = viewInflate.findViewById(com.omarea.c.f.kr_param_app_name);
        kotlin.jvm.internal.r.c(viewFindViewById2, "layout.findViewById(R.id.kr_param_app_name)");
        this.f595d = (TextView) viewFindViewById2;
        g();
        viewInflate.findViewById(com.omarea.c.f.kr_param_app_btn).setOnClickListener(new a());
        TextView textView = this.f595d;
        if (textView == null) {
            kotlin.jvm.internal.r.q("nameView");
            throw null;
        }
        textView.setOnClickListener(new b());
        TextView textView2 = this.f594c;
        if (textView2 == null) {
            kotlin.jvm.internal.r.q("valueView");
            throw null;
        }
        textView2.setTag(this.f.getName());
        kotlin.jvm.internal.r.c(viewInflate, "layout");
        return viewInflate;
    }
}
