package com.omarea.krscript.ui;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import com.omarea.krscript.model.ActionParamInfo;
import com.omarea.krscript.model.ParamInfoFilter;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class o {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private ActionParamInfo f604a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private Context f605b;

    public o(ActionParamInfo actionParamInfo, Context context) {
        kotlin.jvm.internal.r.d(actionParamInfo, "actionParamInfo");
        kotlin.jvm.internal.r.d(context, "context");
        this.f604a = actionParamInfo;
        this.f605b = context;
    }

    /* JADX WARN: Code duplicated, block: B:12:0x0066  */
    /* JADX WARN: Code duplicated, block: B:14:0x0069  */
    /* JADX WARN: Code duplicated, block: B:16:0x0073  */
    public final View a() {
        String value;
        String placeholder;
        View viewInflate = LayoutInflater.from(this.f605b).inflate(com.omarea.c.g.kr_param_text, (ViewGroup) null);
        EditText editText = (EditText) viewInflate.findViewById(com.omarea.c.f.kr_param_text);
        editText.setTag(this.f604a.getName());
        if (this.f604a.getValueFromShell() == null) {
            if (this.f604a.getValue() != null) {
                value = this.f604a.getValue();
            }
            editText.setFilters(new ParamInfoFilter[]{new ParamInfoFilter(this.f604a)});
            editText.setEnabled(!this.f604a.getReadonly());
            if (this.f604a.getPlaceholder().length() > 0) {
                if ((kotlin.jvm.internal.r.a(this.f604a.getType(), "int") || kotlin.jvm.internal.r.a(this.f604a.getType(), "number")) && (this.f604a.getMin() != Integer.MIN_VALUE || this.f604a.getMax() != Integer.MAX_VALUE)) {
                    placeholder = this.f604a.getMin() + " ~ " + this.f604a.getMax();
                }
                kotlin.jvm.internal.r.c(viewInflate, "layout");
                return viewInflate;
            }
            placeholder = this.f604a.getPlaceholder();
            editText.setHint(placeholder);
            kotlin.jvm.internal.r.c(viewInflate, "layout");
            return viewInflate;
        }
        value = this.f604a.getValueFromShell();
        editText.setText(value);
        editText.setFilters(new ParamInfoFilter[]{new ParamInfoFilter(this.f604a)});
        editText.setEnabled(!this.f604a.getReadonly());
        if (this.f604a.getPlaceholder().length() > 0) {
            if (kotlin.jvm.internal.r.a(this.f604a.getType(), "int")) {
                placeholder = this.f604a.getMin() + " ~ " + this.f604a.getMax();
            } else {
                placeholder = this.f604a.getMin() + " ~ " + this.f604a.getMax();
            }
            kotlin.jvm.internal.r.c(viewInflate, "layout");
            return viewInflate;
        }
        placeholder = this.f604a.getPlaceholder();
        editText.setHint(placeholder);
        kotlin.jvm.internal.r.c(viewInflate, "layout");
        return viewInflate;
    }
}
