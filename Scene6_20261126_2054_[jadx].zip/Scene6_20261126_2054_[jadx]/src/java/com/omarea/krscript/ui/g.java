package com.omarea.krscript.ui;

import android.content.Context;
import android.widget.Switch;
import com.omarea.krscript.model.SwitchNode;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class g extends c {
    private Switch m;
    private final Context n;
    private final SwitchNode o;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public g(Context context, SwitchNode switchNode) {
        super(context, com.omarea.c.g.kr_switch_list_item, switchNode);
        kotlin.jvm.internal.r.d(context, "context");
        kotlin.jvm.internal.r.d(switchNode, "config");
        this.n = context;
        this.o = switchNode;
        this.m = (Switch) c().findViewById(com.omarea.c.f.kr_switch);
        n(this.o.getChecked());
    }

    @Override // com.omarea.krscript.ui.i
    public void h() {
        super.h();
        boolean z = true;
        if (this.o.getGetState().length() > 0) {
            String strC = com.omarea.c.n.b.c(this.n, this.o.getGetState(), this.o);
            SwitchNode switchNode = this.o;
            if (!kotlin.jvm.internal.r.a(strC, "1")) {
                kotlin.jvm.internal.r.c(strC, "shellResult");
                if (strC == null) {
                    throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                }
                String lowerCase = strC.toLowerCase();
                kotlin.jvm.internal.r.c(lowerCase, "(this as java.lang.String).toLowerCase()");
                if (!kotlin.jvm.internal.r.a(lowerCase, "true")) {
                    z = false;
                }
            }
            switchNode.setChecked(z);
        }
        n(this.o.getChecked());
    }

    public final void n(boolean z) {
        Switch r0 = this.m;
        if (r0 != null) {
            r0.setChecked(z);
        }
    }
}
