package com.omarea.krscript.ui;

import android.R;
import android.content.Context;
import android.view.ViewGroup;
import com.omarea.krscript.model.GroupNode;
import java.util.ArrayList;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class d extends i {
    private ArrayList<i> h;
    private boolean i;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public d(Context context, boolean z, GroupNode groupNode) {
        super(context, z ? com.omarea.c.g.kr_group_list_root : com.omarea.c.g.kr_group_list_item, groupNode);
        kotlin.jvm.internal.r.d(context, "context");
        kotlin.jvm.internal.r.d(groupNode, "config");
        this.i = z;
        this.h = new ArrayList<>();
        g(groupNode.getTitle());
    }

    public final d i(i iVar) {
        kotlin.jvm.internal.r.d(iVar, "item");
        ((ViewGroup) c().findViewById(R.id.content)).addView(iVar.d());
        this.h.add(iVar);
        return this;
    }

    public final boolean j() {
        return this.i;
    }

    public final boolean k(String str) {
        kotlin.jvm.internal.r.d(str, "key");
        for (i iVar : this.h) {
            if ((iVar instanceof c) && iVar.b().equals(str)) {
                ((c) iVar).m();
                return true;
            }
            if ((iVar instanceof d) && ((d) iVar).k(str)) {
                return true;
            }
        }
        return false;
    }

    public final void l() {
        for (i iVar : this.h) {
            if (iVar instanceof d) {
                ((d) iVar).l();
            } else {
                iVar.h();
            }
        }
    }

    public final void m(String[] strArr) {
        kotlin.jvm.internal.r.d(strArr, "keys");
        for (String str : strArr) {
            if (str.equals(b())) {
                l();
            } else {
                for (i iVar : this.h) {
                    if (iVar instanceof d) {
                        ((d) iVar).m(strArr);
                    } else if (iVar.b().equals(str)) {
                        iVar.h();
                    }
                }
            }
        }
    }
}
