package com.omarea.krscript.ui;

import android.content.Context;
import android.widget.ImageView;
import com.omarea.krscript.model.PageNode;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class e extends c {
    private final ImageView m;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public e(Context context, PageNode pageNode) {
        super(context, com.omarea.c.g.kr_action_list_item, pageNode);
        kotlin.jvm.internal.r.d(context, "context");
        kotlin.jvm.internal.r.d(pageNode, "config");
        ImageView imageView = (ImageView) c().findViewById(com.omarea.c.f.kr_widget);
        this.m = imageView;
        if (imageView != null) {
            imageView.setVisibility(0);
        }
        ImageView imageView2 = this.m;
        if (imageView2 != null) {
            imageView2.setImageDrawable(context.getDrawable(com.omarea.c.e.kr_arrow));
        }
    }
}
