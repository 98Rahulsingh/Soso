package com.omarea.krscript.ui;

import android.app.Activity;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Build;
import android.os.Bundle;
import android.os.Message;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.omarea.krscript.model.RunnableNode;
import com.omarea.krscript.model.ShellHandlerBase;
import java.util.HashMap;
import kotlin.jvm.internal.Ref;
import kotlinx.coroutines.CoroutineStart;
import kotlinx.coroutines.h1;
import kotlinx.coroutines.w0;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class DialogLogFragment extends androidx.fragment.app.c {
    public static final a w0 = new a(null);
    private boolean n0;
    private RunnableNode o0;
    private Runnable p0;
    private String q0;
    private HashMap<String, String> r0;
    private int s0;
    private View t0;
    private Runnable u0;
    private HashMap v0;

    public static final class MyShellHandler extends ShellHandlerBase {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final Context f568a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private final int f569b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private final int f570c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        private final int f571d;
        private final int e;
        private boolean f;
        private final StringBuffer g;
        private int h;
        private boolean i;
        private b j;
        private TextView k;
        private ProgressBar l;

        static final class a implements Runnable {
            final /* synthetic */ SpannableString g;

            a(SpannableString spannableString) {
                this.g = spannableString;
            }

            @Override // java.lang.Runnable
            public final void run() {
                MyShellHandler.this.k.append(this.g);
                ViewParent parent = MyShellHandler.this.k.getParent();
                if (parent == null) {
                    throw new NullPointerException("null cannot be cast to non-null type android.widget.ScrollView");
                }
                ((ScrollView) parent).fullScroll(130);
            }
        }

        static final class b implements Runnable {
            final /* synthetic */ SpannableString g;

            b(SpannableString spannableString) {
                this.g = spannableString;
            }

            @Override // java.lang.Runnable
            public final void run() {
                MyShellHandler.this.k.append(this.g);
                ViewParent parent = MyShellHandler.this.k.getParent();
                if (parent == null) {
                    throw new NullPointerException("null cannot be cast to non-null type android.widget.ScrollView");
                }
                ((ScrollView) parent).fullScroll(130);
            }
        }

        public MyShellHandler(b bVar, TextView textView, ProgressBar progressBar) {
            kotlin.jvm.internal.r.d(bVar, "actionEventHandler");
            kotlin.jvm.internal.r.d(textView, "logView");
            kotlin.jvm.internal.r.d(progressBar, "shellProgress");
            this.j = bVar;
            this.k = textView;
            this.l = progressBar;
            this.f568a = textView.getContext();
            this.f569b = f(com.omarea.c.d.kr_shell_log_error);
            this.f570c = f(com.omarea.c.d.kr_shell_log_basic);
            this.f571d = f(com.omarea.c.d.kr_shell_log_script);
            this.e = f(com.omarea.c.d.kr_shell_log_end);
            this.g = new StringBuffer();
            this.h = -1;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public final void e() {
            if (this.g.length() > 0) {
                SpannableString spannableString = new SpannableString(this.g);
                spannableString.setSpan(new ForegroundColorSpan(this.h), 0, this.g.length(), 33);
                this.k.post(new a(spannableString));
                StringBuffer stringBuffer = this.g;
                stringBuffer.delete(0, stringBuffer.length());
            }
        }

        private final int f(int i) {
            if (Build.VERSION.SDK_INT >= 23) {
                Context context = this.f568a;
                kotlin.jvm.internal.r.b(context);
                return context.getColor(i);
            }
            Context context2 = this.f568a;
            kotlin.jvm.internal.r.b(context2);
            return context2.getResources().getColor(i);
        }

        @Override // com.omarea.krscript.model.ShellHandlerBase, android.os.Handler
        public void handleMessage(Message message) {
            kotlin.jvm.internal.r.d(message, "msg");
            int i = message.what;
            if (i == -2) {
                onExit(message.obj);
                return;
            }
            if (i == 0) {
                onStart(message.obj);
                return;
            }
            if (i == 2) {
                onReaderMsg(message.obj);
                return;
            }
            if (i == 4) {
                Object obj = message.obj;
                kotlin.jvm.internal.r.c(obj, "msg.obj");
                onError(obj);
            } else {
                if (i != 6) {
                    return;
                }
                Object obj2 = message.obj;
                kotlin.jvm.internal.r.c(obj2, "msg.obj");
                onWrite(obj2);
            }
        }

        @Override // com.omarea.krscript.model.ShellHandlerBase
        protected void onError(Object obj) {
            kotlin.jvm.internal.r.d(obj, "msg");
            this.f = true;
            updateLog(obj, this.f569b);
        }

        @Override // com.omarea.krscript.model.ShellHandlerBase
        protected void onExit(Object obj) {
            this.i = false;
            updateLog(this.f568a.getString(com.omarea.c.h.kr_shell_completed), this.e);
            e();
            this.j.c();
            if (this.f) {
                return;
            }
            this.j.b();
        }

        @Override // com.omarea.krscript.model.ShellHandlerBase
        protected void onProgress(int i, int i2) {
            if (i == -1) {
                this.l.setVisibility(0);
                this.l.setIndeterminate(true);
            } else {
                if (i == i2) {
                    this.l.setVisibility(8);
                    return;
                }
                this.l.setVisibility(0);
                this.l.setIndeterminate(false);
                this.l.setMax(i2);
                this.l.setProgress(i);
            }
        }

        @Override // com.omarea.krscript.model.ShellHandlerBase
        protected void onReader(Object obj) {
            kotlin.jvm.internal.r.d(obj, "msg");
            updateLog(obj, this.f570c);
        }

        @Override // com.omarea.krscript.model.ShellHandlerBase
        protected void onStart(Object obj) {
            this.k.setText("");
        }

        @Override // com.omarea.krscript.model.ShellHandlerBase
        public void onStart(Runnable runnable) {
            this.j.a(runnable);
            this.i = true;
            kotlinx.coroutines.f.d(h1.f, w0.c(), (CoroutineStart) null, new DialogLogFragment$MyShellHandler$onStart$1(this, null), 2, (Object) null);
        }

        @Override // com.omarea.krscript.model.ShellHandlerBase
        protected void onWrite(Object obj) {
            kotlin.jvm.internal.r.d(obj, "msg");
            updateLog(obj, this.f571d);
        }

        @Override // com.omarea.krscript.model.ShellHandlerBase
        protected void updateLog(SpannableString spannableString) {
            if (spannableString != null) {
                this.k.post(new b(spannableString));
            }
        }

        @Override // com.omarea.krscript.model.ShellHandlerBase
        protected void updateLog(Object obj, int i) {
            if (obj != null) {
                if (this.h != i) {
                    e();
                    this.h = i;
                }
                this.g.append(obj.toString());
            }
        }
    }

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(kotlin.jvm.internal.o oVar) {
            this();
        }

        public final DialogLogFragment a(RunnableNode runnableNode, Runnable runnable, Runnable runnable2, String str, HashMap<String, String> map, boolean z) {
            kotlin.jvm.internal.r.d(runnableNode, "nodeInfo");
            kotlin.jvm.internal.r.d(runnable, "onExit");
            kotlin.jvm.internal.r.d(runnable2, "onDismiss");
            kotlin.jvm.internal.r.d(str, "script");
            DialogLogFragment dialogLogFragment = new DialogLogFragment();
            dialogLogFragment.o0 = runnableNode;
            dialogLogFragment.p0 = runnable;
            dialogLogFragment.q0 = str;
            dialogLogFragment.r0 = map;
            dialogLogFragment.s0 = z ? com.omarea.c.i.kr_full_screen_dialog_dark : com.omarea.c.i.kr_full_screen_dialog_light;
            dialogLogFragment.u0 = runnable2;
            return dialogLogFragment;
        }
    }

    @FunctionalInterface
    public interface b {
        void a(Runnable runnable);

        void b();

        void c();
    }

    static final class c implements View.OnClickListener {
        c() {
        }

        @Override // android.view.View.OnClickListener
        public final void onClick(View view) {
            DialogLogFragment.this.R1();
        }
    }

    static final class d implements View.OnClickListener {
        final /* synthetic */ Ref.ObjectRef g;

        d(Ref.ObjectRef objectRef) {
            this.g = objectRef;
        }

        @Override // android.view.View.OnClickListener
        public final void onClick(View view) {
            Runnable runnable;
            if (DialogLogFragment.this.n0 && (runnable = (Runnable) this.g.element) != null) {
                runnable.run();
            }
            DialogLogFragment.this.R1();
        }
    }

    static final class e implements View.OnClickListener {
        e() {
        }

        @Override // android.view.View.OnClickListener
        public final void onClick(View view) {
            try {
                Context contextQ = DialogLogFragment.this.q();
                kotlin.jvm.internal.r.b(contextQ);
                Object systemService = contextQ.getSystemService("clipboard");
                if (systemService == null) {
                    throw new NullPointerException("null cannot be cast to non-null type android.content.ClipboardManager");
                }
                TextView textView = (TextView) DialogLogFragment.this.G1(com.omarea.c.f.shell_output);
                kotlin.jvm.internal.r.c(textView, "shell_output");
                ClipData clipDataNewPlainText = ClipData.newPlainText("text", textView.getText().toString());
                kotlin.jvm.internal.r.c(clipDataNewPlainText, "ClipData.newPlainText(\"t…l_output.text.toString())");
                ((ClipboardManager) systemService).setPrimaryClip(clipDataNewPlainText);
                Toast.makeText(DialogLogFragment.this.q(), DialogLogFragment.this.K(com.omarea.c.h.copy_success), 0).show();
            } catch (Exception unused) {
                Toast.makeText(DialogLogFragment.this.q(), DialogLogFragment.this.K(com.omarea.c.h.copy_fail), 0).show();
            }
        }
    }

    public static final class f implements b {

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final /* synthetic */ RunnableNode f573b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        final /* synthetic */ Ref.ObjectRef f574c;

        f(RunnableNode runnableNode, Ref.ObjectRef objectRef) {
            this.f573b = runnableNode;
            this.f574c = objectRef;
        }

        @Override // com.omarea.krscript.ui.DialogLogFragment.b
        public void a(Runnable runnable) {
            Button button;
            int i;
            DialogLogFragment.this.n0 = true;
            if (!this.f573b.getInterruptable() || runnable == null) {
                button = (Button) DialogLogFragment.this.G1(com.omarea.c.f.btn_exit);
                kotlin.jvm.internal.r.c(button, "btn_exit");
                i = 8;
            } else {
                button = (Button) DialogLogFragment.this.G1(com.omarea.c.f.btn_exit);
                kotlin.jvm.internal.r.c(button, "btn_exit");
                i = 0;
            }
            button.setVisibility(i);
            this.f574c.element = runnable;
        }

        @Override // com.omarea.krscript.ui.DialogLogFragment.b
        public void b() {
            if (this.f573b.getAutoOff()) {
                DialogLogFragment.this.R1();
            }
        }

        @Override // com.omarea.krscript.ui.DialogLogFragment.b
        public void c() {
            DialogLogFragment.this.n0 = false;
            DialogLogFragment.I1(DialogLogFragment.this).run();
            if (((ImageButton) DialogLogFragment.this.G1(com.omarea.c.f.btn_hide)) != null) {
                ImageButton imageButton = (ImageButton) DialogLogFragment.this.G1(com.omarea.c.f.btn_hide);
                kotlin.jvm.internal.r.c(imageButton, "btn_hide");
                imageButton.setVisibility(8);
                Button button = (Button) DialogLogFragment.this.G1(com.omarea.c.f.btn_exit);
                kotlin.jvm.internal.r.c(button, "btn_exit");
                button.setVisibility(0);
                ProgressBar progressBar = (ProgressBar) DialogLogFragment.this.G1(com.omarea.c.f.action_progress);
                kotlin.jvm.internal.r.c(progressBar, "action_progress");
                progressBar.setVisibility(8);
            }
            DialogLogFragment.this.C1(true);
        }
    }

    public static final /* synthetic */ Runnable I1(DialogLogFragment dialogLogFragment) {
        Runnable runnable = dialogLogFragment.p0;
        if (runnable != null) {
            return runnable;
        }
        kotlin.jvm.internal.r.q("onExit");
        throw null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void R1() {
        try {
            y1();
        } catch (Exception unused) {
        }
    }

    private final ShellHandlerBase S1(RunnableNode runnableNode) {
        Ref.ObjectRef objectRef = new Ref.ObjectRef();
        objectRef.element = null;
        ((ImageButton) G1(com.omarea.c.f.btn_hide)).setOnClickListener(new c());
        ((Button) G1(com.omarea.c.f.btn_exit)).setOnClickListener(new d(objectRef));
        ((Button) G1(com.omarea.c.f.btn_copy)).setOnClickListener(new e());
        if (runnableNode.getInterruptable()) {
            ImageButton imageButton = (ImageButton) G1(com.omarea.c.f.btn_hide);
            if (imageButton != null) {
                imageButton.setVisibility(0);
            }
            Button button = (Button) G1(com.omarea.c.f.btn_exit);
            if (button != null) {
                button.setVisibility(0);
            }
        } else {
            ImageButton imageButton2 = (ImageButton) G1(com.omarea.c.f.btn_hide);
            if (imageButton2 != null) {
                imageButton2.setVisibility(8);
            }
            Button button2 = (Button) G1(com.omarea.c.f.btn_exit);
            if (button2 != null) {
                button2.setVisibility(8);
            }
        }
        if (runnableNode.getTitle().length() == 0) {
            TextView textView = (TextView) G1(com.omarea.c.f.title);
            kotlin.jvm.internal.r.c(textView, "title");
            textView.setVisibility(8);
        } else {
            TextView textView2 = (TextView) G1(com.omarea.c.f.title);
            kotlin.jvm.internal.r.c(textView2, "title");
            textView2.setText(runnableNode.getTitle());
        }
        if (runnableNode.getDesc().length() == 0) {
            TextView textView3 = (TextView) G1(com.omarea.c.f.desc);
            kotlin.jvm.internal.r.c(textView3, "desc");
            textView3.setVisibility(8);
        } else {
            TextView textView4 = (TextView) G1(com.omarea.c.f.desc);
            kotlin.jvm.internal.r.c(textView4, "desc");
            textView4.setText(runnableNode.getDesc());
        }
        ProgressBar progressBar = (ProgressBar) G1(com.omarea.c.f.action_progress);
        kotlin.jvm.internal.r.c(progressBar, "action_progress");
        progressBar.setIndeterminate(true);
        f fVar = new f(runnableNode, objectRef);
        TextView textView5 = (TextView) G1(com.omarea.c.f.shell_output);
        kotlin.jvm.internal.r.c(textView5, "shell_output");
        ProgressBar progressBar2 = (ProgressBar) G1(com.omarea.c.f.action_progress);
        kotlin.jvm.internal.r.c(progressBar2, "action_progress");
        return new MyShellHandler(fVar, textView5, progressBar2);
    }

    public Dialog B1(Bundle bundle) {
        androidx.fragment.app.d dVarJ = j();
        kotlin.jvm.internal.r.b(dVarJ);
        int i = this.s0;
        if (i == 0) {
            i = com.omarea.c.i.kr_full_screen_dialog_light;
        }
        return new Dialog(dVarJ, i);
    }

    public void E0(View view, Bundle bundle) {
        Dialog dialogA1;
        Window window;
        kotlin.jvm.internal.r.d(view, "view");
        super/*androidx.fragment.app.Fragment*/.E0(view, bundle);
        Activity activityJ = j();
        if (activityJ == null || (dialogA1 = A1()) == null || (window = dialogA1.getWindow()) == null) {
            return;
        }
        com.omarea.common.ui.e.f492b.E(window, activityJ);
    }

    public void F1() {
        HashMap map = this.v0;
        if (map != null) {
            map.clear();
        }
    }

    public View G1(int i) {
        if (this.v0 == null) {
            this.v0 = new HashMap();
        }
        View view = (View) this.v0.get(Integer.valueOf(i));
        if (view != null) {
            return view;
        }
        View viewN = N();
        if (viewN == null) {
            return null;
        }
        View viewFindViewById = viewN.findViewById(i);
        this.v0.put(Integer.valueOf(i), viewFindViewById);
        return viewFindViewById;
    }

    public void Z(Bundle bundle) {
        super.Z(bundle);
        RunnableNode runnableNode = this.o0;
        if (runnableNode == null) {
            y1();
            return;
        }
        if (runnableNode != null) {
            if (runnableNode.getReloadPage()) {
                ImageButton imageButton = (ImageButton) G1(com.omarea.c.f.btn_hide);
                kotlin.jvm.internal.r.c(imageButton, "btn_hide");
                imageButton.setVisibility(8);
            }
            ShellHandlerBase shellHandlerBaseS1 = S1(runnableNode);
            com.omarea.c.n.c cVar = new com.omarea.c.n.c();
            androidx.fragment.app.d dVarJ = j();
            String str = this.q0;
            if (str == null) {
                kotlin.jvm.internal.r.q("script");
                throw null;
            }
            Runnable runnable = this.p0;
            if (runnable != null) {
                cVar.a(dVarJ, runnableNode, str, runnable, this.r0, shellHandlerBaseS1);
            } else {
                kotlin.jvm.internal.r.q("onExit");
                throw null;
            }
        }
    }

    public View j0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        kotlin.jvm.internal.r.d(layoutInflater, "inflater");
        View viewInflate = layoutInflater.inflate(com.omarea.c.g.kr_dialog_log, viewGroup);
        kotlin.jvm.internal.r.c(viewInflate, "inflater.inflate(R.layou…kr_dialog_log, container)");
        this.t0 = viewInflate;
        if (viewInflate != null) {
            return viewInflate;
        }
        kotlin.jvm.internal.r.q("currentView");
        throw null;
    }

    public /* synthetic */ void m0() {
        super.m0();
        F1();
    }

    public void onDismiss(DialogInterface dialogInterface) {
        kotlin.jvm.internal.r.d(dialogInterface, "dialog");
        super.onDismiss(dialogInterface);
        Runnable runnable = this.u0;
        if (runnable != null) {
            runnable.run();
        }
        this.u0 = null;
    }
}
