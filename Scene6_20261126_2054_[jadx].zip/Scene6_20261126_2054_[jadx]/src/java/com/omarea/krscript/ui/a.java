package com.omarea.krscript.ui;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import com.omarea.krscript.model.ActionParamInfo;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class a {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final C0063a f575d = new C0063a(null);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private androidx.fragment.app.d f576a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final String[] f577b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private LinearLayout f578c;

    /* JADX INFO: renamed from: com.omarea.krscript.ui.a$a, reason: collision with other inner class name */
    public static final class C0063a {
        private C0063a() {
        }

        public /* synthetic */ C0063a(kotlin.jvm.internal.o oVar) {
            this();
        }

        public final int a(ActionParamInfo actionParamInfo, ArrayList<com.omarea.a.f.a> arrayList) {
            kotlin.jvm.internal.r.d(actionParamInfo, "actionParamInfo");
            kotlin.jvm.internal.r.d(arrayList, "options");
            ArrayList arrayList2 = new ArrayList();
            if (actionParamInfo.getValueFromShell() != null) {
                String valueFromShell = actionParamInfo.getValueFromShell();
                kotlin.jvm.internal.r.b(valueFromShell);
                arrayList2.add(valueFromShell);
            }
            if (actionParamInfo.getValue() != null) {
                String value = actionParamInfo.getValue();
                kotlin.jvm.internal.r.b(value);
                arrayList2.add(value);
            }
            if (arrayList2.size() <= 0) {
                return -1;
            }
            int size = arrayList2.size();
            int i = -1;
            for (int i2 = 0; i2 < size; i2++) {
                Iterator<com.omarea.a.f.a> it = arrayList.iterator();
                int i3 = 0;
                while (it.hasNext()) {
                    if (kotlin.jvm.internal.r.a(it.next().c(), (String) arrayList2.get(i2))) {
                        i = i3;
                        break;
                    }
                    i3++;
                }
                if (i > -1) {
                    break;
                }
            }
            return i;
        }

        public final boolean[] b(ActionParamInfo actionParamInfo, ArrayList<com.omarea.a.f.a> arrayList) {
            kotlin.jvm.internal.r.d(actionParamInfo, "actionParamInfo");
            kotlin.jvm.internal.r.d(arrayList, "options");
            boolean[] zArr = new boolean[arrayList.size()];
            List<String> listC = c(actionParamInfo);
            int size = arrayList.size();
            for (int i = 0; i < size; i++) {
                com.omarea.a.f.a aVar = arrayList.get(i);
                kotlin.jvm.internal.r.c(aVar, "options[index]");
                zArr[i] = listC != null && kotlin.collections.q.r(listC, aVar.c());
            }
            return zArr;
        }

        public final List<String> c(ActionParamInfo actionParamInfo) {
            kotlin.jvm.internal.r.d(actionParamInfo, "actionParamInfo");
            String valueFromShell = actionParamInfo.getValueFromShell() != null ? actionParamInfo.getValueFromShell() : actionParamInfo.getValue();
            if (valueFromShell != null) {
                return kotlin.text.k.W(valueFromShell, new String[]{actionParamInfo.getSeparator()}, false, 0, 6, (Object) null);
            }
            return null;
        }

        public final ArrayList<com.omarea.a.f.a> d(ActionParamInfo actionParamInfo, ArrayList<com.omarea.a.f.a> arrayList) {
            kotlin.jvm.internal.r.d(actionParamInfo, "actionParamInfo");
            kotlin.jvm.internal.r.d(arrayList, "options");
            List<String> listC = c(actionParamInfo);
            int size = arrayList.size();
            for (int i = 0; i < size; i++) {
                com.omarea.a.f.a aVar = arrayList.get(i);
                kotlin.jvm.internal.r.c(aVar, "options[index]");
                arrayList.get(i).d(listC != null && kotlin.collections.q.r(listC, aVar.c()));
            }
            return arrayList;
        }
    }

    public a(LinearLayout linearLayout, androidx.fragment.app.d dVar) {
        kotlin.jvm.internal.r.d(linearLayout, "linearLayout");
        kotlin.jvm.internal.r.d(dVar, "activity");
        this.f578c = linearLayout;
        this.f576a = dVar;
        this.f577b = new String[]{"bool", "checkbox", "switch"};
    }

    private final void a(View view, ActionParamInfo actionParamInfo) {
        View viewInflate = LayoutInflater.from(this.f576a).inflate(com.omarea.c.g.kr_param_row, (ViewGroup) null);
        String title = actionParamInfo.getTitle();
        if (title == null || title.length() == 0) {
            View viewFindViewById = viewInflate.findViewById(com.omarea.c.f.kr_param_title);
            kotlin.jvm.internal.r.c(viewFindViewById, "layout.findViewById<TextView>(R.id.kr_param_title)");
            ((TextView) viewFindViewById).setVisibility(8);
        } else {
            View viewFindViewById2 = viewInflate.findViewById(com.omarea.c.f.kr_param_title);
            kotlin.jvm.internal.r.c(viewFindViewById2, "layout.findViewById<TextView>(R.id.kr_param_title)");
            ((TextView) viewFindViewById2).setText(actionParamInfo.getTitle());
        }
        String label = actionParamInfo.getLabel();
        if ((label == null || label.length() == 0) || kotlin.collections.h.j(this.f577b, actionParamInfo.getType())) {
            View viewFindViewById3 = viewInflate.findViewById(com.omarea.c.f.kr_param_label);
            kotlin.jvm.internal.r.c(viewFindViewById3, "layout.findViewById<TextView>(R.id.kr_param_label)");
            ((TextView) viewFindViewById3).setVisibility(8);
        } else {
            ((TextView) viewInflate.findViewById(com.omarea.c.f.kr_param_label)).setText(actionParamInfo.getLabel());
        }
        String desc = actionParamInfo.getDesc();
        if (desc == null || desc.length() == 0) {
            View viewFindViewById4 = viewInflate.findViewById(com.omarea.c.f.kr_param_desc);
            kotlin.jvm.internal.r.c(viewFindViewById4, "layout.findViewById<TextView>(R.id.kr_param_desc)");
            ((TextView) viewFindViewById4).setVisibility(8);
        } else {
            View viewFindViewById5 = viewInflate.findViewById(com.omarea.c.f.kr_param_desc);
            kotlin.jvm.internal.r.c(viewFindViewById5, "layout.findViewById<TextView>(R.id.kr_param_desc)");
            ((TextView) viewFindViewById5).setText(actionParamInfo.getDesc());
        }
        ((FrameLayout) viewInflate.findViewById(com.omarea.c.f.kr_param_input)).addView(view);
        this.f578c.addView(viewInflate);
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (layoutParams == null) {
            throw new NullPointerException("null cannot be cast to non-null type android.widget.FrameLayout.LayoutParams");
        }
        ((FrameLayout.LayoutParams) layoutParams).gravity = 16;
    }

    private final String b(ActionParamInfo actionParamInfo) {
        StringBuilder sb = new StringBuilder();
        String title = actionParamInfo.getTitle();
        if (!(title == null || title.length() == 0)) {
            sb.append(actionParamInfo.getTitle());
            sb.append(" ");
        }
        String label = actionParamInfo.getLabel();
        if (!(label == null || label.length() == 0)) {
            sb.append(actionParamInfo.getLabel());
            sb.append(" ");
        }
        sb.append("(");
        sb.append(actionParamInfo.getName());
        sb.append(") ");
        String string = sb.toString();
        kotlin.jvm.internal.r.c(string, "tips.toString()");
        return string;
    }

    /* JADX WARN: Code duplicated, block: B:41:0x0123  */
    /* JADX WARN: Code duplicated, block: B:73:0x018c  */
    /* JADX WARN: Code duplicated, block: B:86:0x01bc A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:87:0x0198 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:88:0x0186 A[SYNTHETIC] */
    public final HashMap<String, String> c(ArrayList<ActionParamInfo> arrayList) throws Exception {
        Object selectedItem;
        String strC;
        String value;
        kotlin.jvm.internal.r.d(arrayList, "actionParamInfos");
        HashMap<String, String> map = new HashMap<>();
        for (ActionParamInfo actionParamInfo : arrayList) {
            if (actionParamInfo.getName() != null) {
                View viewFindViewWithTag = this.f578c.findViewWithTag(actionParamInfo.getName());
                boolean z = true;
                if (viewFindViewWithTag instanceof EditText) {
                    strC = ((EditText) viewFindViewWithTag).getText().toString();
                    if (strC.length() > 0) {
                        if (kotlin.jvm.internal.r.a(actionParamInfo.getType(), "int") || kotlin.jvm.internal.r.a(actionParamInfo.getType(), "number")) {
                            try {
                                int i = Integer.parseInt(strC);
                                if (i < actionParamInfo.getMin()) {
                                    StringBuilder sb = new StringBuilder();
                                    kotlin.jvm.internal.r.c(actionParamInfo, "actionParamInfo");
                                    sb.append(b(actionParamInfo));
                                    sb.append(' ');
                                    sb.append(i);
                                    sb.append(" < ");
                                    sb.append(actionParamInfo.getMin());
                                    sb.append(" !!!");
                                    throw new Exception(sb.toString());
                                }
                                if (i > actionParamInfo.getMax()) {
                                    StringBuilder sb2 = new StringBuilder();
                                    kotlin.jvm.internal.r.c(actionParamInfo, "actionParamInfo");
                                    sb2.append(b(actionParamInfo));
                                    sb2.append(' ');
                                    sb2.append(i);
                                    sb2.append(" > ");
                                    sb2.append(actionParamInfo.getMax());
                                    sb2.append(" !!!");
                                    throw new Exception(sb2.toString());
                                }
                            } catch (NumberFormatException unused) {
                            }
                        } else if (kotlin.jvm.internal.r.a(actionParamInfo.getType(), "color")) {
                            try {
                                Color.parseColor(strC);
                            } catch (Exception unused2) {
                                StringBuilder sb3 = new StringBuilder();
                                sb3.append("");
                                kotlin.jvm.internal.r.c(actionParamInfo, "actionParamInfo");
                                sb3.append(b(actionParamInfo));
                                sb3.append("  \n");
                                sb3.append(this.f576a.getString(com.omarea.c.h.kr_invalid_color));
                                throw new Exception(sb3.toString());
                            }
                        }
                    }
                } else {
                    String str = "1";
                    if (viewFindViewWithTag instanceof CheckBox) {
                        if (!((CheckBox) viewFindViewWithTag).isChecked()) {
                            str = "0";
                        }
                        actionParamInfo.setValue(str);
                    } else if (viewFindViewWithTag instanceof Switch) {
                        if (!((Switch) viewFindViewWithTag).isChecked()) {
                            str = "0";
                        }
                        actionParamInfo.setValue(str);
                    } else if (viewFindViewWithTag instanceof SeekBar) {
                        strC = String.valueOf(((SeekBar) viewFindViewWithTag).getProgress() + actionParamInfo.getMin());
                    } else {
                        if (viewFindViewWithTag instanceof TextView) {
                            selectedItem = ((TextView) viewFindViewWithTag).getText();
                        } else if (viewFindViewWithTag instanceof Spinner) {
                            selectedItem = ((Spinner) viewFindViewWithTag).getSelectedItem();
                            if (selectedItem instanceof com.omarea.a.f.a) {
                                strC = ((com.omarea.a.f.a) selectedItem).c();
                            } else if (selectedItem == null) {
                                actionParamInfo.setValue("");
                            }
                        }
                        strC = selectedItem.toString();
                    }
                    value = actionParamInfo.getValue();
                    if (value != null && value.length() != 0) {
                        z = false;
                    }
                    if (z) {
                        String name = actionParamInfo.getName();
                        kotlin.jvm.internal.r.b(name);
                        String value2 = actionParamInfo.getValue();
                        kotlin.jvm.internal.r.b(value2);
                        map.put(name, value2);
                    } else {
                        if (!actionParamInfo.getRequired()) {
                            StringBuilder sb4 = new StringBuilder();
                            kotlin.jvm.internal.r.c(actionParamInfo, "actionParamInfo");
                            sb4.append(b(actionParamInfo));
                            sb4.append(this.f576a.getString(com.omarea.c.h.do_not_empty));
                            throw new Exception(sb4.toString());
                        }
                        String name2 = actionParamInfo.getName();
                        kotlin.jvm.internal.r.b(name2);
                        map.put(name2, "");
                    }
                }
                actionParamInfo.setValue(strC);
                value = actionParamInfo.getValue();
                if (value != null) {
                    z = false;
                }
                if (z) {
                    String name3 = actionParamInfo.getName();
                    kotlin.jvm.internal.r.b(name3);
                    String value3 = actionParamInfo.getValue();
                    kotlin.jvm.internal.r.b(value3);
                    map.put(name3, value3);
                } else {
                    if (!actionParamInfo.getRequired()) {
                        StringBuilder sb5 = new StringBuilder();
                        kotlin.jvm.internal.r.c(actionParamInfo, "actionParamInfo");
                        sb5.append(b(actionParamInfo));
                        sb5.append(this.f576a.getString(com.omarea.c.h.do_not_empty));
                        throw new Exception(sb5.toString());
                    }
                    String name4 = actionParamInfo.getName();
                    kotlin.jvm.internal.r.b(name4);
                    map.put(name4, "");
                }
            }
        }
        return map;
    }

    public final void d(ArrayList<ActionParamInfo> arrayList, p.a aVar) {
        View viewB;
        kotlin.jvm.internal.r.d(arrayList, "actionParamInfos");
        for (ActionParamInfo actionParamInfo : arrayList) {
            if (actionParamInfo.getOptionsFromShell() == null || kotlin.jvm.internal.r.a(actionParamInfo.getType(), "app") || kotlin.jvm.internal.r.a(actionParamInfo.getType(), "packages")) {
                if (kotlin.jvm.internal.r.a(actionParamInfo.getType(), "bool") || kotlin.jvm.internal.r.a(actionParamInfo.getType(), "checkbox")) {
                    kotlin.jvm.internal.r.c(actionParamInfo, "actionParamInfo");
                    viewB = new m(actionParamInfo, this.f576a).b();
                } else if (kotlin.jvm.internal.r.a(actionParamInfo.getType(), "switch")) {
                    kotlin.jvm.internal.r.c(actionParamInfo, "actionParamInfo");
                    viewB = new t(actionParamInfo, this.f576a).b();
                } else if (kotlin.jvm.internal.r.a(actionParamInfo.getType(), "seekbar")) {
                    kotlin.jvm.internal.r.c(actionParamInfo, "actionParamInfo");
                    viewB = new r(actionParamInfo, this.f576a).b();
                } else if (kotlin.jvm.internal.r.a(actionParamInfo.getType(), "file") || kotlin.jvm.internal.r.a(actionParamInfo.getType(), "folder")) {
                    kotlin.jvm.internal.r.c(actionParamInfo, "actionParamInfo");
                    viewB = new p(actionParamInfo, this.f576a, aVar).d();
                } else if (kotlin.jvm.internal.r.a(actionParamInfo.getType(), "app") || kotlin.jvm.internal.r.a(actionParamInfo.getType(), "packages")) {
                    kotlin.jvm.internal.r.c(actionParamInfo, "actionParamInfo");
                    viewB = new l(actionParamInfo, this.f576a).e();
                } else if (kotlin.jvm.internal.r.a(actionParamInfo.getType(), "color")) {
                    kotlin.jvm.internal.r.c(actionParamInfo, "actionParamInfo");
                    viewB = new n(actionParamInfo, this.f576a).g();
                } else {
                    kotlin.jvm.internal.r.c(actionParamInfo, "actionParamInfo");
                    viewB = new o(actionParamInfo, this.f576a).a();
                }
            } else if (actionParamInfo.getMultiple()) {
                kotlin.jvm.internal.r.c(actionParamInfo, "actionParamInfo");
                viewB = new q(actionParamInfo, this.f576a).e();
            } else {
                kotlin.jvm.internal.r.c(actionParamInfo, "actionParamInfo");
                viewB = new s(actionParamInfo, this.f576a).d();
            }
            a(viewB, actionParamInfo);
        }
    }
}
