package com.omarea.krscript.ui;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import com.omarea.krscript.model.ActionParamInfo;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class p {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private ActionParamInfo f606a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private Context f607b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private a f608c;

    public interface a {
        boolean openFileChooser(b bVar);
    }

    public interface b {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public static final a f609a = a.f610a;

        public static final class a {

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            static final /* synthetic */ a f610a = new a();

            private a() {
            }

            public final int a() {
                return 0;
            }

            public final int b() {
                return 1;
            }
        }

        void a(String str);

        String b();

        String c();

        int d();
    }

    static final class c implements View.OnClickListener {
        final /* synthetic */ TextView g;
        final /* synthetic */ EditText h;

        public static final class a implements b {
            a() {
            }

            @Override // com.omarea.krscript.ui.p.b
            public void a(String str) {
                TextView textView;
                Context context;
                int i;
                if (!(str == null || str.length() == 0)) {
                    TextView textView2 = c.this.g;
                    kotlin.jvm.internal.r.c(textView2, "textView");
                    textView2.setText(str);
                    c.this.h.setText(str);
                    return;
                }
                if (d() == b.f609a.b()) {
                    textView = c.this.g;
                    kotlin.jvm.internal.r.c(textView, "textView");
                    context = p.this.f607b;
                    i = com.omarea.c.h.kr_please_choose_folder;
                } else {
                    textView = c.this.g;
                    kotlin.jvm.internal.r.c(textView, "textView");
                    context = p.this.f607b;
                    i = com.omarea.c.h.kr_please_choose_file;
                }
                textView.setText(context.getString(i));
                c.this.h.setText("");
            }

            @Override // com.omarea.krscript.ui.p.b
            public String b() {
                if (p.this.f606a.getMime().length() > 0) {
                    return p.this.f606a.getMime();
                }
                return null;
            }

            @Override // com.omarea.krscript.ui.p.b
            public String c() {
                if (p.this.f606a.getSuffix().length() > 0) {
                    return p.this.f606a.getSuffix();
                }
                return null;
            }

            @Override // com.omarea.krscript.ui.p.b
            public int d() {
                String type = p.this.f606a.getType();
                return (type != null && type.hashCode() == -1268966290 && type.equals("folder")) ? b.f609a.b() : b.f609a.a();
            }
        }

        c(TextView textView, EditText editText) {
            this.g = textView;
            this.h = editText;
        }

        @Override // android.view.View.OnClickListener
        public final void onClick(View view) {
            a aVar = p.this.f608c;
            if (aVar != null) {
                aVar.openFileChooser(new a());
            }
        }
    }

    public p(ActionParamInfo actionParamInfo, Context context, a aVar) {
        kotlin.jvm.internal.r.d(actionParamInfo, "actionParamInfo");
        kotlin.jvm.internal.r.d(context, "context");
        this.f606a = actionParamInfo;
        this.f607b = context;
        this.f608c = aVar;
    }

    public final View d() {
        String value;
        Context context;
        int i;
        View viewInflate = LayoutInflater.from(this.f607b).inflate(com.omarea.c.g.kr_param_file, (ViewGroup) null);
        TextView textView = (TextView) viewInflate.findViewById(com.omarea.c.f.kr_param_file_text);
        EditText editText = (EditText) viewInflate.findViewById(com.omarea.c.f.kr_param_file_path);
        View viewFindViewById = viewInflate.findViewById(com.omarea.c.f.kr_param_file_btn);
        if (this.f606a.getEditable()) {
            kotlin.jvm.internal.r.c(textView, "textView");
            textView.setVisibility(8);
            kotlin.jvm.internal.r.c(editText, "pathView");
            editText.setVisibility(0);
            if (kotlin.jvm.internal.r.a(this.f606a.getType(), "folder")) {
                context = this.f607b;
                i = com.omarea.c.h.kr_please_choose_folder;
            } else {
                context = this.f607b;
                i = com.omarea.c.h.kr_please_choose_file;
            }
            editText.setHint(context.getString(i));
        } else {
            kotlin.jvm.internal.r.c(editText, "pathView");
            e(editText);
        }
        viewFindViewById.setOnClickListener(new c(textView, editText));
        if (this.f606a.getValueFromShell() == null) {
            String value2 = this.f606a.getValue();
            if (!(value2 == null || value2.length() == 0)) {
                kotlin.jvm.internal.r.c(textView, "textView");
                textView.setText(this.f606a.getValue());
                value = this.f606a.getValue();
            }
            editText.setTag(this.f606a.getName());
            kotlin.jvm.internal.r.c(viewInflate, "layout");
            return viewInflate;
        }
        kotlin.jvm.internal.r.c(textView, "textView");
        textView.setText(this.f606a.getValueFromShell());
        value = this.f606a.getValueFromShell();
        editText.setText(value);
        editText.setTag(this.f606a.getName());
        kotlin.jvm.internal.r.c(viewInflate, "layout");
        return viewInflate;
    }

    public final void e(TextView textView) {
        kotlin.jvm.internal.r.d(textView, "view");
        if (textView instanceof EditText) {
            textView.setCursorVisible(false);
            textView.setFocusable(false);
            textView.setFocusableInTouchMode(false);
        }
    }
}
