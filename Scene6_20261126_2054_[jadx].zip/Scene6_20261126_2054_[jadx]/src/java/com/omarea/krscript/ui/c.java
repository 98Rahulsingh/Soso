package com.omarea.krscript.ui;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.widget.ImageView;
import com.omarea.krscript.model.ClickableNode;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class c extends i {
    private InterfaceC0064c h;
    private d i;
    private View j;
    private ImageView k;
    private final ClickableNode l;

    static final class a implements View.OnClickListener {
        a() {
        }

        @Override // android.view.View.OnClickListener
        public final void onClick(View view) {
            InterfaceC0064c interfaceC0064cI = c.this.i();
            if (interfaceC0064cI != null) {
                interfaceC0064cI.a(c.this);
            }
        }
    }

    static final class b implements View.OnLongClickListener {
        b() {
        }

        @Override // android.view.View.OnLongClickListener
        public final boolean onLongClick(View view) {
            d dVarJ = c.this.j();
            if (dVarJ == null) {
                return true;
            }
            dVarJ.a(c.this);
            return true;
        }
    }

    /* JADX INFO: renamed from: com.omarea.krscript.ui.c$c, reason: collision with other inner class name */
    public interface InterfaceC0064c {
        void a(c cVar);
    }

    public interface d {
        void a(c cVar);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public c(Context context, int i, ClickableNode clickableNode) {
        Drawable drawableB;
        super(context, i, clickableNode);
        kotlin.jvm.internal.r.d(context, "context");
        kotlin.jvm.internal.r.d(clickableNode, "config");
        this.l = clickableNode;
        this.j = c().findViewById(com.omarea.c.f.kr_shortcut_icon);
        this.k = (ImageView) c().findViewById(com.omarea.c.f.kr_icon);
        g(this.l.getTitle());
        e(this.l.getDesc());
        f(this.l.getSummary());
        c().setOnClickListener(new a());
        if ((b().length() > 0) && (!kotlin.jvm.internal.r.a(this.l.getAllowShortcut(), Boolean.FALSE))) {
            c().setOnLongClickListener(new b());
            View view = this.j;
            if (view != null) {
                view.setVisibility(0);
            }
        } else {
            View view2 = this.j;
            if (view2 != null) {
                view2.setVisibility(8);
            }
        }
        ImageView imageView = this.k;
        if (imageView != null) {
            if (imageView != null) {
                imageView.setVisibility(8);
            }
            if (!(this.l.getIconPath().length() > 0) || (drawableB = new com.omarea.c.l.a().b(context, this.l)) == null) {
                return;
            }
            ImageView imageView2 = this.k;
            if (imageView2 != null) {
                imageView2.setImageDrawable(drawableB);
            }
            ImageView imageView3 = this.k;
            if (imageView3 != null) {
                imageView3.setVisibility(0);
            }
        }
    }

    protected final InterfaceC0064c i() {
        return this.h;
    }

    protected final d j() {
        return this.i;
    }

    public final c k(InterfaceC0064c interfaceC0064c) {
        kotlin.jvm.internal.r.d(interfaceC0064c, "onClickListener");
        this.h = interfaceC0064c;
        return this;
    }

    public final c l(d dVar) {
        kotlin.jvm.internal.r.d(dVar, "onLongClickListener");
        this.i = dVar;
        return this;
    }

    public final void m() {
        InterfaceC0064c interfaceC0064c = this.h;
        if (interfaceC0064c != null) {
            interfaceC0064c.a(this);
        }
    }
}
