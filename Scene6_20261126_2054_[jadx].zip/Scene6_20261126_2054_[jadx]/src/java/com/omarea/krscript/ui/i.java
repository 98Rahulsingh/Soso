package com.omarea.krscript.ui;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.omarea.krscript.model.NodeInfoBase;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class i {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private View f579a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private TextView f580b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private TextView f581c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private TextView f582d;
    private final Context e;
    private final int f;
    private final NodeInfoBase g;

    public i(Context context, int i, NodeInfoBase nodeInfoBase) {
        kotlin.jvm.internal.r.d(context, "context");
        kotlin.jvm.internal.r.d(nodeInfoBase, "config");
        this.e = context;
        this.f = i;
        this.g = nodeInfoBase;
        View viewInflate = LayoutInflater.from(context).inflate(this.f, (ViewGroup) null);
        this.f579a = viewInflate;
        this.f580b = (TextView) viewInflate.findViewById(com.omarea.c.f.kr_desc);
        this.f581c = (TextView) this.f579a.findViewById(com.omarea.c.f.kr_summary);
        this.f582d = (TextView) this.f579a.findViewById(com.omarea.c.f.kr_title);
        g(this.g.getTitle());
        e(this.g.getDesc());
        f(this.g.getSummary());
    }

    public final String a() {
        return this.g.getIndex();
    }

    public final String b() {
        return this.g.getKey();
    }

    protected final View c() {
        return this.f579a;
    }

    public final View d() {
        View view = this.f579a;
        kotlin.jvm.internal.r.c(view, "layout");
        return view;
    }

    public final void e(String str) {
        kotlin.jvm.internal.r.d(str, "value");
        if (str.length() == 0) {
            TextView textView = this.f580b;
            if (textView != null) {
                textView.setVisibility(8);
                return;
            }
            return;
        }
        TextView textView2 = this.f580b;
        if (textView2 != null) {
            textView2.setText(str);
        }
        TextView textView3 = this.f580b;
        if (textView3 != null) {
            textView3.setVisibility(0);
        }
    }

    public final void f(String str) {
        kotlin.jvm.internal.r.d(str, "value");
        if (str.length() == 0) {
            TextView textView = this.f581c;
            if (textView != null) {
                textView.setVisibility(8);
                return;
            }
            return;
        }
        TextView textView2 = this.f581c;
        if (textView2 != null) {
            textView2.setText(str);
        }
        TextView textView3 = this.f581c;
        if (textView3 != null) {
            textView3.setVisibility(0);
        }
    }

    public final void g(String str) {
        kotlin.jvm.internal.r.d(str, "value");
        if (str.length() == 0) {
            TextView textView = this.f582d;
            if (textView != null) {
                textView.setVisibility(8);
                return;
            }
            return;
        }
        TextView textView2 = this.f582d;
        if (textView2 != null) {
            textView2.setText(str);
        }
        TextView textView3 = this.f582d;
        if (textView3 != null) {
            textView3.setVisibility(0);
        }
    }

    public void h() {
        if (this.g.getDescSh().length() > 0) {
            NodeInfoBase nodeInfoBase = this.g;
            String strC = com.omarea.c.n.b.c(this.e, nodeInfoBase.getDescSh(), this.g);
            kotlin.jvm.internal.r.c(strC, "ScriptEnvironmen.execute…t, config.descSh, config)");
            nodeInfoBase.setDesc(strC);
            e(this.g.getDesc());
        }
        if (this.g.getSummarySh().length() > 0) {
            NodeInfoBase nodeInfoBase2 = this.g;
            String strC2 = com.omarea.c.n.b.c(this.e, nodeInfoBase2.getSummarySh(), this.g);
            kotlin.jvm.internal.r.c(strC2, "ScriptEnvironmen.execute…config.summarySh, config)");
            nodeInfoBase2.setSummary(strC2);
            f(this.g.getSummary());
        }
    }
}
