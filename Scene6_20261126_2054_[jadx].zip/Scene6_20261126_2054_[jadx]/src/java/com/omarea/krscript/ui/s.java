package com.omarea.krscript.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import com.omarea.krscript.model.ActionParamInfo;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class s {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final Integer f624a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private boolean f625b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final ArrayList<com.omarea.a.f.a> f626c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private int f627d;
    private ActionParamInfo e;
    private androidx.fragment.app.d f;

    public static final class a implements com.omarea.common.ui.f.a {

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final /* synthetic */ TextView f629b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        final /* synthetic */ TextView f630c;

        a(TextView textView, TextView textView2) {
            this.f629b = textView;
            this.f630c = textView2;
        }

        @Override // com.omarea.common.ui.f.a
        public void a(List<com.omarea.a.f.a> list, boolean[] zArr) {
            kotlin.jvm.internal.r.d(list, "selected");
            kotlin.jvm.internal.r.d(zArr, "status");
            s.this.e(kotlin.collections.h.o(zArr, true));
            s.this.f(this.f629b, this.f630c);
        }
    }

    static final class b implements View.OnClickListener {
        final /* synthetic */ TextView g;
        final /* synthetic */ TextView h;

        b(TextView textView, TextView textView2) {
            this.g = textView;
            this.h = textView2;
        }

        @Override // android.view.View.OnClickListener
        public final void onClick(View view) {
            s sVar = s.this;
            TextView textView = this.g;
            kotlin.jvm.internal.r.c(textView, "valueView");
            TextView textView2 = this.h;
            kotlin.jvm.internal.r.c(textView2, "textView");
            sVar.c(textView, textView2);
        }
    }

    public s(ActionParamInfo actionParamInfo, androidx.fragment.app.d dVar) {
        View decorView;
        kotlin.jvm.internal.r.d(actionParamInfo, "actionParamInfo");
        kotlin.jvm.internal.r.d(dVar, "context");
        this.e = actionParamInfo;
        this.f = dVar;
        Window window = dVar.getWindow();
        Integer numValueOf = (window == null || (decorView = window.getDecorView()) == null) ? null : Integer.valueOf(decorView.getSystemUiVisibility());
        this.f624a = numValueOf;
        this.f625b = numValueOf != null && (numValueOf.intValue() & 8192) == 0;
        ArrayList<com.omarea.a.f.a> optionsFromShell = this.e.getOptionsFromShell();
        kotlin.jvm.internal.r.b(optionsFromShell);
        this.f626c = optionsFromShell;
        this.f627d = com.omarea.krscript.ui.a.f575d.a(this.e, optionsFromShell);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void c(TextView textView, TextView textView2) {
        boolean z = this.f625b;
        ArrayList<com.omarea.a.f.a> arrayList = this.f626c;
        ArrayList arrayList2 = new ArrayList(kotlin.collections.q.k(arrayList, 10));
        int i = 0;
        for (Object obj : arrayList) {
            int i2 = i + 1;
            if (i < 0) {
                kotlin.collections.q.j();
                throw null;
            }
            com.omarea.a.f.a aVar = new com.omarea.a.f.a();
            aVar.e(((com.omarea.a.f.a) obj).b());
            aVar.d(i == this.f627d);
            arrayList2.add(aVar);
            i = i2;
        }
        new com.omarea.common.ui.f(z, new ArrayList(arrayList2), false, new a(textView, textView2), null, 16, null).E1(this.f.getSupportFragmentManager(), "params-single-select");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void f(TextView textView, TextView textView2) {
        int i = this.f627d;
        if (i <= -1 || i >= this.f626c.size()) {
            textView.setText("");
            textView2.setText("");
        } else {
            textView.setText(this.f626c.get(this.f627d).c());
            textView2.setText(this.f626c.get(this.f627d).b());
        }
    }

    public final View d() {
        if (this.f626c.size() > 5) {
            View viewInflate = LayoutInflater.from(this.f).inflate(com.omarea.c.g.kr_param_single_select, (ViewGroup) null);
            TextView textView = (TextView) viewInflate.findViewById(com.omarea.c.f.kr_param_single_select);
            TextView textView2 = (TextView) viewInflate.findViewById(com.omarea.c.f.kr_param_value);
            textView2.setTag(this.e.getName());
            kotlin.jvm.internal.r.c(textView2, "this");
            kotlin.jvm.internal.r.c(textView, "textView");
            f(textView2, textView);
            textView.setOnClickListener(new b(textView2, textView));
            kotlin.jvm.internal.r.c(viewInflate, "layout");
            return viewInflate;
        }
        View viewInflate2 = LayoutInflater.from(this.f).inflate(com.omarea.c.g.kr_param_spinner, (ViewGroup) null);
        Spinner spinner = (Spinner) viewInflate2.findViewById(com.omarea.c.f.kr_param_spinner);
        spinner.setTag(this.e.getName());
        ArrayAdapter arrayAdapter = new ArrayAdapter(spinner.getContext(), com.omarea.c.g.kr_spinner_default, com.omarea.c.f.text, this.f626c);
        arrayAdapter.setDropDownViewResource(com.omarea.c.g.kr_spinner_dropdown);
        kotlin.s sVar = kotlin.s.a;
        spinner.setAdapter((SpinnerAdapter) arrayAdapter);
        spinner.setEnabled(!this.e.getReadonly());
        int i = this.f627d;
        if (i > -1 && i < this.f626c.size()) {
            spinner.setSelection(this.f627d);
        }
        kotlin.jvm.internal.r.c(viewInflate2, "layout");
        return viewInflate2;
    }

    public final void e(int i) {
        this.f627d = i;
    }
}
