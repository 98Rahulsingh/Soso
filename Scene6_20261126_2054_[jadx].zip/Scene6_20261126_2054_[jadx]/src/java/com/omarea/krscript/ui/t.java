package com.omarea.krscript.ui;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import com.omarea.krscript.model.ActionParamInfo;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class t {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private ActionParamInfo f631a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private Context f632b;

    static final class a implements View.OnClickListener {
        public static final a f = new a();

        a() {
        }

        @Override // android.view.View.OnClickListener
        public final void onClick(View view) {
        }
    }

    public t(ActionParamInfo actionParamInfo, Context context) {
        kotlin.jvm.internal.r.d(actionParamInfo, "actionParamInfo");
        kotlin.jvm.internal.r.d(context, "context");
        this.f631a = actionParamInfo;
        this.f632b = context;
    }

    private final boolean a(ActionParamInfo actionParamInfo, boolean z) {
        if (actionParamInfo.getValueFromShell() != null) {
            if (!kotlin.jvm.internal.r.a(actionParamInfo.getValueFromShell(), "1")) {
                String valueFromShell = actionParamInfo.getValueFromShell();
                kotlin.jvm.internal.r.b(valueFromShell);
                if (valueFromShell == null) {
                    throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                }
                String lowerCase = valueFromShell.toLowerCase();
                kotlin.jvm.internal.r.c(lowerCase, "(this as java.lang.String).toLowerCase()");
                if (!kotlin.jvm.internal.r.a(lowerCase, "true")) {
                    return false;
                }
            }
            return true;
        }
        if (actionParamInfo.getValue() == null) {
            return z;
        }
        if (!kotlin.jvm.internal.r.a(actionParamInfo.getValue(), "1")) {
            String value = actionParamInfo.getValue();
            kotlin.jvm.internal.r.b(value);
            if (value == null) {
                throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
            }
            String lowerCase2 = value.toLowerCase();
            kotlin.jvm.internal.r.c(lowerCase2, "(this as java.lang.String).toLowerCase()");
            if (!kotlin.jvm.internal.r.a(lowerCase2, "true")) {
                return false;
            }
        }
        return true;
    }

    public final View b() {
        View viewInflate = LayoutInflater.from(this.f632b).inflate(com.omarea.c.g.kr_param_switch, (ViewGroup) null);
        CompoundButton compoundButton = (CompoundButton) viewInflate.findViewById(com.omarea.c.f.kr_param_switch);
        compoundButton.setTag(this.f631a.getName());
        compoundButton.setChecked(a(this.f631a, false));
        String label = this.f631a.getLabel();
        if (!(label == null || label.length() == 0)) {
            compoundButton.setText(this.f631a.getLabel());
        }
        compoundButton.setOnClickListener(a.f);
        kotlin.jvm.internal.r.c(viewInflate, "layout");
        return viewInflate;
    }
}
