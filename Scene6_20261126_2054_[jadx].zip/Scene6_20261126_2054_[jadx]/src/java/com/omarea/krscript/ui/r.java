package com.omarea.krscript.ui;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.TextView;
import com.omarea.krscript.model.ActionParamInfo;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class r {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private ActionParamInfo f620a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private Context f621b;

    public static final class a implements SeekBar.OnSeekBarChangeListener {

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final /* synthetic */ TextView f623b;

        a(TextView textView) {
            this.f623b = textView;
        }

        @Override // android.widget.SeekBar.OnSeekBarChangeListener
        public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
            TextView textView = this.f623b;
            kotlin.jvm.internal.r.c(textView, "textView");
            textView.setText(String.valueOf(i + r.this.f620a.getMin()));
        }

        @Override // android.widget.SeekBar.OnSeekBarChangeListener
        public void onStartTrackingTouch(SeekBar seekBar) {
        }

        @Override // android.widget.SeekBar.OnSeekBarChangeListener
        public void onStopTrackingTouch(SeekBar seekBar) {
        }
    }

    static final class b implements View.OnClickListener {
        final /* synthetic */ SeekBar f;

        b(SeekBar seekBar) {
            this.f = seekBar;
        }

        @Override // android.view.View.OnClickListener
        public final void onClick(View view) {
            SeekBar seekBar = this.f;
            kotlin.jvm.internal.r.c(seekBar, "seekbar");
            if (seekBar.getProgress() > 0) {
                SeekBar seekBar2 = this.f;
                kotlin.jvm.internal.r.c(seekBar2, "seekbar");
                seekBar2.setProgress(seekBar2.getProgress() - 1);
            }
        }
    }

    static final class c implements View.OnClickListener {
        final /* synthetic */ SeekBar f;

        c(SeekBar seekBar) {
            this.f = seekBar;
        }

        @Override // android.view.View.OnClickListener
        public final void onClick(View view) {
            SeekBar seekBar = this.f;
            kotlin.jvm.internal.r.c(seekBar, "seekbar");
            int progress = seekBar.getProgress();
            SeekBar seekBar2 = this.f;
            kotlin.jvm.internal.r.c(seekBar2, "seekbar");
            if (progress < seekBar2.getMax()) {
                SeekBar seekBar3 = this.f;
                kotlin.jvm.internal.r.c(seekBar3, "seekbar");
                seekBar3.setProgress(seekBar3.getProgress() + 1);
            }
        }
    }

    public r(ActionParamInfo actionParamInfo, Context context) {
        kotlin.jvm.internal.r.d(actionParamInfo, "actionParamInfo");
        kotlin.jvm.internal.r.d(context, "context");
        this.f620a = actionParamInfo;
        this.f621b = context;
    }

    public final View b() {
        String value;
        View viewInflate = LayoutInflater.from(this.f621b).inflate(com.omarea.c.g.kr_param_seekbar, (ViewGroup) null);
        SeekBar seekBar = (SeekBar) viewInflate.findViewById(com.omarea.c.f.kr_param_seekbar);
        kotlin.jvm.internal.r.c(seekBar, "seekbar");
        seekBar.setMax(this.f620a.getMax());
        seekBar.setMax(this.f620a.getMax() - this.f620a.getMin());
        try {
            if (this.f620a.getValueFromShell() == null) {
                if (this.f620a.getValue() != null) {
                    value = this.f620a.getValue();
                    kotlin.jvm.internal.r.b(value);
                }
                seekBar.setTag(this.f620a.getName());
                ImageButton imageButton = (ImageButton) viewInflate.findViewById(com.omarea.c.f.kr_param_seekbar_minus);
                ImageButton imageButton2 = (ImageButton) viewInflate.findViewById(com.omarea.c.f.kr_param_seekbar_plus);
                TextView textView = (TextView) viewInflate.findViewById(com.omarea.c.f.kr_param_seekbar_value);
                kotlin.jvm.internal.r.c(textView, "textView");
                textView.setText(String.valueOf(seekBar.getProgress() + this.f620a.getMin()));
                seekBar.setOnSeekBarChangeListener(new a(textView));
                imageButton.setOnClickListener(new b(seekBar));
                imageButton2.setOnClickListener(new c(seekBar));
                kotlin.jvm.internal.r.c(viewInflate, "layout");
                return viewInflate;
            }
            value = this.f620a.getValueFromShell();
            kotlin.jvm.internal.r.b(value);
            seekBar.setProgress(Integer.parseInt(value) - this.f620a.getMin());
        } catch (Exception unused) {
        }
        seekBar.setTag(this.f620a.getName());
        ImageButton imageButton3 = (ImageButton) viewInflate.findViewById(com.omarea.c.f.kr_param_seekbar_minus);
        ImageButton imageButton4 = (ImageButton) viewInflate.findViewById(com.omarea.c.f.kr_param_seekbar_plus);
        TextView textView2 = (TextView) viewInflate.findViewById(com.omarea.c.f.kr_param_seekbar_value);
        kotlin.jvm.internal.r.c(textView2, "textView");
        textView2.setText(String.valueOf(seekBar.getProgress() + this.f620a.getMin()));
        seekBar.setOnSeekBarChangeListener(new a(textView2));
        imageButton3.setOnClickListener(new b(seekBar));
        imageButton4.setOnClickListener(new c(seekBar));
        kotlin.jvm.internal.r.c(viewInflate, "layout");
        return viewInflate;
    }
}
