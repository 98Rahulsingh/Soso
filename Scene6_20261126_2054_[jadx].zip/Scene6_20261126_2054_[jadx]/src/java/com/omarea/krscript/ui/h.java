package com.omarea.krscript.ui;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.text.Layout;
import android.text.SpannableString;
import android.text.TextPaint;
import android.text.method.LinkMovementMethod;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.AlignmentSpan;
import android.text.style.BackgroundColorSpan;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.text.style.UnderlineSpan;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import com.omarea.krscript.model.TextNode;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class h extends i {
    private final TextView h;
    private final Context i;

    public static final class a extends ClickableSpan {
        final /* synthetic */ TextNode.TextRow g;

        a(TextNode.TextRow textRow) {
            this.g = textRow;
        }

        @Override // android.text.style.ClickableSpan
        public void onClick(View view) {
            kotlin.jvm.internal.r.d(view, "widget");
            if (this.g.getLink$krscript_release_mini().length() > 0) {
                try {
                    Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(this.g.getLink$krscript_release_mini()));
                    intent.addFlags(268435456);
                    h.this.i.startActivity(intent);
                } catch (Exception unused) {
                    Toast.makeText(h.this.i, h.this.i.getString(com.omarea.c.h.kr_slice_activity_fail), 0).show();
                }
            }
        }

        @Override // android.text.style.ClickableSpan, android.text.style.CharacterStyle
        public void updateDrawState(TextPaint textPaint) {
            kotlin.jvm.internal.r.d(textPaint, "ds");
            textPaint.setColor(this.g.getColor$krscript_release_mini() != 1 ? textPaint.linkColor : this.g.getColor$krscript_release_mini());
            textPaint.setUnderlineText(this.g.getUnderline$krscript_release_mini());
        }
    }

    public static final class b extends ClickableSpan {
        final /* synthetic */ TextNode.TextRow g;

        b(TextNode.TextRow textRow) {
            this.g = textRow;
        }

        @Override // android.text.style.ClickableSpan
        public void onClick(View view) {
            kotlin.jvm.internal.r.d(view, "widget");
            new com.omarea.c.j(h.this.i, this.g.getActivity$krscript_release_mini()).b();
        }

        @Override // android.text.style.ClickableSpan, android.text.style.CharacterStyle
        public void updateDrawState(TextPaint textPaint) {
            kotlin.jvm.internal.r.d(textPaint, "ds");
            textPaint.setColor(this.g.getColor$krscript_release_mini() != 1 ? textPaint.linkColor : this.g.getColor$krscript_release_mini());
            textPaint.setUnderlineText(this.g.getUnderline$krscript_release_mini());
        }
    }

    public static final class c extends ClickableSpan {
        final /* synthetic */ TextNode.TextRow g;
        final /* synthetic */ TextNode h;

        c(TextNode.TextRow textRow, TextNode textNode) {
            this.g = textRow;
            this.h = textNode;
        }

        @Override // android.text.style.ClickableSpan
        public void onClick(View view) {
            kotlin.jvm.internal.r.d(view, "widget");
            String strC = com.omarea.c.n.b.c(h.this.i, this.g.getOnClickScript$krscript_release_mini(), this.h);
            kotlin.jvm.internal.r.c(strC, "result");
            if (strC == null) {
                throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
            }
            if (kotlin.text.k.k0(strC).toString().length() > 0) {
                com.omarea.common.ui.e.a aVar = com.omarea.common.ui.e.f492b;
                Context context = h.this.i;
                String string = h.this.i.getString(com.omarea.c.h.kr_slice_script_result);
                kotlin.jvm.internal.r.c(string, "context.getString(R.string.kr_slice_script_result)");
                com.omarea.common.ui.e.a.A(aVar, context, string, strC, null, 8, null);
            }
        }

        @Override // android.text.style.ClickableSpan, android.text.style.CharacterStyle
        public void updateDrawState(TextPaint textPaint) {
            kotlin.jvm.internal.r.d(textPaint, "ds");
            textPaint.setColor(this.g.getColor$krscript_release_mini() != 1 ? textPaint.linkColor : this.g.getColor$krscript_release_mini());
            textPaint.setUnderlineText(this.g.getUnderline$krscript_release_mini());
        }
    }

    static final class d implements View.OnLongClickListener {
        public static final d f = new d();

        d() {
        }

        @Override // android.view.View.OnLongClickListener
        public final boolean onLongClick(View view) {
            return true;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Code duplicated, block: B:55:0x011e  */
    /* JADX WARN: Code duplicated, block: B:64:0x012a A[SYNTHETIC] */
    public h(Context context, int i, TextNode textNode) {
        TextView textView;
        StyleSpan styleSpan;
        super(context, i, textNode);
        kotlin.jvm.internal.r.d(context, "context");
        kotlin.jvm.internal.r.d(textNode, "config");
        this.i = context;
        this.h = (TextView) c().findViewById(com.omarea.c.f.kr_rows);
        if (textNode.getRows().size() <= 0 || (textView = this.h) == null) {
            TextView textView2 = this.h;
            if (textView2 != null) {
                textView2.setVisibility(8);
                return;
            }
            return;
        }
        textView.setMovementMethod(LinkMovementMethod.getInstance());
        this.h.setVisibility(0);
        for (TextNode.TextRow textRow : textNode.getRows()) {
            if (textRow.getBreakRow$krscript_release_mini() || textRow.getAlign$krscript_release_mini() != Layout.Alignment.ALIGN_NORMAL) {
                this.h.append("\n");
            }
            String text$krscript_release_mini = textRow.getText$krscript_release_mini();
            int length = text$krscript_release_mini.length();
            SpannableString spannableString = new SpannableString(text$krscript_release_mini);
            if (textRow.getUnderline$krscript_release_mini()) {
                spannableString.setSpan(new UnderlineSpan(), 0, length, 33);
            }
            if (textRow.getLink$krscript_release_mini().length() > 0) {
                spannableString.setSpan(new a(textRow), 0, length, 33);
            }
            if (textRow.getActivity$krscript_release_mini().length() > 0) {
                spannableString.setSpan(new b(textRow), 0, length, 33);
            }
            if (textRow.getOnClickScript$krscript_release_mini().length() > 0) {
                spannableString.setSpan(new c(textRow, textNode), 0, length, 33);
            }
            if (textRow.getColor$krscript_release_mini() != -1) {
                spannableString.setSpan(new ForegroundColorSpan(textRow.getColor$krscript_release_mini()), 0, length, 33);
            }
            if (textRow.getBgColor$krscript_release_mini() != -1) {
                spannableString.setSpan(new BackgroundColorSpan(textRow.getBgColor$krscript_release_mini()), 0, length, 33);
            }
            if (textRow.getBold$krscript_release_mini() && textRow.getItalic$krscript_release_mini()) {
                styleSpan = new StyleSpan(3);
            } else if (textRow.getBold$krscript_release_mini()) {
                styleSpan = new StyleSpan(1);
            } else {
                if (textRow.getItalic$krscript_release_mini()) {
                    styleSpan = new StyleSpan(2);
                }
                if (textRow.getSize$krscript_release_mini() != -1) {
                    spannableString.setSpan(new AbsoluteSizeSpan(textRow.getSize$krscript_release_mini(), true), 0, length, 33);
                }
                spannableString.setSpan(new AlignmentSpan.Standard(textRow.getAlign$krscript_release_mini()), 0, length, 33);
                this.h.append(spannableString);
            }
            spannableString.setSpan(styleSpan, 0, length, 33);
            if (textRow.getSize$krscript_release_mini() != -1) {
                spannableString.setSpan(new AbsoluteSizeSpan(textRow.getSize$krscript_release_mini(), true), 0, length, 33);
            }
            spannableString.setSpan(new AlignmentSpan.Standard(textRow.getAlign$krscript_release_mini()), 0, length, 33);
            this.h.append(spannableString);
        }
        this.h.setOnLongClickListener(d.f);
    }
}
