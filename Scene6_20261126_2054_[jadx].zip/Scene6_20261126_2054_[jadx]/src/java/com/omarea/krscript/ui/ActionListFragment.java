package com.omarea.krscript.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.fragment.app.Fragment;
import com.omarea.krscript.model.ActionNode;
import com.omarea.krscript.model.ActionParamInfo;
import com.omarea.krscript.model.AutoRunTask;
import com.omarea.krscript.model.ClickableNode;
import com.omarea.krscript.model.GroupNode;
import com.omarea.krscript.model.KrScriptActionHandler;
import com.omarea.krscript.model.NodeInfoBase;
import com.omarea.krscript.model.PageNode;
import com.omarea.krscript.model.PickerNode;
import com.omarea.krscript.model.RunnableNode;
import com.omarea.krscript.model.SwitchNode;
import com.omarea.krscript.shortcut.ActionShortcutManager;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;
import kotlin.jvm.internal.w;
import kotlin.text.Regex;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class ActionListFragment extends Fragment implements com.omarea.krscript.ui.j.a {
    public static final a k0 = new a(null);
    private ArrayList<NodeInfoBase> c0;
    private com.omarea.common.ui.j d0;
    private KrScriptActionHandler e0;
    private AutoRunTask f0;
    private com.omarea.common.ui.k g0;
    private com.omarea.krscript.ui.d h0;
    private boolean i0;
    private HashMap j0;

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(kotlin.jvm.internal.o oVar) {
            this();
        }

        public final ActionListFragment a(ArrayList<NodeInfoBase> arrayList, KrScriptActionHandler krScriptActionHandler, AutoRunTask autoRunTask, com.omarea.common.ui.k kVar) {
            ActionListFragment actionListFragment = new ActionListFragment();
            actionListFragment.S1(arrayList, krScriptActionHandler, autoRunTask, kVar);
            return actionListFragment;
        }
    }

    static final class b implements Runnable {
        final /* synthetic */ ArrayList g;
        final /* synthetic */ Handler h;
        final /* synthetic */ ActionNode i;
        final /* synthetic */ LinearLayout j;
        final /* synthetic */ String k;
        final /* synthetic */ Runnable l;

        static final class a implements Runnable {
            final /* synthetic */ ActionParamInfo g;

            a(ActionParamInfo actionParamInfo) {
                this.g = actionParamInfo;
            }

            @Override // java.lang.Runnable
            public final void run() {
                com.omarea.common.ui.j jVarE1 = ActionListFragment.E1(ActionListFragment.this);
                StringBuilder sb = new StringBuilder();
                Context contextQ = ActionListFragment.this.q();
                kotlin.jvm.internal.r.b(contextQ);
                sb.append(contextQ.getString(com.omarea.c.h.kr_param_load));
                String label = this.g.getLabel();
                sb.append(!(label == null || label.length() == 0) ? this.g.getLabel() : this.g.getName());
                jVarE1.d(sb.toString());
            }
        }

        /* JADX INFO: renamed from: com.omarea.krscript.ui.ActionListFragment$b$b, reason: collision with other inner class name */
        static final class RunnableC0059b implements Runnable {
            final /* synthetic */ ActionParamInfo g;

            RunnableC0059b(ActionParamInfo actionParamInfo) {
                this.g = actionParamInfo;
            }

            @Override // java.lang.Runnable
            public final void run() {
                com.omarea.common.ui.j jVarE1 = ActionListFragment.E1(ActionListFragment.this);
                StringBuilder sb = new StringBuilder();
                Context contextQ = ActionListFragment.this.q();
                kotlin.jvm.internal.r.b(contextQ);
                sb.append(contextQ.getString(com.omarea.c.h.kr_param_options_load));
                String label = this.g.getLabel();
                sb.append(!(label == null || label.length() == 0) ? this.g.getLabel() : this.g.getName());
                jVarE1.d(sb.toString());
            }
        }

        static final class c implements Runnable {
            c() {
            }

            @Override // java.lang.Runnable
            public final void run() {
                com.omarea.common.ui.j jVarE1 = ActionListFragment.E1(ActionListFragment.this);
                Context contextQ = ActionListFragment.this.q();
                kotlin.jvm.internal.r.b(contextQ);
                String string = contextQ.getString(com.omarea.c.h.kr_params_render);
                kotlin.jvm.internal.r.c(string, "this.context!!.getString….string.kr_params_render)");
                jVarE1.d(string);
            }
        }

        static final class d implements Runnable {

            public static final class a implements p.a {
                a() {
                }

                @Override // com.omarea.krscript.ui.p.a
                public boolean openFileChooser(p.b bVar) {
                    kotlin.jvm.internal.r.d(bVar, "fileSelectedInterface");
                    if (ActionListFragment.this.e0 == null) {
                        return false;
                    }
                    KrScriptActionHandler krScriptActionHandler = ActionListFragment.this.e0;
                    kotlin.jvm.internal.r.b(krScriptActionHandler);
                    return krScriptActionHandler.openFileChooser(bVar);
                }
            }

            /* JADX INFO: renamed from: com.omarea.krscript.ui.ActionListFragment$b$d$b, reason: collision with other inner class name */
            static final class ViewOnClickListenerC0060b implements View.OnClickListener {
                final /* synthetic */ AlertDialog f;

                ViewOnClickListenerC0060b(AlertDialog alertDialog) {
                    this.f = alertDialog;
                }

                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    try {
                        AlertDialog alertDialog = this.f;
                        kotlin.jvm.internal.r.b(alertDialog);
                        alertDialog.dismiss();
                    } catch (Exception unused) {
                    }
                }
            }

            static final class c implements View.OnClickListener {
                final /* synthetic */ com.omarea.krscript.ui.a g;
                final /* synthetic */ AlertDialog h;

                c(com.omarea.krscript.ui.a aVar, AlertDialog alertDialog) {
                    this.g = aVar;
                    this.h = alertDialog;
                }

                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    try {
                        ActionListFragment.this.L1(b.this.i, b.this.k, b.this.l, this.g.c(b.this.g));
                        AlertDialog alertDialog = this.h;
                        kotlin.jvm.internal.r.b(alertDialog);
                        alertDialog.dismiss();
                    } catch (Exception e) {
                        Context contextQ = ActionListFragment.this.q();
                        kotlin.jvm.internal.r.b(contextQ);
                        Toast.makeText(contextQ, "" + e.getMessage(), 1).show();
                    }
                }
            }

            /* JADX INFO: renamed from: com.omarea.krscript.ui.ActionListFragment$b$d$d, reason: collision with other inner class name */
            static final class RunnableC0061d implements Runnable {
                final /* synthetic */ com.omarea.krscript.ui.a g;

                RunnableC0061d(com.omarea.krscript.ui.a aVar) {
                    this.g = aVar;
                }

                @Override // java.lang.Runnable
                public final void run() {
                    try {
                        ActionListFragment.this.L1(b.this.i, b.this.k, b.this.l, this.g.c(b.this.g));
                    } catch (Exception e) {
                        Context contextQ = ActionListFragment.this.q();
                        kotlin.jvm.internal.r.b(contextQ);
                        Toast.makeText(contextQ, "" + e.getMessage(), 1).show();
                    }
                }
            }

            d() {
            }

            /* JADX WARN: Code duplicated, block: B:13:0x0077  */
            /* JADX WARN: Code duplicated, block: B:23:0x00be  */
            @Override // java.lang.Runnable
            public final void run() {
                Boolean boolValueOf;
                boolean z;
                boolean z2;
                AlertDialog alertDialogC;
                b bVar = b.this;
                LinearLayout linearLayout = bVar.j;
                androidx.fragment.app.d dVarJ = ActionListFragment.this.j();
                kotlin.jvm.internal.r.b(dVarJ);
                kotlin.jvm.internal.r.c(dVarJ, "activity!!");
                com.omarea.krscript.ui.a aVar = new com.omarea.krscript.ui.a(linearLayout, dVarJ);
                aVar.d(b.this.g, new a());
                ActionListFragment.E1(ActionListFragment.this).c();
                KrScriptActionHandler krScriptActionHandler = ActionListFragment.this.e0;
                if (krScriptActionHandler != null) {
                    b bVar2 = b.this;
                    boolValueOf = Boolean.valueOf(krScriptActionHandler.openParamsPage(bVar2.i, bVar2.j, new RunnableC0061d(aVar)));
                } else {
                    boolValueOf = null;
                }
                if (!kotlin.jvm.internal.r.a(boolValueOf, Boolean.TRUE)) {
                    if (b.this.i.getParams() != null) {
                        ArrayList<ActionParamInfo> params = b.this.i.getParams();
                        kotlin.jvm.internal.r.b(params);
                        if (params.size() > 4) {
                            z = true;
                        } else {
                            z = false;
                        }
                    } else {
                        z = false;
                    }
                    View viewInflate = LayoutInflater.from(ActionListFragment.this.q()).inflate(z ? com.omarea.c.g.kr_dialog_params : com.omarea.c.g.kr_dialog_params_small, (ViewGroup) null);
                    ViewGroup viewGroup = (ViewGroup) viewInflate.findViewById(com.omarea.c.f.kr_params_center);
                    viewGroup.removeAllViews();
                    viewGroup.addView(b.this.j);
                    if (ActionListFragment.this.g0 != null) {
                        com.omarea.common.ui.k kVar = ActionListFragment.this.g0;
                        kotlin.jvm.internal.r.b(kVar);
                        if (kVar.a()) {
                            z2 = true;
                        } else {
                            z2 = false;
                        }
                    } else {
                        z2 = false;
                    }
                    if (z) {
                        alertDialogC = new AlertDialog.Builder(ActionListFragment.this.q(), z2 ? com.omarea.c.i.kr_full_screen_dialog_dark : com.omarea.c.i.kr_full_screen_dialog_light).setView(viewInflate).create();
                        alertDialogC.show();
                        kotlin.jvm.internal.r.c(alertDialogC, "this");
                        Window window = alertDialogC.getWindow();
                        Activity activityJ = ActionListFragment.this.j();
                        if (window != null && activityJ != null) {
                            com.omarea.common.ui.e.f492b.E(window, activityJ);
                        }
                    } else {
                        com.omarea.common.ui.e.a aVar2 = com.omarea.common.ui.e.f492b;
                        androidx.fragment.app.d dVarJ2 = ActionListFragment.this.j();
                        kotlin.jvm.internal.r.b(dVarJ2);
                        kotlin.jvm.internal.r.c(dVarJ2, "activity!!");
                        kotlin.jvm.internal.r.c(viewInflate, "dialogView");
                        alertDialogC = com.omarea.common.ui.e.a.q(aVar2, dVarJ2, viewInflate, false, 4, null).c();
                    }
                    View viewFindViewById = viewInflate.findViewById(com.omarea.c.f.title);
                    kotlin.jvm.internal.r.c(viewFindViewById, "dialogView.findViewById<TextView>(R.id.title)");
                    ((TextView) viewFindViewById).setText(b.this.i.getTitle());
                    if (b.this.i.getDesc().length() == 0) {
                        View viewFindViewById2 = viewInflate.findViewById(com.omarea.c.f.desc);
                        kotlin.jvm.internal.r.c(viewFindViewById2, "dialogView.findViewById<TextView>(R.id.desc)");
                        ((TextView) viewFindViewById2).setVisibility(8);
                    } else {
                        View viewFindViewById3 = viewInflate.findViewById(com.omarea.c.f.desc);
                        kotlin.jvm.internal.r.c(viewFindViewById3, "dialogView.findViewById<TextView>(R.id.desc)");
                        ((TextView) viewFindViewById3).setText(b.this.i.getDesc());
                    }
                    if (b.this.i.getWarning().length() == 0) {
                        View viewFindViewById4 = viewInflate.findViewById(com.omarea.c.f.warn);
                        kotlin.jvm.internal.r.c(viewFindViewById4, "dialogView.findViewById<TextView>(R.id.warn)");
                        ((TextView) viewFindViewById4).setVisibility(8);
                    } else {
                        View viewFindViewById5 = viewInflate.findViewById(com.omarea.c.f.warn);
                        kotlin.jvm.internal.r.c(viewFindViewById5, "dialogView.findViewById<TextView>(R.id.warn)");
                        ((TextView) viewFindViewById5).setText(b.this.i.getWarning());
                    }
                    viewInflate.findViewById(com.omarea.c.f.btn_cancel).setOnClickListener(new ViewOnClickListenerC0060b(alertDialogC));
                    viewInflate.findViewById(com.omarea.c.f.btn_confirm).setOnClickListener(new c(aVar, alertDialogC));
                }
            }
        }

        b(ArrayList arrayList, Handler handler, ActionNode actionNode, LinearLayout linearLayout, String str, Runnable runnable) {
            this.g = arrayList;
            this.h = handler;
            this.i = actionNode;
            this.j = linearLayout;
            this.k = str;
            this.l = runnable;
        }

        @Override // java.lang.Runnable
        public final void run() {
            for (ActionParamInfo actionParamInfo : this.g) {
                this.h.post(new a(actionParamInfo));
                if (actionParamInfo.getValueShell() != null) {
                    ActionListFragment actionListFragment = ActionListFragment.this;
                    String valueShell = actionParamInfo.getValueShell();
                    kotlin.jvm.internal.r.b(valueShell);
                    actionParamInfo.setValueFromShell(actionListFragment.M1(valueShell, this.i));
                }
                this.h.post(new RunnableC0059b(actionParamInfo));
                ActionListFragment actionListFragment2 = ActionListFragment.this;
                kotlin.jvm.internal.r.c(actionParamInfo, "actionParamInfo");
                actionParamInfo.setOptionsFromShell(actionListFragment2.N1(actionParamInfo, this.i));
            }
            this.h.post(new c());
            this.h.post(new d());
        }
    }

    static final class c implements Runnable {
        final /* synthetic */ RunnableNode g;

        c(RunnableNode runnableNode) {
            this.g = runnableNode;
        }

        @Override // java.lang.Runnable
        public final void run() {
            KrScriptActionHandler krScriptActionHandler = ActionListFragment.this.e0;
            if (krScriptActionHandler != null) {
                krScriptActionHandler.onActionCompleted(this.g);
            }
        }
    }

    static final class d implements Runnable {
        final /* synthetic */ RunnableNode g;

        d(RunnableNode runnableNode) {
            this.g = runnableNode;
        }

        @Override // java.lang.Runnable
        public final void run() {
            ActionListFragment.this.R1(false);
            KrScriptActionHandler krScriptActionHandler = ActionListFragment.this.e0;
            if (krScriptActionHandler != null) {
                krScriptActionHandler.onActionCompleted(this.g);
            }
        }
    }

    static final class e implements Runnable {
        final /* synthetic */ RunnableNode g;

        e(RunnableNode runnableNode) {
            this.g = runnableNode;
        }

        @Override // java.lang.Runnable
        public final void run() {
            KrScriptActionHandler krScriptActionHandler = ActionListFragment.this.e0;
            if (krScriptActionHandler != null) {
                krScriptActionHandler.onActionCompleted(this.g);
            }
        }
    }

    static final class f implements Runnable {
        final /* synthetic */ ActionNode g;
        final /* synthetic */ Runnable h;

        f(ActionNode actionNode, Runnable runnable) {
            this.g = actionNode;
            this.h = runnable;
        }

        @Override // java.lang.Runnable
        public final void run() {
            ActionListFragment.this.K1(this.g, this.h);
        }
    }

    static final class g implements Runnable {
        final /* synthetic */ ActionNode g;
        final /* synthetic */ Runnable h;

        g(ActionNode actionNode, Runnable runnable) {
            this.g = actionNode;
            this.h = runnable;
        }

        @Override // java.lang.Runnable
        public final void run() {
            ActionListFragment.this.K1(this.g, this.h);
        }
    }

    public static final class h implements KrScriptActionHandler.AddToFavoritesHandler {

        static final class a implements Runnable {
            final /* synthetic */ Intent g;
            final /* synthetic */ ClickableNode h;

            a(Intent intent, ClickableNode clickableNode) {
                this.g = intent;
                this.h = clickableNode;
            }

            @Override // java.lang.Runnable
            public final void run() {
                Context contextQ = ActionListFragment.this.q();
                kotlin.jvm.internal.r.b(contextQ);
                kotlin.jvm.internal.r.c(contextQ, "context!!");
                ActionShortcutManager actionShortcutManager = new ActionShortcutManager(contextQ);
                Intent intent = this.g;
                com.omarea.c.l.a aVar = new com.omarea.c.l.a();
                Context contextQ2 = ActionListFragment.this.q();
                kotlin.jvm.internal.r.b(contextQ2);
                kotlin.jvm.internal.r.c(contextQ2, "context!!");
                (!actionShortcutManager.a(intent, aVar.c(contextQ2, this.h), this.h) ? Toast.makeText(ActionListFragment.this.q(), com.omarea.c.h.kr_shortcut_create_fail, 0) : Toast.makeText(ActionListFragment.this.q(), ActionListFragment.this.K(com.omarea.c.h.kr_shortcut_create_success), 0)).show();
            }
        }

        h() {
        }

        @Override // com.omarea.krscript.model.KrScriptActionHandler.AddToFavoritesHandler
        public void onAddToFavorites(ClickableNode clickableNode, Intent intent) {
            kotlin.jvm.internal.r.d(clickableNode, "clickableNode");
            if (intent != null) {
                com.omarea.common.ui.e.a aVar = com.omarea.common.ui.e.f492b;
                androidx.fragment.app.d dVarJ = ActionListFragment.this.j();
                kotlin.jvm.internal.r.b(dVarJ);
                kotlin.jvm.internal.r.c(dVarJ, "activity!!");
                String strK = ActionListFragment.this.K(com.omarea.c.h.kr_shortcut_create);
                kotlin.jvm.internal.r.c(strK, "getString(R.string.kr_shortcut_create)");
                w wVar = w.a;
                String strK2 = ActionListFragment.this.K(com.omarea.c.h.kr_shortcut_create_desc);
                kotlin.jvm.internal.r.c(strK2, "getString(R.string.kr_shortcut_create_desc)");
                String str = String.format(strK2, Arrays.copyOf(new Object[]{clickableNode.getTitle()}, 1));
                kotlin.jvm.internal.r.c(str, "java.lang.String.format(format, *args)");
                aVar.i(dVarJ, (16 & 2) != 0 ? "" : strK, (16 & 4) != 0 ? "" : str, (16 & 8) != 0 ? null : new a(intent, clickableNode), (16 & 16) != 0 ? null : null);
            }
        }
    }

    static final class i implements Runnable {
        final /* synthetic */ PickerNode g;
        final /* synthetic */ Runnable h;

        i(PickerNode pickerNode, Runnable runnable) {
            this.g = pickerNode;
            this.h = runnable;
        }

        @Override // java.lang.Runnable
        public final void run() {
            ActionListFragment.this.P1(this.g, this.h);
        }
    }

    static final class j implements Runnable {
        final /* synthetic */ PickerNode g;
        final /* synthetic */ Runnable h;

        j(PickerNode pickerNode, Runnable runnable) {
            this.g = pickerNode;
            this.h = runnable;
        }

        @Override // java.lang.Runnable
        public final void run() {
            ActionListFragment.this.P1(this.g, this.h);
        }
    }

    static final class k implements Runnable {
        final /* synthetic */ SwitchNode g;
        final /* synthetic */ boolean h;
        final /* synthetic */ Runnable i;

        k(SwitchNode switchNode, boolean z, Runnable runnable) {
            this.g = switchNode;
            this.h = z;
            this.i = runnable;
        }

        @Override // java.lang.Runnable
        public final void run() {
            ActionListFragment.this.T1(this.g, this.h, this.i);
        }
    }

    static final class l implements Runnable {
        final /* synthetic */ SwitchNode g;
        final /* synthetic */ boolean h;
        final /* synthetic */ Runnable i;

        l(SwitchNode switchNode, boolean z, Runnable runnable) {
            this.g = switchNode;
            this.h = z;
            this.i = runnable;
        }

        @Override // java.lang.Runnable
        public final void run() {
            ActionListFragment.this.T1(this.g, this.h, this.i);
        }
    }

    static final class m implements Runnable {
        final /* synthetic */ PickerNode g;
        final /* synthetic */ ActionParamInfo h;
        final /* synthetic */ Handler i;
        final /* synthetic */ Runnable j;

        static final class a implements Runnable {
            final /* synthetic */ ArrayList g;

            /* JADX INFO: renamed from: com.omarea.krscript.ui.ActionListFragment$m$a$a, reason: collision with other inner class name */
            public static final class C0062a implements com.omarea.common.ui.f.a {
                C0062a() {
                }

                @Override // com.omarea.common.ui.f.a
                public void a(List<com.omarea.a.f.a> list, boolean[] zArr) {
                    kotlin.jvm.internal.r.d(list, "selected");
                    kotlin.jvm.internal.r.d(zArr, "status");
                    String str = "";
                    if (m.this.g.getMultiple()) {
                        m mVar = m.this;
                        ActionListFragment actionListFragment = ActionListFragment.this;
                        PickerNode pickerNode = mVar.g;
                        ArrayList arrayList = new ArrayList(kotlin.collections.q.k(list, 10));
                        Iterator<T> it = list.iterator();
                        while (it.hasNext()) {
                            arrayList.add("" + ((com.omarea.a.f.a) it.next()).c());
                        }
                        actionListFragment.Q1(pickerNode, kotlin.collections.q.A(arrayList, m.this.g.getSeparator(), (CharSequence) null, (CharSequence) null, 0, (CharSequence) null, (kotlin.jvm.b.l) null, 62, (Object) null), m.this.j);
                        return;
                    }
                    if (list.size() <= 0) {
                        Toast.makeText(ActionListFragment.this.q(), ActionListFragment.this.K(com.omarea.c.h.picker_select_none), 0).show();
                        return;
                    }
                    m mVar2 = m.this;
                    ActionListFragment actionListFragment2 = ActionListFragment.this;
                    PickerNode pickerNode2 = mVar2.g;
                    StringBuilder sb = new StringBuilder();
                    sb.append("");
                    if (list.size() > 0) {
                        str = "" + list.get(0).c();
                    }
                    sb.append(str);
                    actionListFragment2.Q1(pickerNode2, sb.toString(), m.this.j);
                }
            }

            a(ArrayList arrayList) {
                this.g = arrayList;
            }

            @Override // java.lang.Runnable
            public final void run() {
                View decorView;
                ActionListFragment.E1(ActionListFragment.this).c();
                boolean z = false;
                if (this.g == null) {
                    Toast.makeText(ActionListFragment.this.q(), ActionListFragment.this.K(com.omarea.c.h.picker_not_item), 0).show();
                    return;
                }
                androidx.fragment.app.d dVarJ = ActionListFragment.this.j();
                kotlin.jvm.internal.r.b(dVarJ);
                kotlin.jvm.internal.r.c(dVarJ, "activity!!");
                Window window = dVarJ.getWindow();
                Integer numValueOf = (window == null || (decorView = window.getDecorView()) == null) ? null : Integer.valueOf(decorView.getSystemUiVisibility());
                if (numValueOf != null && (numValueOf.intValue() & 8192) == 0) {
                    z = true;
                }
                com.omarea.common.ui.f fVar = new com.omarea.common.ui.f(z, this.g, m.this.g.getMultiple(), new C0062a(), null, 16, null);
                androidx.fragment.app.d dVarJ2 = ActionListFragment.this.j();
                kotlin.jvm.internal.r.b(dVarJ2);
                kotlin.jvm.internal.r.c(dVarJ2, "activity!!");
                fVar.E1(dVarJ2.getSupportFragmentManager(), "picker-item-chooser");
            }
        }

        m(PickerNode pickerNode, ActionParamInfo actionParamInfo, Handler handler, Runnable runnable) {
            this.g = pickerNode;
            this.h = actionParamInfo;
            this.i = handler;
            this.j = runnable;
        }

        @Override // java.lang.Runnable
        public final void run() {
            if (this.g.getGetState() != null) {
                ActionParamInfo actionParamInfo = this.h;
                ActionListFragment actionListFragment = ActionListFragment.this;
                String getState = this.g.getGetState();
                kotlin.jvm.internal.r.b(getState);
                actionParamInfo.setValueFromShell(actionListFragment.M1(getState, this.g));
            }
            ArrayList<com.omarea.a.f.a> arrayListN1 = ActionListFragment.this.N1(this.h, this.g);
            if (arrayListN1 != null) {
                com.omarea.krscript.ui.a.f575d.d(this.h, arrayListN1);
            } else {
                arrayListN1 = null;
            }
            this.i.post(new a(arrayListN1));
        }
    }

    public static final /* synthetic */ com.omarea.common.ui.j E1(ActionListFragment actionListFragment) {
        com.omarea.common.ui.j jVar = actionListFragment.d0;
        if (jVar != null) {
            return jVar;
        }
        kotlin.jvm.internal.r.q("progressBarDialog");
        throw null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void K1(ActionNode actionNode, Runnable runnable) {
        String setState = actionNode.getSetState();
        if (setState != null) {
            if (actionNode.getParams() != null) {
                ArrayList<ActionParamInfo> params = actionNode.getParams();
                kotlin.jvm.internal.r.b(params);
                if (params.size() > 0) {
                    Context contextQ = q();
                    kotlin.jvm.internal.r.b(contextQ);
                    View viewInflate = LayoutInflater.from(contextQ).inflate(com.omarea.c.g.kr_params_list, (ViewGroup) null);
                    if (viewInflate == null) {
                        throw new NullPointerException("null cannot be cast to non-null type android.widget.LinearLayout");
                    }
                    LinearLayout linearLayout = (LinearLayout) viewInflate;
                    Handler handler = new Handler();
                    com.omarea.common.ui.j jVar = this.d0;
                    if (jVar == null) {
                        kotlin.jvm.internal.r.q("progressBarDialog");
                        throw null;
                    }
                    Context contextQ2 = q();
                    kotlin.jvm.internal.r.b(contextQ2);
                    String string = contextQ2.getString(com.omarea.c.h.onloading);
                    kotlin.jvm.internal.r.c(string, "this.context!!.getString(R.string.onloading)");
                    jVar.d(string);
                    new Thread(new b(params, handler, actionNode, linearLayout, setState, runnable)).start();
                    return;
                }
            }
            L1(actionNode, setState, runnable, null);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Code duplicated, block: B:16:0x0075  */
    public final void L1(RunnableNode runnableNode, String str, Runnable runnable, HashMap<String, String> map) {
        boolean z;
        Context contextQ = q();
        kotlin.jvm.internal.r.b(contextQ);
        kotlin.jvm.internal.r.c(contextQ, "context!!");
        if (kotlin.jvm.internal.r.a(runnableNode.getShell(), RunnableNode.Companion.getShellModeBgTask())) {
            com.omarea.c.a.i.a(contextQ, str, map, runnableNode, runnable, new c(runnableNode));
            return;
        }
        if (kotlin.jvm.internal.r.a(runnableNode.getShell(), RunnableNode.Companion.getShellModeHidden())) {
            if (this.i0) {
                Toast.makeText(contextQ, K(com.omarea.c.h.kr_hidden_task_running), 0).show();
                return;
            }
            this.i0 = true;
            com.omarea.c.c.g.a(contextQ, str, map, runnableNode, runnable, new d(runnableNode));
            return;
        }
        e eVar = new e(runnableNode);
        com.omarea.common.ui.k kVar = this.g0;
        if (kVar != null) {
            kotlin.jvm.internal.r.b(kVar);
            if (kVar.a()) {
                z = true;
            } else {
                z = false;
            }
        } else {
            z = false;
        }
        DialogLogFragment dialogLogFragmentA = DialogLogFragment.w0.a(runnableNode, runnable, eVar, str, map, z);
        dialogLogFragmentA.C1(false);
        androidx.fragment.app.i iVarV = v();
        kotlin.jvm.internal.r.b(iVarV);
        dialogLogFragmentA.E1(iVarV, "");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final String M1(String str, NodeInfoBase nodeInfoBase) {
        Context contextQ = q();
        kotlin.jvm.internal.r.b(contextQ);
        String strC = com.omarea.c.n.b.c(contextQ, str, nodeInfoBase);
        kotlin.jvm.internal.r.c(strC, "ScriptEnvironmen.execute…hellScript, nodeInfoBase)");
        return strC;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Code duplicated, block: B:60:0x010f  */
    /* JADX WARN: Code duplicated, block: B:62:0x0115  */
    /* JADX WARN: Code duplicated, block: B:65:0x0126 A[LOOP:3: B:63:0x0120->B:65:0x0126, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:67:0x0131 A[RETURN] */
    public final ArrayList<com.omarea.a.f.a> N1(ActionParamInfo actionParamInfo, NodeInfoBase nodeInfoBase) {
        Iterator<com.omarea.a.f.a> it;
        List listE;
        com.omarea.a.f.a aVar;
        List listE2;
        ArrayList<com.omarea.a.f.a> arrayList = new ArrayList<>();
        String strM1 = actionParamInfo.getOptionsSh().length() == 0 ? "" : M1(actionParamInfo.getOptionsSh(), nodeInfoBase);
        if (kotlin.jvm.internal.r.a(strM1, "error") || kotlin.jvm.internal.r.a(strM1, "null")) {
            if (actionParamInfo.getOptions() != null) {
                return null;
            }
            ArrayList<com.omarea.a.f.a> options = actionParamInfo.getOptions();
            kotlin.jvm.internal.r.b(options);
            it = options.iterator();
            while (it.hasNext()) {
                arrayList.add(it.next());
            }
        } else if (!(strM1.length() == 0)) {
            List listSplit = new Regex("\n").split(strM1, 0);
            if (listSplit.isEmpty()) {
                listE = kotlin.collections.q.e();
                break;
            }
            ListIterator listIterator = listSplit.listIterator(listSplit.size());
            while (true) {
                if (!listIterator.hasPrevious()) {
                    listE = kotlin.collections.q.e();
                    break;
                }
                if (!(((String) listIterator.previous()).length() == 0)) {
                    listE = kotlin.collections.q.Q(listSplit, listIterator.nextIndex() + 1);
                    break;
                }
            }
            Object[] array = listE.toArray(new String[0]);
            if (array == null) {
                throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T>");
            }
            for (String str : (String[]) array) {
                if (kotlin.text.k.y(str, "|", false, 2, (Object) null)) {
                    List listSplit2 = new Regex("\\|").split(str, 0);
                    if (listSplit2.isEmpty()) {
                        listE2 = kotlin.collections.q.e();
                        break;
                    }
                    ListIterator listIterator2 = listSplit2.listIterator(listSplit2.size());
                    while (true) {
                        if (!listIterator2.hasPrevious()) {
                            listE2 = kotlin.collections.q.e();
                            break;
                        }
                        if (!(((String) listIterator2.previous()).length() == 0)) {
                            listE2 = kotlin.collections.q.Q(listSplit2, listIterator2.nextIndex() + 1);
                            break;
                        }
                    }
                    Object[] array2 = listE2.toArray(new String[0]);
                    if (array2 == null) {
                        throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T>");
                    }
                    String[] strArr = (String[]) array2;
                    aVar = new com.omarea.a.f.a();
                    String str2 = strArr[0];
                    if (strArr.length > 0) {
                        str2 = strArr[1];
                    }
                    aVar.e(str2);
                    str = strArr[0];
                } else {
                    aVar = new com.omarea.a.f.a();
                    aVar.e(str);
                }
                aVar.f(str);
                kotlin.s sVar = kotlin.s.a;
                arrayList.add(aVar);
            }
        } else {
            if (actionParamInfo.getOptions() != null) {
                return null;
            }
            ArrayList<com.omarea.a.f.a> options2 = actionParamInfo.getOptions();
            kotlin.jvm.internal.r.b(options2);
            it = options2.iterator();
            while (it.hasNext()) {
                arrayList.add(it.next());
            }
        }
        return arrayList;
    }

    /* JADX WARN: Code duplicated, block: B:33:0x0145 A[PHI: r2
      0x0145: PHI (r2v4 java.lang.String) = 
      (r2v3 java.lang.String)
      (r2v12 java.lang.String)
      (r2v12 java.lang.String)
      (r2v12 java.lang.String)
      (r2v12 java.lang.String)
     binds: [B:32:0x0143, B:23:0x0122, B:25:0x012a, B:27:0x0132, B:29:0x013a] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:34:0x0147 A[PHI: r2
      0x0147: PHI (r2v10 java.lang.String) = (r2v3 java.lang.String), (r2v12 java.lang.String) binds: [B:32:0x0143, B:29:0x013a] A[DONT_GENERATE, DONT_INLINE]] */
    private final boolean O1(ClickableNode clickableNode) {
        boolean z;
        int i2 = Build.VERSION.SDK_INT;
        if (clickableNode.getTargetSdkVersion() > 0 && i2 != clickableNode.getTargetSdkVersion()) {
            com.omarea.common.ui.e.a aVar = com.omarea.common.ui.e.f492b;
            Context contextQ = q();
            kotlin.jvm.internal.r.b(contextQ);
            kotlin.jvm.internal.r.c(contextQ, "context!!");
            String strK = K(com.omarea.c.h.kr_sdk_discrepancy);
            kotlin.jvm.internal.r.c(strK, "getString(R.string.kr_sdk_discrepancy)");
            String strK2 = K(com.omarea.c.h.kr_sdk_discrepancy_message);
            kotlin.jvm.internal.r.c(strK2, "getString(R.string.kr_sdk_discrepancy_message)");
            String str = String.format(strK2, Arrays.copyOf(new Object[]{Integer.valueOf(clickableNode.getTargetSdkVersion())}, 1));
            kotlin.jvm.internal.r.c(str, "java.lang.String.format(this, *args)");
            com.omarea.common.ui.e.a.A(aVar, contextQ, strK, str, null, 8, null);
            return false;
        }
        if (i2 > clickableNode.getMaxSdkVersion()) {
            com.omarea.common.ui.e.a aVar2 = com.omarea.common.ui.e.f492b;
            Context contextQ2 = q();
            kotlin.jvm.internal.r.b(contextQ2);
            kotlin.jvm.internal.r.c(contextQ2, "context!!");
            String strK3 = K(com.omarea.c.h.kr_sdk_overtop);
            kotlin.jvm.internal.r.c(strK3, "getString(R.string.kr_sdk_overtop)");
            String strK4 = K(com.omarea.c.h.kr_sdk_message);
            kotlin.jvm.internal.r.c(strK4, "getString(R.string.kr_sdk_message)");
            String str2 = String.format(strK4, Arrays.copyOf(new Object[]{Integer.valueOf(clickableNode.getMinSdkVersion()), Integer.valueOf(clickableNode.getMaxSdkVersion())}, 2));
            kotlin.jvm.internal.r.c(str2, "java.lang.String.format(this, *args)");
            com.omarea.common.ui.e.a.A(aVar2, contextQ2, strK3, str2, null, 8, null);
            return false;
        }
        if (i2 < clickableNode.getMinSdkVersion()) {
            com.omarea.common.ui.e.a aVar3 = com.omarea.common.ui.e.f492b;
            Context contextQ3 = q();
            kotlin.jvm.internal.r.b(contextQ3);
            kotlin.jvm.internal.r.c(contextQ3, "context!!");
            String strK5 = K(com.omarea.c.h.kr_sdk_too_low);
            kotlin.jvm.internal.r.c(strK5, "getString(R.string.kr_sdk_too_low)");
            String strK6 = K(com.omarea.c.h.kr_sdk_message);
            kotlin.jvm.internal.r.c(strK6, "getString(R.string.kr_sdk_message)");
            String str3 = String.format(strK6, Arrays.copyOf(new Object[]{Integer.valueOf(clickableNode.getMinSdkVersion()), Integer.valueOf(clickableNode.getMaxSdkVersion())}, 2));
            kotlin.jvm.internal.r.c(str3, "java.lang.String.format(this, *args)");
            com.omarea.common.ui.e.a.A(aVar3, contextQ3, strK5, str3, null, 8, null);
            return false;
        }
        String strK7 = "";
        if (clickableNode.getLockShell().length() > 0) {
            strK7 = com.omarea.c.n.b.c(q(), clickableNode.getLockShell(), clickableNode);
            kotlin.jvm.internal.r.c(strK7, "ScriptEnvironmen.execute…lockShell, clickableNode)");
            if (kotlin.jvm.internal.r.a(strK7, "unlock") || kotlin.jvm.internal.r.a(strK7, "unlocked") || kotlin.jvm.internal.r.a(strK7, "false") || kotlin.jvm.internal.r.a(strK7, "0")) {
                z = true;
            } else {
                z = false;
            }
        } else if (clickableNode.getLocked()) {
            z = false;
        } else {
            z = true;
        }
        if (!z) {
            Context contextQ4 = q();
            if (!(strK7.length() > 0)) {
                strK7 = K(com.omarea.c.h.kr_lock_message);
                kotlin.jvm.internal.r.c(strK7, "getString(R.string.kr_lock_message)");
            }
            Toast.makeText(contextQ4, strK7, 1).show();
        }
        return z;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void P1(PickerNode pickerNode, Runnable runnable) {
        ActionParamInfo actionParamInfo = new ActionParamInfo();
        actionParamInfo.setOptions(pickerNode.getOptions());
        actionParamInfo.setOptionsSh(pickerNode.getOptionsSh());
        actionParamInfo.setSeparator(pickerNode.getSeparator());
        Handler handler = new Handler();
        com.omarea.common.ui.j jVar = this.d0;
        if (jVar == null) {
            kotlin.jvm.internal.r.q("progressBarDialog");
            throw null;
        }
        String strK = K(com.omarea.c.h.kr_param_options_load);
        kotlin.jvm.internal.r.c(strK, "getString(R.string.kr_param_options_load)");
        jVar.d(strK);
        new Thread(new m(pickerNode, actionParamInfo, handler, runnable)).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void Q1(PickerNode pickerNode, final String str, Runnable runnable) {
        String setState = pickerNode.getSetState();
        if (setState != null) {
            L1(pickerNode, setState, runnable, new HashMap<String, String>(str) { // from class: com.omarea.krscript.ui.ActionListFragment$pickerExecute$2
                final /* synthetic */ String $toValue;

                {
                    this.$toValue = str;
                    put("state", str);
                }

                @Override // java.util.HashMap, java.util.AbstractMap, java.util.Map
                public final /* bridge */ boolean containsKey(Object obj) {
                    if (obj instanceof String) {
                        return containsKey((String) obj);
                    }
                    return false;
                }

                public /* bridge */ boolean containsKey(String str2) {
                    return super.containsKey((Object) str2);
                }

                @Override // java.util.HashMap, java.util.AbstractMap, java.util.Map
                public final /* bridge */ boolean containsValue(Object obj) {
                    if (obj instanceof String) {
                        return containsValue((String) obj);
                    }
                    return false;
                }

                public /* bridge */ boolean containsValue(String str2) {
                    return super.containsValue((Object) str2);
                }

                @Override // java.util.HashMap, java.util.AbstractMap, java.util.Map
                public final /* bridge */ Set<Map.Entry<String, String>> entrySet() {
                    return getEntries();
                }

                @Override // java.util.HashMap, java.util.AbstractMap, java.util.Map
                public final /* bridge */ Object get(Object obj) {
                    if (obj instanceof String) {
                        return get((String) obj);
                    }
                    return null;
                }

                public /* bridge */ String get(String str2) {
                    return (String) super.get((Object) str2);
                }

                public /* bridge */ Set getEntries() {
                    return super.entrySet();
                }

                public /* bridge */ Set getKeys() {
                    return super.keySet();
                }

                @Override // java.util.HashMap, java.util.Map
                public final /* bridge */ Object getOrDefault(Object obj, Object obj2) {
                    return obj instanceof String ? getOrDefault((String) obj, (String) obj2) : obj2;
                }

                public /* bridge */ String getOrDefault(String str2, String str3) {
                    return (String) super.getOrDefault((Object) str2, str3);
                }

                public /* bridge */ int getSize() {
                    return super.size();
                }

                public /* bridge */ Collection getValues() {
                    return super.values();
                }

                @Override // java.util.HashMap, java.util.AbstractMap, java.util.Map
                public final /* bridge */ Set<String> keySet() {
                    return getKeys();
                }

                @Override // java.util.HashMap, java.util.AbstractMap, java.util.Map
                public final /* bridge */ Object remove(Object obj) {
                    if (obj instanceof String) {
                        return remove((String) obj);
                    }
                    return null;
                }

                public /* bridge */ String remove(String str2) {
                    return (String) super.remove((Object) str2);
                }

                @Override // java.util.HashMap, java.util.Map
                public final /* bridge */ boolean remove(Object obj, Object obj2) {
                    if ((obj instanceof String) && (obj2 instanceof String)) {
                        return remove((String) obj, (String) obj2);
                    }
                    return false;
                }

                public /* bridge */ boolean remove(String str2, String str3) {
                    return super.remove((Object) str2, (Object) str3);
                }

                @Override // java.util.HashMap, java.util.AbstractMap, java.util.Map
                public final /* bridge */ int size() {
                    return getSize();
                }

                @Override // java.util.HashMap, java.util.AbstractMap, java.util.Map
                public final /* bridge */ Collection<String> values() {
                    return getValues();
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void S1(ArrayList<NodeInfoBase> arrayList, KrScriptActionHandler krScriptActionHandler, AutoRunTask autoRunTask, com.omarea.common.ui.k kVar) {
        if (arrayList != null) {
            this.c0 = arrayList;
            this.e0 = krScriptActionHandler;
            this.f0 = autoRunTask;
            this.g0 = kVar;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void T1(SwitchNode switchNode, final boolean z, Runnable runnable) {
        String setState = switchNode.getSetState();
        if (setState != null) {
            L1(switchNode, setState, runnable, new HashMap<String, String>(z) { // from class: com.omarea.krscript.ui.ActionListFragment$switchExecute$1
                final /* synthetic */ boolean $toValue;

                {
                    this.$toValue = z;
                    put("state", z ? "1" : "0");
                }

                @Override // java.util.HashMap, java.util.AbstractMap, java.util.Map
                public final /* bridge */ boolean containsKey(Object obj) {
                    if (obj instanceof String) {
                        return containsKey((String) obj);
                    }
                    return false;
                }

                public /* bridge */ boolean containsKey(String str) {
                    return super.containsKey((Object) str);
                }

                @Override // java.util.HashMap, java.util.AbstractMap, java.util.Map
                public final /* bridge */ boolean containsValue(Object obj) {
                    if (obj instanceof String) {
                        return containsValue((String) obj);
                    }
                    return false;
                }

                public /* bridge */ boolean containsValue(String str) {
                    return super.containsValue((Object) str);
                }

                @Override // java.util.HashMap, java.util.AbstractMap, java.util.Map
                public final /* bridge */ Set<Map.Entry<String, String>> entrySet() {
                    return getEntries();
                }

                @Override // java.util.HashMap, java.util.AbstractMap, java.util.Map
                public final /* bridge */ Object get(Object obj) {
                    if (obj instanceof String) {
                        return get((String) obj);
                    }
                    return null;
                }

                public /* bridge */ String get(String str) {
                    return (String) super.get((Object) str);
                }

                public /* bridge */ Set getEntries() {
                    return super.entrySet();
                }

                public /* bridge */ Set getKeys() {
                    return super.keySet();
                }

                @Override // java.util.HashMap, java.util.Map
                public final /* bridge */ Object getOrDefault(Object obj, Object obj2) {
                    return obj instanceof String ? getOrDefault((String) obj, (String) obj2) : obj2;
                }

                public /* bridge */ String getOrDefault(String str, String str2) {
                    return (String) super.getOrDefault((Object) str, str2);
                }

                public /* bridge */ int getSize() {
                    return super.size();
                }

                public /* bridge */ Collection getValues() {
                    return super.values();
                }

                @Override // java.util.HashMap, java.util.AbstractMap, java.util.Map
                public final /* bridge */ Set<String> keySet() {
                    return getKeys();
                }

                @Override // java.util.HashMap, java.util.AbstractMap, java.util.Map
                public final /* bridge */ Object remove(Object obj) {
                    if (obj instanceof String) {
                        return remove((String) obj);
                    }
                    return null;
                }

                public /* bridge */ String remove(String str) {
                    return (String) super.remove((Object) str);
                }

                @Override // java.util.HashMap, java.util.Map
                public final /* bridge */ boolean remove(Object obj, Object obj2) {
                    if ((obj instanceof String) && (obj2 instanceof String)) {
                        return remove((String) obj, (String) obj2);
                    }
                    return false;
                }

                public /* bridge */ boolean remove(String str, String str2) {
                    return super.remove((Object) str, (Object) str2);
                }

                @Override // java.util.HashMap, java.util.AbstractMap, java.util.Map
                public final /* bridge */ int size() {
                    return getSize();
                }

                @Override // java.util.HashMap, java.util.AbstractMap, java.util.Map
                public final /* bridge */ Collection<String> values() {
                    return getValues();
                }
            });
        }
    }

    private final void U1(AutoRunTask autoRunTask) {
        if (autoRunTask != null) {
            String key = autoRunTask.getKey();
            if (key == null || key.length() == 0) {
                return;
            }
            com.omarea.krscript.ui.d dVar = this.h0;
            if (dVar == null) {
                kotlin.jvm.internal.r.q("rootGroup");
                throw null;
            }
            String key2 = autoRunTask.getKey();
            kotlin.jvm.internal.r.b(key2);
            autoRunTask.onCompleted(Boolean.valueOf(dVar.k(key2)));
        }
    }

    public void E0(View view, Bundle bundle) {
        kotlin.jvm.internal.r.d(view, "view");
        super.E0(view, bundle);
        androidx.fragment.app.d dVarJ = j();
        kotlin.jvm.internal.r.b(dVarJ);
        kotlin.jvm.internal.r.c(dVarJ, "this.activity!!");
        this.d0 = new com.omarea.common.ui.j(dVarJ, null, 2, null);
        Context contextQ = q();
        kotlin.jvm.internal.r.b(contextQ);
        kotlin.jvm.internal.r.c(contextQ, "this.context!!");
        this.h0 = new com.omarea.krscript.ui.d(contextQ, true, new GroupNode(""));
        if (this.c0 != null) {
            Context contextQ2 = q();
            kotlin.jvm.internal.r.b(contextQ2);
            kotlin.jvm.internal.r.c(contextQ2, "this.context!!");
            ArrayList<NodeInfoBase> arrayList = this.c0;
            kotlin.jvm.internal.r.b(arrayList);
            com.omarea.krscript.ui.d dVar = this.h0;
            if (dVar == null) {
                kotlin.jvm.internal.r.q("rootGroup");
                throw null;
            }
            new com.omarea.krscript.ui.j(contextQ2, arrayList, this, dVar);
            com.omarea.krscript.ui.d dVar2 = this.h0;
            if (dVar2 == null) {
                kotlin.jvm.internal.r.q("rootGroup");
                throw null;
            }
            View viewD = dVar2.d();
            View viewN = N();
            ScrollView scrollView = viewN != null ? (ScrollView) viewN.findViewById(com.omarea.c.f.kr_content) : null;
            if (scrollView != null) {
                scrollView.removeAllViews();
            }
            if (scrollView != null) {
                scrollView.addView(viewD);
            }
            U1(this.f0);
        }
    }

    public final void R1(boolean z) {
        this.i0 = z;
    }

    @Override // com.omarea.krscript.ui.j.a
    public void a(ActionNode actionNode, Runnable runnable) {
        com.omarea.common.ui.e.a aVar;
        androidx.fragment.app.d dVarJ;
        String title;
        String warning;
        Runnable gVar;
        ArrayList<ActionParamInfo> params;
        kotlin.jvm.internal.r.d(actionNode, "item");
        kotlin.jvm.internal.r.d(runnable, "onCompleted");
        if (O1(actionNode)) {
            if (actionNode.getConfirm()) {
                aVar = com.omarea.common.ui.e.f492b;
                dVarJ = j();
                kotlin.jvm.internal.r.b(dVarJ);
                kotlin.jvm.internal.r.c(dVarJ, "activity!!");
                title = actionNode.getTitle();
                warning = actionNode.getDesc();
                gVar = new f(actionNode, runnable);
            } else {
                if (!(actionNode.getWarning().length() > 0) || (actionNode.getParams() != null && ((params = actionNode.getParams()) == null || params.size() != 0))) {
                    K1(actionNode, runnable);
                    return;
                }
                aVar = com.omarea.common.ui.e.f492b;
                dVarJ = j();
                kotlin.jvm.internal.r.b(dVarJ);
                kotlin.jvm.internal.r.c(dVarJ, "activity!!");
                title = actionNode.getTitle();
                warning = actionNode.getWarning();
                gVar = new g(actionNode, runnable);
            }
            aVar.F(dVarJ, (16 & 2) != 0 ? "" : title, (16 & 4) != 0 ? "" : warning, (16 & 8) != 0 ? null : gVar, (16 & 16) != 0 ? null : null);
        }
    }

    @Override // com.omarea.krscript.ui.j.a
    public void b(ClickableNode clickableNode) {
        kotlin.jvm.internal.r.d(clickableNode, "clickableNode");
        if (!(clickableNode.getKey().length() == 0)) {
            KrScriptActionHandler krScriptActionHandler = this.e0;
            if (krScriptActionHandler != null) {
                krScriptActionHandler.addToFavorites(clickableNode, new h());
                return;
            }
            return;
        }
        com.omarea.common.ui.e.a aVar = com.omarea.common.ui.e.f492b;
        androidx.fragment.app.d dVarJ = j();
        kotlin.jvm.internal.r.b(dVarJ);
        kotlin.jvm.internal.r.c(dVarJ, "this.activity!!");
        String strK = K(com.omarea.c.h.kr_shortcut_create_fail);
        kotlin.jvm.internal.r.c(strK, "getString(R.string.kr_shortcut_create_fail)");
        String strK2 = K(com.omarea.c.h.kr_ushortcut_nsupported);
        kotlin.jvm.internal.r.c(strK2, "getString(R.string.kr_ushortcut_nsupported)");
        com.omarea.common.ui.e.a.b(aVar, dVarJ, strK, strK2, null, 8, null);
    }

    @Override // com.omarea.krscript.ui.j.a
    public void c(PageNode pageNode, Runnable runnable) {
        kotlin.jvm.internal.r.d(pageNode, "item");
        kotlin.jvm.internal.r.d(runnable, "onCompleted");
        if (O1(pageNode)) {
            if (q() != null) {
                if (pageNode.getLink().length() > 0) {
                    try {
                        Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(pageNode.getLink()));
                        intent.addFlags(268435456);
                        Context contextQ = q();
                        if (contextQ != null) {
                            contextQ.startActivity(intent);
                            return;
                        }
                        return;
                    } catch (Exception unused) {
                        Context contextQ2 = q();
                        Context contextQ3 = q();
                        Toast.makeText(contextQ2, contextQ3 != null ? contextQ3.getString(com.omarea.c.h.kr_slice_activity_fail) : null, 0).show();
                        return;
                    }
                }
            }
            if (q() != null) {
                if (pageNode.getActivity().length() > 0) {
                    Context contextQ4 = q();
                    kotlin.jvm.internal.r.b(contextQ4);
                    kotlin.jvm.internal.r.c(contextQ4, "context!!");
                    new com.omarea.c.j(contextQ4, pageNode.getActivity()).b();
                    return;
                }
            }
            KrScriptActionHandler krScriptActionHandler = this.e0;
            if (krScriptActionHandler != null) {
                krScriptActionHandler.onSubPageClick(pageNode);
            }
        }
    }

    @Override // com.omarea.krscript.ui.j.a
    public void d(SwitchNode switchNode, Runnable runnable) {
        com.omarea.common.ui.e.a aVar;
        androidx.fragment.app.d dVarJ;
        String title;
        String warning;
        Runnable lVar;
        kotlin.jvm.internal.r.d(switchNode, "item");
        kotlin.jvm.internal.r.d(runnable, "onCompleted");
        if (O1(switchNode)) {
            boolean z = !switchNode.getChecked();
            if (switchNode.getConfirm()) {
                aVar = com.omarea.common.ui.e.f492b;
                dVarJ = j();
                kotlin.jvm.internal.r.b(dVarJ);
                kotlin.jvm.internal.r.c(dVarJ, "activity!!");
                title = switchNode.getTitle();
                warning = switchNode.getDesc();
                lVar = new k(switchNode, z, runnable);
            } else {
                if (!(switchNode.getWarning().length() > 0)) {
                    T1(switchNode, z, runnable);
                    return;
                }
                aVar = com.omarea.common.ui.e.f492b;
                dVarJ = j();
                kotlin.jvm.internal.r.b(dVarJ);
                kotlin.jvm.internal.r.c(dVarJ, "activity!!");
                title = switchNode.getTitle();
                warning = switchNode.getWarning();
                lVar = new l(switchNode, z, runnable);
            }
            aVar.F(dVarJ, (16 & 2) != 0 ? "" : title, (16 & 4) != 0 ? "" : warning, (16 & 8) != 0 ? null : lVar, (16 & 16) != 0 ? null : null);
        }
    }

    @Override // com.omarea.krscript.ui.j.a
    public void e(PickerNode pickerNode, Runnable runnable) {
        com.omarea.common.ui.e.a aVar;
        androidx.fragment.app.d dVarJ;
        String title;
        String warning;
        Runnable jVar;
        kotlin.jvm.internal.r.d(pickerNode, "item");
        kotlin.jvm.internal.r.d(runnable, "onCompleted");
        if (O1(pickerNode)) {
            if (pickerNode.getConfirm()) {
                aVar = com.omarea.common.ui.e.f492b;
                dVarJ = j();
                kotlin.jvm.internal.r.b(dVarJ);
                kotlin.jvm.internal.r.c(dVarJ, "activity!!");
                title = pickerNode.getTitle();
                warning = pickerNode.getDesc();
                jVar = new i(pickerNode, runnable);
            } else {
                if (!(pickerNode.getWarning().length() > 0)) {
                    P1(pickerNode, runnable);
                    return;
                }
                aVar = com.omarea.common.ui.e.f492b;
                dVarJ = j();
                kotlin.jvm.internal.r.b(dVarJ);
                kotlin.jvm.internal.r.c(dVarJ, "activity!!");
                title = pickerNode.getTitle();
                warning = pickerNode.getWarning();
                jVar = new j(pickerNode, runnable);
            }
            aVar.F(dVarJ, (16 & 2) != 0 ? "" : title, (16 & 4) != 0 ? "" : warning, (16 & 8) != 0 ? null : jVar, (16 & 16) != 0 ? null : null);
        }
    }

    public View j0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        kotlin.jvm.internal.r.d(layoutInflater, "inflater");
        return layoutInflater.inflate(com.omarea.c.g.kr_action_list_fragment, viewGroup, false);
    }

    public /* synthetic */ void m0() {
        super.m0();
        y1();
    }

    public void y1() {
        HashMap map = this.j0;
        if (map != null) {
            map.clear();
        }
    }
}
