package com.omarea.krscript.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.omarea.krscript.model.ActionParamInfo;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class q {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private ArrayList<com.omarea.a.f.a> f612a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private boolean[] f613b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private String[] f614c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private String[] f615d;
    private final ActionParamInfo e;
    private final androidx.fragment.app.d f;

    public static final class a implements com.omarea.common.ui.f.a {

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final /* synthetic */ TextView f617b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        final /* synthetic */ TextView f618c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ TextView f619d;

        a(TextView textView, TextView textView2, TextView textView3) {
            this.f617b = textView;
            this.f618c = textView2;
            this.f619d = textView3;
        }

        @Override // com.omarea.common.ui.f.a
        public void a(List<com.omarea.a.f.a> list, boolean[] zArr) {
            kotlin.jvm.internal.r.d(list, "selected");
            kotlin.jvm.internal.r.d(zArr, "result");
            int length = zArr.length;
            int i = 0;
            int i2 = 0;
            while (i < length) {
                q.this.f613b[i2] = zArr[i];
                i++;
                i2++;
            }
            q.this.f(this.f617b, this.f618c, this.f619d);
        }
    }

    static final class b implements View.OnClickListener {
        final /* synthetic */ TextView g;
        final /* synthetic */ TextView h;
        final /* synthetic */ TextView i;

        b(TextView textView, TextView textView2, TextView textView3) {
            this.g = textView;
            this.h = textView2;
            this.i = textView3;
        }

        @Override // android.view.View.OnClickListener
        public final void onClick(View view) {
            q qVar = q.this;
            TextView textView = this.g;
            kotlin.jvm.internal.r.c(textView, "textView");
            TextView textView2 = this.h;
            kotlin.jvm.internal.r.c(textView2, "valueView");
            TextView textView3 = this.i;
            kotlin.jvm.internal.r.c(textView3, "countView");
            qVar.d(textView, textView2, textView3);
        }
    }

    public q(ActionParamInfo actionParamInfo, androidx.fragment.app.d dVar) {
        kotlin.jvm.internal.r.d(actionParamInfo, "actionParamInfo");
        kotlin.jvm.internal.r.d(dVar, "context");
        this.e = actionParamInfo;
        this.f = dVar;
        this.f613b = new boolean[0];
        this.f614c = new String[0];
        this.f615d = new String[0];
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void d(TextView textView, TextView textView2, TextView textView3) {
        if (this.f612a != null) {
            ArrayList arrayList = new ArrayList();
            int length = this.f614c.length;
            for (int i = 0; i < length; i++) {
                com.omarea.a.f.a aVar = new com.omarea.a.f.a();
                aVar.e("" + this.f614c[i]);
                aVar.d(this.f613b[i]);
                kotlin.s sVar = kotlin.s.a;
                arrayList.add(aVar);
            }
            new com.omarea.common.ui.f(true, new ArrayList(arrayList), true, new a(textView, textView2, textView3), null, 16, null).E1(this.f.getSupportFragmentManager(), "params-multi-select");
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void f(TextView textView, TextView textView2, TextView textView3) {
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        int length = this.f613b.length;
        int i = 0;
        for (int i2 = 0; i2 < length; i2++) {
            if (this.f613b[i2]) {
                String str = this.f615d[i2];
                if (str != null) {
                    arrayList.add(str);
                }
                String str2 = this.f614c[i2];
                if (str2 != null) {
                    arrayList2.add(str2);
                }
                i++;
            }
        }
        StringBuilder sb = new StringBuilder();
        sb.append("");
        sb.append(kotlin.collections.q.A(arrayList, this.e.getSeparator(), (CharSequence) null, (CharSequence) null, 0, (CharSequence) null, (kotlin.jvm.b.l) null, 62, (Object) null));
        String string = sb.toString();
        textView.setText(arrayList2.size() > 0 ? "" + kotlin.collections.q.A(arrayList2, "，", (CharSequence) null, (CharSequence) null, 0, (CharSequence) null, (kotlin.jvm.b.l) null, 62, (Object) null) : "");
        textView2.setText(string);
        textView3.setText(String.valueOf(i));
    }

    public final View e() {
        ArrayList<com.omarea.a.f.a> optionsFromShell = this.e.getOptionsFromShell();
        this.f612a = optionsFromShell;
        if (optionsFromShell != null) {
            ArrayList arrayList = new ArrayList(kotlin.collections.q.k(optionsFromShell, 10));
            Iterator<T> it = optionsFromShell.iterator();
            while (it.hasNext()) {
                arrayList.add(((com.omarea.a.f.a) it.next()).b());
            }
            Object[] array = arrayList.toArray(new String[0]);
            if (array == null) {
                throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T>");
            }
            this.f614c = (String[]) array;
            ArrayList arrayList2 = new ArrayList(kotlin.collections.q.k(optionsFromShell, 10));
            Iterator<T> it2 = optionsFromShell.iterator();
            while (it2.hasNext()) {
                arrayList2.add(((com.omarea.a.f.a) it2.next()).c());
            }
            Object[] array2 = arrayList2.toArray(new String[0]);
            if (array2 == null) {
                throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T>");
            }
            this.f615d = (String[]) array2;
            this.f613b = com.omarea.krscript.ui.a.f575d.b(this.e, optionsFromShell);
        }
        View viewInflate = LayoutInflater.from(this.f).inflate(com.omarea.c.g.kr_param_multiple_select, (ViewGroup) null);
        TextView textView = (TextView) viewInflate.findViewById(com.omarea.c.f.kr_param_label_text);
        TextView textView2 = (TextView) viewInflate.findViewById(com.omarea.c.f.kr_param_value_text);
        TextView textView3 = (TextView) viewInflate.findViewById(com.omarea.c.f.kr_param_count_text);
        kotlin.jvm.internal.r.c(textView2, "valueView");
        textView2.setTag(this.e.getName());
        kotlin.jvm.internal.r.c(textView, "textView");
        kotlin.jvm.internal.r.c(textView3, "countView");
        f(textView, textView2, textView3);
        textView.setOnClickListener(new b(textView, textView2, textView3));
        kotlin.jvm.internal.r.c(viewInflate, "layout");
        return viewInflate;
    }
}
