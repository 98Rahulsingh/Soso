package com.omarea.krscript.ui;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import com.omarea.krscript.model.ActionParamInfo;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class m {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private ActionParamInfo f596a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private Context f597b;

    static final class a implements View.OnClickListener {
        public static final a f = new a();

        a() {
        }

        @Override // android.view.View.OnClickListener
        public final void onClick(View view) {
        }
    }

    public m(ActionParamInfo actionParamInfo, Context context) {
        kotlin.jvm.internal.r.d(actionParamInfo, "actionParamInfo");
        kotlin.jvm.internal.r.d(context, "context");
        this.f596a = actionParamInfo;
        this.f597b = context;
    }

    private final boolean a(ActionParamInfo actionParamInfo, boolean z) {
        if (actionParamInfo.getValueFromShell() != null) {
            if (!kotlin.jvm.internal.r.a(actionParamInfo.getValueFromShell(), "1")) {
                String valueFromShell = actionParamInfo.getValueFromShell();
                kotlin.jvm.internal.r.b(valueFromShell);
                if (valueFromShell == null) {
                    throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                }
                String lowerCase = valueFromShell.toLowerCase();
                kotlin.jvm.internal.r.c(lowerCase, "(this as java.lang.String).toLowerCase()");
                if (!kotlin.jvm.internal.r.a(lowerCase, "true")) {
                    return false;
                }
            }
            return true;
        }
        if (actionParamInfo.getValue() == null) {
            return z;
        }
        if (!kotlin.jvm.internal.r.a(actionParamInfo.getValue(), "1")) {
            String value = actionParamInfo.getValue();
            kotlin.jvm.internal.r.b(value);
            if (value == null) {
                throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
            }
            String lowerCase2 = value.toLowerCase();
            kotlin.jvm.internal.r.c(lowerCase2, "(this as java.lang.String).toLowerCase()");
            if (!kotlin.jvm.internal.r.a(lowerCase2, "true")) {
                return false;
            }
        }
        return true;
    }

    public final View b() {
        View viewInflate = LayoutInflater.from(this.f597b).inflate(com.omarea.c.g.kr_param_checkbox, (ViewGroup) null);
        CheckBox checkBox = (CheckBox) viewInflate.findViewById(com.omarea.c.f.kr_param_checkbox);
        checkBox.setTag(this.f596a.getName());
        checkBox.setChecked(a(this.f596a, false));
        String label = this.f596a.getLabel();
        if (!(label == null || label.length() == 0)) {
            checkBox.setText(this.f596a.getLabel());
        }
        checkBox.setOnClickListener(a.f);
        kotlin.jvm.internal.r.c(viewInflate, "layout");
        return viewInflate;
    }
}
