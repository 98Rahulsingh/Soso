package com.omarea.krscript.ui;

import android.content.Context;
import android.widget.ImageView;
import com.omarea.krscript.model.ActionNode;
import com.omarea.krscript.model.ActionParamInfo;
import java.util.ArrayList;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class b extends c {
    private final ImageView m;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Code duplicated, block: B:12:0x003d  */
    /* JADX WARN: Code duplicated, block: B:14:0x0041  */
    /* JADX WARN: Code duplicated, block: B:18:? A[RETURN, SYNTHETIC] */
    public b(Context context, ActionNode actionNode) {
        ImageView imageView;
        int i;
        super(context, com.omarea.c.g.kr_action_list_item, actionNode);
        kotlin.jvm.internal.r.d(context, "context");
        kotlin.jvm.internal.r.d(actionNode, "config");
        ImageView imageView2 = (ImageView) c().findViewById(com.omarea.c.f.kr_widget);
        this.m = imageView2;
        if (imageView2 != null) {
            imageView2.setVisibility(0);
        }
        if (actionNode.getParams() != null) {
            ArrayList<ActionParamInfo> params = actionNode.getParams();
            kotlin.jvm.internal.r.b(params);
            if (params.size() > 0) {
                imageView = this.m;
                if (imageView == null) {
                    return;
                } else {
                    i = com.omarea.c.e.kr_list;
                }
            } else {
                imageView = this.m;
                if (imageView != null) {
                    return;
                } else {
                    i = com.omarea.c.e.kr_run;
                }
            }
        } else {
            imageView = this.m;
            if (imageView != null) {
                return;
            } else {
                i = com.omarea.c.e.kr_run;
            }
        }
        imageView.setImageDrawable(context.getDrawable(i));
    }
}
