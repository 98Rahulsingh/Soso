package com.omarea.krscript.ui;

import android.content.Context;
import com.omarea.krscript.model.PageMenuOption;
import com.omarea.krscript.model.PageNode;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class k {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private ArrayList<PageMenuOption> f589a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final Context f590b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final PageNode f591c;

    public k(Context context, PageNode pageNode) {
        kotlin.jvm.internal.r.d(context, "applicationContext");
        kotlin.jvm.internal.r.d(pageNode, "pageNode");
        this.f590b = context;
        this.f591c = pageNode;
    }

    public final ArrayList<PageMenuOption> a() {
        PageNode pageNode = this.f591c;
        if (this.f589a == null) {
            if (pageNode.getPageMenuOptionsSh().length() > 0) {
                String strC = com.omarea.c.n.b.c(this.f590b, pageNode.getPageMenuOptionsSh(), pageNode);
                if (!kotlin.jvm.internal.r.a(strC, "error")) {
                    kotlin.jvm.internal.r.c(strC, "result");
                    for (String str : kotlin.text.k.W(strC, new String[]{"\n"}, false, 0, 6, (Object) null)) {
                        PageMenuOption pageMenuOption = new PageMenuOption(pageNode.getPageConfigPath());
                        if (kotlin.text.k.y(str, "|", false, 2, (Object) null)) {
                            List listW = kotlin.text.k.W(str, new String[]{"|"}, false, 0, 6, (Object) null);
                            pageMenuOption.setKey((String) listW.get(0));
                            str = (String) listW.get(1);
                        } else {
                            pageMenuOption.setKey(str);
                        }
                        pageMenuOption.setTitle(str);
                    }
                }
            } else if (pageNode.getPageMenuOptions() != null) {
                this.f589a = pageNode.getPageMenuOptions();
            }
        }
        return this.f589a;
    }
}
