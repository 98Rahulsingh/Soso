package com.omarea.krscript.ui;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import com.omarea.krscript.model.ActionParamInfo;
import java.util.Arrays;
import kotlin.jvm.internal.w;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class n {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final ActionParamInfo f598a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final Context f599b;

    static final class a implements DialogInterface.OnClickListener {
        final /* synthetic */ SeekBar g;
        final /* synthetic */ SeekBar h;
        final /* synthetic */ SeekBar i;
        final /* synthetic */ SeekBar j;
        final /* synthetic */ Button k;
        final /* synthetic */ TextView l;
        final /* synthetic */ ImageView m;
        final /* synthetic */ View n;

        a(SeekBar seekBar, SeekBar seekBar2, SeekBar seekBar3, SeekBar seekBar4, Button button, TextView textView, ImageView imageView, View view) {
            this.g = seekBar;
            this.h = seekBar2;
            this.i = seekBar3;
            this.j = seekBar4;
            this.k = button;
            this.l = textView;
            this.m = imageView;
            this.n = view;
        }

        @Override // android.content.DialogInterface.OnClickListener
        public final void onClick(DialogInterface dialogInterface, int i) {
            SeekBar seekBar = this.g;
            kotlin.jvm.internal.r.c(seekBar, "alphaBar");
            int progress = seekBar.getProgress();
            SeekBar seekBar2 = this.h;
            kotlin.jvm.internal.r.c(seekBar2, "redBar");
            int progress2 = seekBar2.getProgress();
            SeekBar seekBar3 = this.i;
            kotlin.jvm.internal.r.c(seekBar3, "greenBar");
            int progress3 = seekBar3.getProgress();
            SeekBar seekBar4 = this.j;
            kotlin.jvm.internal.r.c(seekBar4, "blueBar");
            int iArgb = Color.argb(progress, progress2, progress3, seekBar4.getProgress());
            this.k.setBackgroundColor(iArgb);
            try {
                TextView textView = this.l;
                n nVar = n.this;
                SeekBar seekBar5 = this.g;
                kotlin.jvm.internal.r.c(seekBar5, "alphaBar");
                int progress4 = seekBar5.getProgress();
                SeekBar seekBar6 = this.h;
                kotlin.jvm.internal.r.c(seekBar6, "redBar");
                int progress5 = seekBar6.getProgress();
                SeekBar seekBar7 = this.i;
                kotlin.jvm.internal.r.c(seekBar7, "greenBar");
                int progress6 = seekBar7.getProgress();
                SeekBar seekBar8 = this.j;
                kotlin.jvm.internal.r.c(seekBar8, "blueBar");
                textView.setText(nVar.f(progress4, progress5, progress6, seekBar8.getProgress()));
                this.m.setVisibility(8);
                this.n.setBackground(new ColorDrawable(iArgb));
            } catch (Exception unused) {
            }
        }
    }

    static final class b implements DialogInterface.OnClickListener {
        public static final b f = new b();

        b() {
        }

        @Override // android.content.DialogInterface.OnClickListener
        public final void onClick(DialogInterface dialogInterface, int i) {
        }
    }

    public static final class c implements SeekBar.OnSeekBarChangeListener {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final /* synthetic */ SeekBar f600a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final /* synthetic */ SeekBar f601b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        final /* synthetic */ SeekBar f602c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ SeekBar f603d;
        final /* synthetic */ Button e;

        c(SeekBar seekBar, SeekBar seekBar2, SeekBar seekBar3, SeekBar seekBar4, Button button) {
            this.f600a = seekBar;
            this.f601b = seekBar2;
            this.f602c = seekBar3;
            this.f603d = seekBar4;
            this.e = button;
        }

        @Override // android.widget.SeekBar.OnSeekBarChangeListener
        public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
            kotlin.jvm.internal.r.d(seekBar, "seekBar");
            SeekBar seekBar2 = this.f600a;
            kotlin.jvm.internal.r.c(seekBar2, "alphaBar");
            int progress = seekBar2.getProgress();
            SeekBar seekBar3 = this.f601b;
            kotlin.jvm.internal.r.c(seekBar3, "redBar");
            int progress2 = seekBar3.getProgress();
            SeekBar seekBar4 = this.f602c;
            kotlin.jvm.internal.r.c(seekBar4, "greenBar");
            int progress3 = seekBar4.getProgress();
            SeekBar seekBar5 = this.f603d;
            kotlin.jvm.internal.r.c(seekBar5, "blueBar");
            this.e.setBackgroundColor(Color.argb(progress, progress2, progress3, seekBar5.getProgress()));
        }

        @Override // android.widget.SeekBar.OnSeekBarChangeListener
        public void onStartTrackingTouch(SeekBar seekBar) {
            kotlin.jvm.internal.r.d(seekBar, "seekBar");
        }

        @Override // android.widget.SeekBar.OnSeekBarChangeListener
        public void onStopTrackingTouch(SeekBar seekBar) {
            kotlin.jvm.internal.r.d(seekBar, "seekBar");
        }
    }

    public static final class d implements TextWatcher {
        final /* synthetic */ EditText g;
        final /* synthetic */ ImageView h;
        final /* synthetic */ View i;

        d(EditText editText, ImageView imageView, View view) {
            this.g = editText;
            this.h = imageView;
            this.i = view;
        }

        @Override // android.text.TextWatcher
        public void afterTextChanged(Editable editable) {
            n nVar = n.this;
            EditText editText = this.g;
            kotlin.jvm.internal.r.c(editText, "textView");
            ImageView imageView = this.h;
            kotlin.jvm.internal.r.c(imageView, "invalidView");
            View view = this.i;
            kotlin.jvm.internal.r.c(view, "preview");
            kotlin.jvm.internal.r.b(editable);
            nVar.h(editText, imageView, view, editable.toString());
        }

        @Override // android.text.TextWatcher
        public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }

        @Override // android.text.TextWatcher
        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }
    }

    static final class e implements View.OnClickListener {
        final /* synthetic */ EditText g;
        final /* synthetic */ ImageView h;
        final /* synthetic */ View i;

        e(EditText editText, ImageView imageView, View view) {
            this.g = editText;
            this.h = imageView;
            this.i = view;
        }

        @Override // android.view.View.OnClickListener
        public final void onClick(View view) {
            n nVar = n.this;
            EditText editText = this.g;
            kotlin.jvm.internal.r.c(editText, "textView");
            ImageView imageView = this.h;
            kotlin.jvm.internal.r.c(imageView, "invalidView");
            View view2 = this.i;
            kotlin.jvm.internal.r.c(view2, "preview");
            nVar.e(editText, imageView, view2);
        }
    }

    public n(ActionParamInfo actionParamInfo, Context context) {
        kotlin.jvm.internal.r.d(actionParamInfo, "actionParamInfo");
        kotlin.jvm.internal.r.d(context, "context");
        this.f598a = actionParamInfo;
        this.f599b = context;
    }

    private final int d(CharSequence charSequence) {
        if (charSequence != null) {
            if (charSequence.length() > 0) {
                try {
                    return Color.parseColor(charSequence.toString());
                } catch (Exception unused) {
                }
            }
        }
        return (int) 4278190080L;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void e(TextView textView, ImageView imageView, View view) {
        View viewInflate = LayoutInflater.from(this.f599b).inflate(com.omarea.c.g.kr_color_picker, (ViewGroup) null);
        int iD = d(textView.getText());
        SeekBar seekBar = (SeekBar) viewInflate.findViewById(com.omarea.c.f.color_alpha);
        SeekBar seekBar2 = (SeekBar) viewInflate.findViewById(com.omarea.c.f.color_red);
        SeekBar seekBar3 = (SeekBar) viewInflate.findViewById(com.omarea.c.f.color_green);
        SeekBar seekBar4 = (SeekBar) viewInflate.findViewById(com.omarea.c.f.color_blue);
        Button button = (Button) viewInflate.findViewById(com.omarea.c.f.color_preview);
        TextView textView2 = (TextView) viewInflate.findViewById(com.omarea.c.f.color_preview_text);
        kotlin.jvm.internal.r.c(seekBar, "alphaBar");
        seekBar.setProgress(Color.alpha(iD));
        kotlin.jvm.internal.r.c(seekBar2, "redBar");
        seekBar2.setProgress(Color.red(iD));
        kotlin.jvm.internal.r.c(seekBar3, "greenBar");
        seekBar3.setProgress(Color.green(iD));
        kotlin.jvm.internal.r.c(seekBar4, "blueBar");
        seekBar4.setProgress(Color.blue(iD));
        button.setBackgroundColor(iD);
        kotlin.jvm.internal.r.c(textView2, "colorPreviewText");
        textView2.setText(f(seekBar.getProgress(), seekBar2.getProgress(), seekBar3.getProgress(), seekBar4.getProgress()));
        c cVar = new c(seekBar, seekBar2, seekBar3, seekBar4, button);
        seekBar.setOnSeekBarChangeListener(cVar);
        seekBar2.setOnSeekBarChangeListener(cVar);
        seekBar3.setOnSeekBarChangeListener(cVar);
        seekBar4.setOnSeekBarChangeListener(cVar);
        com.omarea.common.ui.e.a aVar = com.omarea.common.ui.e.f492b;
        AlertDialog.Builder negativeButton = new AlertDialog.Builder(this.f599b).setTitle(this.f599b.getString(com.omarea.c.h.kr_color_picker)).setView(viewInflate).setPositiveButton(this.f599b.getString(com.omarea.c.h.btn_confirm), new a(seekBar, seekBar2, seekBar3, seekBar4, button, textView, imageView, view)).setNegativeButton(this.f599b.getString(com.omarea.c.h.btn_cancel), b.f);
        kotlin.jvm.internal.r.c(negativeButton, "AlertDialog.Builder(cont….btn_cancel)) { _, _ -> }");
        aVar.c(negativeButton);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final String f(int i, int i2, int i3, int i4) {
        w wVar = w.a;
        String str = String.format("#%02x%02x%02x%02x", Arrays.copyOf(new Object[]{Integer.valueOf(i), Integer.valueOf(i2), Integer.valueOf(i3), Integer.valueOf(i4)}, 4));
        kotlin.jvm.internal.r.c(str, "java.lang.String.format(format, *args)");
        return str;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final boolean h(TextView textView, ImageView imageView, View view, String str) {
        try {
            int color = Color.parseColor(str);
            imageView.setVisibility(8);
            view.setVisibility(0);
            view.setBackground(new ColorDrawable(color));
            return true;
        } catch (Exception unused) {
            imageView.setVisibility(0);
            view.setVisibility(8);
            return false;
        }
    }

    public final View g() {
        String value;
        View viewInflate = LayoutInflater.from(this.f599b).inflate(com.omarea.c.g.kr_param_color, (ViewGroup) null);
        EditText editText = (EditText) viewInflate.findViewById(com.omarea.c.f.kr_param_color_text);
        ImageView imageView = (ImageView) viewInflate.findViewById(com.omarea.c.f.kr_param_color_invalid);
        View viewFindViewById = viewInflate.findViewById(com.omarea.c.f.kr_param_color_preview);
        kotlin.jvm.internal.r.c(editText, "textView");
        editText.setTag(this.f598a.getName());
        editText.addTextChangedListener(new d(editText, imageView, viewFindViewById));
        if (this.f598a.getValueFromShell() == null) {
            if (this.f598a.getValue() != null) {
                value = this.f598a.getValue();
            }
            kotlin.jvm.internal.r.c(imageView, "invalidView");
            kotlin.jvm.internal.r.c(viewFindViewById, "preview");
            h(editText, imageView, viewFindViewById, editText.getText().toString());
            viewInflate.findViewById(com.omarea.c.f.kr_param_color_picker).setOnClickListener(new e(editText, imageView, viewFindViewById));
            kotlin.jvm.internal.r.c(viewInflate, "layout");
            return viewInflate;
        }
        value = this.f598a.getValueFromShell();
        kotlin.jvm.internal.r.b(value);
        editText.setText(value);
        kotlin.jvm.internal.r.c(imageView, "invalidView");
        kotlin.jvm.internal.r.c(viewFindViewById, "preview");
        h(editText, imageView, viewFindViewById, editText.getText().toString());
        viewInflate.findViewById(com.omarea.c.f.kr_param_color_picker).setOnClickListener(new e(editText, imageView, viewFindViewById));
        kotlin.jvm.internal.r.c(viewInflate, "layout");
        return viewInflate;
    }
}
