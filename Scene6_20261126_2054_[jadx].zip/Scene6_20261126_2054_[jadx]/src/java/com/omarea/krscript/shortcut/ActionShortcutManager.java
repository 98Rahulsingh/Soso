package com.omarea.krscript.shortcut;

import android.annotation.TargetApi;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ShortcutInfo;
import android.content.pm.ShortcutManager;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.util.Log;
import com.omarea.common.shared.e;
import com.omarea.krscript.model.NodeInfoBase;
import com.omarea.krscript.model.PageNode;
import java.io.Serializable;
import java.util.ArrayList;
import kotlin.jvm.internal.r;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class ActionShortcutManager {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private Context f564a;

    public ActionShortcutManager(Context context) {
        r.d(context, "context");
        this.f564a = context;
    }

    private final boolean b(Intent intent, Drawable drawable, NodeInfoBase nodeInfoBase) {
        try {
            Intent intent2 = new Intent("com.android.launcher.action.INSTALL_SHORTCUT");
            String str = "addin_" + nodeInfoBase.getIndex();
            intent2.putExtra("android.intent.extra.shortcut.NAME", nodeInfoBase.getTitle());
            intent2.putExtra("duplicate", false);
            if (drawable == null) {
                throw new NullPointerException("null cannot be cast to non-null type android.graphics.drawable.BitmapDrawable");
            }
            intent2.putExtra("android.intent.extra.shortcut.ICON", ((BitmapDrawable) drawable).getBitmap());
            Intent intent3 = new Intent("android.intent.action.MAIN");
            Context applicationContext = this.f564a.getApplicationContext();
            ComponentName component = intent.getComponent();
            r.b(component);
            intent3.setClassName(applicationContext, component.getClassName());
            intent3.putExtras(intent);
            intent2.putExtra("android.intent.extra.shortcut.INTENT", intent3);
            intent3.setFlags(1082130432);
            this.f564a.sendBroadcast(intent2);
            return true;
        } catch (Exception unused) {
            return false;
        }
    }

    private final String e(PageNode pageNode) throws Throwable {
        String strValueOf = String.valueOf(System.currentTimeMillis());
        new e(this.f564a).e(pageNode, strValueOf);
        return strValueOf;
    }

    public final boolean a(Intent intent, Drawable drawable, NodeInfoBase nodeInfoBase) {
        r.d(intent, "intent");
        r.d(drawable, "drawable");
        r.d(nodeInfoBase, "config");
        if (intent.hasExtra("page")) {
            Serializable serializableExtra = intent.getSerializableExtra("page");
            if (serializableExtra == null) {
                throw new NullPointerException("null cannot be cast to non-null type com.omarea.krscript.model.PageNode");
            }
            intent.putExtra("shortcutId", e((PageNode) serializableExtra));
            intent.removeExtra("page");
        }
        return Build.VERSION.SDK_INT >= 26 ? c(intent, drawable, nodeInfoBase) : b(intent, drawable, nodeInfoBase);
    }

    @TargetApi(26)
    public final boolean c(Intent intent, Drawable drawable, NodeInfoBase nodeInfoBase) {
        r.d(intent, "intent");
        r.d(drawable, "drawable");
        r.d(nodeInfoBase, "config");
        try {
            Object systemService = this.f564a.getSystemService("shortcut");
            if (systemService == null) {
                throw new NullPointerException("null cannot be cast to non-null type android.content.pm.ShortcutManager");
            }
            ShortcutManager shortcutManager = (ShortcutManager) systemService;
            if (!shortcutManager.isRequestPinShortcutSupported()) {
                return true;
            }
            String str = "addin_" + nodeInfoBase.getIndex();
            Intent intent2 = new Intent("android.intent.action.MAIN");
            Context applicationContext = this.f564a.getApplicationContext();
            ComponentName component = intent.getComponent();
            r.b(component);
            intent2.setClassName(applicationContext, component.getClassName());
            intent2.putExtras(intent);
            intent2.setFlags(1082130432);
            ShortcutInfo.Builder intent3 = new ShortcutInfo.Builder(this.f564a, str).setIcon(Icon.createWithBitmap(((BitmapDrawable) drawable).getBitmap())).setShortLabel(nodeInfoBase.getTitle()).setIntent(intent2);
            ComponentName component2 = intent.getComponent();
            r.b(component2);
            final ShortcutInfo shortcutInfoBuild = intent3.setActivity(component2).build();
            PendingIntent broadcast = PendingIntent.getBroadcast(this.f564a, 0, new Intent(), 134217728);
            if (!shortcutManager.isRequestPinShortcutSupported()) {
                return false;
            }
            for (ShortcutInfo shortcutInfo : shortcutManager.getPinnedShortcuts()) {
                r.c(shortcutInfo, "item");
                if (r.a(shortcutInfo.getId(), str)) {
                    shortcutManager.updateShortcuts(new ArrayList<ShortcutInfo>(shortcutInfoBuild) { // from class: com.omarea.krscript.shortcut.ActionShortcutManager$createShortcutOreo$1
                        final /* synthetic */ ShortcutInfo $info;

                        {
                            this.$info = shortcutInfoBuild;
                            add(shortcutInfoBuild);
                        }

                        public /* bridge */ boolean contains(ShortcutInfo shortcutInfo2) {
                            return super.contains((Object) shortcutInfo2);
                        }

                        @Override // java.util.ArrayList, java.util.AbstractCollection, java.util.Collection, java.util.List
                        public final /* bridge */ boolean contains(Object obj) {
                            if (obj instanceof ShortcutInfo) {
                                return contains((ShortcutInfo) obj);
                            }
                            return false;
                        }

                        public /* bridge */ int getSize() {
                            return super.size();
                        }

                        public /* bridge */ int indexOf(ShortcutInfo shortcutInfo2) {
                            return super.indexOf((Object) shortcutInfo2);
                        }

                        @Override // java.util.ArrayList, java.util.AbstractList, java.util.List
                        public final /* bridge */ int indexOf(Object obj) {
                            if (obj instanceof ShortcutInfo) {
                                return indexOf((ShortcutInfo) obj);
                            }
                            return -1;
                        }

                        public /* bridge */ int lastIndexOf(ShortcutInfo shortcutInfo2) {
                            return super.lastIndexOf((Object) shortcutInfo2);
                        }

                        @Override // java.util.ArrayList, java.util.AbstractList, java.util.List
                        public final /* bridge */ int lastIndexOf(Object obj) {
                            if (obj instanceof ShortcutInfo) {
                                return lastIndexOf((ShortcutInfo) obj);
                            }
                            return -1;
                        }

                        @Override // java.util.ArrayList, java.util.AbstractList, java.util.List
                        public final /* bridge */ ShortcutInfo remove(int i) {
                            return removeAt(i);
                        }

                        public /* bridge */ boolean remove(ShortcutInfo shortcutInfo2) {
                            return super.remove((Object) shortcutInfo2);
                        }

                        @Override // java.util.ArrayList, java.util.AbstractCollection, java.util.Collection, java.util.List
                        public final /* bridge */ boolean remove(Object obj) {
                            if (obj instanceof ShortcutInfo) {
                                return remove((ShortcutInfo) obj);
                            }
                            return false;
                        }

                        public /* bridge */ ShortcutInfo removeAt(int i) {
                            return (ShortcutInfo) super.remove(i);
                        }

                        @Override // java.util.ArrayList, java.util.AbstractCollection, java.util.Collection, java.util.List
                        public final /* bridge */ int size() {
                            return getSize();
                        }
                    });
                    return true;
                }
            }
            r.c(broadcast, "shortcutCallbackIntent");
            shortcutManager.requestPinShortcut(shortcutInfoBuild, broadcast.getIntentSender());
            return true;
        } catch (Exception e) {
            Log.e("ActionShortcutManager", "" + e.getMessage());
            return false;
        }
    }

    public final PageNode d(String str) {
        r.d(str, "shortcutId");
        return (PageNode) new e(this.f564a).c(str);
    }
}
