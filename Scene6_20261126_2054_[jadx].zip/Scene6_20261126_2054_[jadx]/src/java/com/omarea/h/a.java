package com.omarea.h;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public interface a extends IInterface {

    /* JADX INFO: renamed from: com.omarea.h.a$a, reason: collision with other inner class name */
    public static abstract class AbstractBinderC0057a extends Binder implements a {

        /* JADX INFO: renamed from: com.omarea.h.a$a$a, reason: collision with other inner class name */
        private static class C0058a implements a {

            /* JADX INFO: renamed from: b, reason: collision with root package name */
            public static a f562b;

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            private IBinder f563a;

            C0058a(IBinder iBinder) {
                this.f563a = iBinder;
            }

            @Override // android.os.IInterface
            public IBinder asBinder() {
                return this.f563a;
            }

            @Override // com.omarea.h.a
            public String j(String str, String str2) {
                Parcel parcelObtain = Parcel.obtain();
                Parcel parcelObtain2 = Parcel.obtain();
                try {
                    parcelObtain.writeInterfaceToken("com.omarea.vaddin.IAppConfigAidlInterface");
                    parcelObtain.writeString(str);
                    parcelObtain.writeString(str2);
                    if (!this.f563a.transact(9, parcelObtain, parcelObtain2, 0) && AbstractBinderC0057a.u() != null) {
                        return AbstractBinderC0057a.u().j(str, str2);
                    }
                    parcelObtain2.readException();
                    return parcelObtain2.readString();
                } finally {
                    parcelObtain2.recycle();
                    parcelObtain.recycle();
                }
            }

            @Override // com.omarea.h.a
            public boolean k(String str, String str2) {
                Parcel parcelObtain = Parcel.obtain();
                Parcel parcelObtain2 = Parcel.obtain();
                try {
                    parcelObtain.writeInterfaceToken("com.omarea.vaddin.IAppConfigAidlInterface");
                    parcelObtain.writeString(str);
                    parcelObtain.writeString(str2);
                    if (!this.f563a.transact(5, parcelObtain, parcelObtain2, 0) && AbstractBinderC0057a.u() != null) {
                        return AbstractBinderC0057a.u().k(str, str2);
                    }
                    parcelObtain2.readException();
                    return parcelObtain2.readInt() != 0;
                } finally {
                    parcelObtain2.recycle();
                    parcelObtain.recycle();
                }
            }

            @Override // com.omarea.h.a
            public boolean o(String str, boolean z) {
                Parcel parcelObtain = Parcel.obtain();
                Parcel parcelObtain2 = Parcel.obtain();
                try {
                    parcelObtain.writeInterfaceToken("com.omarea.vaddin.IAppConfigAidlInterface");
                    parcelObtain.writeString(str);
                    parcelObtain.writeInt(z ? 1 : 0);
                    if (!this.f563a.transact(7, parcelObtain, parcelObtain2, 0) && AbstractBinderC0057a.u() != null) {
                        return AbstractBinderC0057a.u().o(str, z);
                    }
                    parcelObtain2.readException();
                    return parcelObtain2.readInt() != 0;
                } finally {
                    parcelObtain2.recycle();
                    parcelObtain.recycle();
                }
            }

            @Override // com.omarea.h.a
            public boolean q(String str, boolean z) {
                Parcel parcelObtain = Parcel.obtain();
                Parcel parcelObtain2 = Parcel.obtain();
                try {
                    parcelObtain.writeInterfaceToken("com.omarea.vaddin.IAppConfigAidlInterface");
                    parcelObtain.writeString(str);
                    parcelObtain.writeInt(z ? 1 : 0);
                    if (!this.f563a.transact(4, parcelObtain, parcelObtain2, 0) && AbstractBinderC0057a.u() != null) {
                        return AbstractBinderC0057a.u().q(str, z);
                    }
                    parcelObtain2.readException();
                    return parcelObtain2.readInt() != 0;
                } finally {
                    parcelObtain2.recycle();
                    parcelObtain.recycle();
                }
            }
        }

        public static a t(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface iInterfaceQueryLocalInterface = iBinder.queryLocalInterface("com.omarea.vaddin.IAppConfigAidlInterface");
            return (iInterfaceQueryLocalInterface == null || !(iInterfaceQueryLocalInterface instanceof a)) ? new C0058a(iBinder) : (a) iInterfaceQueryLocalInterface;
        }

        public static a u() {
            return C0058a.f562b;
        }
    }

    String j(String str, String str2);

    boolean k(String str, String str2);

    boolean o(String str, boolean z);

    boolean q(String str, boolean z);
}
