package com.omarea.d.a;

import java.util.Calendar;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final int f513a;

    public b(int i) {
        this.f513a = i;
    }

    public final int a() {
        Calendar calendar = Calendar.getInstance();
        return (calendar.get(11) * 60) + calendar.get(12);
    }

    public final int b() {
        int iA = a();
        int i = this.f513a;
        return iA > i ? (1440 - iA) + i : i - iA;
    }

    public final long c() {
        return System.currentTimeMillis() + ((long) (b() * 60 * 1000));
    }
}
