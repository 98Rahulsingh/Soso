package com.omarea.d.a;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private int f512a;

    public a(int i) {
        this.f512a = i;
    }

    public final int a(int i) {
        int i2 = i | this.f512a;
        this.f512a = i2;
        return i2;
    }

    public final int b(int i) {
        int i2 = (~i) & this.f512a;
        this.f512a = i2;
        return i2;
    }
}
