package com.omarea.d.b;

import android.annotation.SuppressLint;
import android.opengl.GLSurfaceView;
import android.view.ViewGroup;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public String f514a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public String f515b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public String f516c;

    static class a implements GLSurfaceView.Renderer {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final InterfaceC0053b f517a;

        /* JADX INFO: renamed from: com.omarea.d.b.b$a$a, reason: collision with other inner class name */
        class C0052a extends b {

            /* JADX INFO: renamed from: d, reason: collision with root package name */
            final /* synthetic */ GL10 f518d;

            C0052a(a aVar, GL10 gl10) {
                this.f518d = gl10;
                this.f516c = this.f518d.glGetString(7937);
                this.f515b = this.f518d.glGetString(7936);
                this.f514a = this.f518d.glGetString(7938);
                this.f518d.glGetString(7939);
            }
        }

        public a(InterfaceC0053b interfaceC0053b) {
            this.f517a = interfaceC0053b;
        }

        @Override // android.opengl.GLSurfaceView.Renderer
        public void onDrawFrame(GL10 gl10) {
        }

        @Override // android.opengl.GLSurfaceView.Renderer
        public void onSurfaceChanged(GL10 gl10, int i, int i2) {
        }

        @Override // android.opengl.GLSurfaceView.Renderer
        public void onSurfaceCreated(GL10 gl10, EGLConfig eGLConfig) {
            this.f517a.a(new C0052a(this, gl10));
        }
    }

    /* JADX INFO: renamed from: com.omarea.d.b.b$b, reason: collision with other inner class name */
    public interface InterfaceC0053b {
        void a(b bVar);
    }

    @SuppressLint({"ViewConstructor"})
    static class c extends GLSurfaceView {

        class a implements InterfaceC0053b {

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            final /* synthetic */ ViewGroup f519a;

            /* JADX INFO: renamed from: b, reason: collision with root package name */
            final /* synthetic */ c f520b;

            /* JADX INFO: renamed from: c, reason: collision with root package name */
            final /* synthetic */ InterfaceC0053b f521c;

            /* JADX INFO: renamed from: com.omarea.d.b.b$c$a$a, reason: collision with other inner class name */
            class RunnableC0054a implements Runnable {
                final /* synthetic */ b f;

                RunnableC0054a(b bVar) {
                    this.f = bVar;
                }

                @Override // java.lang.Runnable
                public void run() {
                    a aVar = a.this;
                    aVar.f519a.removeView(aVar.f520b);
                    a.this.f521c.a(this.f);
                }
            }

            a(c cVar, ViewGroup viewGroup, c cVar2, InterfaceC0053b interfaceC0053b) {
                this.f519a = viewGroup;
                this.f520b = cVar2;
                this.f521c = interfaceC0053b;
            }

            @Override // com.omarea.d.b.b.InterfaceC0053b
            public void a(b bVar) {
                this.f519a.getRootView().post(new RunnableC0054a(bVar));
            }
        }

        public c(ViewGroup viewGroup, InterfaceC0053b interfaceC0053b) {
            super(viewGroup.getContext());
            setEGLContextClientVersion(2);
            setEGLConfigChooser(8, 8, 8, 8, 0, 0);
            setRenderer(new a(new a(this, viewGroup, this, interfaceC0053b)));
            viewGroup.addView(this);
        }
    }

    public static void a(ViewGroup viewGroup, InterfaceC0053b interfaceC0053b) {
        if (viewGroup == null || interfaceC0053b == null) {
            return;
        }
        c cVar = new c(viewGroup, interfaceC0053b);
        viewGroup.removeAllViews();
        viewGroup.addView(cVar);
    }
}
