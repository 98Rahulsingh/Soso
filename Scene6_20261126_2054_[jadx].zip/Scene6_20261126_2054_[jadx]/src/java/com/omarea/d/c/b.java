package com.omarea.d.c;

import android.content.Context;
import android.content.Intent;
import androidx.core.app.k;
import java.util.Set;
import kotlin.jvm.internal.r;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class b {
    public final boolean a(Context context) {
        r.d(context, "context");
        Set setA = k.a(context);
        r.c(setA, "NotificationManagerCompa…ListenerPackages(context)");
        return setA.contains(context.getPackageName());
    }

    public final void b(Context context) {
        r.d(context, "context");
        try {
            context.startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"));
        } catch (Exception unused) {
        }
    }
}
