package com.omarea.d.c;

import android.content.Context;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;
import c.f.d.c;
import com.omarea.common.shell.e;
import com.omarea.library.appops.PermissionsHelper;
import java.util.ArrayList;
import kotlin.collections.q;
import kotlin.jvm.internal.r;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final Context f522a;

    public a(Context context) {
        r.d(context, "context");
        this.f522a = context;
    }

    private final boolean a(String str) {
        return c.b(this.f522a, str) == 0;
    }

    public final void b() {
        String string;
        StringBuilder sb;
        String str;
        StringBuilder sb2 = new StringBuilder();
        ArrayList<String> arrayListC = q.c(new String[]{"android.permission.READ_EXTERNAL_STORAGE", "android.permission.WRITE_EXTERNAL_STORAGE", "android.permission.CHANGE_CONFIGURATION", "android.permission.WRITE_SECURE_SETTINGS", "android.permission.SYSTEM_ALERT_WINDOW"});
        if (new com.omarea.vtools.c(this.f522a).b()) {
            PermissionsHelper permissionsHelper = new PermissionsHelper(this.f522a);
            String packageName = this.f522a.getPackageName();
            r.c(packageName, "context.packageName");
            String[] strArrD = permissionsHelper.d(packageName);
            if (strArrD != null) {
                ArrayList arrayList = new ArrayList();
                for (String str2 : strArrD) {
                    if (r.a(str2, "android.permission.MANAGE_EXTERNAL_STORAGE")) {
                        arrayList.add(str2);
                    }
                }
                str = (String) q.u(arrayList);
            } else {
                str = null;
            }
            if (str != null) {
                arrayListC.add("android.permission.MANAGE_EXTERNAL_STORAGE");
            }
        }
        for (String str3 : arrayListC) {
            if (r.a(str3, "android.permission.MANAGE_EXTERNAL_STORAGE")) {
                if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) {
                    string = "appops set --uid " + this.f522a.getPackageName() + " MANAGE_EXTERNAL_STORAGE allow\n";
                    sb2.append(string);
                }
            } else if (r.a(str3, "android.permission.SYSTEM_ALERT_WINDOW")) {
                if (Build.VERSION.SDK_INT >= 23) {
                    if (Settings.canDrawOverlays(this.f522a)) {
                        continue;
                    } else {
                        if (str3 == null) {
                            throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                        }
                        String strSubstring = str3.substring(19);
                        r.c(strSubstring, "(this as java.lang.String).substring(startIndex)");
                        sb = new StringBuilder();
                        sb.append("appops set ");
                        sb.append(this.f522a.getPackageName());
                        sb.append(' ');
                        sb.append(strSubstring);
                        sb.append(" allow\n");
                        string = sb.toString();
                        sb2.append(string);
                    }
                } else if (a(str3)) {
                    continue;
                } else {
                    if (Build.VERSION.SDK_INT >= 23) {
                        if (str3 == null) {
                            throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                        }
                        String strSubstring2 = str3.substring(19);
                        r.c(strSubstring2, "(this as java.lang.String).substring(startIndex)");
                        sb2.append("appops set " + this.f522a.getPackageName() + ' ' + strSubstring2 + " allow\n");
                    }
                    sb = new StringBuilder();
                    sb.append("pm grant ");
                    sb.append(this.f522a.getPackageName());
                    sb.append(' ');
                    sb.append(str3);
                    sb.append('\n');
                    string = sb.toString();
                    sb2.append(string);
                }
            } else if (a(str3)) {
                continue;
            } else {
                if (Build.VERSION.SDK_INT >= 23) {
                    if (str3 == null) {
                        throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                    }
                    String strSubstring3 = str3.substring(19);
                    r.c(strSubstring3, "(this as java.lang.String).substring(startIndex)");
                    sb2.append("appops set " + this.f522a.getPackageName() + ' ' + strSubstring3 + " allow\n");
                }
                sb = new StringBuilder();
                sb.append("pm grant ");
                sb.append(this.f522a.getPackageName());
                sb.append(' ');
                sb.append(str3);
                sb.append('\n');
                string = sb.toString();
                sb2.append(string);
            }
        }
        if (Build.VERSION.SDK_INT >= 23 && !a("android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS")) {
            sb2.append("dumpsys deviceidle whitelist +" + this.f522a.getPackageName() + ";\n");
        }
        e eVar = e.f469b;
        String string2 = sb2.toString();
        r.c(string2, "shellStr.toString()");
        eVar.b(string2);
    }
}
