package com.omarea.library.appops;

import android.app.AppOpsManager;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import com.omarea.c.b;
import com.omarea.common.shared.f;
import com.omarea.common.shell.e;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import kotlin.collections.q;
import kotlin.jvm.internal.r;
import kotlin.text.Regex;
import kotlin.text.k;
import org.json.JSONArray;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class PermissionsHelper {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final JSONObject f633a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final PackageManager f634b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final Context f635c;

    public enum Mode {
        NONE,
        ALLOW,
        IGNORE,
        FOREGROUND,
        DENY
    }

    public static final class a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public String f636a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public String f637b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public Mode f638c;

        public final String a() {
            String str = this.f637b;
            if (str != null) {
                return str;
            }
            r.q("fullName");
            throw null;
        }

        public final Mode b() {
            Mode mode = this.f638c;
            if (mode != null) {
                return mode;
            }
            r.q("mode");
            throw null;
        }

        public final String c() {
            String str = this.f636a;
            if (str != null) {
                return str;
            }
            r.q("name");
            throw null;
        }

        public final void d(String str) {
            r.d(str, "<set-?>");
            this.f637b = str;
        }

        public final void e(Mode mode) {
            r.d(mode, "<set-?>");
            this.f638c = mode;
        }

        public final void f(String str) {
            r.d(str, "<set-?>");
            this.f636a = str;
        }
    }

    public PermissionsHelper(Context context) {
        r.d(context, "context");
        this.f635c = context;
        this.f633a = new JSONObject(f.f453a.b(this.f635c, 2131820564));
        this.f634b = this.f635c.getPackageManager();
    }

    private final String a(String str) {
        int iB = new b(this.f635c).b();
        return e.f469b.e("appops get --user " + iB + ' ' + str);
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code duplicated, block: B:55:0x016d  */
    private final List<a> b(String str) {
        Mode mode;
        Regex regex = new Regex(".*:.*:.*");
        Regex regex2 = new Regex(".*:.*");
        List listW = k.W(k.r(a(str), "Uid mode:", "", false, 4, (Object) null), new String[]{"\n"}, false, 0, 6, (Object) null);
        ArrayList<String> arrayList = new ArrayList();
        Iterator it = listW.iterator();
        while (true) {
            boolean z = false;
            if (!it.hasNext()) {
                break;
            }
            Object next = it.next();
            String str2 = (String) next;
            if (regex2.matches(str2) && !regex.matches(str2)) {
                z = true;
            }
            if (z) {
                arrayList.add(next);
            }
        }
        ArrayList arrayList2 = new ArrayList(q.k(arrayList, 10));
        for (String strSubstring : arrayList) {
            if (k.x(strSubstring, ';', false, 2, (Object) null)) {
                int iG = k.G(strSubstring, ';', 0, false, 6, (Object) null);
                if (strSubstring == null) {
                    throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                }
                strSubstring = strSubstring.substring(0, iG);
                r.c(strSubstring, "(this as java.lang.Strin…ing(startIndex, endIndex)");
            }
            arrayList2.add(strSubstring);
        }
        ArrayList<List> arrayList3 = new ArrayList(q.k(arrayList2, 10));
        Iterator it2 = arrayList2.iterator();
        while (it2.hasNext()) {
            List<String> listW2 = k.W((String) it2.next(), new String[]{":"}, false, 0, 6, (Object) null);
            ArrayList arrayList4 = new ArrayList(q.k(listW2, 10));
            for (String str3 : listW2) {
                if (str3 == null) {
                    throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
                }
                arrayList4.add(k.k0(str3).toString());
            }
            arrayList3.add(arrayList4);
        }
        ArrayList arrayList5 = new ArrayList(q.k(arrayList3, 10));
        for (List list : arrayList3) {
            a aVar = new a();
            aVar.f((String) q.t(list));
            String str4 = (String) q.B(list);
            Locale locale = Locale.getDefault();
            r.c(locale, "Locale.getDefault()");
            if (str4 == null) {
                throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
            }
            String lowerCase = str4.toLowerCase(locale);
            r.c(lowerCase, "(this as java.lang.String).toLowerCase(locale)");
            switch (lowerCase) {
                case "ignore":
                    mode = Mode.IGNORE;
                    break;
                case "deny":
                    mode = Mode.DENY;
                    break;
                case "allow":
                    mode = Mode.ALLOW;
                    break;
                case "foreground":
                    mode = Mode.FOREGROUND;
                    break;
                default:
                    mode = Mode.NONE;
                    break;
            }
            aVar.e(mode);
            arrayList5.add(aVar);
        }
        return arrayList5;
    }

    private final PackageInfo c(String str) {
        try {
            return this.f634b.getPackageInfo(str, 4096);
        } catch (Exception unused) {
            return null;
        }
    }

    private final String f(String str) {
        String strR = k.r(str, "android:", "", false, 4, (Object) null);
        Locale locale = Locale.ENGLISH;
        r.c(locale, "Locale.ENGLISH");
        if (strR == null) {
            throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
        }
        String upperCase = strR.toUpperCase(locale);
        r.c(upperCase, "(this as java.lang.String).toUpperCase(locale)");
        return upperCase;
    }

    public final String[] d(String str) {
        r.d(str, "packageName");
        PackageInfo packageInfoC = c(str);
        if (packageInfoC == null) {
            return null;
        }
        String[] strArr = packageInfoC.requestedPermissions;
        r.c(strArr, "packageInfo.requestedPermissions");
        ArrayList arrayList = new ArrayList();
        for (String str2 : strArr) {
            r.c(str2, "it");
            if (k.t(str2, "android.permission", false, 2, (Object) null)) {
                arrayList.add(str2);
            }
        }
        Object[] array = arrayList.toArray(new String[0]);
        if (array != null) {
            return (String[]) array;
        }
        throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T>");
    }

    /* JADX WARN: Code duplicated, block: B:25:0x006a  */
    public final List<a> e(String str) {
        List<a> arrayList;
        String strSubstring;
        Object next;
        Mode modeB;
        a aVar;
        r.d(str, "packageName");
        String[] strArrD = d(str);
        JSONArray jSONArray = new JSONArray(f.f453a.b(this.f635c, 2131820563));
        ArrayList arrayList2 = new ArrayList();
        int length = jSONArray.length();
        for (int i = 0; i < length; i++) {
            arrayList2.add(jSONArray.getString(i));
        }
        if (strArrD != null) {
            ArrayList arrayList3 = new ArrayList();
            for (String str2 : strArrD) {
                String strPermissionToOp = AppOpsManager.permissionToOp(str2);
                if (strPermissionToOp == null) {
                    strPermissionToOp = this.f633a.has(str2) ? this.f633a.getString(str2) : null;
                }
                if (strPermissionToOp != null) {
                    arrayList3.add(str2);
                }
            }
            arrayList = q.W(arrayList3);
            if (arrayList == null) {
                arrayList = new ArrayList<>();
            }
        } else {
            arrayList = new ArrayList<>();
        }
        arrayList.addAll(arrayList2);
        if (arrayList == null) {
            return arrayList;
        }
        List<a> listB = b(str);
        ArrayList arrayList4 = new ArrayList(q.k(arrayList, 10));
        Iterator<T> it = arrayList.iterator();
        while (it.hasNext()) {
            String str3 = (String) it.next();
            a aVar2 = new a();
            if (k.y(str3, ".", false, 2, (Object) null)) {
                int iM = k.M(str3, '.', 0, false, 6, (Object) null) + 1;
                if (str3 == null) {
                    throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                }
                strSubstring = str3.substring(iM);
                r.c(strSubstring, "(this as java.lang.String).substring(startIndex)");
            } else {
                strSubstring = str3;
            }
            String strPermissionToOp2 = AppOpsManager.permissionToOp(str3);
            if (strPermissionToOp2 == null) {
                strPermissionToOp2 = this.f633a.has(str3) ? this.f633a.getString(str3) : null;
            }
            String strF = f(strPermissionToOp2 != null ? strPermissionToOp2 : str3);
            aVar2.d(str3);
            aVar2.f(strSubstring);
            Iterator<T> it2 = listB.iterator();
            do {
                if (!it2.hasNext()) {
                    next = null;
                    break;
                }
                next = it2.next();
                aVar = (a) next;
            } while (!(r.a(aVar.c(), strPermissionToOp2) || r.a(aVar.c(), strF)));
            a aVar3 = (a) next;
            if (aVar3 == null || (modeB = aVar3.b()) == null) {
                modeB = arrayList2.contains(aVar2.c()) ? Mode.ALLOW : Mode.NONE;
            }
            aVar2.e(modeB);
            arrayList4.add(aVar2);
        }
        return arrayList4;
    }

    public final void g(String str, String str2, Mode mode) {
        e eVar;
        StringBuilder sb;
        String str3;
        r.d(str, "packageName");
        r.d(str2, "permission");
        r.d(mode, "mode");
        String strPermissionToOp = AppOpsManager.permissionToOp(str2);
        if (strPermissionToOp == null) {
            strPermissionToOp = this.f633a.has(str2) ? this.f633a.getString(str2) : null;
        }
        if (strPermissionToOp != null) {
            String string = mode.toString();
            Locale locale = Locale.getDefault();
            r.c(locale, "Locale.getDefault()");
            if (string == null) {
                throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
            }
            String lowerCase = string.toLowerCase(locale);
            r.c(lowerCase, "(this as java.lang.String).toLowerCase(locale)");
            String strF = f(strPermissionToOp);
            int iB = new b(this.f635c).b();
            if (mode == Mode.ALLOW || mode == Mode.FOREGROUND) {
                eVar = e.f469b;
                sb = new StringBuilder();
                str3 = "pm grant --user ";
            } else {
                eVar = e.f469b;
                sb = new StringBuilder();
                str3 = "pm revoke --user ";
            }
            sb.append(str3);
            sb.append(iB);
            sb.append(' ');
            sb.append(str);
            sb.append(' ');
            sb.append(str2);
            sb.append("\nappops set --user ");
            sb.append(iB);
            sb.append(' ');
            sb.append(str);
            sb.append(' ');
            sb.append(strF);
            sb.append(' ');
            sb.append(lowerCase);
            eVar.e(sb.toString());
        }
    }
}
