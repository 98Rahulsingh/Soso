package com.omarea.library.basic;

import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.graphics.drawable.Drawable;
import android.util.LruCache;
import com.omarea.model.AppInfo;
import java.io.File;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlinx.coroutines.h0;
import kotlinx.coroutines.o0;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
@kotlin.coroutines.jvm.internal.d(c = "com.omarea.library.basic.AppInfoLoader$loadIcon$1", f = "AppInfoLoader.kt", l = {38}, m = "invokeSuspend")
final class AppInfoLoader$loadIcon$1 extends SuspendLambda implements kotlin.jvm.b.p<h0, kotlin.coroutines.c<? super Drawable>, Object> {
    final /* synthetic */ AppInfo $item;
    Object L$0;
    Object L$1;
    int label;
    private h0 p$;
    final /* synthetic */ AppInfoLoader this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    AppInfoLoader$loadIcon$1(AppInfoLoader appInfoLoader, AppInfo appInfo, kotlin.coroutines.c cVar) {
        super(2, cVar);
        this.this$0 = appInfoLoader;
        this.$item = appInfo;
    }

    public final kotlin.coroutines.c<kotlin.s> create(Object obj, kotlin.coroutines.c<?> cVar) {
        kotlin.jvm.internal.r.d(cVar, "completion");
        AppInfoLoader$loadIcon$1 appInfoLoader$loadIcon$1 = new AppInfoLoader$loadIcon$1(this.this$0, this.$item, cVar);
        appInfoLoader$loadIcon$1.p$ = (h0) obj;
        return appInfoLoader$loadIcon$1;
    }

    public final Object invoke(Object obj, Object obj2) {
        return create(obj, (kotlin.coroutines.c) obj2).invokeSuspend(kotlin.s.a);
    }

    public final Object invokeSuspend(Object obj) {
        ApplicationInfo applicationInfo;
        Object objD = kotlin.coroutines.intrinsics.a.d();
        int i = this.label;
        Drawable drawableLoadIcon = null;
        if (i == 0) {
            kotlin.h.b(obj);
            h0 h0Var = this.p$;
            LruCache lruCache = this.this$0.f642a;
            Drawable drawable = lruCache != null ? (Drawable) lruCache.get(this.$item.getPackageName()) : null;
            if (drawable != null) {
                return drawable;
            }
            o0<Drawable> o0VarF = this.this$0.f(this.$item.getPackageName());
            this.L$0 = h0Var;
            this.L$1 = drawable;
            this.label = 1;
            obj = o0VarF.u(this);
            if (obj == objD) {
                return objD;
            }
        } else {
            if (i != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            kotlin.h.b(obj);
        }
        Drawable drawable2 = (Drawable) obj;
        if (drawable2 != null) {
            return drawable2;
        }
        CharSequence charSequence = this.$item.path;
        if (charSequence == null || charSequence.length() == 0) {
            return drawable2;
        }
        try {
            File file = new File(this.$item.path.toString());
            if (!file.exists() || !file.canRead()) {
                return drawable2;
            }
            PackageInfo packageArchiveInfo = this.this$0.c().getPackageArchiveInfo(file.getAbsolutePath(), 1);
            if (packageArchiveInfo != null && (applicationInfo = packageArchiveInfo.applicationInfo) != null) {
                drawableLoadIcon = applicationInfo.loadIcon(this.this$0.c());
            }
            try {
                this.this$0.g(this.$item.getPackageName(), drawableLoadIcon);
            } catch (Exception unused) {
            }
            return drawableLoadIcon;
        } catch (Exception unused2) {
            return drawable2;
        }
    }
}
