package com.omarea.library.basic;

import java.text.SimpleDateFormat;
import java.util.Date;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class s {
    public boolean a(long j) {
        return b(new Date(j));
    }

    public boolean b(Date date) {
        Date date2 = new Date();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        return simpleDateFormat.format(date).equals(simpleDateFormat.format(date2));
    }
}
