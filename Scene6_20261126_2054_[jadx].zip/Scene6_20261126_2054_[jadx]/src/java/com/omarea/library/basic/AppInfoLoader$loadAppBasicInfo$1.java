package com.omarea.library.basic;

import android.content.pm.PackageInfo;
import android.graphics.drawable.Drawable;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlinx.coroutines.h0;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
@kotlin.coroutines.jvm.internal.d(c = "com.omarea.library.basic.AppInfoLoader$loadAppBasicInfo$1", f = "AppInfoLoader.kt", l = {}, m = "invokeSuspend")
final class AppInfoLoader$loadAppBasicInfo$1 extends SuspendLambda implements kotlin.jvm.b.p<h0, kotlin.coroutines.c<? super AppInfoLoader.a>, Object> {
    final /* synthetic */ String $packageName;
    int label;
    private h0 p$;
    final /* synthetic */ AppInfoLoader this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    AppInfoLoader$loadAppBasicInfo$1(AppInfoLoader appInfoLoader, String str, kotlin.coroutines.c cVar) {
        super(2, cVar);
        this.this$0 = appInfoLoader;
        this.$packageName = str;
    }

    public final kotlin.coroutines.c<kotlin.s> create(Object obj, kotlin.coroutines.c<?> cVar) {
        kotlin.jvm.internal.r.d(cVar, "completion");
        AppInfoLoader$loadAppBasicInfo$1 appInfoLoader$loadAppBasicInfo$1 = new AppInfoLoader$loadAppBasicInfo$1(this.this$0, this.$packageName, cVar);
        appInfoLoader$loadAppBasicInfo$1.p$ = (h0) obj;
        return appInfoLoader$loadAppBasicInfo$1;
    }

    public final Object invoke(Object obj, Object obj2) {
        return create(obj, (kotlin.coroutines.c) obj2).invokeSuspend(kotlin.s.a);
    }

    public final Object invokeSuspend(Object obj) {
        kotlin.coroutines.intrinsics.a.d();
        if (this.label != 0) {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        kotlin.h.b(obj);
        Drawable drawableLoadIcon = null;
        String str = this.$packageName;
        try {
            PackageInfo packageInfo = this.this$0.c().getPackageInfo(this.$packageName, 0);
            str = "" + packageInfo.applicationInfo.loadLabel(this.this$0.c());
            drawableLoadIcon = packageInfo.applicationInfo.loadIcon(this.this$0.c());
        } catch (Exception unused) {
        }
        return new AppInfoLoader.a(str, drawableLoadIcon);
    }
}
