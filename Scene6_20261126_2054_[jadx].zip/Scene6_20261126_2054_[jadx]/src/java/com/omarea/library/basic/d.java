package com.omarea.library.basic;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Build;
import com.omarea.model.AppInfo;
import java.io.File;
import java.io.FileFilter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private PackageManager f670a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final Context f671b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final boolean f672c;

    static final class a implements FileFilter {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public static final a f673a = new a();

        a() {
        }

        @Override // java.io.FileFilter
        public final boolean accept(File file) {
            kotlin.jvm.internal.r.c(file, "name");
            String strE = kotlin.io.e.e(file);
            if (strE == null) {
                throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
            }
            String lowerCase = strE.toLowerCase();
            kotlin.jvm.internal.r.c(lowerCase, "(this as java.lang.String).toLowerCase()");
            return kotlin.jvm.internal.r.a(lowerCase, "apk");
        }
    }

    public d(Context context, boolean z) {
        kotlin.jvm.internal.r.d(context, "context");
        this.f671b = context;
        this.f672c = z;
        PackageManager packageManager = context.getPackageManager();
        kotlin.jvm.internal.r.c(packageManager, "context.packageManager");
        this.f670a = packageManager;
    }

    public /* synthetic */ d(Context context, boolean z, int i, kotlin.jvm.internal.o oVar) {
        this(context, (i & 2) != 0 ? true : z);
    }

    private final boolean b(String str) {
        return kotlin.text.k.y(str, ".overlay", false, 2, (Object) null) || kotlin.text.k.y(str, "com.android.theme.color", false, 2, (Object) null) || kotlin.text.k.y(str, "com.android.theme.icon", false, 2, (Object) null);
    }

    public static /* synthetic */ ArrayList f(d dVar, Boolean bool, boolean z, int i, Object obj) {
        if ((i & 1) != 0) {
            bool = null;
        }
        if ((i & 2) != 0) {
            z = true;
        }
        return dVar.e(bool, z);
    }

    /* JADX WARN: Code restructure failed: missing block: B:7:0x0012, code lost:
    
        if (b(r12) != false) goto L56;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private final com.omarea.model.AppInfo g(android.content.pm.ApplicationInfo r10, java.lang.Boolean r11, boolean r12) {
        /*
            Method dump skipped, instruction units count: 247
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.omarea.library.basic.d.g(android.content.pm.ApplicationInfo, java.lang.Boolean, boolean):com.omarea.model.AppInfo");
    }

    public final String a(PackageInfo packageInfo) {
        kotlin.jvm.internal.r.d(packageInfo, "backupInfo");
        try {
            PackageInfo packageInfo2 = this.f670a.getPackageInfo(packageInfo.packageName, 0);
            if (packageInfo2 == null) {
                return "";
            }
            if (packageInfo.versionCode == packageInfo2.versionCode) {
                return this.f671b.getString(2131886449) + " ";
            }
            if (packageInfo.versionCode > packageInfo2.versionCode) {
                return this.f671b.getString(2131886451) + " ";
            }
            return this.f671b.getString(2131886450) + " ";
        } catch (PackageManager.NameNotFoundException unused) {
            return "";
        }
    }

    public final ArrayList<AppInfo> c() {
        return e(null, false);
    }

    public final AppInfo d(String str) {
        kotlin.jvm.internal.r.d(str, "packageName");
        try {
            ApplicationInfo applicationInfo = this.f670a.getApplicationInfo(str, 8192);
            kotlin.jvm.internal.r.c(applicationInfo, "packageManager.getApplic…TCH_UNINSTALLED_PACKAGES)");
            return g(applicationInfo, null, false);
        } catch (Exception unused) {
            return null;
        }
    }

    public final ArrayList<AppInfo> e(Boolean bool, boolean z) {
        List<ApplicationInfo> installedApplications = this.f670a.getInstalledApplications(0);
        kotlin.jvm.internal.r.c(installedApplications, "packageManager.getInstalledApplications(0)");
        ArrayList<AppInfo> arrayList = new ArrayList<>();
        int size = installedApplications.size();
        for (int i = 0; i < size; i++) {
            ApplicationInfo applicationInfo = installedApplications.get(i);
            kotlin.jvm.internal.r.c(applicationInfo, "applicationInfo");
            AppInfo appInfoG = g(applicationInfo, bool, z);
            if (appInfoG != null) {
                arrayList.add(appInfoG);
            }
        }
        return arrayList;
    }

    /* JADX WARN: Code duplicated, block: B:12:0x004a  */
    /* JADX WARN: Code duplicated, block: B:18:0x0063  */
    /* JADX WARN: Code duplicated, block: B:20:0x006d  */
    /* JADX WARN: Code duplicated, block: B:22:0x0076  */
    /* JADX WARN: Code duplicated, block: B:24:0x007e  */
    /* JADX WARN: Code duplicated, block: B:27:0x0089  */
    /* JADX WARN: Code duplicated, block: B:30:0x0098  */
    /* JADX WARN: Code duplicated, block: B:32:0x00d3  */
    /* JADX WARN: Code duplicated, block: B:34:0x00da  */
    /* JADX WARN: Code duplicated, block: B:35:0x00dc  */
    /* JADX WARN: Code duplicated, block: B:39:0x00f6  */
    /* JADX WARN: Code duplicated, block: B:41:0x0108  */
    /* JADX WARN: Code duplicated, block: B:42:0x010a  */
    /* JADX WARN: Code duplicated, block: B:45:0x0116  */
    /* JADX WARN: Code duplicated, block: B:46:0x0119  */
    /* JADX WARN: Code duplicated, block: B:57:0x0130 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:59:0x0130 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:60:0x0130 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:61:0x0130 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:62:0x005e A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:9:0x0040  */
    /* JADX WARN: Instruction removed from duplicated block: B:30:0x0098, please report this as an issue */
    public final ArrayList<AppInfo> h(Boolean bool, boolean z) {
        Iterator<T> it;
        Object next;
        File file;
        AppInfo item;
        boolean z2;
        AppInfo.AppType appType;
        String parent;
        boolean z3;
        Intent intent = new Intent("android.intent.action.MAIN", (Uri) null);
        intent.addCategory("android.intent.category.LAUNCHER");
        List<ResolveInfo> listQueryIntentActivities = this.f670a.queryIntentActivities(intent, 0);
        kotlin.jvm.internal.r.c(listQueryIntentActivities, "packageManager.queryInte…Activities(mainIntent, 0)");
        ArrayList<AppInfo> arrayList = new ArrayList<>();
        int size = listQueryIntentActivities.size();
        for (int i = 0; i < size; i++) {
            ApplicationInfo applicationInfo = listQueryIntentActivities.get(i).activityInfo.applicationInfo;
            if (z) {
                String str = applicationInfo.packageName;
                kotlin.jvm.internal.r.c(str, "applicationInfo.packageName");
                if (!b(str)) {
                    it = arrayList.iterator();
                    do {
                        if (it.hasNext()) {
                            next = null;
                            break;
                        }
                        next = it.next();
                    } while (!kotlin.jvm.internal.r.a(((AppInfo) next).getPackageName(), applicationInfo.packageName));
                    if (next == null) {
                        if (kotlin.jvm.internal.r.a(bool, Boolean.FALSE)) {
                            kotlin.jvm.internal.r.c(applicationInfo, "applicationInfo");
                            if (!m(applicationInfo)) {
                                if (kotlin.jvm.internal.r.a(bool, Boolean.TRUE)) {
                                    kotlin.jvm.internal.r.c(applicationInfo, "applicationInfo");
                                    if (!m(applicationInfo)) {
                                        file = new File(applicationInfo.publicSourceDir);
                                        if (!file.exists()) {
                                            item = AppInfo.getItem();
                                            item.setAppName("" + applicationInfo.loadLabel(this.f670a));
                                            String str2 = applicationInfo.packageName;
                                            kotlin.jvm.internal.r.c(str2, "applicationInfo.packageName");
                                            item.setPackageName(str2);
                                            item.dir = file.getParent();
                                            item.enabled = Boolean.valueOf(applicationInfo.enabled);
                                            if (Build.VERSION.SDK_INT >= 24) {
                                                if ((applicationInfo.flags & 1073741824) != 0) {
                                                    z3 = true;
                                                } else {
                                                    z3 = false;
                                                }
                                                item.suspended = Boolean.valueOf(z3);
                                            }
                                            kotlin.jvm.internal.r.c(applicationInfo, "applicationInfo");
                                            item.stateTags = k(applicationInfo);
                                            item.path = applicationInfo.sourceDir;
                                            if (m(applicationInfo)) {
                                                parent = file.getParent();
                                                kotlin.jvm.internal.r.c(parent, "file.parent");
                                                if (kotlin.text.k.t(parent, "/data", false, 2, (Object) null)) {
                                                    z2 = true;
                                                } else {
                                                    z2 = false;
                                                }
                                            } else {
                                                z2 = false;
                                            }
                                            item.updated = Boolean.valueOf(z2);
                                            if ((applicationInfo.flags & 1) == 0) {
                                                appType = AppInfo.AppType.USER;
                                            } else {
                                                appType = AppInfo.AppType.SYSTEM;
                                            }
                                            item.appType = appType;
                                            try {
                                                PackageInfo packageInfo = this.f670a.getPackageInfo(applicationInfo.packageName, 0);
                                                item.versionName = packageInfo.versionName;
                                                item.versionCode = packageInfo.versionCode;
                                            } catch (Exception unused) {
                                            }
                                            arrayList.add(item);
                                        }
                                    }
                                } else {
                                    file = new File(applicationInfo.publicSourceDir);
                                    if (!file.exists()) {
                                        item = AppInfo.getItem();
                                        item.setAppName("" + applicationInfo.loadLabel(this.f670a));
                                        String str3 = applicationInfo.packageName;
                                        kotlin.jvm.internal.r.c(str3, "applicationInfo.packageName");
                                        item.setPackageName(str3);
                                        item.dir = file.getParent();
                                        item.enabled = Boolean.valueOf(applicationInfo.enabled);
                                        if (Build.VERSION.SDK_INT >= 24) {
                                            if ((applicationInfo.flags & 1073741824) != 0) {
                                                z3 = true;
                                            } else {
                                                z3 = false;
                                            }
                                            item.suspended = Boolean.valueOf(z3);
                                        }
                                        kotlin.jvm.internal.r.c(applicationInfo, "applicationInfo");
                                        item.stateTags = k(applicationInfo);
                                        item.path = applicationInfo.sourceDir;
                                        if (m(applicationInfo)) {
                                            parent = file.getParent();
                                            kotlin.jvm.internal.r.c(parent, "file.parent");
                                            if (kotlin.text.k.t(parent, "/data", false, 2, (Object) null)) {
                                                z2 = true;
                                            } else {
                                                z2 = false;
                                            }
                                        } else {
                                            z2 = false;
                                        }
                                        item.updated = Boolean.valueOf(z2);
                                        if ((applicationInfo.flags & 1) == 0) {
                                            appType = AppInfo.AppType.USER;
                                        } else {
                                            appType = AppInfo.AppType.SYSTEM;
                                        }
                                        item.appType = appType;
                                        PackageInfo packageInfo2 = this.f670a.getPackageInfo(applicationInfo.packageName, 0);
                                        item.versionName = packageInfo2.versionName;
                                        item.versionCode = packageInfo2.versionCode;
                                        arrayList.add(item);
                                    }
                                }
                            }
                        } else if (kotlin.jvm.internal.r.a(bool, Boolean.TRUE)) {
                            kotlin.jvm.internal.r.c(applicationInfo, "applicationInfo");
                            if (!m(applicationInfo)) {
                                file = new File(applicationInfo.publicSourceDir);
                                if (!file.exists()) {
                                    item = AppInfo.getItem();
                                    item.setAppName("" + applicationInfo.loadLabel(this.f670a));
                                    String str4 = applicationInfo.packageName;
                                    kotlin.jvm.internal.r.c(str4, "applicationInfo.packageName");
                                    item.setPackageName(str4);
                                    item.dir = file.getParent();
                                    item.enabled = Boolean.valueOf(applicationInfo.enabled);
                                    if (Build.VERSION.SDK_INT >= 24) {
                                        if ((applicationInfo.flags & 1073741824) != 0) {
                                            z3 = true;
                                        } else {
                                            z3 = false;
                                        }
                                        item.suspended = Boolean.valueOf(z3);
                                    }
                                    kotlin.jvm.internal.r.c(applicationInfo, "applicationInfo");
                                    item.stateTags = k(applicationInfo);
                                    item.path = applicationInfo.sourceDir;
                                    if (m(applicationInfo)) {
                                        parent = file.getParent();
                                        kotlin.jvm.internal.r.c(parent, "file.parent");
                                        if (kotlin.text.k.t(parent, "/data", false, 2, (Object) null)) {
                                            z2 = true;
                                        } else {
                                            z2 = false;
                                        }
                                    } else {
                                        z2 = false;
                                    }
                                    item.updated = Boolean.valueOf(z2);
                                    if ((applicationInfo.flags & 1) == 0) {
                                        appType = AppInfo.AppType.USER;
                                    } else {
                                        appType = AppInfo.AppType.SYSTEM;
                                    }
                                    item.appType = appType;
                                    PackageInfo packageInfo3 = this.f670a.getPackageInfo(applicationInfo.packageName, 0);
                                    item.versionName = packageInfo3.versionName;
                                    item.versionCode = packageInfo3.versionCode;
                                    arrayList.add(item);
                                }
                            }
                        } else {
                            file = new File(applicationInfo.publicSourceDir);
                            if (!file.exists()) {
                                item = AppInfo.getItem();
                                item.setAppName("" + applicationInfo.loadLabel(this.f670a));
                                String str5 = applicationInfo.packageName;
                                kotlin.jvm.internal.r.c(str5, "applicationInfo.packageName");
                                item.setPackageName(str5);
                                item.dir = file.getParent();
                                item.enabled = Boolean.valueOf(applicationInfo.enabled);
                                if (Build.VERSION.SDK_INT >= 24) {
                                    if ((applicationInfo.flags & 1073741824) != 0) {
                                        z3 = true;
                                    } else {
                                        z3 = false;
                                    }
                                    item.suspended = Boolean.valueOf(z3);
                                }
                                kotlin.jvm.internal.r.c(applicationInfo, "applicationInfo");
                                item.stateTags = k(applicationInfo);
                                item.path = applicationInfo.sourceDir;
                                if (m(applicationInfo)) {
                                    parent = file.getParent();
                                    kotlin.jvm.internal.r.c(parent, "file.parent");
                                    if (kotlin.text.k.t(parent, "/data", false, 2, (Object) null)) {
                                        z2 = true;
                                    } else {
                                        z2 = false;
                                    }
                                } else {
                                    z2 = false;
                                }
                                item.updated = Boolean.valueOf(z2);
                                if ((applicationInfo.flags & 1) == 0) {
                                    appType = AppInfo.AppType.USER;
                                } else {
                                    appType = AppInfo.AppType.SYSTEM;
                                }
                                item.appType = appType;
                                PackageInfo packageInfo4 = this.f670a.getPackageInfo(applicationInfo.packageName, 0);
                                item.versionName = packageInfo4.versionName;
                                item.versionCode = packageInfo4.versionCode;
                                arrayList.add(item);
                            }
                        }
                    }
                }
            } else {
                it = arrayList.iterator();
                do {
                    if (it.hasNext()) {
                        next = null;
                        break;
                    }
                    next = it.next();
                } while (!kotlin.jvm.internal.r.a(((AppInfo) next).getPackageName(), applicationInfo.packageName));
                if (next == null) {
                    if (kotlin.jvm.internal.r.a(bool, Boolean.FALSE)) {
                        kotlin.jvm.internal.r.c(applicationInfo, "applicationInfo");
                        if (!m(applicationInfo)) {
                            if (kotlin.jvm.internal.r.a(bool, Boolean.TRUE)) {
                                kotlin.jvm.internal.r.c(applicationInfo, "applicationInfo");
                                if (!m(applicationInfo)) {
                                    file = new File(applicationInfo.publicSourceDir);
                                    if (!file.exists()) {
                                        item = AppInfo.getItem();
                                        item.setAppName("" + applicationInfo.loadLabel(this.f670a));
                                        String str6 = applicationInfo.packageName;
                                        kotlin.jvm.internal.r.c(str6, "applicationInfo.packageName");
                                        item.setPackageName(str6);
                                        item.dir = file.getParent();
                                        item.enabled = Boolean.valueOf(applicationInfo.enabled);
                                        if (Build.VERSION.SDK_INT >= 24) {
                                            if ((applicationInfo.flags & 1073741824) != 0) {
                                                z3 = true;
                                            } else {
                                                z3 = false;
                                            }
                                            item.suspended = Boolean.valueOf(z3);
                                        }
                                        kotlin.jvm.internal.r.c(applicationInfo, "applicationInfo");
                                        item.stateTags = k(applicationInfo);
                                        item.path = applicationInfo.sourceDir;
                                        if (m(applicationInfo)) {
                                            parent = file.getParent();
                                            kotlin.jvm.internal.r.c(parent, "file.parent");
                                            if (kotlin.text.k.t(parent, "/data", false, 2, (Object) null)) {
                                                z2 = true;
                                            } else {
                                                z2 = false;
                                            }
                                        } else {
                                            z2 = false;
                                        }
                                        item.updated = Boolean.valueOf(z2);
                                        if ((applicationInfo.flags & 1) == 0) {
                                            appType = AppInfo.AppType.USER;
                                        } else {
                                            appType = AppInfo.AppType.SYSTEM;
                                        }
                                        item.appType = appType;
                                        PackageInfo packageInfo5 = this.f670a.getPackageInfo(applicationInfo.packageName, 0);
                                        item.versionName = packageInfo5.versionName;
                                        item.versionCode = packageInfo5.versionCode;
                                        arrayList.add(item);
                                    }
                                }
                            } else {
                                file = new File(applicationInfo.publicSourceDir);
                                if (!file.exists()) {
                                    item = AppInfo.getItem();
                                    item.setAppName("" + applicationInfo.loadLabel(this.f670a));
                                    String str7 = applicationInfo.packageName;
                                    kotlin.jvm.internal.r.c(str7, "applicationInfo.packageName");
                                    item.setPackageName(str7);
                                    item.dir = file.getParent();
                                    item.enabled = Boolean.valueOf(applicationInfo.enabled);
                                    if (Build.VERSION.SDK_INT >= 24) {
                                        if ((applicationInfo.flags & 1073741824) != 0) {
                                            z3 = true;
                                        } else {
                                            z3 = false;
                                        }
                                        item.suspended = Boolean.valueOf(z3);
                                    }
                                    kotlin.jvm.internal.r.c(applicationInfo, "applicationInfo");
                                    item.stateTags = k(applicationInfo);
                                    item.path = applicationInfo.sourceDir;
                                    if (m(applicationInfo)) {
                                        parent = file.getParent();
                                        kotlin.jvm.internal.r.c(parent, "file.parent");
                                        if (kotlin.text.k.t(parent, "/data", false, 2, (Object) null)) {
                                            z2 = true;
                                        } else {
                                            z2 = false;
                                        }
                                    } else {
                                        z2 = false;
                                    }
                                    item.updated = Boolean.valueOf(z2);
                                    if ((applicationInfo.flags & 1) == 0) {
                                        appType = AppInfo.AppType.USER;
                                    } else {
                                        appType = AppInfo.AppType.SYSTEM;
                                    }
                                    item.appType = appType;
                                    PackageInfo packageInfo6 = this.f670a.getPackageInfo(applicationInfo.packageName, 0);
                                    item.versionName = packageInfo6.versionName;
                                    item.versionCode = packageInfo6.versionCode;
                                    arrayList.add(item);
                                }
                            }
                        }
                    } else if (kotlin.jvm.internal.r.a(bool, Boolean.TRUE)) {
                        kotlin.jvm.internal.r.c(applicationInfo, "applicationInfo");
                        if (!m(applicationInfo)) {
                            file = new File(applicationInfo.publicSourceDir);
                            if (!file.exists()) {
                                item = AppInfo.getItem();
                                item.setAppName("" + applicationInfo.loadLabel(this.f670a));
                                String str8 = applicationInfo.packageName;
                                kotlin.jvm.internal.r.c(str8, "applicationInfo.packageName");
                                item.setPackageName(str8);
                                item.dir = file.getParent();
                                item.enabled = Boolean.valueOf(applicationInfo.enabled);
                                if (Build.VERSION.SDK_INT >= 24) {
                                    if ((applicationInfo.flags & 1073741824) != 0) {
                                        z3 = true;
                                    } else {
                                        z3 = false;
                                    }
                                    item.suspended = Boolean.valueOf(z3);
                                }
                                kotlin.jvm.internal.r.c(applicationInfo, "applicationInfo");
                                item.stateTags = k(applicationInfo);
                                item.path = applicationInfo.sourceDir;
                                if (m(applicationInfo)) {
                                    parent = file.getParent();
                                    kotlin.jvm.internal.r.c(parent, "file.parent");
                                    if (kotlin.text.k.t(parent, "/data", false, 2, (Object) null)) {
                                        z2 = true;
                                    } else {
                                        z2 = false;
                                    }
                                } else {
                                    z2 = false;
                                }
                                item.updated = Boolean.valueOf(z2);
                                if ((applicationInfo.flags & 1) == 0) {
                                    appType = AppInfo.AppType.USER;
                                } else {
                                    appType = AppInfo.AppType.SYSTEM;
                                }
                                item.appType = appType;
                                PackageInfo packageInfo7 = this.f670a.getPackageInfo(applicationInfo.packageName, 0);
                                item.versionName = packageInfo7.versionName;
                                item.versionCode = packageInfo7.versionCode;
                                arrayList.add(item);
                            }
                        }
                    } else {
                        file = new File(applicationInfo.publicSourceDir);
                        if (!file.exists()) {
                            item = AppInfo.getItem();
                            item.setAppName("" + applicationInfo.loadLabel(this.f670a));
                            String str9 = applicationInfo.packageName;
                            kotlin.jvm.internal.r.c(str9, "applicationInfo.packageName");
                            item.setPackageName(str9);
                            item.dir = file.getParent();
                            item.enabled = Boolean.valueOf(applicationInfo.enabled);
                            if (Build.VERSION.SDK_INT >= 24) {
                                if ((applicationInfo.flags & 1073741824) != 0) {
                                    z3 = true;
                                } else {
                                    z3 = false;
                                }
                                item.suspended = Boolean.valueOf(z3);
                            }
                            kotlin.jvm.internal.r.c(applicationInfo, "applicationInfo");
                            item.stateTags = k(applicationInfo);
                            item.path = applicationInfo.sourceDir;
                            if (m(applicationInfo)) {
                                parent = file.getParent();
                                kotlin.jvm.internal.r.c(parent, "file.parent");
                                if (kotlin.text.k.t(parent, "/data", false, 2, (Object) null)) {
                                    z2 = true;
                                } else {
                                    z2 = false;
                                }
                            } else {
                                z2 = false;
                            }
                            item.updated = Boolean.valueOf(z2);
                            if ((applicationInfo.flags & 1) == 0) {
                                appType = AppInfo.AppType.USER;
                            } else {
                                appType = AppInfo.AppType.SYSTEM;
                            }
                            item.appType = appType;
                            PackageInfo packageInfo8 = this.f670a.getPackageInfo(applicationInfo.packageName, 0);
                            item.versionName = packageInfo8.versionName;
                            item.versionCode = packageInfo8.versionCode;
                            arrayList.add(item);
                        }
                    }
                }
            }
        }
        return arrayList;
    }

    public final ArrayList<AppInfo> i() {
        File[] fileArrListFiles;
        String strA = com.omarea.g.b.f561c.a();
        ArrayList<AppInfo> arrayList = new ArrayList<>();
        File file = new File(strA);
        if (!file.exists()) {
            return arrayList;
        }
        if (!file.isDirectory()) {
            file.delete();
            file.mkdirs();
            return arrayList;
        }
        if (!file.canRead() || (fileArrListFiles = file.listFiles(a.f673a)) == null) {
            return arrayList;
        }
        for (File file2 : fileArrListFiles) {
            kotlin.jvm.internal.r.c(file2, "files[i]");
            String absolutePath = file2.getAbsolutePath();
            try {
                PackageInfo packageArchiveInfo = this.f670a.getPackageArchiveInfo(absolutePath, 1);
                if (packageArchiveInfo != null) {
                    ApplicationInfo applicationInfo = packageArchiveInfo.applicationInfo;
                    applicationInfo.sourceDir = absolutePath;
                    applicationInfo.publicSourceDir = absolutePath;
                    AppInfo item = AppInfo.getItem();
                    item.setSelected(false);
                    item.setAppName(applicationInfo.loadLabel(this.f670a).toString() + "  (" + packageArchiveInfo.versionCode + ")");
                    String str = applicationInfo.packageName;
                    kotlin.jvm.internal.r.c(str, "applicationInfo.packageName");
                    item.setPackageName(str);
                    item.path = applicationInfo.sourceDir;
                    item.stateTags = a(packageArchiveInfo);
                    item.versionName = packageArchiveInfo.versionName;
                    item.versionCode = packageArchiveInfo.versionCode;
                    item.appType = AppInfo.AppType.BACKUPFILE;
                    arrayList.add(item);
                }
            } catch (Exception unused) {
            }
        }
        return arrayList;
    }

    public final ArrayList<AppInfo> j() {
        return f(this, Boolean.TRUE, false, 2, null);
    }

    /* JADX WARN: Code duplicated, block: B:35:0x0103  */
    /* JADX WARN: Code duplicated, block: B:37:0x010c  */
    public final String k(ApplicationInfo applicationInfo) {
        String string;
        String string2;
        kotlin.jvm.internal.r.d(applicationInfo, "applicationInfo");
        StringBuilder sb = new StringBuilder();
        String strA = com.omarea.g.b.f561c.a();
        try {
            if (!applicationInfo.enabled) {
                sb.append(this.f671b.getString(2131886447));
                sb.append(" ");
            }
            if ((applicationInfo.flags & 1073741824) != 0) {
                sb.append(this.f671b.getString(2131886452));
                sb.append(" ");
            }
            if (m(applicationInfo)) {
                String str = applicationInfo.sourceDir;
                kotlin.jvm.internal.r.c(str, "applicationInfo.sourceDir");
                if (kotlin.text.k.t(str, "/data", false, 2, (Object) null)) {
                    sb.append(this.f671b.getString(2131886453));
                    sb.append(" ");
                }
            }
            String str2 = applicationInfo.packageName;
            String str3 = strA + str2 + ".apk";
            if (!new File(str3).exists()) {
                if (new File(strA + str2 + ".tar.gz").exists()) {
                    string2 = this.f671b.getString(2131886448);
                }
                string = sb.toString();
                kotlin.jvm.internal.r.c(string, "stateTags.toString()");
                if (string != null) {
                    return kotlin.text.k.k0(string).toString();
                }
                throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
            }
            PackageInfo packageArchiveInfo = this.f670a.getPackageArchiveInfo(str3, 1);
            kotlin.jvm.internal.r.b(packageArchiveInfo);
            kotlin.jvm.internal.r.c(packageArchiveInfo, "packageManager.getPackag…Manager.GET_ACTIVITIES)!!");
            PackageInfo packageInfo = this.f670a.getPackageInfo(applicationInfo.packageName, 0);
            if (packageInfo == null) {
                return "";
            }
            if (packageArchiveInfo.versionCode == packageInfo.versionCode) {
                string2 = this.f671b.getString(2131886445);
            } else {
                string2 = packageArchiveInfo.versionCode > packageInfo.versionCode ? this.f671b.getString(2131886446) : this.f671b.getString(2131886444);
            }
            sb.append(string2);
            sb.append(" ");
        } catch (Exception unused) {
        }
        string = sb.toString();
        kotlin.jvm.internal.r.c(string, "stateTags.toString()");
        if (string != null) {
            return kotlin.text.k.k0(string).toString();
        }
        throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
    }

    public final ArrayList<AppInfo> l() {
        return f(this, Boolean.FALSE, false, 2, null);
    }

    public final boolean m(ApplicationInfo applicationInfo) {
        kotlin.jvm.internal.r.d(applicationInfo, "applicationInfo");
        return (applicationInfo.flags & 128) != 0;
    }
}
