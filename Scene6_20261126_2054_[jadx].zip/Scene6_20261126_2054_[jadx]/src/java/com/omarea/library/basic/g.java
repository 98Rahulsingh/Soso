package com.omarea.library.basic;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class g {
    public final String a(double d2) {
        double d3 = 1440;
        String str = "";
        if (d2 >= d3) {
            int i = (int) ((d2 % d3) / ((double) 60));
            StringBuilder sb = new StringBuilder();
            sb.append("");
            sb.append((int) (d2 / d3));
            sb.append("d");
            if (i > 0) {
                str = String.valueOf(i) + "h";
            }
            sb.append(str);
            return sb.toString();
        }
        double d4 = 60;
        if (d2 > d4) {
            int i2 = (int) (d2 % d4);
            StringBuilder sb2 = new StringBuilder();
            sb2.append("");
            sb2.append((int) (d2 / d4));
            sb2.append("h");
            if (i2 > 0) {
                str = String.valueOf(i2) + "m";
            }
            sb2.append(str);
            return sb2.toString();
        }
        if (d2 == 0.0d) {
            return "0";
        }
        double d5 = 1;
        if (d2 < d5) {
            return String.valueOf((int) (d2 * d4)) + "s";
        }
        int i3 = (int) ((d2 % d5) * d4);
        StringBuilder sb3 = new StringBuilder();
        sb3.append("");
        sb3.append((int) d2);
        sb3.append("m");
        if (i3 > 0) {
            str = String.valueOf(i3) + "s";
        }
        sb3.append(str);
        return sb3.toString();
    }
}
