package com.omarea.library.basic;

import android.content.pm.PackageInfo;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.internal.Ref;
import kotlinx.coroutines.AwaitKt;
import kotlinx.coroutines.CoroutineStart;
import kotlinx.coroutines.h0;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
@kotlin.coroutines.jvm.internal.d(c = "com.omarea.library.basic.AppContents$buildCache$1", f = "AppContents.kt", l = {125}, m = "invokeSuspend")
final class AppContents$buildCache$1 extends SuspendLambda implements kotlin.jvm.b.p<h0, kotlin.coroutines.c<? super List<? extends kotlin.s>>, Object> {
    final /* synthetic */ int $flags;
    final /* synthetic */ Ref.ObjectRef $packages;
    Object L$0;
    int label;
    private h0 p$;
    final /* synthetic */ AppContents this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    AppContents$buildCache$1(AppContents appContents, Ref.ObjectRef objectRef, int i, kotlin.coroutines.c cVar) {
        super(2, cVar);
        this.this$0 = appContents;
        this.$packages = objectRef;
        this.$flags = i;
    }

    public final kotlin.coroutines.c<kotlin.s> create(Object obj, kotlin.coroutines.c<?> cVar) {
        kotlin.jvm.internal.r.d(cVar, "completion");
        AppContents$buildCache$1 appContents$buildCache$1 = new AppContents$buildCache$1(this.this$0, this.$packages, this.$flags, cVar);
        appContents$buildCache$1.p$ = (h0) obj;
        return appContents$buildCache$1;
    }

    public final Object invoke(Object obj, Object obj2) {
        return create(obj, (kotlin.coroutines.c) obj2).invokeSuspend(kotlin.s.a);
    }

    public final Object invokeSuspend(Object obj) {
        Object objD = kotlin.coroutines.intrinsics.a.d();
        int i = this.label;
        if (i == 0) {
            kotlin.h.b(obj);
            h0 h0Var = this.p$;
            List list = (List) this.$packages.element;
            ArrayList arrayList = new ArrayList(kotlin.collections.q.k(list, 10));
            Iterator it = list.iterator();
            while (it.hasNext()) {
                arrayList.add(kotlinx.coroutines.f.b(h0Var, (CoroutineContext) null, (CoroutineStart) null, new AppContents$buildCache$1$invokeSuspend$$inlined$map$lambda$1((PackageInfo) it.next(), null, this, h0Var), 3, (Object) null));
            }
            this.L$0 = h0Var;
            this.label = 1;
            obj = AwaitKt.a(arrayList, this);
            if (obj == objD) {
                return objD;
            }
        } else {
            if (i != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            kotlin.h.b(obj);
        }
        return obj;
    }
}
