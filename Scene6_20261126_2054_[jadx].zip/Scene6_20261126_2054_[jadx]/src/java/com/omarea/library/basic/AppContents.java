package com.omarea.library.basic;

import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ProviderInfo;
import android.content.pm.ServiceInfo;
import android.os.Build;
import java.util.ArrayList;
import java.util.List;
import kotlin.coroutines.CoroutineContext;
import kotlin.jvm.internal.Ref;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class AppContents {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final PackageManager f639a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final com.omarea.store.a f640b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final Context f641c;

    public AppContents(Context context) {
        kotlin.jvm.internal.r.d(context, "context");
        this.f641c = context;
        this.f639a = context.getPackageManager();
        this.f640b = new com.omarea.store.a(this.f641c);
    }

    public final void c() {
        this.f640b.e();
        int i = Build.VERSION.SDK_INT;
        Ref.ObjectRef objectRef = new Ref.ObjectRef();
        List<PackageInfo> installedPackages = this.f639a.getInstalledPackages(0);
        kotlin.jvm.internal.r.c(installedPackages, "packageManager.getInstalledPackages(0)");
        objectRef.element = installedPackages;
        kotlinx.coroutines.f.f((CoroutineContext) null, new AppContents$buildCache$1(this, objectRef, 527, null), 1, (Object) null);
    }

    public final ArrayList<ActivityInfo> d(String str) {
        kotlin.jvm.internal.r.d(str, "packageName");
        int i = Build.VERSION.SDK_INT;
        ActivityInfo[] activityInfoArr = this.f639a.getPackageInfo(str, 513).activities;
        return activityInfoArr != null ? new ArrayList<>(kotlin.collections.h.z(activityInfoArr)) : new ArrayList<>();
    }

    public final ArrayList<ProviderInfo> e(String str) {
        kotlin.jvm.internal.r.d(str, "packageName");
        int i = Build.VERSION.SDK_INT;
        ProviderInfo[] providerInfoArr = this.f639a.getPackageInfo(str, 520).providers;
        return providerInfoArr != null ? new ArrayList<>(kotlin.collections.h.z(providerInfoArr)) : new ArrayList<>();
    }

    public final ArrayList<ActivityInfo> f(String str) {
        kotlin.jvm.internal.r.d(str, "packageName");
        int i = Build.VERSION.SDK_INT;
        ActivityInfo[] activityInfoArr = this.f639a.getPackageInfo(str, 514).receivers;
        return activityInfoArr != null ? new ArrayList<>(kotlin.collections.h.z(activityInfoArr)) : new ArrayList<>();
    }

    public final ArrayList<ServiceInfo> g(String str) {
        kotlin.jvm.internal.r.d(str, "packageName");
        int i = Build.VERSION.SDK_INT;
        ServiceInfo[] serviceInfoArr = this.f639a.getPackageInfo(str, 516).services;
        return serviceInfoArr != null ? new ArrayList<>(kotlin.collections.h.z(serviceInfoArr)) : new ArrayList<>();
    }
}
