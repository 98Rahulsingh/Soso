package com.omarea.library.basic;

import android.graphics.Rect;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.inputmethod.InputMethodManager;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import kotlin.coroutines.CoroutineContext;
import kotlin.jvm.internal.Ref;
import kotlinx.coroutines.CoroutineStart;
import kotlinx.coroutines.i0;
import kotlinx.coroutines.w0;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class FormValueHandler {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private static final String f648c = "keyboard";

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private static final String f649d = "change";
    public static final a e = new a(null);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private boolean f650a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final String f651b;

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(kotlin.jvm.internal.o oVar) {
            this();
        }

        public final String a() {
            return FormValueHandler.f649d;
        }
    }

    public interface b<T> {
        T getValue();

        void setValue(T t);
    }

    public static final class c implements SeekBar.OnSeekBarChangeListener {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final /* synthetic */ b f652a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final /* synthetic */ TextView f653b;

        c(b bVar, TextView textView) {
            this.f652a = bVar;
            this.f653b = textView;
        }

        @Override // android.widget.SeekBar.OnSeekBarChangeListener
        public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
        }

        @Override // android.widget.SeekBar.OnSeekBarChangeListener
        public void onStartTrackingTouch(SeekBar seekBar) {
        }

        @Override // android.widget.SeekBar.OnSeekBarChangeListener
        public void onStopTrackingTouch(SeekBar seekBar) {
            b bVar = this.f652a;
            kotlin.jvm.internal.r.b(seekBar);
            bVar.setValue(Integer.valueOf(seekBar.getProgress()));
            TextView textView = this.f653b;
            if (textView != null) {
                textView.setText(String.valueOf(seekBar.getProgress()));
            }
        }
    }

    static final class d implements TextView.OnEditorActionListener {

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final /* synthetic */ Ref.ObjectRef f655b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        final /* synthetic */ b f656c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ EditText f657d;

        d(Ref.ObjectRef objectRef, b bVar, EditText editText) {
            this.f655b = objectRef;
            this.f656c = bVar;
            this.f657d = editText;
        }

        @Override // android.widget.TextView.OnEditorActionListener
        public final boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
            String string;
            CharSequence text;
            if (i != 3 && i != 6 && i != 5) {
                return false;
            }
            if (textView == null || (text = textView.getText()) == null || (string = text.toString()) == null) {
                string = "";
            }
            this.f655b.element = string;
            this.f656c.setValue(string);
            if (i != 3) {
                FormValueHandler.this.j(this.f657d);
            }
            return true;
        }
    }

    static final class e implements View.OnFocusChangeListener {
        final /* synthetic */ Ref.ObjectRef f;
        final /* synthetic */ b g;

        e(Ref.ObjectRef objectRef, b bVar) {
            this.f = objectRef;
            this.g = bVar;
        }

        @Override // android.view.View.OnFocusChangeListener
        public final void onFocusChange(View view, boolean z) {
            String string;
            if (view == null) {
                throw new NullPointerException("null cannot be cast to non-null type android.widget.TextView");
            }
            CharSequence text = ((TextView) view).getText();
            if (text == null || (string = text.toString()) == null) {
                string = "";
            }
            if (!kotlin.jvm.internal.r.a(string, (String) this.f.element)) {
                this.f.element = string;
                this.g.setValue(string);
            }
        }
    }

    public static final class f implements TextWatcher {
        final /* synthetic */ Ref.ObjectRef f;
        final /* synthetic */ b g;

        f(Ref.ObjectRef objectRef, b bVar) {
            this.f = objectRef;
            this.g = bVar;
        }

        @Override // android.text.TextWatcher
        public void afterTextChanged(Editable editable) {
            String string;
            if (editable == null || (string = editable.toString()) == null) {
                string = "";
            }
            if (!kotlin.jvm.internal.r.a(string, (String) this.f.element)) {
                this.f.element = string;
                this.g.setValue(string);
            }
        }

        @Override // android.text.TextWatcher
        public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }

        @Override // android.text.TextWatcher
        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }
    }

    static final class g implements CompoundButton.OnCheckedChangeListener {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final /* synthetic */ b f658a;

        g(b bVar) {
            this.f658a = bVar;
        }

        @Override // android.widget.CompoundButton.OnCheckedChangeListener
        public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
            this.f658a.setValue(Boolean.valueOf(z));
        }
    }

    static final class h implements TextView.OnEditorActionListener {

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final /* synthetic */ Ref.DoubleRef f660b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        final /* synthetic */ b f661c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ EditText f662d;

        h(Ref.DoubleRef doubleRef, b bVar, EditText editText) {
            this.f660b = doubleRef;
            this.f661c = bVar;
            this.f662d = editText;
        }

        @Override // android.widget.TextView.OnEditorActionListener
        public final boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
            String string;
            CharSequence text;
            if (i != 3 && i != 6 && i != 5) {
                return false;
            }
            if (textView == null || (text = textView.getText()) == null || (string = text.toString()) == null) {
                string = "";
            }
            try {
                this.f660b.element = Double.parseDouble(string);
                this.f661c.setValue(Double.valueOf(this.f660b.element));
                if (i != 3) {
                    FormValueHandler.this.j(this.f662d);
                }
            } catch (Exception unused) {
                this.f662d.setText(String.valueOf(this.f660b.element));
            }
            return true;
        }
    }

    static final class i implements View.OnFocusChangeListener {
        final /* synthetic */ Ref.DoubleRef f;
        final /* synthetic */ b g;
        final /* synthetic */ EditText h;

        i(Ref.DoubleRef doubleRef, b bVar, EditText editText) {
            this.f = doubleRef;
            this.g = bVar;
            this.h = editText;
        }

        @Override // android.view.View.OnFocusChangeListener
        public final void onFocusChange(View view, boolean z) {
            String string;
            if (view == null) {
                throw new NullPointerException("null cannot be cast to non-null type android.widget.TextView");
            }
            CharSequence text = ((TextView) view).getText();
            if (text == null || (string = text.toString()) == null) {
                string = "";
            }
            try {
                double d2 = Double.parseDouble(string);
                this.f.element = d2;
                this.g.setValue(Double.valueOf(d2));
            } catch (Exception unused) {
                this.h.setText(String.valueOf(this.f.element));
            }
        }
    }

    public static final class j implements TextWatcher {
        final /* synthetic */ Ref.DoubleRef f;
        final /* synthetic */ b g;
        final /* synthetic */ EditText h;

        j(Ref.DoubleRef doubleRef, b bVar, EditText editText) {
            this.f = doubleRef;
            this.g = bVar;
            this.h = editText;
        }

        @Override // android.text.TextWatcher
        public void afterTextChanged(Editable editable) {
            String string;
            if (editable == null || (string = editable.toString()) == null) {
                string = "";
            }
            try {
                double d2 = Double.parseDouble(string);
                this.f.element = d2;
                this.g.setValue(Double.valueOf(d2));
            } catch (Exception unused) {
                this.h.setText(String.valueOf(this.f.element));
            }
        }

        @Override // android.text.TextWatcher
        public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }

        @Override // android.text.TextWatcher
        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }
    }

    static final class k implements ViewTreeObserver.OnGlobalLayoutListener {
        final /* synthetic */ View g;
        final /* synthetic */ kotlin.jvm.b.a h;

        k(View view, kotlin.jvm.b.a aVar) {
            this.g = view;
            this.h = aVar;
        }

        @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
        public final void onGlobalLayout() {
            Rect rect = new Rect();
            this.g.getWindowVisibleDisplayFrame(rect);
            if (this.g.getRootView().getHeight() - rect.bottom > 200) {
                FormValueHandler.this.f650a = true;
            } else if (FormValueHandler.this.f650a && this.g.hasFocus()) {
                FormValueHandler.this.f650a = false;
                this.h.invoke();
            }
        }
    }

    /* JADX WARN: Illegal instructions before constructor call */
    public FormValueHandler() {
        String str = null;
        this(str, 1, str);
    }

    public FormValueHandler(String str) {
        kotlin.jvm.internal.r.d(str, "editSyncMode");
        this.f651b = str;
    }

    public /* synthetic */ FormValueHandler(String str, int i2, kotlin.jvm.internal.o oVar) {
        this((i2 & 1) != 0 ? f648c : str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void j(EditText editText) {
        Object systemService = editText.getContext().getSystemService("input_method");
        if (systemService == null) {
            throw new NullPointerException("null cannot be cast to non-null type android.view.inputmethod.InputMethodManager");
        }
        ((InputMethodManager) systemService).hideSoftInputFromWindow(editText.getWindowToken(), 0);
        editText.clearFocus();
    }

    private final void k(View view, kotlin.jvm.b.a<kotlin.s> aVar) {
        view.getViewTreeObserver().addOnGlobalLayoutListener(new k(view, aVar));
    }

    public final void e(CompoundButton compoundButton, b<Boolean> bVar) {
        kotlin.jvm.internal.r.d(compoundButton, "compoundButton");
        kotlin.jvm.internal.r.d(bVar, "inputHandler");
        kotlinx.coroutines.f.d(i0.a(w0.a()), (CoroutineContext) null, (CoroutineStart) null, new FormValueHandler$bindInput$8(bVar, compoundButton, null), 3, (Object) null);
        compoundButton.setOnCheckedChangeListener(new g(bVar));
    }

    public final void f(final EditText editText, final b<String> bVar) {
        kotlin.jvm.internal.r.d(editText, "editText");
        kotlin.jvm.internal.r.d(bVar, "inputHandler");
        final Ref.ObjectRef objectRef = new Ref.ObjectRef();
        objectRef.element = "";
        kotlinx.coroutines.f.d(i0.a(w0.a()), (CoroutineContext) null, (CoroutineStart) null, new FormValueHandler$bindInput$3(bVar, objectRef, editText, null), 3, (Object) null);
        editText.setOnEditorActionListener(new d(objectRef, bVar, editText));
        editText.setOnFocusChangeListener(new e(objectRef, bVar));
        if (kotlin.jvm.internal.r.a(this.f651b, f649d)) {
            editText.addTextChangedListener(new f(objectRef, bVar));
        } else {
            k(editText, new kotlin.jvm.b.a<kotlin.s>() { // from class: com.omarea.library.basic.FormValueHandler$bindInput$7
                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                {
                    super(0);
                }

                public /* bridge */ /* synthetic */ Object invoke() {
                    m0invoke();
                    return kotlin.s.a;
                }

                /* JADX INFO: renamed from: invoke, reason: collision with other method in class */
                public final void m0invoke() {
                    String string;
                    Editable text = editText.getText();
                    if (text == null || (string = text.toString()) == null) {
                        string = "";
                    }
                    if (!kotlin.jvm.internal.r.a(string, (String) objectRef.element)) {
                        objectRef.element = string;
                        bVar.setValue(string);
                    }
                }
            });
        }
    }

    public final void g(SeekBar seekBar, b<Integer> bVar, TextView textView) {
        kotlin.jvm.internal.r.d(seekBar, "seekBar");
        kotlin.jvm.internal.r.d(bVar, "inputHandler");
        kotlinx.coroutines.f.d(i0.a(w0.a()), (CoroutineContext) null, (CoroutineStart) null, new FormValueHandler$bindInput$1(bVar, textView, seekBar, null), 3, (Object) null);
        seekBar.setOnSeekBarChangeListener(new c(bVar, textView));
    }

    public final void h(Spinner spinner, b<Integer> bVar) {
        kotlin.jvm.internal.r.d(spinner, "spinner");
        kotlin.jvm.internal.r.d(bVar, "inputHandler");
        Ref.IntRef intRef = new Ref.IntRef();
        intRef.element = 0;
        kotlinx.coroutines.f.d(i0.a(w0.a()), (CoroutineContext) null, (CoroutineStart) null, new FormValueHandler$bindInput$10(bVar, intRef, spinner, null), 3, (Object) null);
    }

    public final void i(final EditText editText, final b<Double> bVar) {
        kotlin.jvm.internal.r.d(editText, "editText");
        kotlin.jvm.internal.r.d(bVar, "inputHandler");
        final Ref.DoubleRef doubleRef = new Ref.DoubleRef();
        doubleRef.element = 0.0d;
        kotlinx.coroutines.f.d(i0.a(w0.a()), (CoroutineContext) null, (CoroutineStart) null, new FormValueHandler$bindInputDecimal$1(bVar, doubleRef, editText, null), 3, (Object) null);
        editText.setOnEditorActionListener(new h(doubleRef, bVar, editText));
        editText.setOnFocusChangeListener(new i(doubleRef, bVar, editText));
        if (kotlin.jvm.internal.r.a(this.f651b, f649d)) {
            editText.addTextChangedListener(new j(doubleRef, bVar, editText));
        } else {
            k(editText, new kotlin.jvm.b.a<kotlin.s>() { // from class: com.omarea.library.basic.FormValueHandler$bindInputDecimal$5
                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                {
                    super(0);
                }

                public /* bridge */ /* synthetic */ Object invoke() {
                    m1invoke();
                    return kotlin.s.a;
                }

                /* JADX INFO: renamed from: invoke, reason: collision with other method in class */
                public final void m1invoke() {
                    String string;
                    Editable text = editText.getText();
                    if (text == null || (string = text.toString()) == null) {
                        string = "";
                    }
                    try {
                        double d2 = Double.parseDouble(string);
                        doubleRef.element = d2;
                        bVar.setValue(Double.valueOf(d2));
                    } catch (Exception unused) {
                        editText.setText(String.valueOf(doubleRef.element));
                    }
                }
            });
        }
    }
}
