package com.omarea.library.basic;

import android.app.Activity;
import android.app.KeyguardManager;
import android.content.Context;
import android.view.Display;
import android.view.WindowManager;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class o {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final KeyguardManager f686a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final WindowManager f687b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final Integer[] f688c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private Context f689d;

    public o(Context context) {
        kotlin.jvm.internal.r.d(context, "context");
        this.f689d = context;
        Object systemService = context.getSystemService("keyguard");
        if (systemService == null) {
            throw new NullPointerException("null cannot be cast to non-null type android.app.KeyguardManager");
        }
        this.f686a = (KeyguardManager) systemService;
        Object systemService2 = this.f689d.getSystemService("window");
        if (systemService2 == null) {
            throw new NullPointerException("null cannot be cast to non-null type android.view.WindowManager");
        }
        this.f687b = (WindowManager) systemService2;
        this.f688c = kotlin.collections.h.i(new int[]{1, 3, 4, 6});
    }

    private final Display a() {
        Context context = this.f689d;
        if (!(context instanceof Activity)) {
            Display defaultDisplay = this.f687b.getDefaultDisplay();
            kotlin.jvm.internal.r.c(defaultDisplay, "windowManager.defaultDisplay");
            return defaultDisplay;
        }
        Display display = context.getDisplay();
        if (display != null) {
            return display;
        }
        Display defaultDisplay2 = this.f687b.getDefaultDisplay();
        kotlin.jvm.internal.r.c(defaultDisplay2, "windowManager.defaultDisplay");
        return defaultDisplay2;
    }

    public final boolean b() {
        if (this.f689d instanceof Activity) {
            if (kotlin.collections.h.j(this.f688c, Integer.valueOf(a().getState()))) {
                return true;
            }
        } else if (kotlin.collections.h.j(this.f688c, Integer.valueOf(a().getState()))) {
            return true;
        }
        if (this.f686a.isDeviceLocked()) {
            return true;
        }
        try {
            return this.f686a.isKeyguardLocked();
        } catch (Exception unused) {
            return false;
        }
    }

    public final boolean c() {
        return !b();
    }
}
