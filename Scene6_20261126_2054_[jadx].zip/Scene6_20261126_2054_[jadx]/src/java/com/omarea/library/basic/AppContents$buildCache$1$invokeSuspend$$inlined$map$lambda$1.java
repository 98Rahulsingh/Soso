package com.omarea.library.basic;

import android.content.pm.ActivityInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ProviderInfo;
import android.content.pm.ServiceInfo;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlinx.coroutines.h0;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
final class AppContents$buildCache$1$invokeSuspend$$inlined$map$lambda$1 extends SuspendLambda implements kotlin.jvm.b.p<h0, kotlin.coroutines.c<? super kotlin.s>, Object> {
    final /* synthetic */ PackageInfo $pkg;
    final /* synthetic */ h0 $this_runBlocking$inlined;
    int label;
    private h0 p$;
    final /* synthetic */ AppContents$buildCache$1 this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    AppContents$buildCache$1$invokeSuspend$$inlined$map$lambda$1(PackageInfo packageInfo, kotlin.coroutines.c cVar, AppContents$buildCache$1 appContents$buildCache$1, h0 h0Var) {
        super(2, cVar);
        this.$pkg = packageInfo;
        this.this$0 = appContents$buildCache$1;
        this.$this_runBlocking$inlined = h0Var;
    }

    public final kotlin.coroutines.c<kotlin.s> create(Object obj, kotlin.coroutines.c<?> cVar) {
        kotlin.jvm.internal.r.d(cVar, "completion");
        AppContents$buildCache$1$invokeSuspend$$inlined$map$lambda$1 appContents$buildCache$1$invokeSuspend$$inlined$map$lambda$1 = new AppContents$buildCache$1$invokeSuspend$$inlined$map$lambda$1(this.$pkg, cVar, this.this$0, this.$this_runBlocking$inlined);
        appContents$buildCache$1$invokeSuspend$$inlined$map$lambda$1.p$ = (h0) obj;
        return appContents$buildCache$1$invokeSuspend$$inlined$map$lambda$1;
    }

    public final Object invoke(Object obj, Object obj2) {
        return create(obj, (kotlin.coroutines.c) obj2).invokeSuspend(kotlin.s.a);
    }

    public final Object invokeSuspend(Object obj) throws PackageManager.NameNotFoundException {
        kotlin.coroutines.intrinsics.a.d();
        if (this.label != 0) {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        kotlin.h.b(obj);
        PackageInfo packageInfo = this.this$0.this$0.f639a.getPackageInfo(this.$pkg.packageName, this.this$0.$flags);
        ActivityInfo[] activityInfoArr = packageInfo.activities;
        if (activityInfoArr != null) {
            for (ActivityInfo activityInfo : activityInfoArr) {
                CharSequence charSequenceLoadLabel = activityInfo.loadLabel(this.this$0.this$0.f639a);
                kotlin.jvm.internal.r.c(charSequenceLoadLabel, "activity.loadLabel(packageManager)");
                this.this$0.this$0.f640b.a(activityInfo, "" + charSequenceLoadLabel);
            }
        }
        ServiceInfo[] serviceInfoArr = packageInfo.services;
        if (serviceInfoArr != null) {
            for (ServiceInfo serviceInfo : serviceInfoArr) {
                this.this$0.this$0.f640b.d(serviceInfo);
            }
        }
        ProviderInfo[] providerInfoArr = packageInfo.providers;
        if (providerInfoArr != null) {
            for (ProviderInfo providerInfo : providerInfoArr) {
                this.this$0.this$0.f640b.b(providerInfo);
            }
        }
        ActivityInfo[] activityInfoArr2 = packageInfo.receivers;
        if (activityInfoArr2 == null) {
            return null;
        }
        for (ActivityInfo activityInfo2 : activityInfoArr2) {
            this.this$0.this$0.f640b.c(activityInfo2);
        }
        return kotlin.s.a;
    }
}
