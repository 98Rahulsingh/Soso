package com.omarea.library.basic;

import android.content.Context;
import java.io.File;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class q {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final String f690a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final Context f691b;

    public q(Context context) {
        kotlin.jvm.internal.r.d(context, "context");
        this.f691b = context;
        this.f690a = context.getPackageName();
    }

    public final void a(String str) {
        String parent;
        kotlin.jvm.internal.r.d(str, "absPath");
        File file = new File(str);
        if (file.exists()) {
            String str2 = this.f690a;
            kotlin.jvm.internal.r.c(str2, "packageName");
            if (kotlin.text.k.y(str, str2, false, 2, (Object) null)) {
                file.setReadable(true, false);
                file.setExecutable(true, false);
                file.setWritable(true, false);
                String str3 = this.f690a;
                kotlin.jvm.internal.r.c(str3, "packageName");
                if (kotlin.text.k.m(str, str3, false, 2, (Object) null) || (parent = file.getParent()) == null) {
                    return;
                }
                a(parent);
            }
        }
    }
}
