package com.omarea.library.basic;

import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Environment;
import android.text.TextUtils;
import android.util.Log;
import com.omarea.Scene;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class l extends BroadcastReceiver {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private static l f683a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final a f684b = new a(null);

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(kotlin.jvm.internal.o oVar) {
            this();
        }

        public final void a(Context context) {
            kotlin.jvm.internal.r.d(context, "context");
            if (l.f683a == null) {
                l.f683a = new l();
                IntentFilter intentFilter = new IntentFilter();
                intentFilter.addAction("android.intent.action.DOWNLOAD_COMPLETE");
                context.registerReceiver(l.f683a, intentFilter);
            }
        }
    }

    private final boolean a(String str, String str2) {
        try {
            ZipOutputStream zipOutputStream = new ZipOutputStream(new FileOutputStream(new File(str2)));
            new u().a(new File(str), "", zipOutputStream);
            zipOutputStream.close();
            return true;
        } catch (Exception unused) {
            return false;
        }
    }

    private final boolean d(Context context, String str, String str2) {
        try {
            File file = new File(str2);
            if (!file.exists()) {
                return false;
            }
            ZipFile zipFile = new ZipFile(file);
            ZipInputStream zipInputStream = new ZipInputStream(new FileInputStream(file));
            String strSubstring = "";
            File cacheDir = context.getCacheDir();
            kotlin.jvm.internal.r.b(cacheDir);
            String absolutePath = new File(cacheDir.getAbsolutePath()).getAbsolutePath();
            boolean z = true;
            for (ZipEntry nextEntry = zipInputStream.getNextEntry(); nextEntry != null; nextEntry = zipInputStream.getNextEntry()) {
                String name = nextEntry.getName();
                kotlin.jvm.internal.r.c(name, "zipEntry.getName()");
                String canonicalPath = new File("/data", name).getCanonicalPath();
                kotlin.jvm.internal.r.c(canonicalPath, "vFile.canonicalPath");
                if (kotlin.text.k.t(canonicalPath, "/data", false, 2, (Object) null)) {
                    if (z) {
                        int length = name.length() - 1;
                        if (name == null) {
                            throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                        }
                        strSubstring = name.substring(0, length);
                        kotlin.jvm.internal.r.c(strSubstring, "(this as java.lang.Strin…ing(startIndex, endIndex)");
                        z = false;
                    }
                    File file2 = new File(absolutePath + File.separator + name);
                    if (nextEntry.isDirectory()) {
                        new File(absolutePath + File.separator + name).mkdirs();
                    } else {
                        File parentFile = file2.getParentFile();
                        if (parentFile != null && !parentFile.exists()) {
                            parentFile.mkdirs();
                        }
                        byte[] bArr = new byte[1024];
                        FileOutputStream fileOutputStream = new FileOutputStream(file2);
                        InputStream inputStream = zipFile.getInputStream(nextEntry);
                        kotlin.jvm.internal.r.c(inputStream, "zipFile.getInputStream(zipEntry)");
                        while (true) {
                            int i = inputStream.read(bArr);
                            if (i == -1) {
                                break;
                            }
                            fileOutputStream.write(bArr, 0, i);
                        }
                        fileOutputStream.close();
                        inputStream.close();
                    }
                } else {
                    Log.e("Scene", "Module(Zip) SecurityException EntryName: " + name);
                }
            }
            zipInputStream.close();
            return a(absolutePath + '/' + strSubstring, str);
        } catch (Exception unused) {
            return false;
        }
    }

    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        Scene.a aVar;
        String str;
        kotlin.jvm.internal.r.d(context, "context");
        kotlin.jvm.internal.r.d(intent, "intent");
        if (kotlin.jvm.internal.r.a("android.intent.action.DOWNLOAD_COMPLETE", intent.getAction())) {
            try {
                long longExtra = intent.getLongExtra("extra_download_id", -1L);
                Object systemService = context.getSystemService("download");
                try {
                    if (systemService == null) {
                        throw new NullPointerException("null cannot be cast to non-null type android.app.DownloadManager");
                    }
                    DownloadManager downloadManager = (DownloadManager) systemService;
                    TextUtils.isEmpty(downloadManager.getMimeTypeForDownloadedFile(longExtra));
                    Uri uriForDownloadedFile = downloadManager.getUriForDownloadedFile(longExtra);
                    c.i.a.a aVarE = c.i.a.a.e(context, uriForDownloadedFile);
                    kotlin.jvm.internal.r.b(aVarE);
                    String strG = aVarE.g();
                    InputStream inputStreamOpenInputStream = context.getContentResolver().openInputStream(uriForDownloadedFile);
                    byte[] bArrC = inputStreamOpenInputStream != null ? kotlin.io.a.c(inputStreamOpenInputStream) : null;
                    SharedPreferences sharedPreferences = context.getSharedPreferences("MagiskReCompress", 0);
                    if (!sharedPreferences.contains("" + longExtra)) {
                        Scene.l.k(aVarE.g() + ", OK!");
                        return;
                    }
                    String string = sharedPreferences.getString("" + longExtra, strG);
                    if (string == null) {
                        string = "Scene_Download_" + longExtra;
                    } else if (kotlin.text.k.m(string, ".zip", false, 2, (Object) null)) {
                        string = string.substring(0, kotlin.text.k.N(string, ".", 0, false, 6, (Object) null));
                        kotlin.jvm.internal.r.c(string, "(this as java.lang.Strin…ing(startIndex, endIndex)");
                    }
                    StringBuilder sb = new StringBuilder();
                    File cacheDir = context.getCacheDir();
                    kotlin.jvm.internal.r.b(cacheDir);
                    sb.append(cacheDir.getAbsolutePath());
                    sb.append("/cache_");
                    sb.append(longExtra);
                    sb.append(".zip");
                    File file = new File(sb.toString());
                    FileOutputStream fileOutputStream = new FileOutputStream(file);
                    fileOutputStream.write(bArrC);
                    fileOutputStream.flush();
                    fileOutputStream.close();
                    String absolutePath = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), '/' + string + ".zip").getAbsolutePath();
                    kotlin.jvm.internal.r.c(absolutePath, "sdcardFile.absolutePath");
                    String absolutePath2 = file.getAbsolutePath();
                    kotlin.jvm.internal.r.c(absolutePath2, "fileOut.absolutePath");
                    if (d(context, absolutePath, absolutePath2)) {
                        aVar = Scene.l;
                        str = string + ", OK!";
                    } else {
                        aVar = Scene.l;
                        str = string + ", Unable to save!";
                    }
                    aVar.k(str);
                    downloadManager.remove(longExtra);
                    return;
                } catch (Exception e) {
                    e = e;
                }
            } catch (Exception e2) {
                e = e2;
            }
            e.printStackTrace();
        }
    }
}
