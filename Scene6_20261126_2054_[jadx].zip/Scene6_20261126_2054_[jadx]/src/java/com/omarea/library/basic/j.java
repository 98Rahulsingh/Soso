package com.omarea.library.basic;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class j {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final Context f681a;

    public j(Context context) {
        kotlin.jvm.internal.r.d(context, "context");
        this.f681a = context;
    }

    public final String a() {
        try {
            Intent intent = new Intent("android.intent.action.MAIN");
            intent.addCategory("android.intent.category.HOME");
            ResolveInfo resolveInfoResolveActivity = this.f681a.getPackageManager().resolveActivity(intent, 0);
            kotlin.jvm.internal.r.b(resolveInfoResolveActivity);
            kotlin.jvm.internal.r.c(resolveInfoResolveActivity, "context.getPackageManage…olveActivity(intent, 0)!!");
            if (resolveInfoResolveActivity.activityInfo == null || kotlin.jvm.internal.r.a(resolveInfoResolveActivity.activityInfo.packageName, "android")) {
                return null;
            }
            return resolveInfoResolveActivity.activityInfo.packageName;
        } catch (Exception unused) {
            return null;
        }
    }

    public final ArrayList<String> b() {
        Intent intent = new Intent("android.intent.action.MAIN", (Uri) null);
        intent.addCategory("android.intent.category.HOME");
        List<ResolveInfo> listQueryIntentActivities = this.f681a.getPackageManager().queryIntentActivities(intent, 0);
        kotlin.jvm.internal.r.c(listQueryIntentActivities, "context.packageManager.q…ivities(resolveIntent, 0)");
        ArrayList<String> arrayList = new ArrayList<>();
        Iterator<ResolveInfo> it = listQueryIntentActivities.iterator();
        while (it.hasNext()) {
            String str = it.next().activityInfo.packageName;
            if (!kotlin.jvm.internal.r.a("com.android.settings", str)) {
                arrayList.add(str);
            }
        }
        return arrayList;
    }
}
