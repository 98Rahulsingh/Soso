package com.omarea.library.basic;

import java.util.ArrayList;
import java.util.Iterator;
import org.json.JSONException;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class m {
    private final com.omarea.f.b b(com.omarea.common.net.e eVar) {
        com.omarea.f.b bVar = new com.omarea.f.b();
        bVar.f552a = eVar.c();
        bVar.f554c = eVar.a();
        return bVar;
    }

    public final com.omarea.f.a a(String str) throws JSONException {
        kotlin.jvm.internal.r.d(str, "dir");
        com.omarea.f.a aVar = new com.omarea.f.a();
        aVar.f551c = new ArrayList<>();
        ArrayList<com.omarea.common.net.e> arrayListH = com.omarea.common.shell.g.f472a.h(str);
        ArrayList arrayList = new ArrayList();
        for (Object obj : arrayListH) {
            com.omarea.common.net.e eVar = (com.omarea.common.net.e) obj;
            if (!eVar.f() && (kotlin.jvm.internal.r.a(eVar.c(), "uevent") ^ true)) {
                arrayList.add(obj);
            }
        }
        aVar.f549a = str;
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            aVar.f551c.add(b((com.omarea.common.net.e) it.next()));
        }
        return aVar;
    }
}
