package com.omarea.library.basic;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class n {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final com.omarea.common.shared.g f685a;

    public n(com.omarea.common.shared.g gVar) {
        kotlin.jvm.internal.r.d(gVar, "resolver");
        this.f685a = gVar;
    }

    private final double a(JSONObject jSONObject, String str, double d2) {
        if (jSONObject.has(str)) {
            try {
                return Double.parseDouble(jSONObject.get(str).toString());
            } catch (Exception unused) {
            }
        }
        return d2;
    }

    private final String b(JSONObject jSONObject, String str, String str2) {
        return jSONObject.has(str) ? this.f685a.a(jSONObject.get(str).toString()) : str2;
    }

    private final com.omarea.f.a d(JSONObject jSONObject) throws JSONException {
        com.omarea.f.b bVarE;
        com.omarea.f.a aVar = new com.omarea.f.a();
        aVar.f549a = b(jSONObject, "title", "");
        aVar.f550b = b(jSONObject, "desc", "");
        aVar.f551c = new ArrayList<>();
        if (jSONObject.has("items")) {
            Object obj = jSONObject.get("items");
            if (obj instanceof JSONArray) {
                JSONArray jSONArray = (JSONArray) obj;
                int length = jSONArray.length();
                for (int i = 0; i < length; i++) {
                    Object obj2 = jSONArray.get(i);
                    if ((obj2 instanceof JSONObject) && (bVarE = e((JSONObject) obj2)) != null) {
                        aVar.f551c.add(bVarE);
                    }
                }
            }
        }
        if (aVar.f551c.size() > 0) {
            return aVar;
        }
        return null;
    }

    /* JADX WARN: Code duplicated, block: B:32:0x00e1  */
    /* JADX WARN: Code duplicated, block: B:35:0x00f4  */
    /* JADX WARN: Code duplicated, block: B:37:0x00fe  */
    /* JADX WARN: Code duplicated, block: B:41:0x0121  */
    /* JADX WARN: Code duplicated, block: B:43:0x012e  */
    /* JADX WARN: Code duplicated, block: B:45:0x0139  */
    /* JADX WARN: Code duplicated, block: B:47:0x0141  */
    /* JADX WARN: Code duplicated, block: B:49:0x0152  */
    /* JADX WARN: Code duplicated, block: B:51:0x0156  */
    /* JADX WARN: Code duplicated, block: B:55:0x0182  */
    /* JADX WARN: Code duplicated, block: B:56:0x0187  */
    /* JADX WARN: Code duplicated, block: B:63:0x0105 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:66:0x0177 A[SYNTHETIC] */
    private final com.omarea.f.b e(JSONObject jSONObject) throws JSONException {
        double d2;
        ArrayList arrayList;
        Object[] array;
        JSONArray jSONArray;
        int length;
        int i;
        Object obj;
        com.omarea.f.c cVar;
        String string;
        JSONObject jSONObject2;
        Iterator<String> itKeys;
        if (!jSONObject.has("field")) {
            return null;
        }
        Object obj2 = jSONObject.get("field");
        if (!(obj2 instanceof JSONObject)) {
            return null;
        }
        JSONObject jSONObject3 = (JSONObject) obj2;
        if (!jSONObject3.has("path")) {
            return null;
        }
        String strB = b(jSONObject3, "path", "");
        String strB2 = b(jSONObject3, "default", "");
        String strB3 = b(jSONObject, "visible", "auto");
        if (!(!kotlin.jvm.internal.r.a(strB3, "never"))) {
            return null;
        }
        if (!kotlin.jvm.internal.r.a(strB3, "always")) {
            if (!(strB.length() > 0) || !com.omarea.common.shell.g.f472a.d(strB)) {
                return null;
            }
        }
        com.omarea.f.b bVar = new com.omarea.f.b();
        bVar.f552a = b(jSONObject, "title", "");
        bVar.f553b = b(jSONObject, "desc", "");
        bVar.f554c = strB;
        bVar.g = a(jSONObject3, "min", 0.0d);
        String strB4 = b(jSONObject3, "type", "string");
        bVar.f = strB4;
        bVar.f555d = strB2;
        if (!kotlin.jvm.internal.r.a(strB4, "number")) {
            if (kotlin.jvm.internal.r.a(bVar.f, "decimal")) {
                bVar.h = a(jSONObject3, "max", 0.0d);
                d2 = 999999.99d;
            } else if (kotlin.jvm.internal.r.a(bVar.f, "boolean")) {
                bVar.i = b(jSONObject3, "on", "1");
                bVar.j = b(jSONObject3, "off", "0");
            } else {
                bVar.e = b(jSONObject3, "hint", "");
            }
            if (jSONObject.has("convert")) {
                jSONObject2 = jSONObject.getJSONObject("convert");
                itKeys = jSONObject2.keys();
                kotlin.jvm.internal.r.c(itKeys, "convert.keys()");
                while (itKeys.hasNext()) {
                    String next = itKeys.next();
                    if (bVar.l == null) {
                        bVar.l = new HashMap<>();
                    }
                    HashMap<String, String> map = bVar.l;
                    kotlin.jvm.internal.r.c(jSONObject2, "convert");
                    kotlin.jvm.internal.r.c(next, "key");
                    map.put(next, b(jSONObject2, next, ""));
                }
            }
            if (kotlin.jvm.internal.r.a(bVar.f, "select")) {
                arrayList = new ArrayList();
                if (jSONObject3.has("options")) {
                    jSONArray = jSONObject3.getJSONArray("options");
                    length = jSONArray.length();
                    for (i = 0; i < length; i++) {
                        obj = jSONArray.get(i);
                        if (obj instanceof String) {
                            cVar = new com.omarea.f.c();
                            string = (String) obj;
                            cVar.f556a = string;
                        } else {
                            if (obj instanceof JSONObject) {
                                cVar = new com.omarea.f.c();
                                com.omarea.common.shared.g gVar = this.f685a;
                                JSONObject jSONObject4 = (JSONObject) obj;
                                String string2 = jSONObject4.getString("label");
                                kotlin.jvm.internal.r.c(string2, "option.getString(\"label\")");
                                cVar.f556a = gVar.a(string2);
                                string = jSONObject4.getString("value");
                            }
                        }
                        cVar.f557b = string;
                        kotlin.s sVar = kotlin.s.a;
                        arrayList.add(cVar);
                    }
                }
                array = arrayList.toArray(new com.omarea.f.c[0]);
                if (array != null) {
                    throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T>");
                }
                bVar.k = (com.omarea.f.c[]) array;
            }
            return bVar;
        }
        bVar.h = a(jSONObject3, "max", 0.0d);
        d2 = 999999.0d;
        bVar.g = a(jSONObject3, "min", d2);
        if (jSONObject.has("convert")) {
            jSONObject2 = jSONObject.getJSONObject("convert");
            itKeys = jSONObject2.keys();
            kotlin.jvm.internal.r.c(itKeys, "convert.keys()");
            while (itKeys.hasNext()) {
                String next2 = itKeys.next();
                if (bVar.l == null) {
                    bVar.l = new HashMap<>();
                }
                HashMap<String, String> map2 = bVar.l;
                kotlin.jvm.internal.r.c(jSONObject2, "convert");
                kotlin.jvm.internal.r.c(next2, "key");
                map2.put(next2, b(jSONObject2, next2, ""));
            }
        }
        if (kotlin.jvm.internal.r.a(bVar.f, "select")) {
            arrayList = new ArrayList();
            if (jSONObject3.has("options")) {
                jSONArray = jSONObject3.getJSONArray("options");
                length = jSONArray.length();
                while (i < length) {
                    obj = jSONArray.get(i);
                    if (obj instanceof String) {
                        cVar = new com.omarea.f.c();
                        string = (String) obj;
                        cVar.f556a = string;
                    } else {
                        if (obj instanceof JSONObject) {
                            cVar = new com.omarea.f.c();
                            com.omarea.common.shared.g gVar2 = this.f685a;
                            JSONObject jSONObject5 = (JSONObject) obj;
                            String string3 = jSONObject5.getString("label");
                            kotlin.jvm.internal.r.c(string3, "option.getString(\"label\")");
                            cVar.f556a = gVar2.a(string3);
                            string = jSONObject5.getString("value");
                        }
                    }
                    cVar.f557b = string;
                    kotlin.s sVar2 = kotlin.s.a;
                    arrayList.add(cVar);
                }
            }
            array = arrayList.toArray(new com.omarea.f.c[0]);
            if (array != null) {
                throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T>");
            }
            bVar.k = (com.omarea.f.c[]) array;
        }
        return bVar;
    }

    public final ArrayList<com.omarea.f.a> c(String str) throws JSONException {
        kotlin.jvm.internal.r.d(str, "content");
        ArrayList<com.omarea.f.a> arrayList = new ArrayList<>();
        JSONArray jSONArray = new JSONArray(str);
        int length = jSONArray.length();
        for (int i = 0; i < length; i++) {
            JSONObject jSONObject = jSONArray.getJSONObject(i);
            kotlin.jvm.internal.r.c(jSONObject, "item");
            com.omarea.f.a aVarD = d(jSONObject);
            if (aVarD != null) {
                arrayList.add(aVarD);
            }
        }
        return arrayList;
    }
}
