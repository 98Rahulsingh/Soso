package com.omarea.library.basic;

import android.annotation.TargetApi;
import android.content.Context;
import android.net.Uri;
import android.preference.PreferenceManager;
import android.util.Log;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final String f674a = e.class.getSimpleName();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final List<String> f675b = new ArrayList();

    @TargetApi(19)
    private String c(File file, Context context) {
        String[] strArrD = d(context);
        for (int i = 0; i < strArrD.length; i++) {
            try {
                if (file.getCanonicalPath().startsWith(strArrD[i])) {
                    return strArrD[i];
                }
            } catch (IOException unused) {
            }
        }
        return null;
    }

    @TargetApi(19)
    private String[] d(Context context) {
        Object[] array;
        if (this.f675b.size() > 0) {
            array = this.f675b.toArray(new String[0]);
        } else {
            for (File file : context.getExternalFilesDirs("external")) {
                if (file != null && !file.equals(context.getExternalFilesDir("external"))) {
                    int iLastIndexOf = file.getAbsolutePath().lastIndexOf("/Android/data");
                    if (iLastIndexOf < 0) {
                        Log.w(this.f674a, "Unexpected external file dir: " + file.getAbsolutePath());
                    } else {
                        String strSubstring = file.getAbsolutePath().substring(0, iLastIndexOf);
                        try {
                            strSubstring = new File(strSubstring).getCanonicalPath();
                        } catch (IOException unused) {
                        }
                        this.f675b.add(strSubstring);
                    }
                }
            }
            if (this.f675b.isEmpty()) {
                this.f675b.add("/storage/sdcard1");
            }
            array = this.f675b.toArray(new String[0]);
        }
        return (String[]) array;
    }

    public boolean a(Context context, String str) {
        File file = new File(str);
        if (file.canWrite()) {
            return true;
        }
        if (e(file, context)) {
            c.i.a.a aVarB = b(file, true, context);
            return aVarB != null && aVarB.a();
        }
        String string = PreferenceManager.getDefaultSharedPreferences(context).getString(str, "");
        if (string != null && !string.isEmpty()) {
            return true;
        }
        c.i.a.a aVarF = c.i.a.a.f(context, Uri.parse(string));
        return aVarF != null && aVarF.a();
    }

    public c.i.a.a b(File file, boolean z, Context context) {
        String strSubstring;
        boolean z2;
        String strC = c(file, context);
        if (strC == null) {
            return null;
        }
        int i = 0;
        try {
            String canonicalPath = file.getCanonicalPath();
            if (strC.equals(canonicalPath)) {
                strSubstring = null;
                z2 = true;
            } else {
                strSubstring = canonicalPath.substring(strC.length() + 1);
                z2 = false;
            }
        } catch (IOException unused) {
            return null;
        } catch (Exception unused2) {
        }
        String string = PreferenceManager.getDefaultSharedPreferences(context).getString(strC, null);
        Uri uri = string != null ? Uri.parse(string) : null;
        if (uri == null) {
            return null;
        }
        c.i.a.a aVarF = c.i.a.a.f(context, uri);
        if (z2) {
            return aVarF;
        }
        String[] strArrSplit = strSubstring.split("/");
        while (i < strArrSplit.length) {
            c.i.a.a aVarD = aVarF.d(strArrSplit[i]);
            if (aVarD == null) {
                aVarF = (i < strArrSplit.length - 1 || z) ? aVarF.b(strArrSplit[i]) : aVarF.c("image", strArrSplit[i]);
            } else {
                aVarF = aVarD;
            }
            i++;
        }
        return aVarF;
    }

    @TargetApi(19)
    public boolean e(File file, Context context) {
        return c(file, context) != null;
    }

    public boolean f(Context context, String str, Uri uri) {
        c.i.a.a aVarF = c.i.a.a.f(context, uri);
        if (aVarF != null && aVarF.a()) {
            PreferenceManager.getDefaultSharedPreferences(context).edit().putString(str, uri.toString()).apply();
            return true;
        }
        Log.e(this.f674a, "no write permission: " + str);
        return false;
    }
}
