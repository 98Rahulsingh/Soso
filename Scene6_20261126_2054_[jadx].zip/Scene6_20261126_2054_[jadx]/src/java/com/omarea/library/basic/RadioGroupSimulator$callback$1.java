package com.omarea.library.basic;

import kotlin.jvm.internal.Lambda;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
final class RadioGroupSimulator$callback$1 extends Lambda implements kotlin.jvm.b.l<RadioGroupSimulator, kotlin.s> {
    public static final RadioGroupSimulator$callback$1 INSTANCE = new RadioGroupSimulator$callback$1();

    RadioGroupSimulator$callback$1() {
        super(1);
    }

    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        invoke((RadioGroupSimulator) obj);
        return kotlin.s.a;
    }

    public final void invoke(RadioGroupSimulator radioGroupSimulator) {
        kotlin.jvm.internal.r.d(radioGroupSimulator, "it");
    }
}
