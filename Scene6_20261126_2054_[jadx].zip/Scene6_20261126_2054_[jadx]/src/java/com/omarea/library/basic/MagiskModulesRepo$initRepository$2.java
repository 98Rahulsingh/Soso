package com.omarea.library.basic;

import java.util.ArrayList;
import java.util.Iterator;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlinx.coroutines.CoroutineStart;
import kotlinx.coroutines.h0;
import kotlinx.coroutines.o0;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
@kotlin.coroutines.jvm.internal.d(c = "com.omarea.library.basic.MagiskModulesRepo$initRepository$2", f = "MagiskModulesRepo.kt", l = {}, m = "invokeSuspend")
final class MagiskModulesRepo$initRepository$2 extends SuspendLambda implements kotlin.jvm.b.p<h0, kotlin.coroutines.c<? super o0<? extends kotlin.s>>, Object> {
    final /* synthetic */ ArrayList $list;
    int label;
    private h0 p$;
    final /* synthetic */ MagiskModulesRepo this$0;

    /* JADX INFO: renamed from: com.omarea.library.basic.MagiskModulesRepo$initRepository$2$1, reason: invalid class name */
    @kotlin.coroutines.jvm.internal.d(c = "com.omarea.library.basic.MagiskModulesRepo$initRepository$2$1", f = "MagiskModulesRepo.kt", l = {}, m = "invokeSuspend")
    static final class AnonymousClass1 extends SuspendLambda implements kotlin.jvm.b.p<h0, kotlin.coroutines.c<? super kotlin.s>, Object> {
        int label;
        private h0 p$;

        AnonymousClass1(kotlin.coroutines.c cVar) {
            super(2, cVar);
        }

        public final kotlin.coroutines.c<kotlin.s> create(Object obj, kotlin.coroutines.c<?> cVar) {
            kotlin.jvm.internal.r.d(cVar, "completion");
            AnonymousClass1 anonymousClass1 = MagiskModulesRepo$initRepository$2.this.new AnonymousClass1(cVar);
            anonymousClass1.p$ = (h0) obj;
            return anonymousClass1;
        }

        public final Object invoke(Object obj, Object obj2) {
            return create(obj, (kotlin.coroutines.c) obj2).invokeSuspend(kotlin.s.a);
        }

        public final Object invokeSuspend(Object obj) {
            kotlin.coroutines.intrinsics.a.d();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            kotlin.h.b(obj);
            Iterator it = MagiskModulesRepo$initRepository$2.this.$list.iterator();
            while (it.hasNext()) {
                com.omarea.store.g.b bVarC = MagiskModulesRepo$initRepository$2.this.this$0.c(((com.omarea.store.g.a) it.next()).getPropUrl());
                if (bVarC != null) {
                    kotlin.coroutines.jvm.internal.a.a(MagiskModulesRepo$initRepository$2.this.this$0.f663a.b(bVarC));
                }
            }
            return kotlin.s.a;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    MagiskModulesRepo$initRepository$2(MagiskModulesRepo magiskModulesRepo, ArrayList arrayList, kotlin.coroutines.c cVar) {
        super(2, cVar);
        this.this$0 = magiskModulesRepo;
        this.$list = arrayList;
    }

    public final kotlin.coroutines.c<kotlin.s> create(Object obj, kotlin.coroutines.c<?> cVar) {
        kotlin.jvm.internal.r.d(cVar, "completion");
        MagiskModulesRepo$initRepository$2 magiskModulesRepo$initRepository$2 = new MagiskModulesRepo$initRepository$2(this.this$0, this.$list, cVar);
        magiskModulesRepo$initRepository$2.p$ = (h0) obj;
        return magiskModulesRepo$initRepository$2;
    }

    public final Object invoke(Object obj, Object obj2) {
        return create(obj, (kotlin.coroutines.c) obj2).invokeSuspend(kotlin.s.a);
    }

    public final Object invokeSuspend(Object obj) {
        kotlin.coroutines.intrinsics.a.d();
        if (this.label != 0) {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        kotlin.h.b(obj);
        return kotlinx.coroutines.f.b(this.p$, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass1(null), 3, (Object) null);
    }
}
