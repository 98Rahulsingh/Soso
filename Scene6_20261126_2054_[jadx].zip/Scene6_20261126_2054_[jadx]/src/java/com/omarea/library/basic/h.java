package com.omarea.library.basic;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import java.io.File;
import java.util.Set;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class h {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final String[] f676a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final PackageManager f677b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final SharedPreferences f678c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private final String[] f679d;
    private final Context e;

    public h(Context context) {
        kotlin.jvm.internal.r.d(context, "context");
        this.e = context;
        String[] stringArray = context.getResources().getStringArray(2130903053);
        kotlin.jvm.internal.r.c(stringArray, "context.resources.getStr…(R.array.games_blacklist)");
        this.f676a = stringArray;
        this.f677b = this.e.getPackageManager();
        this.f678c = this.e.getSharedPreferences("games", 0);
        this.f679d = new String[]{"libunity.so", "libil2cpp.so", "libUE4.so"};
    }

    private final boolean c(ApplicationInfo applicationInfo) throws PackageManager.NameNotFoundException {
        File file;
        Set<String> setKeySet;
        if (kotlin.collections.h.j(this.f676a, applicationInfo.packageName)) {
            return false;
        }
        boolean z = (Build.VERSION.SDK_INT >= 26 && applicationInfo.category == 0) || (applicationInfo.flags & 33554432) == 33554432;
        Object obj = null;
        if (!z) {
            Intent launchIntentForPackage = this.f677b.getLaunchIntentForPackage(applicationInfo.packageName);
            ComponentName component = launchIntentForPackage != null ? launchIntentForPackage.getComponent() : null;
            if (component != null) {
                ActivityInfo activityInfo = this.f677b.getActivityInfo(component, 0);
                kotlin.jvm.internal.r.c(activityInfo, "packageManager.getActivityInfo(componentName, 0)");
                int i = activityInfo.screenOrientation;
                if (i == 0 || i == 6 || i == 8 || i == 11) {
                    z = true;
                }
            }
        }
        if (!z) {
            File[] fileArrListFiles = new File(applicationInfo.nativeLibraryDir).listFiles();
            if (fileArrListFiles == null) {
                file = null;
                break;
            }
            int length = fileArrListFiles.length;
            int i2 = 0;
            while (true) {
                if (i2 >= length) {
                    file = null;
                    break;
                }
                file = fileArrListFiles[i2];
                if (file != null && kotlin.collections.h.j(this.f679d, file.getName())) {
                    break;
                }
                i2++;
            }
            if (file != null) {
                return true;
            }
            Bundle bundle = applicationInfo.metaData;
            if (bundle != null && (setKeySet = bundle.keySet()) != null) {
                for (Object obj2 : setKeySet) {
                    String str = (String) obj2;
                    if (str != null && kotlin.text.k.y(str, "game", false, 2, (Object) null)) {
                        obj = obj2;
                        break;
                    }
                }
                obj = (String) obj;
            }
            if (obj != null) {
                return true;
            }
        }
        return z;
    }

    public final SharedPreferences a() {
        return this.f678c;
    }

    public final Boolean b(String str) {
        kotlin.jvm.internal.r.d(str, "app");
        if (this.f678c.contains(str)) {
            return Boolean.valueOf(this.f678c.getBoolean(str, false));
        }
        try {
            ApplicationInfo applicationInfo = this.f677b.getApplicationInfo(str, 128);
            kotlin.jvm.internal.r.c(applicationInfo, "packageManager.getApplic…ageManager.GET_META_DATA)");
            boolean zC = c(applicationInfo);
            this.f678c.edit().putBoolean(str, zC).apply();
            return Boolean.valueOf(zC);
        } catch (Exception unused) {
            return null;
        }
    }
}
