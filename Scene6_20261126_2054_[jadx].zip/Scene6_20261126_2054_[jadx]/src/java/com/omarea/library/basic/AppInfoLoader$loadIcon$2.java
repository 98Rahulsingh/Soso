package com.omarea.library.basic;

import android.graphics.drawable.Drawable;
import android.util.LruCache;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlinx.coroutines.h0;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
@kotlin.coroutines.jvm.internal.d(c = "com.omarea.library.basic.AppInfoLoader$loadIcon$2", f = "AppInfoLoader.kt", l = {}, m = "invokeSuspend")
final class AppInfoLoader$loadIcon$2 extends SuspendLambda implements kotlin.jvm.b.p<h0, kotlin.coroutines.c<? super Drawable>, Object> {
    final /* synthetic */ String $packageName;
    int label;
    private h0 p$;
    final /* synthetic */ AppInfoLoader this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    AppInfoLoader$loadIcon$2(AppInfoLoader appInfoLoader, String str, kotlin.coroutines.c cVar) {
        super(2, cVar);
        this.this$0 = appInfoLoader;
        this.$packageName = str;
    }

    public final kotlin.coroutines.c<kotlin.s> create(Object obj, kotlin.coroutines.c<?> cVar) {
        kotlin.jvm.internal.r.d(cVar, "completion");
        AppInfoLoader$loadIcon$2 appInfoLoader$loadIcon$2 = new AppInfoLoader$loadIcon$2(this.this$0, this.$packageName, cVar);
        appInfoLoader$loadIcon$2.p$ = (h0) obj;
        return appInfoLoader$loadIcon$2;
    }

    public final Object invoke(Object obj, Object obj2) {
        return create(obj, (kotlin.coroutines.c) obj2).invokeSuspend(kotlin.s.a);
    }

    public final Object invokeSuspend(Object obj) {
        kotlin.coroutines.intrinsics.a.d();
        if (this.label != 0) {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        kotlin.h.b(obj);
        LruCache lruCache = this.this$0.f642a;
        Drawable drawableLoadIcon = null;
        Drawable drawable = lruCache != null ? (Drawable) lruCache.get(this.$packageName) : null;
        if (drawable != null) {
            return drawable;
        }
        try {
            drawableLoadIcon = this.this$0.c().getPackageInfo(this.$packageName, 0).applicationInfo.loadIcon(this.this$0.c());
            this.this$0.g(this.$packageName, drawableLoadIcon);
            return drawableLoadIcon;
        } catch (Exception unused) {
            return drawableLoadIcon;
        }
    }
}
