package com.omarea.library.basic;

import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.util.LruCache;
import com.omarea.model.AppInfo;
import kotlinx.coroutines.CoroutineStart;
import kotlinx.coroutines.h1;
import kotlinx.coroutines.o0;
import kotlinx.coroutines.w0;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class AppInfoLoader {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final LruCache<String, Drawable> f642a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private PackageManager f643b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final Context f644c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private final int f645d;

    public static final class a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private String f646a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private Drawable f647b;

        public a(String str, Drawable drawable) {
            kotlin.jvm.internal.r.d(str, "appName");
            this.f646a = str;
            this.f647b = drawable;
        }

        public final String a() {
            return this.f646a;
        }

        public final Drawable b() {
            return this.f647b;
        }
    }

    public AppInfoLoader(Context context, int i) {
        kotlin.jvm.internal.r.d(context, "context");
        this.f644c = context;
        this.f645d = i;
        this.f642a = i < 1 ? null : new LruCache<>(this.f645d);
    }

    public /* synthetic */ AppInfoLoader(Context context, int i, int i2, kotlin.jvm.internal.o oVar) {
        this(context, (i2 & 2) != 0 ? 0 : i);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void g(String str, Drawable drawable) {
        LruCache<String, Drawable> lruCache = this.f642a;
        if (lruCache == null || drawable == null) {
            return;
        }
        lruCache.put(str, drawable);
    }

    protected final PackageManager c() {
        if (this.f643b == null) {
            this.f643b = this.f644c.getPackageManager();
        }
        PackageManager packageManager = this.f643b;
        kotlin.jvm.internal.r.b(packageManager);
        return packageManager;
    }

    public final o0<a> d(String str) {
        kotlin.jvm.internal.r.d(str, "packageName");
        return kotlinx.coroutines.f.b(h1.f, w0.b(), (CoroutineStart) null, new AppInfoLoader$loadAppBasicInfo$1(this, str, null), 2, (Object) null);
    }

    public final o0<Drawable> e(AppInfo appInfo) {
        kotlin.jvm.internal.r.d(appInfo, "item");
        return kotlinx.coroutines.f.b(h1.f, w0.b(), (CoroutineStart) null, new AppInfoLoader$loadIcon$1(this, appInfo, null), 2, (Object) null);
    }

    public final o0<Drawable> f(String str) {
        kotlin.jvm.internal.r.d(str, "packageName");
        return kotlinx.coroutines.f.b(h1.f, w0.b(), (CoroutineStart) null, new AppInfoLoader$loadIcon$2(this, str, null), 2, (Object) null);
    }
}
