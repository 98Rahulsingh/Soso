package com.omarea.library.basic;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.net.Uri;
import android.os.Environment;
import android.webkit.URLUtil;
import android.widget.Toast;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class k {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private Context f682a;

    public k(Context context, Activity activity) {
        kotlin.jvm.internal.r.d(context, "context");
        this.f682a = context;
    }

    public final Long a(String str, String str2, String str3, String str4, boolean z) {
        kotlin.jvm.internal.r.d(str, "url");
        kotlin.jvm.internal.r.d(str2, "contentDisposition");
        kotlin.jvm.internal.r.d(str3, "mimeType");
        kotlin.jvm.internal.r.d(str4, "fileName");
        try {
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(str));
            request.allowScanningByMediaScanner();
            boolean z2 = true;
            request.setNotificationVisibility(1);
            request.setAllowedOverMetered(true);
            request.setVisibleInDownloadsUi(true);
            request.setAllowedOverRoaming(true);
            if (str4.length() != 0) {
                z2 = false;
            }
            if (z2) {
                str4 = URLUtil.guessFileName(str, str2, str3);
            }
            request.setDescription(str4);
            request.setTitle(str4);
            Toast.makeText(this.f682a, this.f682a.getString(2131886827), 0).show();
            l.a aVar = l.f684b;
            Context applicationContext = this.f682a.getApplicationContext();
            kotlin.jvm.internal.r.c(applicationContext, "context.applicationContext");
            aVar.a(applicationContext);
            Object systemService = this.f682a.getSystemService("download");
            if (systemService == null) {
                throw new NullPointerException("null cannot be cast to non-null type android.app.DownloadManager");
            }
            DownloadManager downloadManager = (DownloadManager) systemService;
            if (!z) {
                request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, str4);
                return Long.valueOf(downloadManager.enqueue(request));
            }
            long jEnqueue = downloadManager.enqueue(request);
            this.f682a.getSharedPreferences("MagiskReCompress", 0).edit().putString("" + jEnqueue, str4).apply();
            return Long.valueOf(jEnqueue);
        } catch (Exception e) {
            com.omarea.common.ui.e.a aVar2 = com.omarea.common.ui.e.f492b;
            Context context = this.f682a;
            String string = context.getString(2131886826);
            kotlin.jvm.internal.r.c(string, "context.getString(R.stri….kr_download_create_fail)");
            com.omarea.common.ui.e.a.A(aVar2, context, string, "" + e.getMessage(), null, 8, null);
            return null;
        }
    }
}
