package com.omarea.library.basic;

import android.util.Log;
import kotlin.text.Regex;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class f {
    public final String a(String str) {
        kotlin.jvm.internal.r.d(str, "origin");
        try {
            return new Regex("\r\t").replace(new Regex("\r\n").replace(str, "\n"), "\t");
        } catch (Exception e) {
            Log.e("Dos2Unix", "" + e.getMessage());
            return "";
        }
    }
}
