package com.omarea.library.basic;

import android.widget.SeekBar;
import android.widget.TextView;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.internal.Ref;
import kotlinx.coroutines.h0;
import kotlinx.coroutines.w0;
import kotlinx.coroutines.z1;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
@kotlin.coroutines.jvm.internal.d(c = "com.omarea.library.basic.FormValueHandler$bindInput$1", f = "FormValueHandler.kt", l = {61}, m = "invokeSuspend")
final class FormValueHandler$bindInput$1 extends SuspendLambda implements kotlin.jvm.b.p<h0, kotlin.coroutines.c<? super kotlin.s>, Object> {
    final /* synthetic */ FormValueHandler.b $inputHandler;
    final /* synthetic */ SeekBar $seekBar;
    final /* synthetic */ TextView $valueView;
    Object L$0;
    Object L$1;
    int label;
    private h0 p$;

    /* JADX INFO: renamed from: com.omarea.library.basic.FormValueHandler$bindInput$1$1, reason: invalid class name */
    @kotlin.coroutines.jvm.internal.d(c = "com.omarea.library.basic.FormValueHandler$bindInput$1$1", f = "FormValueHandler.kt", l = {}, m = "invokeSuspend")
    static final class AnonymousClass1 extends SuspendLambda implements kotlin.jvm.b.p<h0, kotlin.coroutines.c<? super kotlin.s>, Object> {
        final /* synthetic */ Ref.IntRef $value;
        int label;
        private h0 p$;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass1(Ref.IntRef intRef, kotlin.coroutines.c cVar) {
            super(2, cVar);
            this.$value = intRef;
        }

        public final kotlin.coroutines.c<kotlin.s> create(Object obj, kotlin.coroutines.c<?> cVar) {
            kotlin.jvm.internal.r.d(cVar, "completion");
            AnonymousClass1 anonymousClass1 = FormValueHandler$bindInput$1.this.new AnonymousClass1(this.$value, cVar);
            anonymousClass1.p$ = (h0) obj;
            return anonymousClass1;
        }

        public final Object invoke(Object obj, Object obj2) {
            return create(obj, (kotlin.coroutines.c) obj2).invokeSuspend(kotlin.s.a);
        }

        public final Object invokeSuspend(Object obj) {
            kotlin.coroutines.intrinsics.a.d();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            kotlin.h.b(obj);
            TextView textView = FormValueHandler$bindInput$1.this.$valueView;
            if (textView != null) {
                textView.setText(String.valueOf(this.$value.element));
            }
            FormValueHandler$bindInput$1.this.$seekBar.setProgress(this.$value.element);
            return kotlin.s.a;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    FormValueHandler$bindInput$1(FormValueHandler.b bVar, TextView textView, SeekBar seekBar, kotlin.coroutines.c cVar) {
        super(2, cVar);
        this.$inputHandler = bVar;
        this.$valueView = textView;
        this.$seekBar = seekBar;
    }

    public final kotlin.coroutines.c<kotlin.s> create(Object obj, kotlin.coroutines.c<?> cVar) {
        kotlin.jvm.internal.r.d(cVar, "completion");
        FormValueHandler$bindInput$1 formValueHandler$bindInput$1 = new FormValueHandler$bindInput$1(this.$inputHandler, this.$valueView, this.$seekBar, cVar);
        formValueHandler$bindInput$1.p$ = (h0) obj;
        return formValueHandler$bindInput$1;
    }

    public final Object invoke(Object obj, Object obj2) {
        return create(obj, (kotlin.coroutines.c) obj2).invokeSuspend(kotlin.s.a);
    }

    public final Object invokeSuspend(Object obj) {
        Object objD = kotlin.coroutines.intrinsics.a.d();
        int i = this.label;
        try {
            if (i == 0) {
                kotlin.h.b(obj);
                h0 h0Var = this.p$;
                Ref.IntRef intRef = new Ref.IntRef();
                intRef.element = ((Number) this.$inputHandler.getValue()).intValue();
                z1 z1VarC = w0.c();
                AnonymousClass1 anonymousClass1 = new AnonymousClass1(intRef, null);
                this.L$0 = h0Var;
                this.L$1 = intRef;
                this.label = 1;
                if (kotlinx.coroutines.f.g(z1VarC, anonymousClass1, this) == objD) {
                    return objD;
                }
            } else {
                if (i != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.h.b(obj);
            }
        } catch (Exception unused) {
        }
        return kotlin.s.a;
    }
}
