package com.omarea.library.basic;

import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class p {
    public final boolean a(Context context, ComponentName componentName) {
        kotlin.jvm.internal.r.d(context, "context");
        kotlin.jvm.internal.r.d(componentName, "componentName");
        Object systemService = context.getSystemService("activity");
        if (systemService != null) {
            return ((ActivityManager) systemService).getRunningServiceControlPanel(componentName) != null;
        }
        throw new NullPointerException("null cannot be cast to non-null type android.app.ActivityManager");
    }
}
