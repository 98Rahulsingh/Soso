package com.omarea.library.basic;

import android.view.View;
import android.widget.CompoundButton;
import java.util.ArrayList;
import java.util.Iterator;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class RadioGroupSimulator {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final ArrayList<CompoundButton> f665a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private kotlin.jvm.b.l<? super RadioGroupSimulator, kotlin.s> f666b;

    static final class a implements View.OnClickListener {
        a() {
        }

        @Override // android.view.View.OnClickListener
        public final void onClick(View view) {
            if (view == null) {
                throw new NullPointerException("null cannot be cast to non-null type android.widget.CompoundButton");
            }
            CompoundButton compoundButton = (CompoundButton) view;
            if (compoundButton.isChecked()) {
                RadioGroupSimulator.this.e(compoundButton);
            } else {
                RadioGroupSimulator.this.d(compoundButton);
            }
            RadioGroupSimulator.this.f666b.invoke(RadioGroupSimulator.this);
        }
    }

    static final class b implements CompoundButton.OnCheckedChangeListener {
        b() {
        }

        @Override // android.widget.CompoundButton.OnCheckedChangeListener
        public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
            if (z) {
                RadioGroupSimulator radioGroupSimulator = RadioGroupSimulator.this;
                kotlin.jvm.internal.r.c(compoundButton, "compoundButton");
                radioGroupSimulator.e(compoundButton);
            }
        }
    }

    public RadioGroupSimulator(Iterator<? extends CompoundButton> it) {
        kotlin.jvm.internal.r.d(it, "items");
        this.f665a = new ArrayList<>();
        this.f666b = RadioGroupSimulator$callback$1.INSTANCE;
        j(it);
    }

    public RadioGroupSimulator(CompoundButton... compoundButtonArr) {
        kotlin.jvm.internal.r.d(compoundButtonArr, "items");
        this.f665a = new ArrayList<>();
        this.f666b = RadioGroupSimulator$callback$1.INSTANCE;
        j(kotlin.jvm.internal.h.a(compoundButtonArr));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void d(CompoundButton compoundButton) {
        ArrayList<CompoundButton> arrayList = this.f665a;
        ArrayList arrayList2 = new ArrayList();
        Iterator<T> it = arrayList.iterator();
        while (true) {
            if (!it.hasNext()) {
                break;
            }
            Object next = it.next();
            CompoundButton compoundButton2 = (CompoundButton) next;
            if (compoundButton2.isChecked() && (kotlin.jvm.internal.r.a(compoundButton2, compoundButton) ^ true)) {
                arrayList2.add(next);
            }
        }
        if (arrayList2.isEmpty()) {
            compoundButton.setChecked(true);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void e(CompoundButton compoundButton) {
        for (CompoundButton compoundButton2 : this.f665a) {
            if (!kotlin.jvm.internal.r.a(compoundButton2, compoundButton)) {
                compoundButton2.setChecked(false);
            }
        }
    }

    private final void j(Iterator<? extends CompoundButton> it) {
        while (it.hasNext()) {
            CompoundButton next = it.next();
            this.f665a.add(next);
            next.setOnClickListener(new a());
            next.setOnCheckedChangeListener(new b());
        }
        ArrayList<CompoundButton> arrayList = this.f665a;
        ArrayList<CompoundButton> arrayList2 = new ArrayList();
        for (Object obj : arrayList) {
            if (((CompoundButton) obj).isChecked()) {
                arrayList2.add(obj);
            }
        }
        if (arrayList2.size() > 0) {
            CompoundButton compoundButton = (CompoundButton) kotlin.collections.q.B(arrayList2);
            for (CompoundButton compoundButton2 : arrayList2) {
                if (!kotlin.jvm.internal.r.a(compoundButton2, compoundButton)) {
                    compoundButton2.setChecked(false);
                }
            }
        }
    }

    public final CompoundButton f() {
        Object next;
        Iterator<T> it = this.f665a.iterator();
        while (it.hasNext()) {
            next = it.next();
            if (((CompoundButton) next).isChecked()) {
                return (CompoundButton) next;
            }
        }
        next = null;
        return (CompoundButton) next;
    }

    public final int g() {
        CompoundButton compoundButtonF = f();
        if (compoundButtonF != null) {
            return this.f665a.indexOf(compoundButtonF);
        }
        return -1;
    }

    public final void h(Object obj) {
        Object next;
        kotlin.jvm.internal.r.d(obj, "value");
        Iterator<T> it = this.f665a.iterator();
        do {
            if (!it.hasNext()) {
                next = null;
                break;
            }
            next = it.next();
        } while (!kotlin.jvm.internal.r.a(((CompoundButton) next).getTag(), obj));
        CompoundButton compoundButton = (CompoundButton) next;
        if (compoundButton != null) {
            compoundButton.setChecked(true);
        }
    }

    public final void i(kotlin.jvm.b.l<? super RadioGroupSimulator, kotlin.s> lVar) {
        kotlin.jvm.internal.r.d(lVar, "callback");
        this.f666b = lVar;
    }
}
