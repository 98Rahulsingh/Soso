package com.omarea.library.basic;

import android.view.View;
import android.widget.AdapterView;
import android.widget.Spinner;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.internal.Ref;
import kotlinx.coroutines.h0;
import kotlinx.coroutines.w0;
import kotlinx.coroutines.z1;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
@kotlin.coroutines.jvm.internal.d(c = "com.omarea.library.basic.FormValueHandler$bindInput$10", f = "FormValueHandler.kt", l = {240}, m = "invokeSuspend")
final class FormValueHandler$bindInput$10 extends SuspendLambda implements kotlin.jvm.b.p<h0, kotlin.coroutines.c<? super kotlin.s>, Object> {
    final /* synthetic */ FormValueHandler.b $inputHandler;
    final /* synthetic */ Ref.IntRef $selectedItemPosition;
    final /* synthetic */ Spinner $spinner;
    int I$0;
    Object L$0;
    int label;
    private h0 p$;

    /* JADX INFO: renamed from: com.omarea.library.basic.FormValueHandler$bindInput$10$1, reason: invalid class name */
    @kotlin.coroutines.jvm.internal.d(c = "com.omarea.library.basic.FormValueHandler$bindInput$10$1", f = "FormValueHandler.kt", l = {}, m = "invokeSuspend")
    static final class AnonymousClass1 extends SuspendLambda implements kotlin.jvm.b.p<h0, kotlin.coroutines.c<? super kotlin.s>, Object> {
        int label;
        private h0 p$;

        /* JADX INFO: renamed from: com.omarea.library.basic.FormValueHandler$bindInput$10$1$a */
        public static final class a implements AdapterView.OnItemSelectedListener {
            a() {
            }

            @Override // android.widget.AdapterView.OnItemSelectedListener
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
                FormValueHandler$bindInput$10 formValueHandler$bindInput$10 = FormValueHandler$bindInput$10.this;
                Ref.IntRef intRef = formValueHandler$bindInput$10.$selectedItemPosition;
                if (i != intRef.element) {
                    intRef.element = i;
                    formValueHandler$bindInput$10.$inputHandler.setValue(Integer.valueOf(i));
                }
            }

            @Override // android.widget.AdapterView.OnItemSelectedListener
            public void onNothingSelected(AdapterView<?> adapterView) {
                FormValueHandler$bindInput$10 formValueHandler$bindInput$10 = FormValueHandler$bindInput$10.this;
                Ref.IntRef intRef = formValueHandler$bindInput$10.$selectedItemPosition;
                if (-1 != intRef.element) {
                    intRef.element = -1;
                    formValueHandler$bindInput$10.$inputHandler.setValue(-1);
                }
            }
        }

        AnonymousClass1(kotlin.coroutines.c cVar) {
            super(2, cVar);
        }

        public final kotlin.coroutines.c<kotlin.s> create(Object obj, kotlin.coroutines.c<?> cVar) {
            kotlin.jvm.internal.r.d(cVar, "completion");
            AnonymousClass1 anonymousClass1 = FormValueHandler$bindInput$10.this.new AnonymousClass1(cVar);
            anonymousClass1.p$ = (h0) obj;
            return anonymousClass1;
        }

        public final Object invoke(Object obj, Object obj2) {
            return create(obj, (kotlin.coroutines.c) obj2).invokeSuspend(kotlin.s.a);
        }

        public final Object invokeSuspend(Object obj) {
            kotlin.coroutines.intrinsics.a.d();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            kotlin.h.b(obj);
            FormValueHandler$bindInput$10 formValueHandler$bindInput$10 = FormValueHandler$bindInput$10.this;
            formValueHandler$bindInput$10.$spinner.setSelection(formValueHandler$bindInput$10.$selectedItemPosition.element);
            FormValueHandler$bindInput$10.this.$spinner.setOnItemSelectedListener(new a());
            return kotlin.s.a;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    FormValueHandler$bindInput$10(FormValueHandler.b bVar, Ref.IntRef intRef, Spinner spinner, kotlin.coroutines.c cVar) {
        super(2, cVar);
        this.$inputHandler = bVar;
        this.$selectedItemPosition = intRef;
        this.$spinner = spinner;
    }

    public final kotlin.coroutines.c<kotlin.s> create(Object obj, kotlin.coroutines.c<?> cVar) {
        kotlin.jvm.internal.r.d(cVar, "completion");
        FormValueHandler$bindInput$10 formValueHandler$bindInput$10 = new FormValueHandler$bindInput$10(this.$inputHandler, this.$selectedItemPosition, this.$spinner, cVar);
        formValueHandler$bindInput$10.p$ = (h0) obj;
        return formValueHandler$bindInput$10;
    }

    public final Object invoke(Object obj, Object obj2) {
        return create(obj, (kotlin.coroutines.c) obj2).invokeSuspend(kotlin.s.a);
    }

    public final Object invokeSuspend(Object obj) {
        Object objD = kotlin.coroutines.intrinsics.a.d();
        int i = this.label;
        try {
            if (i == 0) {
                kotlin.h.b(obj);
                h0 h0Var = this.p$;
                int iIntValue = ((Number) this.$inputHandler.getValue()).intValue();
                if (iIntValue != this.$selectedItemPosition.element) {
                    this.$selectedItemPosition.element = iIntValue;
                    this.$inputHandler.setValue(kotlin.coroutines.jvm.internal.a.e(this.$selectedItemPosition.element));
                }
                z1 z1VarC = w0.c();
                AnonymousClass1 anonymousClass1 = new AnonymousClass1(null);
                this.L$0 = h0Var;
                this.I$0 = iIntValue;
                this.label = 1;
                if (kotlinx.coroutines.f.g(z1VarC, anonymousClass1, this) == objD) {
                    return objD;
                }
            } else {
                if (i != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.h.b(obj);
            }
        } catch (Exception unused) {
        }
        return kotlin.s.a;
    }
}
