package com.omarea.library.basic;

import android.content.Context;
import com.omarea.vtools.AccessibilitySceneMode;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class a {
    public final boolean a(Context context) {
        kotlin.jvm.internal.r.d(context, "context");
        return new b().a(context, "AccessibilitySceneMode");
    }

    public final void b(Context context) {
        kotlin.jvm.internal.r.d(context, "context");
        new com.omarea.library.shell.a().a(context.getPackageName() + '/' + AccessibilitySceneMode.class.getName());
        new b().b(context, "AccessibilitySceneMode");
    }
}
