package com.omarea.library.basic;

import android.content.Context;
import android.provider.Settings;
import android.view.inputmethod.InputMethodInfo;
import android.view.inputmethod.InputMethodManager;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class i {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private Context f680a;

    public i(Context context) {
        kotlin.jvm.internal.r.d(context, "context");
        this.f680a = context;
    }

    public final ArrayList<String> a() {
        try {
            String string = Settings.Secure.getString(this.f680a.getContentResolver(), "enabled_input_methods");
            if (!(string == null || string.length() == 0)) {
                ArrayList<String> arrayList = new ArrayList<>();
                List listW = kotlin.text.k.W(string, new String[]{":"}, false, 0, 6, (Object) null);
                ArrayList arrayList2 = new ArrayList(kotlin.collections.q.k(listW, 10));
                Iterator it = listW.iterator();
                while (it.hasNext()) {
                    arrayList2.add((String) kotlin.collections.q.t(kotlin.text.k.W((String) it.next(), new String[]{"/"}, false, 0, 6, (Object) null)));
                }
                kotlin.collections.q.S(arrayList2, arrayList);
                return arrayList;
            }
        } catch (Exception unused) {
        }
        ArrayList<String> arrayList3 = new ArrayList<>();
        InputMethodManager inputMethodManager = (InputMethodManager) this.f680a.getSystemService("input_method");
        if (inputMethodManager != null) {
            for (InputMethodInfo inputMethodInfo : inputMethodManager.getInputMethodList()) {
                kotlin.jvm.internal.r.c(inputMethodInfo, "input");
                arrayList3.add(inputMethodInfo.getPackageName());
            }
        }
        return arrayList3;
    }
}
