package com.omarea.library.basic;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import java.util.ArrayList;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class t {
    public ArrayList<ApplicationInfo> a(Context context) {
        ArrayList<ApplicationInfo> arrayList = new ArrayList<>();
        PackageManager packageManager = context.getPackageManager();
        for (PackageInfo packageInfo : packageManager.getInstalledPackages(8192)) {
            try {
                try {
                    packageManager.getApplicationInfo(packageInfo.packageName, 0);
                } catch (Exception unused) {
                    if (Build.VERSION.SDK_INT >= 24) {
                        arrayList.add(packageManager.getApplicationInfo(packageInfo.packageName, 8192));
                    }
                }
            } catch (Exception unused2) {
            }
        }
        return arrayList;
    }
}
