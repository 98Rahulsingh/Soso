package com.omarea.library.basic;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.view.accessibility.AccessibilityManager;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class b {
    public final boolean a(Context context, String str) {
        kotlin.jvm.internal.r.d(context, "context");
        kotlin.jvm.internal.r.d(str, "serviceName");
        Object systemService = context.getSystemService("accessibility");
        if (systemService == null) {
            throw new NullPointerException("null cannot be cast to non-null type android.view.accessibility.AccessibilityManager");
        }
        for (AccessibilityServiceInfo accessibilityServiceInfo : ((AccessibilityManager) systemService).getEnabledAccessibilityServiceList(-1)) {
            kotlin.jvm.internal.r.c(accessibilityServiceInfo, "serviceInfo");
            String id = accessibilityServiceInfo.getId();
            kotlin.jvm.internal.r.c(id, "serviceInfo.id");
            if (kotlin.text.k.m(id, str, false, 2, (Object) null)) {
                return true;
            }
        }
        return false;
    }

    public final boolean b(Context context, String str) {
        kotlin.jvm.internal.r.d(context, "context");
        kotlin.jvm.internal.r.d(str, "serviceName");
        Object systemService = context.getSystemService("accessibility");
        if (systemService == null) {
            throw new NullPointerException("null cannot be cast to non-null type android.view.accessibility.AccessibilityManager");
        }
        for (AccessibilityServiceInfo accessibilityServiceInfo : ((AccessibilityManager) systemService).getEnabledAccessibilityServiceList(-1)) {
            kotlin.jvm.internal.r.c(accessibilityServiceInfo, "serviceInfo");
            String id = accessibilityServiceInfo.getId();
            kotlin.jvm.internal.r.c(id, "serviceInfo.id");
            if (kotlin.text.k.m(id, str, false, 2, (Object) null)) {
                ServiceInfo serviceInfo = accessibilityServiceInfo.getResolveInfo().serviceInfo;
                Intent intent = new Intent();
                intent.setComponent(new ComponentName(serviceInfo.packageName, serviceInfo.name));
                context.stopService(intent);
                return true;
            }
        }
        return false;
    }
}
