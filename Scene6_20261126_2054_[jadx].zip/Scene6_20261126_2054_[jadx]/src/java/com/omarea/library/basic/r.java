package com.omarea.library.basic;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class r {
    public double a(Float[] fArr) {
        double d2 = 0.0d;
        double dFloatValue = 0.0d;
        for (Float f : fArr) {
            dFloatValue += (double) f.floatValue();
        }
        double length = dFloatValue / ((double) fArr.length);
        for (Float f2 : fArr) {
            double dFloatValue2 = ((double) f2.floatValue()) - length;
            d2 += dFloatValue2 * dFloatValue2;
        }
        return d2 / ((double) fArr.length);
    }
}
