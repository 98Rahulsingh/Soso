package com.omarea.library.basic;

import android.widget.EditText;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.internal.Ref;
import kotlinx.coroutines.h0;
import kotlinx.coroutines.w0;
import kotlinx.coroutines.z1;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
@kotlin.coroutines.jvm.internal.d(c = "com.omarea.library.basic.FormValueHandler$bindInputDecimal$1", f = "FormValueHandler.kt", l = {146}, m = "invokeSuspend")
final class FormValueHandler$bindInputDecimal$1 extends SuspendLambda implements kotlin.jvm.b.p<h0, kotlin.coroutines.c<? super kotlin.s>, Object> {
    final /* synthetic */ Ref.DoubleRef $currentValue;
    final /* synthetic */ EditText $editText;
    final /* synthetic */ FormValueHandler.b $inputHandler;
    Object L$0;
    Object L$1;
    int label;
    private h0 p$;

    /* JADX INFO: renamed from: com.omarea.library.basic.FormValueHandler$bindInputDecimal$1$1, reason: invalid class name */
    @kotlin.coroutines.jvm.internal.d(c = "com.omarea.library.basic.FormValueHandler$bindInputDecimal$1$1", f = "FormValueHandler.kt", l = {}, m = "invokeSuspend")
    static final class AnonymousClass1 extends SuspendLambda implements kotlin.jvm.b.p<h0, kotlin.coroutines.c<? super kotlin.s>, Object> {
        final /* synthetic */ Ref.DoubleRef $value;
        int label;
        private h0 p$;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass1(Ref.DoubleRef doubleRef, kotlin.coroutines.c cVar) {
            super(2, cVar);
            this.$value = doubleRef;
        }

        public final kotlin.coroutines.c<kotlin.s> create(Object obj, kotlin.coroutines.c<?> cVar) {
            kotlin.jvm.internal.r.d(cVar, "completion");
            AnonymousClass1 anonymousClass1 = FormValueHandler$bindInputDecimal$1.this.new AnonymousClass1(this.$value, cVar);
            anonymousClass1.p$ = (h0) obj;
            return anonymousClass1;
        }

        public final Object invoke(Object obj, Object obj2) {
            return create(obj, (kotlin.coroutines.c) obj2).invokeSuspend(kotlin.s.a);
        }

        public final Object invokeSuspend(Object obj) {
            kotlin.coroutines.intrinsics.a.d();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            kotlin.h.b(obj);
            FormValueHandler$bindInputDecimal$1.this.$editText.setText(String.valueOf(this.$value.element));
            return kotlin.s.a;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    FormValueHandler$bindInputDecimal$1(FormValueHandler.b bVar, Ref.DoubleRef doubleRef, EditText editText, kotlin.coroutines.c cVar) {
        super(2, cVar);
        this.$inputHandler = bVar;
        this.$currentValue = doubleRef;
        this.$editText = editText;
    }

    public final kotlin.coroutines.c<kotlin.s> create(Object obj, kotlin.coroutines.c<?> cVar) {
        kotlin.jvm.internal.r.d(cVar, "completion");
        FormValueHandler$bindInputDecimal$1 formValueHandler$bindInputDecimal$1 = new FormValueHandler$bindInputDecimal$1(this.$inputHandler, this.$currentValue, this.$editText, cVar);
        formValueHandler$bindInputDecimal$1.p$ = (h0) obj;
        return formValueHandler$bindInputDecimal$1;
    }

    public final Object invoke(Object obj, Object obj2) {
        return create(obj, (kotlin.coroutines.c) obj2).invokeSuspend(kotlin.s.a);
    }

    public final Object invokeSuspend(Object obj) {
        Object objD = kotlin.coroutines.intrinsics.a.d();
        int i = this.label;
        try {
            if (i == 0) {
                kotlin.h.b(obj);
                h0 h0Var = this.p$;
                Ref.DoubleRef doubleRef = new Ref.DoubleRef();
                double dDoubleValue = ((Number) this.$inputHandler.getValue()).doubleValue();
                doubleRef.element = dDoubleValue;
                this.$currentValue.element = dDoubleValue;
                z1 z1VarC = w0.c();
                AnonymousClass1 anonymousClass1 = new AnonymousClass1(doubleRef, null);
                this.L$0 = h0Var;
                this.L$1 = doubleRef;
                this.label = 1;
                if (kotlinx.coroutines.f.g(z1VarC, anonymousClass1, this) == objD) {
                    return objD;
                }
            } else {
                if (i != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.h.b(obj);
            }
        } catch (Exception unused) {
        }
        return kotlin.s.a;
    }
}
