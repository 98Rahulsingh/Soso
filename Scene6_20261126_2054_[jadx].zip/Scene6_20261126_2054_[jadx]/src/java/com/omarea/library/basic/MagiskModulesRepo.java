package com.omarea.library.basic;

import android.content.Context;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import kotlinx.coroutines.w0;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class MagiskModulesRepo {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final com.omarea.store.g f663a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final Context f664b;

    public MagiskModulesRepo(Context context) {
        kotlin.jvm.internal.r.d(context, "context");
        this.f664b = context;
        this.f663a = new com.omarea.store.g(this.f664b);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    public final com.omarea.store.g.b c(String str) {
        try {
            URLConnection uRLConnectionOpenConnection = new URL(str).openConnection();
            kotlin.jvm.internal.r.c(uRLConnectionOpenConnection, "connection");
            uRLConnectionOpenConnection.setConnectTimeout(1000);
            uRLConnectionOpenConnection.setConnectTimeout(5000);
            uRLConnectionOpenConnection.connect();
            InputStream inputStream = uRLConnectionOpenConnection.getInputStream();
            kotlin.jvm.internal.r.c(inputStream, "connection.getInputStream()");
            List listW = kotlin.text.k.W(new String(kotlin.io.a.c(inputStream), kotlin.text.d.a), new String[]{"\n"}, false, 0, 6, (Object) null);
            com.omarea.store.g.b bVar = new com.omarea.store.g.b();
            Iterator it = listW.iterator();
            while (true) {
                if (it.hasNext()) {
                    String str2 = (String) it.next();
                    int iH = kotlin.text.k.H(str2, "=", 0, false, 6, (Object) null);
                    if (iH > 0) {
                        if (str2 == null) {
                            throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                        }
                        String strSubstring = str2.substring(0, iH);
                        kotlin.jvm.internal.r.c(strSubstring, "(this as java.lang.Strin…ing(startIndex, endIndex)");
                        int i = iH + 1;
                        if (str2 == null) {
                            throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                        }
                        String strSubstring2 = str2.substring(i);
                        kotlin.jvm.internal.r.c(strSubstring2, "(this as java.lang.String).substring(startIndex)");
                        if (strSubstring2 == null) {
                            throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
                        }
                        String string = kotlin.text.k.k0(strSubstring2).toString();
                        switch (strSubstring.hashCode()) {
                            case -1854767153:
                                if (!strSubstring.equals("support")) {
                                    continue;
                                } else {
                                    bVar.setSupport(string);
                                }
                                break;
                            case -1724546052:
                                if (!strSubstring.equals("description")) {
                                    continue;
                                } else {
                                    bVar.setDescription(string);
                                }
                                break;
                            case -1406328437:
                                if (!strSubstring.equals("author")) {
                                    continue;
                                } else {
                                    bVar.setAuthor(string);
                                }
                                break;
                            case -1326167441:
                                if (!strSubstring.equals("donate")) {
                                    continue;
                                } else {
                                    bVar.setDonate(string);
                                }
                                break;
                            case -1321546630:
                                if (!strSubstring.equals("template")) {
                                    continue;
                                } else {
                                    bVar.setTemplate(string);
                                }
                                break;
                            case 3355:
                                if (!strSubstring.equals("id")) {
                                    continue;
                                } else {
                                    bVar.setId(string);
                                }
                                break;
                            case 3373707:
                                if (!strSubstring.equals("name")) {
                                    continue;
                                } else {
                                    bVar.setName(string);
                                }
                                break;
                            case 351608024:
                                if (!strSubstring.equals("version")) {
                                }
                                break;
                            case 688591589:
                                if (!strSubstring.equals("versionCode")) {
                                    continue;
                                } else {
                                    bVar.setVersionCode(string);
                                }
                                break;
                            case 688906115:
                                if (!strSubstring.equals("versionName")) {
                                }
                                break;
                            default:
                                continue;
                        }
                        bVar.setVersionName(string);
                    }
                } else if (bVar.getId().length() > 0) {
                    return bVar;
                }
            }
        } catch (Exception unused) {
        }
        return null;
    }

    public final Object d(kotlin.coroutines.c<? super kotlin.s> cVar) throws JSONException, IOException {
        URLConnection uRLConnectionOpenConnection = new URL("https://magisk-modules-repo.github.io/submission/modules.json").openConnection();
        uRLConnectionOpenConnection.connect();
        InputStream inputStream = uRLConnectionOpenConnection.getInputStream();
        kotlin.jvm.internal.r.c(inputStream, "connection.getInputStream()");
        JSONArray jSONArray = new JSONObject(new String(kotlin.io.a.c(inputStream), kotlin.text.d.a)).getJSONArray("modules");
        int length = jSONArray.length();
        this.f663a.a();
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < length; i++) {
            JSONObject jSONObject = jSONArray.getJSONObject(i);
            com.omarea.store.g.a aVar = new com.omarea.store.g.a();
            String string = jSONObject.getString("id");
            kotlin.jvm.internal.r.c(string, "item.getString(\"id\")");
            aVar.setId(string);
            aVar.setLastUpdate(jSONObject.getLong("last_update"));
            String string2 = jSONObject.getString("prop_url");
            kotlin.jvm.internal.r.c(string2, "item.getString(\"prop_url\")");
            aVar.setPropUrl(string2);
            String string3 = jSONObject.getString("zip_url");
            kotlin.jvm.internal.r.c(string3, "item.getString(\"zip_url\")");
            aVar.setZipUrl(string3);
            String string4 = jSONObject.getString("notes_url");
            kotlin.jvm.internal.r.c(string4, "item.getString(\"notes_url\")");
            aVar.setNotesUrl(string4);
            arrayList.add(aVar);
        }
        Object objG = kotlinx.coroutines.f.g(w0.b(), new MagiskModulesRepo$initRepository$2(this, arrayList, null), cVar);
        return objG == kotlin.coroutines.intrinsics.a.d() ? objG : kotlin.s.a;
    }

    public final ArrayList<com.omarea.store.g.b> e() {
        return this.f663a.c();
    }
}
