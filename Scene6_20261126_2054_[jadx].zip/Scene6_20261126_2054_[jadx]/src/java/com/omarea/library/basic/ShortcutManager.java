package com.omarea.library.basic;

import android.annotation.TargetApi;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ShortcutInfo;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.util.Log;
import com.omarea.vtools.activities.ActivityQuickStart;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class ShortcutManager {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private Context f668a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final boolean f669b;

    public ShortcutManager(Context context, boolean z) {
        kotlin.jvm.internal.r.d(context, "context");
        this.f668a = context;
        this.f669b = z;
    }

    private final boolean b(Intent intent, String str, Drawable drawable) {
        try {
            Intent intent2 = new Intent("com.android.launcher.action.INSTALL_SHORTCUT");
            intent2.putExtra("android.intent.extra.shortcut.NAME", str);
            intent2.putExtra("duplicate", false);
            if (drawable == null) {
                throw new NullPointerException("null cannot be cast to non-null type android.graphics.drawable.BitmapDrawable");
            }
            intent2.putExtra("android.intent.extra.shortcut.ICON", ((BitmapDrawable) drawable).getBitmap());
            Intent intent3 = new Intent("android.intent.action.MAIN");
            Context applicationContext = this.f668a.getApplicationContext();
            ComponentName component = intent.getComponent();
            kotlin.jvm.internal.r.b(component);
            kotlin.jvm.internal.r.c(component, "intent.component!!");
            intent3.setClassName(applicationContext, component.getClassName());
            intent3.putExtras(intent);
            intent2.putExtra("android.intent.extra.shortcut.INTENT", intent3);
            this.f668a.sendBroadcast(intent2);
            return true;
        } catch (Exception e) {
            Log.e("ShortcutManager", "" + e.getMessage());
            return false;
        }
    }

    private final String c(Intent intent) {
        StringBuilder sb = new StringBuilder();
        ComponentName component = intent.getComponent();
        kotlin.jvm.internal.r.b(component);
        kotlin.jvm.internal.r.c(component, "intent.component!!");
        sb.append(component.getPackageName());
        sb.append("/");
        ComponentName component2 = intent.getComponent();
        kotlin.jvm.internal.r.b(component2);
        kotlin.jvm.internal.r.c(component2, "intent.component!!");
        sb.append(component2.getClassName());
        return sb.toString();
    }

    public final boolean a(Intent intent, String str, Drawable drawable) {
        kotlin.jvm.internal.r.d(intent, "intent");
        kotlin.jvm.internal.r.d(str, "title");
        kotlin.jvm.internal.r.d(drawable, "drawable");
        return Build.VERSION.SDK_INT >= 26 ? d(intent, str, drawable) : b(intent, str, drawable);
    }

    @TargetApi(26)
    public final boolean d(Intent intent, String str, Drawable drawable) {
        kotlin.jvm.internal.r.d(intent, "intent");
        kotlin.jvm.internal.r.d(str, "title");
        kotlin.jvm.internal.r.d(drawable, "drawable");
        try {
            Object systemService = this.f668a.getSystemService("shortcut");
            if (systemService == null) {
                throw new NullPointerException("null cannot be cast to non-null type android.content.pm.ShortcutManager");
            }
            android.content.pm.ShortcutManager shortcutManager = (android.content.pm.ShortcutManager) systemService;
            if (shortcutManager.isRequestPinShortcutSupported()) {
                Intent intent2 = new Intent("android.intent.action.MAIN");
                intent2.putExtras(intent);
                if (this.f669b) {
                    intent2.setClassName(this.f668a, new ComponentName(this.f668a, (Class<?>) ActivityQuickStart.class).getClassName());
                    intent2.setFlags(1082130432);
                    ComponentName component = intent.getComponent();
                    intent2.putExtra("packageName", component != null ? component.getPackageName() : null);
                    ComponentName component2 = intent.getComponent();
                    kotlin.jvm.internal.r.c(intent2.putExtra("className", component2 != null ? component2.getClassName() : null), "shortcutIntent.run {\n   …me)\n                    }");
                } else {
                    intent2.setComponent(intent.getComponent());
                }
                String strC = c(intent);
                ShortcutInfo.Builder intent3 = new ShortcutInfo.Builder(this.f668a, strC).setIcon(Icon.createWithBitmap(((BitmapDrawable) drawable).getBitmap())).setShortLabel(str).setIntent(intent2);
                if (this.f669b) {
                    kotlin.jvm.internal.r.c(intent3.setActivity(new ComponentName(this.f668a, (Class<?>) ActivityQuickStart.class)), "setActivity(ComponentNam…yQuickStart::class.java))");
                }
                final ShortcutInfo shortcutInfoBuild = intent3.build();
                kotlin.jvm.internal.r.c(shortcutInfoBuild, "ShortcutInfo.Builder(con…                 .build()");
                PendingIntent broadcast = PendingIntent.getBroadcast(this.f668a, 0, new Intent(), 134217728);
                List<ShortcutInfo> pinnedShortcuts = shortcutManager.getPinnedShortcuts();
                kotlin.jvm.internal.r.c(pinnedShortcuts, "shortcutManager.pinnedShortcuts");
                for (ShortcutInfo shortcutInfo : pinnedShortcuts) {
                    kotlin.jvm.internal.r.c(shortcutInfo, "item");
                    if (kotlin.jvm.internal.r.a(shortcutInfo.getId(), strC)) {
                        shortcutManager.updateShortcuts(new ArrayList<ShortcutInfo>(shortcutInfoBuild) { // from class: com.omarea.library.basic.ShortcutManager$createShortcutOreo$2
                            final /* synthetic */ ShortcutInfo $info;

                            {
                                this.$info = shortcutInfoBuild;
                                add(shortcutInfoBuild);
                            }

                            public /* bridge */ boolean contains(ShortcutInfo shortcutInfo2) {
                                return super.contains((Object) shortcutInfo2);
                            }

                            @Override // java.util.ArrayList, java.util.AbstractCollection, java.util.Collection, java.util.List
                            public final /* bridge */ boolean contains(Object obj) {
                                if (obj instanceof ShortcutInfo) {
                                    return contains((ShortcutInfo) obj);
                                }
                                return false;
                            }

                            public /* bridge */ int getSize() {
                                return super.size();
                            }

                            public /* bridge */ int indexOf(ShortcutInfo shortcutInfo2) {
                                return super.indexOf((Object) shortcutInfo2);
                            }

                            @Override // java.util.ArrayList, java.util.AbstractList, java.util.List
                            public final /* bridge */ int indexOf(Object obj) {
                                if (obj instanceof ShortcutInfo) {
                                    return indexOf((ShortcutInfo) obj);
                                }
                                return -1;
                            }

                            public /* bridge */ int lastIndexOf(ShortcutInfo shortcutInfo2) {
                                return super.lastIndexOf((Object) shortcutInfo2);
                            }

                            @Override // java.util.ArrayList, java.util.AbstractList, java.util.List
                            public final /* bridge */ int lastIndexOf(Object obj) {
                                if (obj instanceof ShortcutInfo) {
                                    return lastIndexOf((ShortcutInfo) obj);
                                }
                                return -1;
                            }

                            @Override // java.util.ArrayList, java.util.AbstractList, java.util.List
                            public final /* bridge */ ShortcutInfo remove(int i) {
                                return removeAt(i);
                            }

                            public /* bridge */ boolean remove(ShortcutInfo shortcutInfo2) {
                                return super.remove((Object) shortcutInfo2);
                            }

                            @Override // java.util.ArrayList, java.util.AbstractCollection, java.util.Collection, java.util.List
                            public final /* bridge */ boolean remove(Object obj) {
                                if (obj instanceof ShortcutInfo) {
                                    return remove((ShortcutInfo) obj);
                                }
                                return false;
                            }

                            public /* bridge */ ShortcutInfo removeAt(int i) {
                                return (ShortcutInfo) super.remove(i);
                            }

                            @Override // java.util.ArrayList, java.util.AbstractCollection, java.util.Collection, java.util.List
                            public final /* bridge */ int size() {
                                return getSize();
                            }
                        });
                        return true;
                    }
                }
                kotlin.jvm.internal.r.c(broadcast, "shortcutCallbackIntent");
                shortcutManager.requestPinShortcut(shortcutInfoBuild, broadcast.getIntentSender());
            }
            return true;
        } catch (Exception e) {
            Log.e("ShortcutManager", "" + e.getMessage());
            return false;
        }
    }
}
