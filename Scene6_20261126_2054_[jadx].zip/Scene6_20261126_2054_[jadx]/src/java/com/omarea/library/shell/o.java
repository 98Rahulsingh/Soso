package com.omarea.library.shell;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class o {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final String f764a = "/sys/module/lowmemorykiller/parameters/minfree";

    public final void a(long j) {
        float f = 1.0f;
        if (j > 8589934592L) {
            f = 2.0f;
        } else if (j > 6442450944L) {
            f = 1.5f;
        } else if (j <= 4294967296L && j <= 3221225472L) {
            if (j > 2147483648L) {
                f = 0.7f;
            } else {
                long j2 = 1073741824;
                if (j > j2) {
                    f = 0.5f;
                } else {
                    f = j > j2 ? 0.25f : 0.2f;
                }
            }
        }
        StringBuilder sb = new StringBuilder();
        sb.append("chmod 666 /sys/module/lowmemorykiller/parameters/minfree\n");
        sb.append("echo \"" + ((int) (((float) 10240) * f)) + ',' + ((int) (16384 * f)) + ',' + ((int) (18432 * f)) + ',' + ((int) (20480 * f)) + ',' + ((int) (30720 * f)) + ',' + ((int) (33280 * f)) + "\" > /sys/module/lowmemorykiller/parameters/minfree\n");
        StringBuilder sb2 = new StringBuilder();
        sb2.append("chmod 666 ");
        sb2.append("/sys/module/lowmemorykiller/parameters/enable_adaptive_lmk");
        sb2.append('\n');
        sb.append(sb2.toString());
        StringBuilder sb3 = new StringBuilder();
        sb3.append("echo 0 > ");
        sb3.append("/sys/module/lowmemorykiller/parameters/enable_adaptive_lmk");
        sb3.append('\n');
        sb.append(sb3.toString());
        com.omarea.common.shell.e eVar = com.omarea.common.shell.e.f469b;
        String string = sb.toString();
        kotlin.jvm.internal.r.c(string, "cmds.toString()");
        eVar.e(string);
    }

    public final String b() {
        return com.omarea.common.shell.f.f471b.a(this.f764a);
    }

    public final boolean c() {
        return com.omarea.common.shell.g.f472a.d(this.f764a);
    }
}
