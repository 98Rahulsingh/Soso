package com.omarea.library.shell;

import com.omarea.common.net.Daemon;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class z {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final a f784a = new a(null);

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(kotlin.jvm.internal.o oVar) {
            this();
        }

        public final double a(String str) {
            kotlin.jvm.internal.r.d(str, "sensorName");
            int iX0 = Daemon.E.a().x0(str);
            return iX0 > -1 ? ((double) (iX0 / 100)) / 10.0d : iX0;
        }
    }
}
