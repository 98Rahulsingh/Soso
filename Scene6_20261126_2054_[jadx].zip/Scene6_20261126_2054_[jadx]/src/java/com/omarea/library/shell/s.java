package com.omarea.library.shell;

import java.util.Iterator;
import java.util.List;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class s {
    public final int a(String str) {
        Object next;
        String strE = com.omarea.common.shell.e.f469b.e(com.omarea.e.b.f546d.a() + " pidof '" + str + "' 2>/dev/null || pidof '" + str + "' 2>/dev/null");
        if (strE == null) {
            throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
        }
        String string = kotlin.text.k.k0(strE).toString();
        if ((string.length() == 0) || kotlin.jvm.internal.r.a(string, "error")) {
            return -1;
        }
        List listW = kotlin.text.k.W(string, new String[]{" "}, false, 0, 6, (Object) null);
        if (listW.size() > 1) {
            String strA = com.omarea.common.shell.f.f471b.a("/dev/cpuset/top-app/cgroup.procs");
            if (strA == null) {
                throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
            }
            List listW2 = kotlin.text.k.W(kotlin.text.k.k0(strA).toString(), new String[]{" "}, false, 0, 6, (Object) null);
            Iterator it = listW.iterator();
            do {
                if (!it.hasNext()) {
                    next = null;
                    break;
                }
                next = it.next();
            } while (!listW2.contains((String) next));
            String str2 = (String) next;
            if (str2 != null) {
                return Integer.parseInt(str2);
            }
        }
        return Integer.parseInt((String) kotlin.collections.q.t(listW));
    }
}
