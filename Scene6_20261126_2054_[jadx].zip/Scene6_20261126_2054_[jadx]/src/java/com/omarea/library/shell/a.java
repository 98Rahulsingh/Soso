package com.omarea.library.shell;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class a {
    public final boolean a(String str) {
        kotlin.jvm.internal.r.d(str, "serviceName");
        String strE = com.omarea.common.shell.e.f469b.e("settings get secure enabled_accessibility_services");
        if (kotlin.text.k.y(strE, str, false, 2, (Object) null)) {
            StringBuilder sb = new StringBuilder();
            for (String str2 : kotlin.text.k.W(strE, new String[]{":"}, false, 0, 6, (Object) null)) {
                if (!kotlin.jvm.internal.r.a(str2, str)) {
                    if (sb.length() > 0) {
                        sb.append(":");
                    }
                    sb.append(str2);
                }
            }
            com.omarea.common.shell.e.f469b.e("settings put secure enabled_accessibility_services " + ((Object) sb) + "\nsettings put secure accessibility_enabled 1");
        }
        return true;
    }
}
