package com.omarea.library.shell;

import com.omarea.common.net.Daemon;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class f {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private String f740b;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private final boolean f742d;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final String f739a = "/sys/class/devfreq/mtk-dvfsrc-devfreq/cur_freq";

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final String f741c = "/sys/devices/system/cpu/bus_dcvs/DDR/cur_freq";

    public f() {
        this.f742d = kotlin.text.k.H(new r().b(), "mt", 0, false, 6, (Object) null) == 0;
    }

    private final int b() {
        if (this.f740b == null) {
            this.f740b = "";
            String[] strArr = {"/sys/kernel/helio-dvfsrc/dvfsrc_dump", "/sys/devices/platform/10012000.dvfsrc/helio-dvfsrc/dvfsrc_dump", "/sys/devices/platform/1c00f000.dvfsrc/1c00f000.dvfsrc:dvfsrc-helper/dvfsrc_dump", "/sys/devices/platform/soc/1c00f000.dvfsrc/helio-dvfsrc/dvfsrc_dump", "/sys/class/devfreq/mtk-dvfsrc-devfreq/cur_freq"};
            for (int i = 0; i < 5; i++) {
                String str = strArr[i];
                if (com.omarea.common.shell.g.f472a.d(str)) {
                    this.f740b = str;
                    break;
                }
            }
        }
        if (kotlin.jvm.internal.r.a(this.f740b, "")) {
            return -1;
        }
        if (kotlin.jvm.internal.r.a(this.f740b, this.f739a)) {
            return c();
        }
        com.omarea.common.shell.f fVar = com.omarea.common.shell.f.f471b;
        String str2 = this.f740b;
        kotlin.jvm.internal.r.b(str2);
        String strA = fVar.a(str2);
        if (kotlin.text.k.y(strA, "DDR", false, 2, (Object) null)) {
            List listW = kotlin.text.k.W(strA, new String[]{"\n"}, false, 0, 6, (Object) null);
            ArrayList arrayList = new ArrayList();
            for (Object obj : listW) {
                String str3 = (String) obj;
                if (kotlin.text.k.t(str3, "DDR", false, 2, (Object) null) && kotlin.text.k.y(str3, ":", false, 2, (Object) null)) {
                    arrayList.add(obj);
                }
            }
            String str4 = (String) kotlin.collections.q.u(arrayList);
            if (str4 != null) {
                String str5 = (String) kotlin.collections.q.B(kotlin.text.k.W(str4, new String[]{":"}, false, 0, 6, (Object) null));
                Locale locale = Locale.ENGLISH;
                kotlin.jvm.internal.r.c(locale, "Locale.ENGLISH");
                if (str5 == null) {
                    throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                }
                String lowerCase = str5.toLowerCase(locale);
                kotlin.jvm.internal.r.c(lowerCase, "(this as java.lang.String).toLowerCase(locale)");
                String strR = kotlin.text.k.r(lowerCase, "khz", "", false, 4, (Object) null);
                if (strR == null) {
                    throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
                }
                try {
                    return Integer.parseInt(kotlin.text.k.k0(strR).toString()) / 1000;
                } catch (Exception unused) {
                    return -1;
                }
            }
        }
        return -1;
    }

    private final int c() {
        try {
            long j = 1000;
            return (int) (((Long.parseLong(com.omarea.common.shell.f.f471b.a(this.f739a)) / j) / j) / ((long) 2));
        } catch (Exception unused) {
            return -1;
        }
    }

    public final int a() {
        if (kotlin.jvm.internal.r.a(Daemon.E.c(), "root")) {
            return this.f742d ? b() : d();
        }
        return -1;
    }

    public final int d() {
        String str = this.f740b;
        if (str == null) {
            if (com.omarea.common.shell.g.f472a.d(this.f741c)) {
                this.f740b = this.f741c;
            } else {
                this.f740b = "";
            }
        } else if (kotlin.jvm.internal.r.a(str, "")) {
            return -1;
        }
        try {
            return Integer.parseInt(com.omarea.common.shell.f.f471b.a(this.f741c)) / 500;
        } catch (Exception unused) {
            return -1;
        }
    }
}
