package com.omarea.library.shell;

import android.content.Context;
import android.os.Build;
import java.io.File;
import java.nio.charset.Charset;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class g {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final com.omarea.library.basic.q f743a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final Context f744b;

    public g(Context context) {
        kotlin.jvm.internal.r.d(context, "context");
        this.f744b = context;
        this.f743a = new com.omarea.library.basic.q(context);
    }

    private final boolean c() {
        try {
            byte[] bArrA = com.omarea.common.shared.f.f453a.a(this.f744b, 2131820547);
            com.omarea.common.shared.d.f450b.h(bArrA, "scene-daemon", this.f744b);
            com.omarea.common.shared.d.f450b.h(bArrA, "scene-daemon-bak", this.f744b);
            f(com.omarea.common.shared.d.f450b.b(this.f744b, "scene-daemon"));
            return true;
        } catch (Exception unused) {
            return false;
        }
    }

    private final boolean d() {
        try {
            String strB = com.omarea.common.shared.f.f453a.b(this.f744b, 2131820560);
            com.omarea.common.shared.d dVar = com.omarea.common.shared.d.f450b;
            Charset charset = kotlin.text.d.a;
            if (strB == null) {
                throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
            }
            byte[] bytes = strB.getBytes(charset);
            kotlin.jvm.internal.r.c(bytes, "(this as java.lang.String).getBytes(charset)");
            dVar.h(bytes, "rish.sh", this.f744b);
            f(com.omarea.common.shared.d.f450b.b(this.f744b, "rish.sh"));
            com.omarea.common.shared.d.f450b.h(com.omarea.common.shared.f.f453a.a(this.f744b, 2131820561), "rish_shizuku.dex", this.f744b);
            f(com.omarea.common.shared.d.f450b.b(this.f744b, "rish_shizuku.dex"));
            return true;
        } catch (Exception unused) {
            return false;
        }
    }

    private final boolean e() {
        try {
            String strB = com.omarea.common.shared.f.f453a.b(this.f744b, 2131820565);
            com.omarea.common.shared.d dVar = com.omarea.common.shared.d.f450b;
            Charset charset = kotlin.text.d.a;
            if (strB == null) {
                throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
            }
            byte[] bytes = strB.getBytes(charset);
            kotlin.jvm.internal.r.c(bytes, "(this as java.lang.String).getBytes(charset)");
            dVar.h(bytes, "up.sh", this.f744b);
            f(com.omarea.common.shared.d.f450b.b(this.f744b, "up.sh"));
            return true;
        } catch (Exception unused) {
            return false;
        }
    }

    private final void f(String str) {
        this.f743a.a(str);
    }

    public final String a() {
        if (Build.VERSION.SDK_INT >= 30) {
            b();
        }
        d();
        if (!new File(com.omarea.common.shared.d.f450b.b(this.f744b, "categories.json")).exists()) {
            com.omarea.common.shared.d.f450b.i("categories.json", "categories.json", this.f744b);
        }
        if (c() && e()) {
            return com.omarea.common.shared.d.f450b.b(this.f744b, "up.sh");
        }
        return null;
    }

    public final void b() {
        com.omarea.common.shared.d.f450b.f(this.f744b, com.omarea.common.shared.f.f453a.a(this.f744b, 2131820547), "daemon");
        String strB = com.omarea.common.shared.f.f453a.b(this.f744b, 2131820562);
        com.omarea.common.shared.d dVar = com.omarea.common.shared.d.f450b;
        Context context = this.f744b;
        Charset charset = kotlin.text.d.a;
        if (strB == null) {
            throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
        }
        byte[] bytes = strB.getBytes(charset);
        kotlin.jvm.internal.r.c(bytes, "(this as java.lang.String).getBytes(charset)");
        dVar.f(context, bytes, "up.sh");
        com.omarea.common.shared.d.f450b.e(this.f744b, "toolkit/busybox", true);
        com.omarea.common.shared.d.f450b.e(this.f744b, "toolkit/toybox-outside64", true);
        String strB2 = com.omarea.common.shared.f.f453a.b(this.f744b, 2131820560);
        com.omarea.common.shared.d dVar2 = com.omarea.common.shared.d.f450b;
        Context context2 = this.f744b;
        Charset charset2 = kotlin.text.d.a;
        if (strB2 == null) {
            throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
        }
        byte[] bytes2 = strB2.getBytes(charset2);
        kotlin.jvm.internal.r.c(bytes2, "(this as java.lang.String).getBytes(charset)");
        dVar2.f(context2, bytes2, "rish.sh");
        com.omarea.common.shared.d.f450b.f(this.f744b, com.omarea.common.shared.f.f453a.a(this.f744b, 2131820561), "rish_shizuku.dex");
    }
}
