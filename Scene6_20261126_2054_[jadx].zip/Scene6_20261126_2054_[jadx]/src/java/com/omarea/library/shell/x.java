package com.omarea.library.shell;

import com.omarea.model.CpuStatus;
import java.util.AbstractMap;
import java.util.ArrayList;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class x {
    private void b(ArrayList<AbstractMap.SimpleEntry<String, String>> arrayList, String str, String str2) {
        arrayList.add(new AbstractMap.SimpleEntry<>(str, str2));
    }

    public ArrayList<AbstractMap.SimpleEntry<String, String>> a(CpuStatus cpuStatus, ArrayList<AbstractMap.SimpleEntry<String, String>> arrayList) {
        String str = cpuStatus.coreControl;
        if (str != null && !str.isEmpty()) {
            b(arrayList, "/sys/module/msm_thermal/core_control/enabled", cpuStatus.coreControl);
        }
        String str2 = cpuStatus.vdd;
        if (str2 != null && !str2.isEmpty()) {
            b(arrayList, "/sys/module/msm_thermal/vdd_restriction/enabled", cpuStatus.vdd);
        }
        String str3 = cpuStatus.msmThermal;
        if (str3 != null && !str3.isEmpty()) {
            b(arrayList, "/sys/module/msm_thermal/parameters/enabled", cpuStatus.msmThermal);
        }
        return arrayList;
    }

    public String c() {
        return com.omarea.common.shell.f.f471b.a("/sys/module/msm_thermal/core_control/enabled").trim();
    }

    public String d() {
        return com.omarea.common.shell.f.f471b.a("/sys/module/msm_thermal/parameters/enabled").trim();
    }

    public String e() {
        return com.omarea.common.shell.f.f471b.a("/sys/module/msm_thermal/vdd_restriction/enabled").trim();
    }

    public Boolean f() {
        return Boolean.valueOf(com.omarea.common.shell.g.f472a.g("/sys/module/msm_thermal/core_control/enabled") || com.omarea.common.shell.g.f472a.g("/sys/module/msm_thermal/vdd_restriction/enabled") || com.omarea.common.shell.g.f472a.g("/sys/module/msm_thermal/parameters/enabled"));
    }

    public void g(Boolean bool) {
        String str = bool.booleanValue() ? "1" : "0";
        ArrayList arrayList = new ArrayList();
        arrayList.add("chmod 0664 /sys/module/msm_thermal/core_control/enabled");
        arrayList.add("echo " + str + " > /sys/module/msm_thermal/core_control/enabled");
        com.omarea.common.shell.e.f469b.d(arrayList);
    }

    public void h(Boolean bool) {
        String str = bool.booleanValue() ? "Y" : "N";
        ArrayList arrayList = new ArrayList();
        arrayList.add("chmod 0664 /sys/module/msm_thermal/parameters/enabled");
        arrayList.add("echo " + str + " > /sys/module/msm_thermal/parameters/enabled");
        com.omarea.common.shell.e.f469b.d(arrayList);
    }

    public void i(Boolean bool) {
        String str = bool.booleanValue() ? "1" : "0";
        ArrayList arrayList = new ArrayList();
        arrayList.add("chmod 0664 /sys/module/msm_thermal/vdd_restriction/enabled");
        arrayList.add("echo " + str + " > /sys/module/msm_thermal/vdd_restriction/enabled");
        com.omarea.common.shell.e.f469b.d(arrayList);
    }
}
