package com.omarea.library.shell;

import com.omarea.common.net.Daemon;
import java.util.ArrayList;
import java.util.Iterator;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class u {
    public final String a() {
        Object next;
        String str;
        JSONObject jSONObjectS0 = Daemon.E.a().s0();
        if (jSONObjectS0 != null) {
            String[] strArr = {"serial_id", "serial_no", "cpu_id", "gid"};
            ArrayList arrayList = new ArrayList(4);
            for (int i = 0; i < 4; i++) {
                String str2 = strArr[i];
                arrayList.add(jSONObjectS0.has(str2) ? jSONObjectS0.getString(str2) : "");
            }
            Iterator it = arrayList.iterator();
            do {
                if (!it.hasNext()) {
                    next = null;
                    break;
                }
                next = it.next();
                str = (String) next;
                kotlin.jvm.internal.r.c(str, "it");
            } while (!(str.length() > 0));
            String str3 = (String) next;
            if (str3 != null) {
                return str3;
            }
        }
        return "";
    }

    public String toString() {
        return a().toString();
    }
}
