package com.omarea.library.shell;

import com.omarea.common.net.Daemon;
import com.omarea.model.BatteryStatus;
import java.util.List;
import java.util.ListIterator;
import kotlin.coroutines.CoroutineContext;
import kotlin.text.Regex;
import kotlinx.coroutines.CoroutineStart;
import kotlinx.coroutines.i0;
import kotlinx.coroutines.w0;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class BatteryUtils {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private static boolean f692c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private static Boolean f693d;
    public static final a e = new a(null);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private Boolean f694a = Boolean.FALSE;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private Boolean f695b;

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(kotlin.jvm.internal.o oVar) {
            this();
        }

        public final BatteryStatus a() {
            List<String> listW = kotlin.text.k.W(Daemon.E.a().d0("battery"), new String[]{"\n"}, false, 0, 6, (Object) null);
            BatteryStatus batteryStatus = new BatteryStatus();
            boolean z = false;
            boolean z2 = false;
            boolean z3 = false;
            for (String str : listW) {
                if (str == null) {
                    throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
                }
                String string = kotlin.text.k.k0(str).toString();
                int iH = kotlin.text.k.H(string, ":", 0, false, 6, (Object) null);
                if (iH > Integer.MIN_VALUE && iH < string.length() - 1) {
                    int iH2 = kotlin.text.k.H(string, ":", 0, false, 6, (Object) null) + 1;
                    if (string == null) {
                        throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                    }
                    String strSubstring = string.substring(iH2);
                    kotlin.jvm.internal.r.c(strSubstring, "(this as java.lang.String).substring(startIndex)");
                    if (strSubstring == null) {
                        throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
                    }
                    String string2 = kotlin.text.k.k0(strSubstring).toString();
                    try {
                        if (kotlin.text.k.t(string, "status", false, 2, (Object) null)) {
                            if (!z) {
                                batteryStatus.statusText = string2;
                                z = true;
                            }
                        } else if (kotlin.text.k.t(string, "level", false, 2, (Object) null)) {
                            if (!z2) {
                                batteryStatus.capacity = Integer.parseInt(string2);
                                z2 = true;
                            }
                        } else if (kotlin.text.k.t(string, "temperature", false, 2, (Object) null) && !z3) {
                            try {
                                batteryStatus.temperature = ((double) Float.parseFloat(string2)) / 10.0d;
                            } catch (Exception unused) {
                            }
                            z3 = true;
                        }
                    } catch (Exception unused2) {
                    }
                }
            }
            return batteryStatus;
        }

        public final double b() {
            if (!kotlin.jvm.internal.r.a(Daemon.E.c(), "root")) {
                return -1.0d;
            }
            if (BatteryUtils.f693d == null) {
                BatteryUtils.f693d = Boolean.valueOf(new Regex("[0-9]{2,}").matches(com.omarea.common.shell.f.f471b.a("/sys/class/power_supply/battery/voltage_now")));
            }
            if (!kotlin.jvm.internal.r.a(BatteryUtils.f693d, Boolean.TRUE)) {
                return -1.0d;
            }
            String strA = com.omarea.common.shell.f.f471b.a("/sys/class/power_supply/battery/voltage_now");
            try {
                if (strA.length() > 4) {
                    if (strA == null) {
                        throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                    }
                    strA = strA.substring(0, 4);
                    kotlin.jvm.internal.r.c(strA, "(this as java.lang.Strin…ing(startIndex, endIndex)");
                }
                StringBuilder sb = new StringBuilder();
                sb.append("");
                if (strA == null) {
                    throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                }
                String strSubstring = strA.substring(0, 1);
                kotlin.jvm.internal.r.c(strSubstring, "(this as java.lang.Strin…ing(startIndex, endIndex)");
                sb.append(strSubstring);
                sb.append(".");
                if (strA == null) {
                    throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                }
                String strSubstring2 = strA.substring(1);
                kotlin.jvm.internal.r.c(strSubstring2, "(this as java.lang.String).substring(startIndex)");
                sb.append(strSubstring2);
                return Double.parseDouble(sb.toString());
            } catch (Exception unused) {
                return -1.0d;
            }
        }
    }

    public static /* synthetic */ void u(BatteryUtils batteryUtils, int i, boolean z, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            z = false;
        }
        batteryUtils.t(i, z);
    }

    private final String y(String str) {
        int i;
        int length = str.length() <= 4 ? str.length() : 4;
        if (str == null) {
            throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
        }
        String strSubstring = str.substring(0, length);
        kotlin.jvm.internal.r.c(strSubstring, "(this as java.lang.Strin…ing(startIndex, endIndex)");
        double d2 = Double.parseDouble(strSubstring);
        StringBuilder sb = new StringBuilder();
        if (d2 > 3000) {
            i = 1000;
        } else {
            if (d2 <= 300) {
                if (d2 > 30) {
                    i = 10;
                }
                sb.append(String.valueOf(d2));
                sb.append("v");
                return sb.toString();
            }
            i = 100;
        }
        d2 /= (double) i;
        sb.append(String.valueOf(d2));
        sb.append("v");
        return sb.toString();
    }

    public final boolean d() {
        return com.omarea.common.shell.g.f472a.g("/sys/class/power_supply/battery/battery_charging_enabled") || com.omarea.common.shell.g.f472a.g("/sys/class/power_supply/battery/input_suspend") || com.omarea.common.shell.g.f472a.g("/sys/class/qcom-battery/input_suspend") || com.omarea.common.shell.g.f472a.g("/sys/class/power_supply/battery/night_charging");
    }

    public final String e() {
        List listE;
        String[] strArr;
        int i;
        String strSubstring;
        String strSubstring2;
        String strSubstring3;
        int i2;
        Object objValueOf;
        String str = "/sys/class/power_supply/bms/uevent";
        if (!com.omarea.common.shell.g.f472a.d("/sys/class/power_supply/bms/uevent")) {
            str = com.omarea.common.shell.g.f472a.d("/sys/class/power_supply/battery/uevent") ? "/sys/class/power_supply/battery/uevent" : "";
        }
        boolean z = false;
        if (!(str.length() > 0)) {
            return "";
        }
        List listSplit = new Regex("\n").split(com.omarea.common.shell.f.f471b.a(str), 0);
        if (!listSplit.isEmpty()) {
            ListIterator listIterator = listSplit.listIterator(listSplit.size());
            while (true) {
                if (!listIterator.hasPrevious()) {
                    listE = kotlin.collections.q.e();
                    break;
                }
                if (!(((String) listIterator.previous()).length() == 0)) {
                    listE = kotlin.collections.q.Q(listSplit, listIterator.nextIndex() + 1);
                    break;
                }
            }
        } else {
            listE = kotlin.collections.q.e();
            break;
        }
        Object[] array = listE.toArray(new String[0]);
        if (array == null) {
            throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T>");
        }
        String[] strArr2 = (String[]) array;
        StringBuilder sb = new StringBuilder();
        int length = strArr2.length;
        String str2 = "";
        int i3 = 0;
        int length2 = 0;
        while (i3 < length) {
            String str3 = strArr2[i3];
            try {
                try {
                    if (kotlin.text.k.t(str3, "POWER_SUPPLY_CHARGE_FULL=", z, 2, (Object) null)) {
                        sb.append("充满容量 = ");
                        if (str3 == null) {
                            throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                        }
                        String strSubstring4 = str3.substring(25, 29);
                        kotlin.jvm.internal.r.c(strSubstring4, "(this as java.lang.Strin…ing(startIndex, endIndex)");
                        sb.append(strSubstring4);
                        if (length2 == 0) {
                            int length3 = str3.length();
                            if (str3 == null) {
                                throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                            }
                            String strSubstring5 = str3.substring(25, length3);
                            kotlin.jvm.internal.r.c(strSubstring5, "(this as java.lang.Strin…ing(startIndex, endIndex)");
                            length2 = strSubstring5.length();
                        }
                        sb.append("mAh");
                        strArr = strArr2;
                        i = length;
                    } else {
                        strArr = strArr2;
                        i = length;
                        if (kotlin.text.k.t(str3, "POWER_SUPPLY_CHARGE_FULL_DESIGN=", false, 2, (Object) null)) {
                            sb.append("设计容量 = ");
                            if (str3 == null) {
                                throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                            }
                            String strSubstring6 = str3.substring(32, 36);
                            kotlin.jvm.internal.r.c(strSubstring6, "(this as java.lang.Strin…ing(startIndex, endIndex)");
                            sb.append(strSubstring6);
                            sb.append("mAh");
                            int length4 = str3.length();
                            if (str3 == null) {
                                throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                            }
                            String strSubstring7 = str3.substring(32, length4);
                            kotlin.jvm.internal.r.c(strSubstring7, "(this as java.lang.Strin…ing(startIndex, endIndex)");
                            length2 = strSubstring7.length();
                        } else {
                            if (kotlin.text.k.t(str3, "POWER_SUPPLY_TEMP=", false, 2, (Object) null)) {
                                sb.append("电池温度 = ");
                                int length5 = str3.length();
                                if (str3 == null) {
                                    throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                                }
                                String strSubstring8 = str3.substring(18, length5);
                                kotlin.jvm.internal.r.c(strSubstring8, "(this as java.lang.Strin…ing(startIndex, endIndex)");
                                String str4 = kotlin.text.k.y(strSubstring8, "-", false, 2, (Object) null) ? "-" : "";
                                String strR = kotlin.text.k.r(strSubstring8, "-", "", false, 4, (Object) null);
                                sb.append(str4);
                                if (strR.length() >= 3) {
                                    if (strR == null) {
                                        throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                                    }
                                    String strSubstring9 = strR.substring(0, 3);
                                    kotlin.jvm.internal.r.c(strSubstring9, "(this as java.lang.Strin…ing(startIndex, endIndex)");
                                    objValueOf = Float.valueOf(Integer.parseInt(strSubstring9) / 10.0f);
                                } else {
                                    if (strR == null) {
                                        throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                                    }
                                    String strSubstring10 = strR.substring(0, 2);
                                    kotlin.jvm.internal.r.c(strSubstring10, "(this as java.lang.Strin…ing(startIndex, endIndex)");
                                    objValueOf = Integer.valueOf(Integer.parseInt(strSubstring10));
                                }
                                sb.append(objValueOf);
                            } else {
                                if (kotlin.text.k.t(str3, "POWER_SUPPLY_TEMP_WARM=", false, 2, (Object) null)) {
                                    sb.append("警戒温度 = ");
                                    int length6 = str3.length();
                                    if (str3 == null) {
                                        throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                                    }
                                    String strSubstring11 = str3.substring(23, length6);
                                    kotlin.jvm.internal.r.c(strSubstring11, "(this as java.lang.Strin…ing(startIndex, endIndex)");
                                    i2 = Integer.parseInt(strSubstring11) / 10;
                                } else {
                                    if (kotlin.text.k.t(str3, "POWER_SUPPLY_TEMP_COOL=", false, 2, (Object) null)) {
                                        sb.append("低温温度 = ");
                                        int length7 = str3.length();
                                        if (str3 == null) {
                                            throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                                        }
                                        String strSubstring12 = str3.substring(23, length7);
                                        kotlin.jvm.internal.r.c(strSubstring12, "(this as java.lang.Strin…ing(startIndex, endIndex)");
                                        i2 = Integer.parseInt(strSubstring12) / 10;
                                    } else {
                                        if (kotlin.text.k.t(str3, "POWER_SUPPLY_VOLTAGE_NOW=", false, 2, (Object) null)) {
                                            sb.append("当前电压 = ");
                                            int length8 = str3.length();
                                            if (str3 == null) {
                                                throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                                            }
                                            strSubstring3 = str3.substring(25, length8);
                                            kotlin.jvm.internal.r.c(strSubstring3, "(this as java.lang.Strin…ing(startIndex, endIndex)");
                                        } else if (kotlin.text.k.t(str3, "POWER_SUPPLY_VOLTAGE_MAX_DESIGN=", false, 2, (Object) null)) {
                                            sb.append("设计电压 = ");
                                            int length9 = str3.length();
                                            if (str3 == null) {
                                                throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                                            }
                                            strSubstring3 = str3.substring(32, length9);
                                            kotlin.jvm.internal.r.c(strSubstring3, "(this as java.lang.Strin…ing(startIndex, endIndex)");
                                        } else if (kotlin.text.k.t(str3, "POWER_SUPPLY_VOLTAGE_MIN=", false, 2, (Object) null)) {
                                            sb.append("最小电压 = ");
                                            int length10 = str3.length();
                                            if (str3 == null) {
                                                throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                                            }
                                            strSubstring3 = str3.substring(25, length10);
                                            kotlin.jvm.internal.r.c(strSubstring3, "(this as java.lang.Strin…ing(startIndex, endIndex)");
                                        } else if (kotlin.text.k.t(str3, "POWER_SUPPLY_VOLTAGE_MAX=", false, 2, (Object) null)) {
                                            sb.append("最大电压 = ");
                                            int length11 = str3.length();
                                            if (str3 == null) {
                                                throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                                            }
                                            strSubstring3 = str3.substring(25, length11);
                                            kotlin.jvm.internal.r.c(strSubstring3, "(this as java.lang.Strin…ing(startIndex, endIndex)");
                                        } else {
                                            if (kotlin.text.k.t(str3, "POWER_SUPPLY_BATTERY_TYPE=", false, 2, (Object) null)) {
                                                sb.append("电池类型 = ");
                                                int length12 = str3.length();
                                                if (str3 == null) {
                                                    throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                                                }
                                                strSubstring2 = str3.substring(26, length12);
                                            } else if (kotlin.text.k.t(str3, "POWER_SUPPLY_TECHNOLOGY=", false, 2, (Object) null)) {
                                                sb.append("电池技术 = ");
                                                int length13 = str3.length();
                                                if (str3 == null) {
                                                    throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                                                }
                                                strSubstring2 = str3.substring(24, length13);
                                            } else if (kotlin.text.k.t(str3, "POWER_SUPPLY_CYCLE_COUNT=", false, 2, (Object) null)) {
                                                sb.append("循环次数 = ");
                                                int length14 = str3.length();
                                                if (str3 == null) {
                                                    throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                                                }
                                                strSubstring2 = str3.substring(25, length14);
                                            } else if (kotlin.text.k.t(str3, "POWER_SUPPLY_CONSTANT_CHARGE_VOLTAGE=", false, 2, (Object) null)) {
                                                sb.append("充电电压 = ");
                                                int length15 = str3.length();
                                                if (str3 == null) {
                                                    throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                                                }
                                                strSubstring3 = str3.substring(37, length15);
                                                kotlin.jvm.internal.r.c(strSubstring3, "(this as java.lang.Strin…ing(startIndex, endIndex)");
                                            } else if (kotlin.text.k.t(str3, "POWER_SUPPLY_CAPACITY=", false, 2, (Object) null)) {
                                                sb.append("电池电量 = ");
                                                int length16 = str3.length();
                                                if (str3 == null) {
                                                    throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                                                }
                                                String strSubstring13 = str3.substring(22, length16);
                                                kotlin.jvm.internal.r.c(strSubstring13, "(this as java.lang.Strin…ing(startIndex, endIndex)");
                                                sb.append(strSubstring13);
                                                strSubstring2 = "%";
                                                sb.append(strSubstring2);
                                            } else if (kotlin.text.k.t(str3, "POWER_SUPPLY_MODEL_NAME=", false, 2, (Object) null)) {
                                                sb.append("模块/型号 = ");
                                                int length17 = str3.length();
                                                if (str3 == null) {
                                                    throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                                                }
                                                strSubstring2 = str3.substring(24, length17);
                                            } else if (kotlin.text.k.t(str3, "POWER_SUPPLY_CHARGE_TYPE=", false, 2, (Object) null)) {
                                                sb.append("充电类型 = ");
                                                int length18 = str3.length();
                                                if (str3 == null) {
                                                    throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                                                }
                                                strSubstring2 = str3.substring(25, length18);
                                            } else if (kotlin.text.k.t(str3, "POWER_SUPPLY_RESISTANCE_NOW=", false, 2, (Object) null)) {
                                                sb.append("电阻/阻值 = ");
                                                int length19 = str3.length();
                                                if (str3 == null) {
                                                    throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                                                }
                                                strSubstring2 = str3.substring(28, length19);
                                            } else {
                                                if (kotlin.text.k.t(str3, "POWER_SUPPLY_CURRENT_NOW=", false, 2, (Object) null)) {
                                                    int length20 = str3.length();
                                                    if (str3 == null) {
                                                        throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                                                    }
                                                    strSubstring = str3.substring(25, length20);
                                                } else if (kotlin.text.k.t(str3, "POWER_SUPPLY_CONSTANT_CHARGE_CURRENT=", false, 2, (Object) null)) {
                                                    if (str2.length() == 0) {
                                                        int length21 = str3.length();
                                                        if (str3 == null) {
                                                            throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                                                        }
                                                        strSubstring = str3.substring(37, length21);
                                                    } else {
                                                        continue;
                                                    }
                                                } else {
                                                    continue;
                                                }
                                                kotlin.jvm.internal.r.c(strSubstring, "(this as java.lang.Strin…ing(startIndex, endIndex)");
                                                str2 = strSubstring;
                                            }
                                            kotlin.jvm.internal.r.c(strSubstring2, "(this as java.lang.Strin…ing(startIndex, endIndex)");
                                            sb.append(strSubstring2);
                                        }
                                        strSubstring2 = y(strSubstring3);
                                        sb.append(strSubstring2);
                                    }
                                    i3++;
                                    strArr2 = strArr;
                                    length = i;
                                    z = false;
                                }
                                sb.append(i2);
                            }
                            sb.append("°C");
                        }
                    }
                    sb.append("\n");
                } catch (Exception unused) {
                    sb.append("\n");
                }
            } catch (Exception unused2) {
                strArr = strArr2;
                i = length;
            }
            i3++;
            strArr2 = strArr;
            length = i;
            z = false;
        }
        if ((str2.length() > 0) && length2 != 0) {
            sb.insert(0, "放电速度 = " + (length2 < 5 ? Integer.parseInt(str2) : (int) (((double) Integer.parseInt(str2)) / Math.pow(10.0d, length2 - 4))) + "mA\n");
        }
        String string = sb.toString();
        kotlin.jvm.internal.r.c(string, "stringBuilder.toString()");
        return string;
    }

    public final int f() {
        String strA = com.omarea.common.shell.f.f471b.a("/sys/class/power_supply/battery/capacity");
        if (new Regex("^[0-9]+").matches(strA)) {
            return Integer.parseInt(strA);
        }
        return 0;
    }

    public final int g() {
        String strA = com.omarea.common.shell.f.f471b.a("/sys/class/power_supply/bms/charge_full");
        if (new Regex("^[0-9]+").matches(strA)) {
            return Integer.parseInt(strA) / 1000;
        }
        return 0;
    }

    public final float h(int i) {
        if (this.f695b == null) {
            this.f695b = Boolean.valueOf(com.omarea.common.shell.g.f472a.d("/sys/class/power_supply/bms/capacity_raw"));
        }
        if (kotlin.jvm.internal.r.a(this.f695b, Boolean.TRUE)) {
            try {
                String strA = com.omarea.common.shell.f.f471b.a("/sys/class/power_supply/bms/capacity_raw");
                int i2 = Integer.parseInt(strA);
                float fAbs = Math.abs(i2 - i);
                float f = i2 / 100.0f;
                float f2 = i;
                if (fAbs <= Math.abs(f - f2)) {
                    f = Float.parseFloat(strA);
                }
                if (Math.abs(f - f2) <= 7) {
                    return f;
                }
                this.f695b = Boolean.FALSE;
                return -1.0f;
            } catch (Exception unused) {
                this.f695b = Boolean.FALSE;
            }
        }
        return -1.0f;
    }

    /* JADX WARN: Code duplicated, block: B:15:0x0041  */
    /* JADX WARN: Code duplicated, block: B:17:0x004d  */
    /* JADX WARN: Code duplicated, block: B:18:0x0063  */
    /* JADX WARN: Code duplicated, block: B:20:0x006b  */
    /* JADX WARN: Code duplicated, block: B:22:0x0071  */
    /* JADX WARN: Code duplicated, block: B:26:0x007a A[ORIG_RETURN, RETURN] */
    /* JADX WARN: Code duplicated, block: B:28:0x007d A[RETURN] */
    /* JADX WARN: Code duplicated, block: B:31:0x0074 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:34:? A[RETURN, SYNTHETIC] */
    public final String i() {
        com.omarea.common.shell.f fVar;
        String strA;
        StringBuilder sb;
        int length;
        String str = "/sys/class/power_supply/main/constant_charge_current_max";
        if (this.f694a == null) {
            this.f694a = Boolean.valueOf(com.omarea.common.shell.g.f472a.d("/sys/class/power_supply/main/constant_charge_current_max"));
        }
        if (!kotlin.jvm.internal.r.a(this.f694a, Boolean.TRUE)) {
            if (com.omarea.common.shell.g.f472a.d("/sys/class/power_supply/battery/constant_charge_current_max")) {
                strA = com.omarea.common.shell.f.f471b.a("/sys/class/power_supply/battery/constant_charge_current_max");
            } else {
                fVar = com.omarea.common.shell.f.f471b;
                str = "/sys/class/power_supply/battery/constant_charge_current";
            }
            if (strA.length() > 3) {
                if (strA.length() > 0) {
                    return "?mA";
                }
                try {
                    if (Integer.parseInt(strA) == 0) {
                        return "0";
                    }
                    return strA;
                } catch (Exception unused) {
                    return strA;
                }
            }
            sb = new StringBuilder();
            length = strA.length() - 3;
            if (strA != null) {
                throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
            }
            String strSubstring = strA.substring(0, length);
            kotlin.jvm.internal.r.c(strSubstring, "(this as java.lang.Strin…ing(startIndex, endIndex)");
            sb.append(strSubstring);
            sb.append("mA");
            return sb.toString();
        }
        fVar = com.omarea.common.shell.f.f471b;
        strA = fVar.a(str);
        if (strA.length() > 3) {
            if (strA.length() > 0) {
                return "?mA";
            }
            if (Integer.parseInt(strA) == 0) {
                return "0";
            }
            return strA;
        }
        sb = new StringBuilder();
        length = strA.length() - 3;
        if (strA != null) {
            throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
        }
        String strSubstring2 = strA.substring(0, length);
        kotlin.jvm.internal.r.c(strSubstring2, "(this as java.lang.Strin…ing(startIndex, endIndex)");
        sb.append(strSubstring2);
        sb.append("mA");
        return sb.toString();
    }

    public final boolean j() {
        return kotlin.jvm.internal.r.a(com.omarea.common.shell.f.f471b.a("/sys/class/power_supply/battery/step_charging_enabled"), "1");
    }

    public final String k() {
        List listE;
        String[] strArr;
        String strSubstring;
        String strSubstring2;
        String strSubstring3;
        if (!com.omarea.common.shell.g.f472a.d("/sys/class/power_supply/usb/uevent")) {
            return "";
        }
        boolean z = false;
        List listSplit = new Regex("\n").split(com.omarea.common.shell.f.f471b.a("/sys/class/power_supply/usb/uevent"), 0);
        if (!listSplit.isEmpty()) {
            ListIterator listIterator = listSplit.listIterator(listSplit.size());
            while (true) {
                if (!listIterator.hasPrevious()) {
                    listE = kotlin.collections.q.e();
                    break;
                }
                if (!(((String) listIterator.previous()).length() == 0)) {
                    listE = kotlin.collections.q.Q(listSplit, listIterator.nextIndex() + 1);
                    break;
                }
            }
        } else {
            listE = kotlin.collections.q.e();
            break;
        }
        Object[] array = listE.toArray(new String[0]);
        if (array == null) {
            throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T>");
        }
        String[] strArr2 = (String[]) array;
        StringBuilder sb = new StringBuilder();
        int length = strArr2.length;
        float f = 0.0f;
        int i = 0;
        boolean z2 = false;
        float f2 = 0.0f;
        while (i < length) {
            String str = strArr2[i];
            try {
                try {
                    if (kotlin.text.k.t(str, "POWER_SUPPLY_VOLTAGE_NOW=", z, 2, (Object) null)) {
                        sb.append("当前电压 = ");
                        int length2 = str.length();
                        if (str == null) {
                            throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                        }
                        String strSubstring4 = str.substring(25, length2);
                        kotlin.jvm.internal.r.c(strSubstring4, "(this as java.lang.Strin…ing(startIndex, endIndex)");
                        String strY = y(strSubstring4);
                        f = Float.parseFloat(kotlin.text.k.r(strY, "v", "", false, 4, (Object) null));
                        sb.append(strY);
                        strArr = strArr2;
                        sb.append("\n");
                        i++;
                        strArr2 = strArr;
                        z = false;
                    } else {
                        strArr = strArr2;
                        if (kotlin.text.k.t(str, "POWER_SUPPLY_CURRENT_MAX=", false, 2, (Object) null)) {
                            int length3 = str.length();
                            if (str == null) {
                                throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                            }
                            String strSubstring5 = str.substring(25, length3);
                            kotlin.jvm.internal.r.c(strSubstring5, "(this as java.lang.Strin…ing(startIndex, endIndex)");
                            float f3 = (Integer.parseInt(strSubstring5) / 1000) / 1000.0f;
                            if (f3 > 0) {
                                sb.append("最大电流 = ");
                                sb.append(f3);
                                sb.append("A");
                            }
                        } else {
                            if (kotlin.text.k.t(str, "POWER_SUPPLY_PD_VOLTAGE_MAX=", false, 2, (Object) null)) {
                                sb.append("最大电压(PD) = ");
                                int length4 = str.length();
                                if (str == null) {
                                    throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                                }
                                strSubstring3 = str.substring(28, length4);
                                kotlin.jvm.internal.r.c(strSubstring3, "(this as java.lang.Strin…ing(startIndex, endIndex)");
                            } else {
                                if (kotlin.text.k.t(str, "POWER_SUPPLY_CONNECTOR_TEMP=", false, 2, (Object) null)) {
                                    sb.append("接口温度 = ");
                                    int length5 = str.length();
                                    if (str == null) {
                                        throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                                    }
                                    String strSubstring6 = str.substring(28, length5);
                                    kotlin.jvm.internal.r.c(strSubstring6, "(this as java.lang.Strin…ing(startIndex, endIndex)");
                                    sb.append(Integer.parseInt(strSubstring6) / 10.0f);
                                    strSubstring2 = "°C";
                                } else if (kotlin.text.k.t(str, "POWER_SUPPLY_PD_VOLTAGE_MIN=", false, 2, (Object) null)) {
                                    sb.append("最小电压(PD) = ");
                                    int length6 = str.length();
                                    if (str == null) {
                                        throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                                    }
                                    strSubstring3 = str.substring(28, length6);
                                    kotlin.jvm.internal.r.c(strSubstring3, "(this as java.lang.Strin…ing(startIndex, endIndex)");
                                } else if (kotlin.text.k.t(str, "POWER_SUPPLY_PD_CURRENT_MAX=", false, 2, (Object) null)) {
                                    int length7 = str.length();
                                    if (str == null) {
                                        throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                                    }
                                    String strSubstring7 = str.substring(28, length7);
                                    kotlin.jvm.internal.r.c(strSubstring7, "(this as java.lang.Strin…ing(startIndex, endIndex)");
                                    float f4 = (Integer.parseInt(strSubstring7) / 1000) / 1000.0f;
                                    if (f4 > 0) {
                                        sb.append("最大电流(PD) = ");
                                        sb.append(f4);
                                        sb.append("A");
                                    }
                                } else if (kotlin.text.k.t(str, "POWER_SUPPLY_INPUT_CURRENT_NOW=", false, 2, (Object) null)) {
                                    int length8 = str.length();
                                    if (str == null) {
                                        throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                                    }
                                    String strSubstring8 = str.substring(31, length8);
                                    kotlin.jvm.internal.r.c(strSubstring8, "(this as java.lang.Strin…ing(startIndex, endIndex)");
                                    f2 = (Integer.parseInt(strSubstring8) / 1000) / 1000.0f;
                                } else if (kotlin.text.k.t(str, "POWER_SUPPLY_QUICK_CHARGE_TYPE=", false, 2, (Object) null)) {
                                    sb.append("快充类型 = ");
                                    int length9 = str.length();
                                    if (str == null) {
                                        throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                                    }
                                    strSubstring2 = str.substring(31, length9);
                                    kotlin.jvm.internal.r.c(strSubstring2, "(this as java.lang.Strin…ing(startIndex, endIndex)");
                                    if (kotlin.jvm.internal.r.a(strSubstring2, "0")) {
                                        strSubstring2 = "慢速充电";
                                    } else {
                                        sb.append("类型");
                                    }
                                } else {
                                    if (kotlin.text.k.t(str, "POWER_SUPPLY_REAL_TYPE=", false, 2, (Object) null)) {
                                        sb.append("输电协议 = ");
                                        int length10 = str.length();
                                        if (str == null) {
                                            throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                                        }
                                        strSubstring = str.substring(23, length10);
                                        kotlin.jvm.internal.r.c(strSubstring, "(this as java.lang.Strin…ing(startIndex, endIndex)");
                                    } else if (kotlin.text.k.t(str, "POWER_SUPPLY_HVDCP3_TYPE=", false, 2, (Object) null)) {
                                        sb.append("高压快充 = ");
                                        int length11 = str.length();
                                        if (str == null) {
                                            throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                                        }
                                        strSubstring = str.substring(25, length11);
                                        kotlin.jvm.internal.r.c(strSubstring, "(this as java.lang.Strin…ing(startIndex, endIndex)");
                                        if (kotlin.jvm.internal.r.a(strSubstring, "0")) {
                                            strSubstring = "否";
                                        } else {
                                            sb.append("类型");
                                        }
                                    } else if (kotlin.text.k.t(str, "POWER_SUPPLY_PD_AUTHENTICATION=", false, 2, (Object) null)) {
                                        sb.append("PD认证 = ");
                                        int length12 = str.length();
                                        if (str == null) {
                                            throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                                        }
                                        String strSubstring9 = str.substring(31, length12);
                                        kotlin.jvm.internal.r.c(strSubstring9, "(this as java.lang.Strin…ing(startIndex, endIndex)");
                                        boolean zA = kotlin.jvm.internal.r.a(strSubstring9, "1");
                                        try {
                                            sb.append(zA ? "已认证" : "未认证");
                                            z2 = zA;
                                        } catch (Exception unused) {
                                            z2 = zA;
                                        }
                                    } else {
                                        continue;
                                    }
                                    sb.append(strSubstring);
                                }
                                sb.append(strSubstring2);
                            }
                            strSubstring2 = y(strSubstring3);
                            sb.append(strSubstring2);
                        }
                        i++;
                        strArr2 = strArr;
                        z = false;
                    }
                    sb.append("\n");
                } catch (Exception unused2) {
                    sb.append("\n");
                }
            } catch (Exception unused3) {
                strArr = strArr2;
            }
            i++;
            strArr2 = strArr;
            z = false;
        }
        if (!z2) {
            float f5 = 0;
            if (f > f5 && f2 > f5) {
                sb.append("当前电流 = ");
                sb.append(f2);
                sb.append("A");
                sb.append("\n参考功率 = ");
                sb.append(((int) ((f * f2) * 100)) / 100.0f);
                sb.append("W");
            }
        }
        String string = sb.toString();
        kotlin.jvm.internal.r.c(string, "stringBuilder.toString()");
        return string;
    }

    public final boolean l() {
        return kotlin.jvm.internal.r.a(Daemon.A0(Daemon.E.a(), "charge-control", "pause", 0, 4, null), "true");
    }

    public final boolean m() {
        return kotlin.jvm.internal.r.a(com.omarea.common.shell.f.f471b.a("/sys/class/power_supply/usb/pd_active"), "1");
    }

    public final boolean n() {
        return kotlin.jvm.internal.r.a(com.omarea.common.shell.f.f471b.a("/sys/class/power_supply/usb/pd_allowed"), "1");
    }

    public final boolean o() {
        return com.omarea.common.shell.g.f472a.d("/sys/class/power_supply/usb/pd_allowed") || com.omarea.common.shell.g.f472a.d("/sys/class/power_supply/usb/pd_active");
    }

    public final boolean p() {
        return com.omarea.common.shell.g.f472a.g("/sys/class/power_supply/battery/constant_charge_current_max") || com.omarea.common.shell.g.f472a.g("/sys/class/power_supply/battery/constant_charge_current") || com.omarea.common.shell.g.f472a.g("/sys/class/power_supply/main/constant_charge_current_max");
    }

    public final boolean q() {
        return kotlin.jvm.internal.r.a(Daemon.A0(Daemon.E.a(), "charge-control", "resume", 0, 4, null), "true");
    }

    public final void r(int i) {
        com.omarea.common.shell.f.f471b.b("/sys/class/power_supply/battery/capacity", String.valueOf(i));
    }

    public final void s(int i) {
        com.omarea.common.shell.f.f471b.b("/sys/class/power_supply/bms/charge_full", String.valueOf(i * 1000));
    }

    public final void t(int i, boolean z) {
        if (!f692c || z) {
            kotlinx.coroutines.f.d(i0.a(w0.b()), (CoroutineContext) null, (CoroutineStart) null, new BatteryUtils$setCurrentLimitMA$1(i, null), 3, (Object) null);
        }
    }

    public final boolean v(boolean z) {
        StringBuilder sb = new StringBuilder();
        sb.append("chmod 777 /sys/class/power_supply/usb/pd_allowed\n");
        StringBuilder sb2 = new StringBuilder();
        sb2.append("echo ");
        sb2.append(z ? "1" : "0");
        sb2.append("> /sys/class/power_supply/usb/pd_allowed\n");
        sb.append(sb2.toString());
        sb.append("chmod 777 /sys/class/power_supply/usb/pd_active\n");
        sb.append("echo 1 > /sys/class/power_supply/usb/pd_active\n");
        com.omarea.common.shell.e eVar = com.omarea.common.shell.e.f469b;
        String string = sb.toString();
        kotlin.jvm.internal.r.c(string, "builder.toString()");
        return !kotlin.jvm.internal.r.a(eVar.e(string), "error");
    }

    public final void w(boolean z) {
        com.omarea.common.shell.f.f471b.b("/sys/class/power_supply/battery/step_charging_enabled", z ? "1" : "0");
    }

    public final boolean x() {
        return com.omarea.common.shell.g.f472a.g("/sys/class/power_supply/battery/step_charging_enabled");
    }
}
