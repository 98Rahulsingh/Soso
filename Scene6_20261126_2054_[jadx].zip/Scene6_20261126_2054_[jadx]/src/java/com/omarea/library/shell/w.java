package com.omarea.library.shell;

import android.content.Context;
import com.omarea.model.ZramWriteBackStat;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import kotlin.text.Regex;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class w {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private String f776a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private String f777b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private String f778c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private final Context f779d;

    public w(Context context) {
        kotlin.jvm.internal.r.d(context, "context");
        this.f779d = context;
        this.f776a = "/data/swapfile";
        this.f777b = com.omarea.common.shared.d.f450b.i("addin/swap_control.sh", "addin/swap_control.sh", context);
    }

    public final String a(int i) {
        if (this.f778c == null) {
            this.f778c = com.omarea.common.shared.d.f450b.i("addin/force_compact.sh", "addin/force_compact.sh", this.f779d);
            com.omarea.common.shell.e.f469b.c("rm /cache/force_compact.log 2>/dev/null");
        }
        if (this.f778c == null) {
            return "Fail!";
        }
        return com.omarea.common.shell.e.f469b.c("sh " + this.f778c + ' ' + i);
    }

    public final String b() {
        Object obj;
        Iterator it = kotlin.text.k.W(com.omarea.common.shell.f.f471b.a("/sys/block/zram0/comp_algorithm"), new String[]{" "}, false, 0, 6, (Object) null).iterator();
        while (true) {
            obj = null;
            if (!it.hasNext()) {
                break;
            }
            Object next = it.next();
            String str = (String) next;
            boolean z = false;
            if (kotlin.text.k.t(str, "[", false, 2, (Object) null) && kotlin.text.k.m(str, "]", false, 2, (Object) null)) {
                z = true;
            }
            if (z) {
                obj = next;
                break;
            }
        }
        String str2 = (String) obj;
        if (str2 == null) {
            return "";
        }
        String strR = kotlin.text.k.r(kotlin.text.k.r(str2, "[", "", false, 4, (Object) null), "]", "", false, 4, (Object) null);
        if (strR != null) {
            return kotlin.text.k.k0(strR).toString();
        }
        throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
    }

    public final String[] c() {
        List listW = kotlin.text.k.W(com.omarea.common.shell.f.f471b.a("/sys/block/zram0/comp_algorithm"), new String[]{" "}, false, 0, 6, (Object) null);
        ArrayList arrayList = new ArrayList(kotlin.collections.q.k(listW, 10));
        Iterator it = listW.iterator();
        while (it.hasNext()) {
            arrayList.add(kotlin.text.k.r(kotlin.text.k.r((String) it.next(), "[", "", false, 4, (Object) null), "]", "", false, 4, (Object) null));
        }
        Object[] array = arrayList.toArray(new String[0]);
        if (array != null) {
            return (String[]) array;
        }
        throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T>");
    }

    public final List<String> d() {
        String strR = kotlin.text.k.r(kotlin.text.k.r(com.omarea.common.shell.f.f471b.a("/proc/swaps"), "\t\t", "\t", false, 4, (Object) null), "\t", " ", false, 4, (Object) null);
        while (kotlin.text.k.y(strR, "  ", false, 2, (Object) null)) {
            strR = kotlin.text.k.r(strR, "  ", " ", false, 4, (Object) null);
        }
        return kotlin.collections.q.W(kotlin.text.k.W(strR, new String[]{"\n"}, false, 0, 6, (Object) null));
    }

    public final String e() {
        if (!f()) {
            return "";
        }
        String strR = kotlin.text.k.r(kotlin.text.k.r(com.omarea.common.shell.f.f471b.a("/proc/swaps"), "\t\t", "\t", false, 4, (Object) null), "\t", " ", false, 4, (Object) null);
        String str = "/data/swapfile";
        return (kotlin.text.k.y(strR, "/data/swapfile", false, 2, (Object) null) || kotlin.text.k.y(strR, "/swapfile", false, 2, (Object) null) || ((str = (String) kotlin.collections.q.C(kotlin.text.k.W(t.f771a.a("vtools.swap.loop"), new String[]{"/"}, false, 0, 6, (Object) null))) != null && (kotlin.jvm.internal.r.a(str, "error") ^ true) && kotlin.text.k.y(strR, str, false, 2, (Object) null))) ? str : "";
    }

    public final boolean f() {
        return com.omarea.common.shell.g.f472a.g(this.f776a);
    }

    public final int g() {
        if (!f()) {
            return 0;
        }
        long length = 0;
        try {
            try {
                length = com.omarea.common.shell.g.f472a.f("/data/swapfile");
            } catch (Exception unused) {
            }
        } catch (Exception unused2) {
            length = new File("/data/swapfile").length();
        }
        long j = 1024;
        return (int) ((length / j) / j);
    }

    public final int h() {
        String str = (String) kotlin.collections.q.C(kotlin.text.k.W(t.f771a.a("vtools.swap.loop"), new String[]{"/"}, false, 0, 6, (Object) null));
        if (str != null && !kotlin.text.k.y(str, "loop", false, 2, (Object) null)) {
            str = null;
        }
        for (String str2 : d()) {
            if (kotlin.text.k.t(str2, "/swapfile ", false, 2, (Object) null) || kotlin.text.k.t(str2, "/data/swapfile ", false, 2, (Object) null) || (str != null && kotlin.text.k.y(str2, str, false, 2, (Object) null))) {
                List listW = kotlin.collections.q.W(kotlin.text.k.W(str2, new String[]{" "}, false, 0, 6, (Object) null));
                try {
                    return Integer.parseInt((String) listW.get(3)) / 1024;
                } catch (Exception unused) {
                    return -1;
                }
            }
        }
        return -1;
    }

    public final int i() {
        String string;
        List listSplit;
        String str;
        String str2 = (String) kotlin.collections.q.u(kotlin.text.k.W(com.omarea.common.shell.f.f471b.a("/proc/version"), new String[]{"-"}, false, 0, 6, (Object) null));
        if (str2 == null || (listSplit = new Regex("[\\s]+").split(str2, 0)) == null || (str = (String) kotlin.collections.q.C(listSplit)) == null) {
            string = null;
        } else {
            if (str == null) {
                throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
            }
            string = kotlin.text.k.k0(str).toString();
        }
        if (string != null) {
            return (kotlin.text.k.H(string, "5.", 0, false, 6, (Object) null) == 0 || kotlin.text.k.H(string, "6.", 0, false, 6, (Object) null) == 0) ? 200 : 100;
        }
        return 100;
    }

    public final ZramWriteBackStat j() {
        ZramWriteBackStat zramWriteBackStat = new ZramWriteBackStat();
        zramWriteBackStat.setBackingDev(com.omarea.common.shell.f.f471b.a("/sys/block/zram0/backing_dev"));
        String strA = com.omarea.common.shell.f.f471b.a("/sys/block/zram0/bd_stat");
        if (strA == null) {
            throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
        }
        List listSplit = new Regex("[ ]+").split(kotlin.text.k.k0(strA).toString(), 0);
        if (listSplit.size() == 3) {
            zramWriteBackStat.setBacked(Integer.parseInt((String) listSplit.get(0)) * 4);
            zramWriteBackStat.setBackReads(Integer.parseInt((String) listSplit.get(1)) * 4);
            zramWriteBackStat.setBackWrites(Integer.parseInt((String) listSplit.get(2)) * 4);
        }
        return zramWriteBackStat;
    }

    public final int k() {
        try {
            long j = 1024;
            return (int) ((Long.parseLong(com.omarea.common.shell.f.f471b.a("/sys/block/zram0/disksize")) / j) / j);
        } catch (Exception unused) {
            return 0;
        }
    }

    public final boolean l() {
        return kotlin.text.k.y(com.omarea.common.shell.f.f471b.a("/proc/swaps"), "/block/zram0", false, 2, (Object) null);
    }

    public final Integer m() {
        for (String str : d()) {
            if (kotlin.text.k.t(str, "/block/zram0 ", false, 2, (Object) null) || kotlin.text.k.t(str, "/dev/block/zram0 ", false, 2, (Object) null)) {
                try {
                    return Integer.valueOf(Integer.parseInt((String) kotlin.collections.q.W(kotlin.text.k.W(str, new String[]{" "}, false, 0, 6, (Object) null)).get(4)));
                } catch (Exception unused) {
                    break;
                }
            }
        }
        return null;
    }

    public final boolean n() {
        return kotlin.jvm.internal.r.a(com.omarea.common.shell.e.f469b.c("if [[ ! -e /dev/block/zram0 ]] && [[ -e /sys/class/zram-control ]]; then\n  cat /sys/class/zram-control/hot_add\nfi\nif [[ -e /dev/block/zram0 ]]; then echo 1; else echo 0; fi;"), "1");
    }

    public final int o() {
        for (String str : d()) {
            if (kotlin.text.k.t(str, "/block/zram0 ", false, 2, (Object) null) || kotlin.text.k.t(str, "/dev/block/zram0 ", false, 2, (Object) null)) {
                List listW = kotlin.collections.q.W(kotlin.text.k.W(str, new String[]{" "}, false, 0, 6, (Object) null));
                try {
                    return Integer.parseInt((String) listW.get(3)) / 1024;
                } catch (Exception unused) {
                    return -1;
                }
            }
        }
        return -1;
    }

    public final boolean p() {
        return com.omarea.common.shell.g.f472a.g("/sys/block/zram0/backing_dev");
    }

    public final void q(int i) {
        StringBuilder sb = new StringBuilder();
        sb.append("swapoff " + this.f776a + " >/dev/null 2>&1;\n");
        sb.append("dd if=/dev/zero of=" + this.f776a + " bs=1048576 count=" + i + '\n');
        com.omarea.common.shell.e eVar = com.omarea.common.shell.e.f469b;
        String string = sb.toString();
        kotlin.jvm.internal.r.c(string, "sb.toString()");
        eVar.c(string);
    }

    public final void r(int i, String str) {
        StringBuilder sb;
        String str2;
        kotlin.jvm.internal.r.d(str, "algorithm");
        if (k() == i) {
            if ((!(str.length() > 0) || !(!kotlin.jvm.internal.r.a(str, b()))) && l()) {
                return;
            }
        }
        StringBuilder sb2 = new StringBuilder();
        sb2.append("echo 4 > /sys/block/zram0/max_comp_streams\n");
        sb2.append("sync\n");
        sb2.append("if [[ -f /sys/block/zram0/backing_dev ]]; then\n");
        sb2.append("  backing_dev=$(cat /sys/block/zram0/backing_dev)\n");
        sb2.append("fi\n");
        sb2.append("echo 3 > /proc/sys/vm/drop_caches\n");
        sb2.append("swapoff /dev/block/zram0 >/dev/null 2>&1\n");
        sb2.append("echo 1 > /sys/block/zram0/reset\n");
        if (str.length() > 0) {
            sb2.append("echo \"" + str + "\" > /sys/block/zram0/comp_algorithm\n");
        }
        sb2.append("if [[ -f /sys/block/zram0/backing_dev ]]; then\n");
        sb2.append("  echo \"$backing_dev\" > /sys/block/zram0/backing_dev\n");
        sb2.append("fi\n");
        if (i > 2047) {
            sb = new StringBuilder();
            sb.append("echo ");
            sb.append(i);
            str2 = "M > /sys/block/zram0/disksize\n";
        } else {
            sb = new StringBuilder();
            sb.append("echo ");
            sb.append(((long) (i * 1024)) * 1024);
            str2 = " > /sys/block/zram0/disksize\n";
        }
        sb.append(str2);
        sb2.append(sb.toString());
        sb2.append("echo 4 > /sys/block/zram0/max_comp_streams\n");
        sb2.append("mkswap /dev/block/zram0 >/dev/null 2>&1\n");
        sb2.append("swapon /dev/block/zram0 -p 0 >/dev/null 2>&1\n");
        com.omarea.common.shell.e eVar = com.omarea.common.shell.e.f469b;
        String string = sb2.toString();
        kotlin.jvm.internal.r.c(string, "sb.toString()");
        eVar.c(string);
    }

    public final void s() {
        StringBuilder sb = new StringBuilder("sync\necho 3 > /proc/sys/vm/drop_caches\n");
        sb.append("sh ");
        sb.append(this.f777b);
        sb.append(" disable_swap ");
        sb.append(kotlin.text.k.y(e(), "loop", false, 2, (Object) null) ? "1" : "0");
        sb.append("\nrm -f " + this.f776a);
        com.omarea.common.shell.e eVar = com.omarea.common.shell.e.f469b;
        String string = sb.toString();
        kotlin.jvm.internal.r.c(string, "sb.toString()");
        eVar.c(string);
    }

    public final void t() {
        StringBuilder sb = new StringBuilder("sync\necho 3 > /proc/sys/vm/drop_caches\n");
        sb.append("sh ");
        sb.append(this.f777b);
        sb.append(" disable_swap ");
        sb.append(kotlin.text.k.y(e(), "loop", false, 2, (Object) null) ? "1" : "0");
        com.omarea.common.shell.e eVar = com.omarea.common.shell.e.f469b;
        String string = sb.toString();
        kotlin.jvm.internal.r.c(string, "sb.toString()");
        eVar.c(string);
    }

    public final String u(int i, boolean z) {
        StringBuilder sb = new StringBuilder();
        sb.append("sh ");
        sb.append(this.f777b);
        sb.append(" enable_swap ");
        sb.append(z ? "1" : "0");
        if (i > -2) {
            sb.append(" ");
            sb.append(i);
        }
        com.omarea.common.shell.j jVar = new com.omarea.common.shell.j(this.f779d);
        com.omarea.common.shell.e eVar = com.omarea.common.shell.e.f469b;
        String string = sb.toString();
        kotlin.jvm.internal.r.c(string, "sb.toString()");
        return jVar.a(eVar.c(string));
    }

    public final void v() {
        com.omarea.common.shell.e eVar = com.omarea.common.shell.e.f469b;
        String str = "sync\necho 3 > /proc/sys/vm/drop_caches\nswapoff /dev/block/zram0\n";
        kotlin.jvm.internal.r.c(str, "sb.toString()");
        eVar.c(str);
    }
}
