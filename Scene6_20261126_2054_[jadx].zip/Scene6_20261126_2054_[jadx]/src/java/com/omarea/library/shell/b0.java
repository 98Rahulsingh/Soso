package com.omarea.library.shell;

import android.content.Context;
import android.provider.Settings;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class b0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final int f728a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final int f729b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final Context f730c;

    public b0(Context context) {
        kotlin.jvm.internal.r.d(context, "context");
        this.f730c = context;
        this.f729b = 2;
    }

    public final void a() {
        if (Settings.Global.putInt(this.f730c.getContentResolver(), "zen_mode", this.f728a)) {
            return;
        }
        com.omarea.common.shell.e.f469b.e("settings put global zen_mode " + this.f728a);
    }

    public final void b() {
        if (Settings.Global.putInt(this.f730c.getContentResolver(), "zen_mode", this.f729b)) {
            return;
        }
        com.omarea.common.shell.e.f469b.e("settings put global zen_mode " + this.f729b);
    }
}
