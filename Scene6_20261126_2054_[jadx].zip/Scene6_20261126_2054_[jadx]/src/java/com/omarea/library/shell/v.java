package com.omarea.library.shell;

import android.content.SharedPreferences;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class v {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private Boolean f772a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final String f773b = "swap";

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final String f774c = "swap_size";

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private final String f775d = "swap_priority";
    private final String e = "swap_use_loop";
    private final String f = "zram";
    private final String g = "zram_size";
    private final String h = "comp_algorithm";
    private final String i = "swappiness";
    private final String j = "extra_free_kbytes";
    private final String k = "watermark_scale_factor";

    private final String c(List<String> list, String str) {
        Object obj;
        Iterator<T> it = list.iterator();
        while (true) {
            obj = null;
            if (!it.hasNext()) {
                break;
            }
            Object next = it.next();
            if (kotlin.text.k.t((String) next, str + '=', false, 2, (Object) null)) {
                obj = next;
                break;
            }
        }
        String str2 = (String) obj;
        return str2 != null ? str2.subSequence(str.length() + 1, str2.length()).toString() : "";
    }

    private final void f(String str, Object obj) {
        com.omarea.common.shell.e.f469b.e("busybox sed -i 's/^" + str + "=.*/" + str + '=' + obj + "/' /data/swap_config.conf");
    }

    public final boolean a() {
        Boolean boolValueOf;
        if (this.f772a == null) {
            if (com.omarea.common.shell.g.f472a.d("/data/swap_config.conf")) {
                String strA = t.f771a.a("vtools.swap.controller");
                boolValueOf = Boolean.valueOf(kotlin.jvm.internal.r.a(strA, "magisk") || kotlin.jvm.internal.r.a(strA, "module"));
            } else {
                boolValueOf = Boolean.FALSE;
            }
            this.f772a = boolValueOf;
        }
        Boolean bool = this.f772a;
        kotlin.jvm.internal.r.b(bool);
        return bool.booleanValue();
    }

    public final int b() {
        String strA = t.f771a.a("vtools.swap.module");
        if (kotlin.jvm.internal.r.a(strA, "error")) {
            return Integer.MAX_VALUE;
        }
        if (kotlin.jvm.internal.r.a(strA, "")) {
            return 0;
        }
        try {
            return Integer.parseInt(strA);
        } catch (Exception unused) {
            return 0;
        }
    }

    public final void d(SharedPreferences sharedPreferences) {
        kotlin.jvm.internal.r.d(sharedPreferences, "spf");
        if (a()) {
            SharedPreferences.Editor editorEdit = sharedPreferences.edit();
            List<String> listW = kotlin.text.k.W(com.omarea.common.shell.e.f469b.e("cat /data/swap_config.conf"), new String[]{"\n"}, false, 0, 6, (Object) null);
            try {
                editorEdit.putBoolean(com.omarea.store.j.n0, kotlin.jvm.internal.r.a(c(listW, this.f773b), "true"));
                editorEdit.putInt(com.omarea.store.j.o0, Integer.parseInt(c(listW, this.f774c)));
                editorEdit.putInt(com.omarea.store.j.p0, Integer.parseInt(c(listW, this.f775d)));
                editorEdit.putBoolean(com.omarea.store.j.q0, kotlin.jvm.internal.r.a(c(listW, this.e), "true"));
            } catch (Exception unused) {
            }
            try {
                editorEdit.putBoolean(com.omarea.store.j.r0, kotlin.jvm.internal.r.a(c(listW, this.f), "true"));
                editorEdit.putInt(com.omarea.store.j.s0, Integer.parseInt(c(listW, this.g)));
                editorEdit.putString(com.omarea.store.j.x0, c(listW, this.h));
            } catch (Exception unused2) {
            }
            try {
                editorEdit.putInt(com.omarea.store.j.t0, Integer.parseInt(c(listW, this.i)));
                editorEdit.putInt(com.omarea.store.j.u0, Integer.parseInt(c(listW, this.j)));
            } catch (Exception unused3) {
            }
            try {
                editorEdit.putInt(com.omarea.store.j.v0, Integer.parseInt(c(listW, this.k)));
            } catch (Exception unused4) {
            }
            editorEdit.apply();
        }
    }

    public final void e(SharedPreferences sharedPreferences) {
        kotlin.jvm.internal.r.d(sharedPreferences, "spf");
        f(this.f773b, Boolean.valueOf(sharedPreferences.getBoolean(com.omarea.store.j.n0, false)));
        f(this.f774c, Integer.valueOf(sharedPreferences.getInt(com.omarea.store.j.o0, 0)));
        f(this.f775d, Integer.valueOf(sharedPreferences.getInt(com.omarea.store.j.p0, 0)));
        f(this.e, Boolean.valueOf(sharedPreferences.getBoolean(com.omarea.store.j.q0, false)));
        f(this.f, Boolean.valueOf(sharedPreferences.getBoolean(com.omarea.store.j.r0, false)));
        f(this.g, Integer.valueOf(sharedPreferences.getInt(com.omarea.store.j.s0, 0)));
        f(this.h, "" + sharedPreferences.getString(com.omarea.store.j.x0, "lzo"));
        f(this.i, Integer.valueOf(sharedPreferences.getInt(com.omarea.store.j.t0, 100)));
        f(this.j, Integer.valueOf(sharedPreferences.getInt(com.omarea.store.j.u0, 29615)));
        f(this.k, Integer.valueOf(sharedPreferences.getInt(com.omarea.store.j.v0, 100)));
    }
}
