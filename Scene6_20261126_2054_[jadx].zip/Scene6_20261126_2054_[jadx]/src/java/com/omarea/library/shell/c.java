package com.omarea.library.shell;

import android.content.Context;
import android.util.Log;
import com.omarea.common.net.Daemon;
import java.nio.charset.Charset;
import java.util.Arrays;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class c {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private static Boolean f731b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private static String f732c;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final Context f733a;

    public c(Context context) {
        kotlin.jvm.internal.r.d(context, "context");
        this.f733a = context;
    }

    public final void a() {
        if (f732c == null && b()) {
            String strB = com.omarea.common.shared.f.f453a.b(this.f733a, 2131820551);
            Charset charsetDefaultCharset = Charset.defaultCharset();
            kotlin.jvm.internal.r.c(charsetDefaultCharset, "Charset.defaultCharset()");
            if (strB == null) {
                throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
            }
            byte[] bytes = strB.getBytes(charsetDefaultCharset);
            kotlin.jvm.internal.r.c(bytes, "(this as java.lang.String).getBytes(charset)");
            String strB2 = com.omarea.common.shared.f.f453a.b(this.f733a, 2131820549);
            Charset charsetDefaultCharset2 = Charset.defaultCharset();
            kotlin.jvm.internal.r.c(charsetDefaultCharset2, "Charset.defaultCharset()");
            if (strB2 == null) {
                throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
            }
            byte[] bytes2 = strB2.getBytes(charsetDefaultCharset2);
            kotlin.jvm.internal.r.c(bytes2, "(this as java.lang.String).getBytes(charset)");
            if (com.omarea.common.shared.d.f450b.h(bytes, "memcg_set_init.sh", this.f733a) && com.omarea.common.shared.d.f450b.h(bytes2, "memcg_set.sh", this.f733a)) {
                String strB3 = com.omarea.common.shared.d.f450b.b(this.f733a, "memcg_set_init.sh");
                com.omarea.common.shell.e.f469b.c("sh " + strB3);
                f732c = "sh " + com.omarea.common.shared.d.f450b.b(this.f733a, "memcg_set.sh") + " '%s' '%s' > /dev/null 2>&1 &";
            }
        }
    }

    public final boolean b() {
        if (f731b == null && Daemon.E.b() && kotlin.jvm.internal.r.a(Daemon.E.c(), "root")) {
            f731b = Boolean.valueOf(com.omarea.common.shell.g.f472a.d("/dev/memcg/tasks") || com.omarea.common.shell.g.f472a.d("/sys/fs/cgroup/memory/tasks"));
        }
        return kotlin.jvm.internal.r.a(f731b, Boolean.TRUE);
    }

    public final void c(String str, String str2) {
        String str3;
        kotlin.jvm.internal.r.d(str, "packageName");
        kotlin.jvm.internal.r.d(str2, "group");
        if (b()) {
            a();
            if (f732c == null) {
                Log.e("Scene", "CGroup Init Fail!");
                return;
            }
            if (str2.length() > 0) {
                str3 = '/' + str2;
            } else {
                str3 = "";
            }
            kotlin.jvm.internal.w wVar = kotlin.jvm.internal.w.a;
            String str4 = f732c;
            kotlin.jvm.internal.r.b(str4);
            String str5 = String.format(str4, Arrays.copyOf(new Object[]{str, str3}, 2));
            kotlin.jvm.internal.r.c(str5, "java.lang.String.format(format, *args)");
            com.omarea.common.shell.e.f469b.c(str5);
        }
    }
}
