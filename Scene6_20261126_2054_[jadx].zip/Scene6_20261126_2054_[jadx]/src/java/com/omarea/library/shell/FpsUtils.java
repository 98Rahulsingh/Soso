package com.omarea.library.shell;

import com.omarea.common.net.Daemon;
import java.util.Arrays;
import java.util.List;
import kotlin.coroutines.CoroutineContext;
import kotlin.text.Regex;
import kotlinx.coroutines.CoroutineStart;
import kotlinx.coroutines.i0;
import kotlinx.coroutines.w0;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class FpsUtils {
    private static float g;
    private static long h = System.currentTimeMillis();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private String f700a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private String f701b = "| awk '{print $2}'";

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private j f702c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private String f703d;
    private long e;
    private int f;

    public FpsUtils() {
        FpsUtils$subStrFun$1 fpsUtils$subStrFun$1 = new kotlin.jvm.b.l<String, String>() { // from class: com.omarea.library.shell.FpsUtils$subStrFun$1
            public final String invoke(String str) {
                kotlin.jvm.internal.r.d(str, "it");
                List listSplit = new Regex("[\\s]+").split(str, 0);
                return listSplit.size() > 1 ? (String) listSplit.get(1) : "";
            }
        };
        this.f703d = "service call SurfaceFlinger 1013";
        this.e = -1L;
        this.f = -1;
    }

    public final String c() {
        String str = this.f700a;
        if (!(str == null || str.length() == 0)) {
            return Daemon.E.a().i0("cat " + this.f700a + ' ' + this.f701b);
        }
        if (this.f700a != null) {
            if (this.f703d.length() > 0) {
                String strI0 = Daemon.E.a().i0(this.f703d);
                if (strI0 == null) {
                    throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
                }
                String string = kotlin.text.k.k0(strI0).toString();
                if (!(!kotlin.jvm.internal.r.a(string, "error")) || kotlin.text.k.y(string, "Parcel", false, 2, (Object) null)) {
                    try {
                        int iH = kotlin.text.k.H(string, "(", 0, false, 6, (Object) null) + 1;
                        int i = iH + 8;
                        if (string == null) {
                            throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                        }
                        String strSubstring = string.substring(iH, i);
                        kotlin.jvm.internal.r.c(strSubstring, "(this as java.lang.Strin…ing(startIndex, endIndex)");
                        int i2 = Integer.parseInt(strSubstring, 16);
                        long jCurrentTimeMillis = System.currentTimeMillis();
                        float f = 0.0f;
                        if (this.e > 0 && this.f > 0) {
                            f = ((i2 - this.f) * 1000.0f) / (jCurrentTimeMillis - this.e);
                        }
                        this.f = i2;
                        this.e = jCurrentTimeMillis;
                        kotlin.jvm.internal.w wVar = kotlin.jvm.internal.w.a;
                        String str2 = String.format("%.1f", Arrays.copyOf(new Object[]{Float.valueOf(f)}, 1));
                        kotlin.jvm.internal.r.c(str2, "java.lang.String.format(format, *args)");
                        return str2;
                    } catch (Exception unused) {
                        if (this.e <= 0 || this.f <= 0) {
                        }
                    }
                } else {
                    this.f703d = "";
                }
            }
        } else if (com.omarea.common.shell.g.f472a.d("/sys/class/drm/sde-crtc-0/measured_fps")) {
            this.f700a = "/sys/class/drm/sde-crtc-0/measured_fps";
        } else if (com.omarea.common.shell.g.f472a.d("/sys/class/graphics/fb0/measured_fps")) {
            this.f700a = "/sys/class/graphics/fb0/measured_fps";
            this.f701b = "";
        } else {
            this.f700a = "";
            kotlinx.coroutines.f.d(i0.a(w0.b()), (CoroutineContext) null, (CoroutineStart) null, new FpsUtils$currentFpsLegend$1(this, new com.omarea.common.shell.b(), null), 3, (Object) null);
        }
        return null;
    }

    public final String d() {
        if (this.f703d.length() > 0) {
            String strE = com.omarea.common.shell.e.f469b.e(this.f703d);
            if (strE == null) {
                throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
            }
            String string = kotlin.text.k.k0(strE).toString();
            if (!(!kotlin.jvm.internal.r.a(string, "error")) || kotlin.text.k.y(string, "Parcel", false, 2, (Object) null)) {
                try {
                    int iH = kotlin.text.k.H(string, "(", 0, false, 6, (Object) null) + 1;
                    int i = iH + 8;
                    if (string == null) {
                        throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                    }
                    String strSubstring = string.substring(iH, i);
                    kotlin.jvm.internal.r.c(strSubstring, "(this as java.lang.Strin…ing(startIndex, endIndex)");
                    int i2 = Integer.parseInt(strSubstring, 16);
                    long jCurrentTimeMillis = System.currentTimeMillis();
                    float f = 0.0f;
                    if (this.e > 0 && this.f > 0) {
                        f = ((i2 - this.f) * 1000.0f) / (jCurrentTimeMillis - this.e);
                    }
                    if (i2 < this.f) {
                        this.f703d = "";
                    }
                    this.f = i2;
                    this.e = jCurrentTimeMillis;
                    kotlin.jvm.internal.w wVar = kotlin.jvm.internal.w.a;
                    String str = String.format("%.1f", Arrays.copyOf(new Object[]{Float.valueOf(f)}, 1));
                    kotlin.jvm.internal.r.c(str, "java.lang.String.format(format, *args)");
                    return str;
                } catch (Exception unused) {
                    if (this.e <= 0 || this.f <= 0) {
                    }
                }
            } else {
                this.f703d = "";
            }
        }
        return c();
    }

    public final float e() {
        if (System.currentTimeMillis() - h < 250) {
            return g;
        }
        if (!kotlin.jvm.internal.r.a(Daemon.E.c(), "adb")) {
            g = 0.0f;
            String strD = d();
            if (strD != null) {
                try {
                    g = Float.parseFloat(strD);
                    h = System.currentTimeMillis();
                } catch (Exception unused) {
                }
            }
            return g;
        }
        if (this.f702c == null) {
            this.f702c = new j();
        }
        j jVar = this.f702c;
        kotlin.jvm.internal.r.b(jVar);
        j.a aVarC = j.c(jVar, false, null, 3, null);
        g = aVarC != null ? aVarC.b() : 0;
        h = System.currentTimeMillis();
        return g;
    }
}
