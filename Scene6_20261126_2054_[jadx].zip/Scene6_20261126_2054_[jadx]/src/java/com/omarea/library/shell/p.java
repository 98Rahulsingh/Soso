package com.omarea.library.shell;

import android.os.Build;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class p {
    public final void a() {
        com.omarea.common.shell.e eVar;
        String str;
        int i = Build.VERSION.SDK_INT;
        if (i > 28) {
            eVar = com.omarea.common.shell.e.f469b;
            str = "settings put secure location_mode 0";
        } else if (i >= 23) {
            eVar = com.omarea.common.shell.e.f469b;
            str = "settings put secure location_providers_allowed -gps";
        } else {
            eVar = com.omarea.common.shell.e.f469b;
            str = "settings put secure location_providers_allowed network";
        }
        eVar.e(str);
    }

    public final void b() {
        com.omarea.common.shell.e eVar;
        String str;
        int i = Build.VERSION.SDK_INT;
        if (i > 28) {
            eVar = com.omarea.common.shell.e.f469b;
            str = "settings put secure location_mode 0";
        } else if (i >= 23) {
            eVar = com.omarea.common.shell.e.f469b;
            str = "settings put secure location_providers_allowed -gps,-network";
        } else {
            eVar = com.omarea.common.shell.e.f469b;
            str = "settings delete secure location_providers_allowed";
        }
        eVar.e(str);
    }

    public final void c() {
        com.omarea.common.shell.e eVar;
        String str;
        int i = Build.VERSION.SDK_INT;
        if (i > 28) {
            eVar = com.omarea.common.shell.e.f469b;
            str = "settings put secure location_mode 3";
        } else if (i >= 23) {
            eVar = com.omarea.common.shell.e.f469b;
            str = "settings put secure location_providers_allowed +gps";
        } else {
            eVar = com.omarea.common.shell.e.f469b;
            str = "settings put secure location_providers_allowed gps,network";
        }
        eVar.e(str);
    }
}
