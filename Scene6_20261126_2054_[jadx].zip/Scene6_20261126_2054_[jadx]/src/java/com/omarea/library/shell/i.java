package com.omarea.library.shell;

import android.os.Build;
import java.util.ArrayList;
import java.util.List;
import kotlin.text.Regex;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class i {
    public final ArrayList<String> a() {
        ArrayList<String> arrayList = new ArrayList<>();
        Object obj = null;
        if (Build.VERSION.SDK_INT >= 28) {
            String strE = com.omarea.common.shell.e.f469b.e("dumpsys activity lru");
            if ((!kotlin.jvm.internal.r.a(strE, "error")) && !kotlin.text.k.y(strE, "Unknown command", false, 2, (Object) null)) {
                for (String str : kotlin.text.k.W(strE, new String[]{"\n"}, false, 0, 6, (Object) null)) {
                    if (kotlin.text.k.y(str, " TOP ", false, 2, obj)) {
                        List<String> listSplit = new Regex("[ ]+").split(str, 0);
                        Regex regex = new Regex("[0-9]+:.*/u.*");
                        for (String str2 : listSplit) {
                            if (regex.matches(str2)) {
                                int iH = kotlin.text.k.H(str2, ":", 0, false, 6, (Object) null) + 1;
                                int iH2 = kotlin.text.k.H(str2, "/", 0, false, 6, (Object) null);
                                if (str2 == null) {
                                    throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                                }
                                String strSubstring = str2.substring(iH, iH2);
                                kotlin.jvm.internal.r.c(strSubstring, "(this as java.lang.Strin…ing(startIndex, endIndex)");
                                arrayList.add(strSubstring);
                            }
                        }
                    }
                    obj = null;
                }
            }
        } else {
            String strB = new b().b();
            if (kotlin.text.k.y(strB, "/", false, 2, (Object) null)) {
                int iH3 = kotlin.text.k.H(strB, "/", 0, false, 6, (Object) null);
                if (strB == null) {
                    throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                }
                String strSubstring2 = strB.substring(0, iH3);
                kotlin.jvm.internal.r.c(strSubstring2, "(this as java.lang.Strin…ing(startIndex, endIndex)");
                arrayList.add(strSubstring2);
            }
        }
        return arrayList;
    }
}
