package com.omarea.library.shell;

import java.util.Iterator;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class b {
    private final String a(String str) {
        if (!kotlin.text.k.y(str, "/.", false, 2, (Object) null)) {
            return str;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("/");
        int iH = kotlin.text.k.H(str, "/.", 0, false, 6, (Object) null);
        if (str == null) {
            throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
        }
        String strSubstring = str.substring(0, iH);
        kotlin.jvm.internal.r.c(strSubstring, "(this as java.lang.Strin…ing(startIndex, endIndex)");
        sb.append(strSubstring);
        sb.append(".");
        return kotlin.text.k.r(str, "/.", sb.toString(), false, 4, (Object) null);
    }

    public final String b() {
        String strE = com.omarea.common.shell.e.f469b.e("dumpsys activity activities | grep -E '(mFocusedWindow|mResumedActivity)'");
        if (!kotlin.text.k.y(strE, "mFocusedWindow", false, 2, (Object) null) && !kotlin.text.k.y(strE, "mResumedActivity", false, 2, (Object) null)) {
            return "";
        }
        Iterator it = kotlin.text.k.W(strE, new String[]{"\n"}, false, 0, 6, (Object) null).iterator();
        while (it.hasNext()) {
            for (String str : kotlin.text.k.W((String) it.next(), new String[]{" "}, false, 0, 6, (Object) null)) {
                if (kotlin.text.k.y(str, "/", false, 2, (Object) null)) {
                    if (!kotlin.text.k.m(str, "}", false, 2, (Object) null)) {
                        return a(str);
                    }
                    int length = str.length() - 1;
                    if (str == null) {
                        throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                    }
                    String strSubstring = str.substring(0, length);
                    kotlin.jvm.internal.r.c(strSubstring, "(this as java.lang.Strin…ing(startIndex, endIndex)");
                    return a(strSubstring);
                }
            }
        }
        return "";
    }
}
