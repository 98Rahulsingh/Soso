package com.omarea.library.shell;

import com.omarea.common.net.Daemon;
import com.omarea.model.CpuStatus;
import java.io.File;
import java.util.AbstractMap;
import java.util.ArrayList;
import kotlin.text.Regex;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class n {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private static String f760a = null;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private static String f761b = null;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private static String f762c = "/proc/mtk_mali/gpu_memory";

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private static String f763d = "/proc/mali/memory_usage";
    private static String e = "cat /proc/mali/memory_usage | grep \"Total\" | cut -f2 -d \"(\" | cut -f1 -d \" \"";
    private static String f = null;
    private static String g = null;
    private static boolean h = true;
    private static Boolean i = null;
    private static Boolean j = null;
    private static String k = "/sys/class/kgsl/kgsl-3d0";
    private static String l = "/sys/class/devfreq/gpufreq";
    private static String m = null;
    private static f n = null;
    private static String o = "";
    private static int p;
    private static long q = System.currentTimeMillis() - 201;
    private static f r;

    static class a implements f {
        a() {
        }

        @Override // com.omarea.library.shell.n.f
        public String a(String str) {
            return n.e(str);
        }
    }

    static class b implements f {
        b() {
        }

        @Override // com.omarea.library.shell.n.f
        public String a(String str) {
            return n.f(str);
        }
    }

    static class c implements f {
        c() {
        }

        @Override // com.omarea.library.shell.n.f
        public String a(String str) {
            try {
                return "" + (Long.parseLong(str.split(" ")[1]) / 1000);
            } catch (Exception unused) {
                return "";
            }
        }
    }

    static class d implements f {
        d() {
        }

        @Override // com.omarea.library.shell.n.f
        public String a(String str) {
            try {
                return "" + (Long.parseLong(str.split(" ")[1]) / 1000);
            } catch (Exception unused) {
                return "";
            }
        }
    }

    static class e implements f {
        e() {
        }

        @Override // com.omarea.library.shell.n.f
        public String a(String str) {
            String[] strArrSplit = str.trim().split(" ");
            if (strArrSplit.length != 2) {
                return "-1";
            }
            int i = Integer.parseInt(strArrSplit[0]);
            return "" + ((i * 100) / Integer.parseInt(strArrSplit[1]));
        }
    }

    @FunctionalInterface
    interface f {
        String a(String str);
    }

    private static boolean A(String str) {
        return new Regex("[0-9]{1,}").matches(str);
    }

    public static int B() {
        if (System.currentTimeMillis() - q < 200) {
            return p;
        }
        String strA = com.omarea.common.shell.f.f471b.a("/sys/kernel/debug/mali0/dvfs_utilization");
        int i2 = 0;
        if (!o.isEmpty()) {
            try {
                String[] strArrSplit = o.split(" ");
                String[] strArrSplit2 = strA.split(" ");
                long j2 = Long.parseLong(strArrSplit[1]);
                long j3 = Long.parseLong(strArrSplit[3]) + j2;
                long j4 = Long.parseLong(strArrSplit2[1]);
                long j5 = Long.parseLong(strArrSplit2[3]) + j4;
                if (j3 == j5) {
                    return 0;
                }
                i2 = (int) (((j4 - j2) * 100) / (j5 - j3));
            } catch (Exception unused) {
                return -1;
            }
        } else if (!strA.contains("busy_time")) {
            return -1;
        }
        o = strA;
        p = i2;
        q = System.currentTimeMillis();
        return i2;
    }

    public static void C(String str) {
        ArrayList arrayList = new ArrayList();
        arrayList.add("chmod 0664 /sys/class/kgsl/kgsl-3d0/default_pwrlevel;");
        arrayList.add("echo " + str + " > /sys/class/kgsl/kgsl-3d0/default_pwrlevel;");
        com.omarea.common.shell.e.f469b.d(arrayList);
    }

    public static void D(String str) {
        ArrayList arrayList = new ArrayList();
        arrayList.add("chmod 0664 /sys/class/kgsl/kgsl-3d0/max_pwrlevel;");
        arrayList.add("echo " + str + " > /sys/class/kgsl/kgsl-3d0/max_pwrlevel;");
        com.omarea.common.shell.e.f469b.d(arrayList);
    }

    public static void E(String str) {
        ArrayList arrayList = new ArrayList();
        arrayList.add("chmod 0664 /sys/class/kgsl/kgsl-3d0/min_pwrlevel;");
        arrayList.add("echo " + str + " > /sys/class/kgsl/kgsl-3d0/min_pwrlevel;");
        com.omarea.common.shell.e.f469b.d(arrayList);
    }

    public static void F(String str) {
        ArrayList arrayList = new ArrayList();
        arrayList.add("chmod 0664 " + t() + "/governor;");
        arrayList.add("echo " + str + " > " + t() + "/governor;");
        com.omarea.common.shell.e.f469b.d(arrayList);
    }

    public static void G(String str) {
        ArrayList arrayList = new ArrayList();
        arrayList.add("chmod 0664 " + t() + "/max_freq;");
        arrayList.add("echo " + str + " > " + t() + "/max_freq;");
        com.omarea.common.shell.e.f469b.d(arrayList);
    }

    public static void H(String str) {
        ArrayList arrayList = new ArrayList();
        arrayList.add("chmod 0664 " + t() + "/min_freq;");
        arrayList.add("echo " + str + " > " + t() + "/min_freq;");
        com.omarea.common.shell.e.f469b.d(arrayList);
    }

    public static boolean I() {
        return x() || z();
    }

    private static boolean d() {
        if (!com.omarea.common.shell.g.f472a.d("/proc/gpufreq/gpufreq_var_dump")) {
            return false;
        }
        String strA = com.omarea.common.shell.f.f471b.a("/proc/gpufreq/gpufreq_var_dump");
        String strE = e(strA);
        String strF = f(strA);
        if (strE.length() > 0) {
            f761b = "/proc/gpufreq/gpufreq_var_dump";
            n = new a();
        }
        if (strF.length() <= 0) {
            return true;
        }
        f760a = "/proc/gpufreq/gpufreq_var_dump";
        r = new b();
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static String e(String str) {
        try {
            for (String str2 : str.split("\n")) {
                if (str2.startsWith("(real)") && str2.contains("freq:")) {
                    String str3 = str2.split(",")[0];
                    return "" + (Long.parseLong(str3.substring(str3.indexOf(":") + 1).trim()) / 1000);
                }
            }
        } catch (Exception unused) {
        }
        return "";
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static String f(String str) {
        try {
            for (String str2 : str.split("\n")) {
                if (str2.startsWith("gpu_loading")) {
                    return str2.contains(":") ? str2.trim().split(":")[1].trim() : str2.trim().split("=")[1].trim();
                }
            }
            return "";
        } catch (Exception unused) {
            return "";
        }
    }

    private static String g() {
        String strTrim = com.omarea.common.shell.f.f471b.a(f762c).trim().split("\n")[0].replace("\t", " ").trim();
        return (strTrim.length() <= 0 || !strTrim.contains(" ")) ? "" : strTrim.substring(strTrim.indexOf(" ")).trim();
    }

    private static String h() {
        String strTrim = com.omarea.common.shell.f.f471b.a(f763d).trim().split("\n")[0].replace("\t", " ").trim();
        if (strTrim.length() <= 0 || !strTrim.contains(" ") || !strTrim.contains("bytes") || !strTrim.contains("(")) {
            return "";
        }
        String strTrim2 = strTrim.substring(strTrim.indexOf(" ")).trim();
        return strTrim2.substring(strTrim2.indexOf("(") + 1, strTrim2.indexOf("b")).trim();
    }

    private void i(ArrayList<AbstractMap.SimpleEntry<String, String>> arrayList, String str, String str2) {
        arrayList.add(new AbstractMap.SimpleEntry<>(str, str2));
    }

    public static String j() {
        return com.omarea.common.shell.f.f471b.a("/sys/class/kgsl/kgsl-3d0/default_pwrlevel");
    }

    public static String k() {
        return com.omarea.common.shell.f.f471b.a("/sys/class/kgsl/kgsl-3d0/max_pwrlevel");
    }

    public static String l() {
        return com.omarea.common.shell.f.f471b.a("/sys/class/kgsl/kgsl-3d0/min_pwrlevel");
    }

    public static String[] m() {
        try {
            int i2 = Integer.parseInt(com.omarea.common.shell.f.f471b.a("/sys/class/kgsl/kgsl-3d0/num_pwrlevels"));
            ArrayList arrayList = new ArrayList();
            for (int i3 = 0; i3 < i2; i3++) {
                arrayList.add("" + i3);
            }
            return (String[]) arrayList.toArray(new String[0]);
        } catch (Exception unused) {
            return new String[0];
        }
    }

    public static String[] n() {
        String strA = com.omarea.common.shell.f.f471b.a(t() + "/available_frequencies");
        return strA.isEmpty() ? new String[0] : strA.split("[ ]+");
    }

    public static String[] o() {
        if (x()) {
            String strA = com.omarea.common.shell.f.f471b.a(k + "/freq_table_mhz");
            if (!strA.isEmpty()) {
                return strA.split("[ ]+");
            }
        }
        return new String[0];
    }

    public static String p() {
        return com.omarea.common.shell.f.f471b.a(t() + "/governor");
    }

    public static String[] q() {
        String strA = com.omarea.common.shell.f.f471b.a(t() + "/available_governors");
        return strA.isEmpty() ? new String[0] : strA.split("[ ]+");
    }

    public static String r() {
        int length;
        f dVar;
        if (!Daemon.E.c().equals("root")) {
            return "";
        }
        if (f761b == null) {
            String str = t() + "/cur_freq";
            if (com.omarea.common.shell.g.f472a.d(str)) {
                f761b = str;
            } else if (com.omarea.common.shell.g.f472a.d("/sys/kernel/gpu/gpu_clock")) {
                f761b = "/sys/kernel/gpu/gpu_clock";
            } else if (com.omarea.common.shell.g.f472a.d("/sys/devices/platform/1c500000.mali/cur_freq")) {
                f761b = "/sys/devices/platform/1c500000.mali/cur_freq";
            } else if (!d() || f761b == null) {
                if (com.omarea.common.shell.g.f472a.d("/sys/kernel/debug/ged/hal/current_freqency")) {
                    f761b = "/sys/kernel/debug/ged/hal/current_freqency";
                    dVar = new c();
                } else if (com.omarea.common.shell.g.f472a.d("/sys/kernel/ged/hal/current_freqency")) {
                    f761b = "/sys/kernel/ged/hal/current_freqency";
                    dVar = new d();
                } else {
                    f761b = "";
                }
                n = dVar;
            }
        }
        if (f761b.isEmpty()) {
            return "";
        }
        String strA = com.omarea.common.shell.f.f471b.a(f761b);
        f fVar = n;
        if (fVar != null) {
            strA = fVar.a(strA);
        }
        if (strA.length() > 6) {
            length = strA.length() - 6;
        } else {
            if (strA.length() <= 4) {
                return strA;
            }
            length = strA.length() - 3;
        }
        return strA.substring(0, length);
    }

    public static int s() {
        if (Daemon.E.c().equals("basic")) {
            return -1;
        }
        if (f760a == null && o.isEmpty()) {
            B();
            if (o.equals("") && (!d() || f761b == null)) {
                String[] strArr = {"/sys/class/kgsl/kgsl-3d0/gpu_busy_percentage", "/sys/class/kgsl/kgsl-3d0/devfreq/gpu_load", "/sys/kernel/gpu/gpu_busy", "/sys/class/kgsl/kgsl-3d0/gpubusy", "/sys/class/kgsl/kgsl-3d0/gpuload", "/sys/class/devfreq/gpufreq/mali_ondemand/utilisation", "/sys/kernel/debug/ged/hal/gpu_utilization", "/sys/kernel/ged/hal/gpu_utilization", "/sys/module/ged/parameters/gpu_loading", "/sys/devices/platform/1c500000.mali/utilization"};
                f760a = "";
                for (int i2 = 0; i2 < 10; i2++) {
                    String str = strArr[i2];
                    if (com.omarea.common.shell.g.f472a.d(str)) {
                        f760a = str;
                        if (!str.equals("/sys/class/kgsl/kgsl-3d0/gpubusy")) {
                            break;
                        }
                        r = new e();
                        break;
                    }
                }
            }
        }
        if (!o.isEmpty()) {
            return B();
        }
        if (f760a.equals("")) {
            return -1;
        }
        String strA = com.omarea.common.shell.f.f471b.a(f760a);
        try {
            return r != null ? Integer.parseInt(r.a(strA)) : Integer.parseInt(strA.replace("%", "").trim().split(" ")[0]);
        } catch (Exception unused) {
            return -1;
        }
    }

    private static String t() {
        String str;
        if (!Daemon.E.c().equals("root")) {
            return "";
        }
        if (m == null) {
            if (x()) {
                str = k + "/devfreq";
            } else if (z()) {
                str = l;
            } else {
                m = "";
            }
            m = str;
        }
        return m;
    }

    public static String u() {
        return com.omarea.common.shell.f.f471b.a(t() + "/max_freq");
    }

    public static String v() {
        String str;
        if (!Daemon.E.c().equals("root")) {
            return null;
        }
        if (!y()) {
            if (h) {
                try {
                    return ((Long.parseLong(com.omarea.common.shell.f.f471b.a("/sys/devices/virtual/kgsl/kgsl/page_alloc")) / 1024) / 1024) + "MB";
                } catch (Exception unused) {
                    h = false;
                }
            }
            return null;
        }
        if (f == null) {
            f = "";
            if (A(com.omarea.common.shell.e.f469b.e(e))) {
                str = e;
            } else if (A(g())) {
                str = f762c;
            } else if (A(h())) {
                str = f763d;
            }
            f = str;
        }
        if (f.equals("")) {
            return "?MB";
        }
        try {
            if (f762c.equals(f)) {
                String strG = g();
                if (!A(strG)) {
                    return "?MB";
                }
                return ((Long.parseLong(strG) * 4) / 1024) + "MB";
            }
            if (f763d.equals(f)) {
                String strH = h();
                if (!A(strH)) {
                    return "?MB";
                }
                return ((Long.parseLong(strH) / 1024) / 1024) + "MB";
            }
            String strE = com.omarea.common.shell.e.f469b.e(f);
            if (!A(strE)) {
                return "?MB";
            }
            return ((Long.parseLong(strE) / 1024) / 1024) + "MB";
        } catch (Exception unused2) {
            return "?MB";
        }
    }

    public static String w() {
        return com.omarea.common.shell.f.f471b.a(t() + "/min_freq");
    }

    public static boolean x() {
        if (!Daemon.E.c().equals("root")) {
            return false;
        }
        if (i == null) {
            i = Boolean.valueOf(new File(k).exists() || com.omarea.common.shell.g.f472a.b(k));
        }
        return i.booleanValue();
    }

    private static boolean y() {
        if (g == null) {
            g = new r().b();
        }
        return g.startsWith("mt");
    }

    private static boolean z() {
        if (!Daemon.E.c().equals("root")) {
            return false;
        }
        if (j == null) {
            j = Boolean.valueOf(new File(l).exists() || com.omarea.common.shell.g.f472a.b(l));
        }
        return j.booleanValue();
    }

    public ArrayList<AbstractMap.SimpleEntry<String, String>> c(CpuStatus cpuStatus) {
        ArrayList<AbstractMap.SimpleEntry<String, String>> arrayList = new ArrayList<>();
        if (!cpuStatus.adrenoGovernor.equals("")) {
            i(arrayList, t() + "/governor", cpuStatus.adrenoGovernor);
        }
        if (!cpuStatus.adrenoMinFreq.equals("")) {
            i(arrayList, t() + "/min_freq", cpuStatus.adrenoMinFreq);
        }
        if (!cpuStatus.adrenoMaxFreq.equals("")) {
            i(arrayList, t() + "/max_freq", cpuStatus.adrenoMaxFreq);
        }
        if (!cpuStatus.adrenoMinFreq.equals("")) {
            i(arrayList, t() + "/min_freq", cpuStatus.adrenoMinFreq);
        }
        if (!cpuStatus.adrenoMinPL.equals("")) {
            i(arrayList, "/sys/class/kgsl/kgsl-3d0/min_pwrlevel", cpuStatus.adrenoMinPL);
        }
        if (!cpuStatus.adrenoMaxPL.equals("")) {
            i(arrayList, "/sys/class/kgsl/kgsl-3d0/max_pwrlevel", cpuStatus.adrenoMaxPL);
        }
        if (!cpuStatus.adrenoMinPL.equals("")) {
            i(arrayList, "/sys/class/kgsl/kgsl-3d0/min_pwrlevel", cpuStatus.adrenoMinPL);
        }
        if (!cpuStatus.adrenoDefaultPL.equals("")) {
            i(arrayList, "/sys/class/kgsl/kgsl-3d0/default_pwrlevel", cpuStatus.adrenoDefaultPL);
        }
        return arrayList;
    }
}
