package com.omarea.library.shell;

import com.omarea.Scene;
import com.omarea.common.net.Daemon;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlinx.coroutines.h0;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
@kotlin.coroutines.jvm.internal.d(c = "com.omarea.library.shell.BatteryUtils$setCurrentLimitMA$1", f = "BatteryUtils.kt", l = {}, m = "invokeSuspend")
final class BatteryUtils$setCurrentLimitMA$1 extends SuspendLambda implements kotlin.jvm.b.p<h0, kotlin.coroutines.c<? super kotlin.s>, Object> {
    final /* synthetic */ int $limit;
    int label;
    private h0 p$;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    BatteryUtils$setCurrentLimitMA$1(int i, kotlin.coroutines.c cVar) {
        super(2, cVar);
        this.$limit = i;
    }

    public final kotlin.coroutines.c<kotlin.s> create(Object obj, kotlin.coroutines.c<?> cVar) {
        kotlin.jvm.internal.r.d(cVar, "completion");
        BatteryUtils$setCurrentLimitMA$1 batteryUtils$setCurrentLimitMA$1 = new BatteryUtils$setCurrentLimitMA$1(this.$limit, cVar);
        batteryUtils$setCurrentLimitMA$1.p$ = (h0) obj;
        return batteryUtils$setCurrentLimitMA$1;
    }

    public final Object invoke(Object obj, Object obj2) {
        return create(obj, (kotlin.coroutines.c) obj2).invokeSuspend(kotlin.s.a);
    }

    public final Object invokeSuspend(Object obj) {
        kotlin.coroutines.intrinsics.a.d();
        if (this.label != 0) {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        kotlin.h.b(obj);
        synchronized (Scene.l.b()) {
            BatteryUtils.f692c = true;
            Daemon.A0(Daemon.E.a(), "charge-control", this.$limit + "000", 0, 4, null);
            BatteryUtils.f692c = false;
            kotlin.s sVar = kotlin.s.a;
        }
        return kotlin.s.a;
    }
}
