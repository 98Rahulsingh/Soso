package com.omarea.library.shell;

import android.content.Context;
import java.util.LinkedHashMap;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public abstract class d {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private static final LinkedHashMap<String, String> f734b = new LinkedHashMap<>();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final String f735a;

    public d(Context context, String str) {
        kotlin.jvm.internal.r.d(context, "context");
        kotlin.jvm.internal.r.d(str, "storageKey");
        this.f735a = str;
    }

    private final void a() {
        String strC = c();
        if (strC != null) {
            if ((strC.length() > 0) && (!kotlin.jvm.internal.r.a(strC, "error"))) {
                f734b.put(this.f735a, strC);
            }
        }
    }

    private final String b() {
        if (!f734b.containsKey(this.f735a)) {
            a();
        }
        if (f734b.containsKey(this.f735a)) {
            return f734b.get(this.f735a);
        }
        return null;
    }

    public abstract String c();

    public final void d() {
        if (f734b.containsKey(this.f735a)) {
            f734b.remove(this.f735a);
        }
        b();
    }

    public String toString() {
        String strB = b();
        return strB != null ? strB : "";
    }
}
