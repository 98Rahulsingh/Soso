package com.omarea.library.shell;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class t {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final t f771a = new t();

    private t() {
    }

    public final String a(String str) {
        kotlin.jvm.internal.r.d(str, "propName");
        try {
            String property = System.getProperty(str);
            if (!(property == null || property.length() == 0)) {
                return property;
            }
        } catch (Exception unused) {
        }
        String strE = com.omarea.common.shell.e.f469b.e("getprop \"" + str + '\"');
        if (kotlin.jvm.internal.r.a(strE, "error")) {
            return "";
        }
        if (!kotlin.text.k.m(strE, "\n", false, 2, (Object) null)) {
            return strE;
        }
        int length = strE.length() - 1;
        if (strE == null) {
            throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
        }
        String strSubstring = strE.substring(0, length);
        kotlin.jvm.internal.r.c(strSubstring, "(this as java.lang.Strin…ing(startIndex, endIndex)");
        return strSubstring;
    }

    public final boolean b(String str, String str2) {
        kotlin.jvm.internal.r.d(str, "propName");
        kotlin.jvm.internal.r.d(str2, "value");
        return !kotlin.jvm.internal.r.a(com.omarea.common.shell.e.f469b.e("setprop \"" + str + "\" \"" + str2 + '\"'), "error");
    }
}
