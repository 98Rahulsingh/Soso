package com.omarea.library.shell;

import android.os.Build;
import com.omarea.common.net.Daemon;
import java.util.Locale;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class y {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final String f780a = "/sys/class/thermal/thermal_message/board_sensor_temp";

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final String f781b = "/sys/module/migt/parameters/glk_maxfreq";

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final String f782c = "com.xiaomi.gamecenter.sdk.service";

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private final String f783d = "com.xiaomi.gamecenter.sdk.service/.PidService";
    private final String e = "vtools.thermal.disguise";

    private final boolean c() {
        return kotlin.text.k.t(new r().b(), "mt", false, 2, (Object) null);
    }

    public final void a() {
        if (c()) {
            Daemon.E.a().k0(true);
            return;
        }
        com.omarea.common.shell.e.f469b.c("chmod 644 " + this.f780a + "\necho 34900 > " + this.f780a + "\nchmod 000 " + this.f780a + "\nchmod 644 " + this.f781b + "\necho 0 0 0 > " + this.f781b + "\nchmod 644 " + this.f781b + "\npm disable " + this.f783d + "\npm clear " + this.f782c + "\nsetprop " + this.e + " 1");
    }

    public final boolean b() {
        return kotlin.jvm.internal.r.a(t.f771a.a(this.e), "1");
    }

    public final void d() {
        if (c()) {
            Daemon.E.a().k0(false);
            return;
        }
        com.omarea.common.shell.e.f469b.c("chmod 644 " + this.f780a + "\nchmod 644 " + this.f781b + "\npm enable " + this.f783d + "\nsetprop " + this.e + " 0");
    }

    public final boolean e() {
        String strB = new r().b();
        if (kotlin.jvm.internal.r.a(strB, "mt6895") || kotlin.jvm.internal.r.a(strB, "mt6983")) {
            return true;
        }
        String str = Build.MANUFACTURER;
        kotlin.jvm.internal.r.c(str, "Build.MANUFACTURER");
        Locale locale = Locale.getDefault();
        kotlin.jvm.internal.r.c(locale, "Locale.getDefault()");
        if (str == null) {
            throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
        }
        String upperCase = str.toUpperCase(locale);
        kotlin.jvm.internal.r.c(upperCase, "(this as java.lang.String).toUpperCase(locale)");
        if (kotlin.jvm.internal.r.a(upperCase, "XIAOMI") && new r().b().equals("lahaina") && kotlin.jvm.internal.r.a(t.f771a.a("init.svc.mi_thermald"), "running")) {
            return com.omarea.common.shell.g.f472a.d(this.f780a);
        }
        return false;
    }
}
