package com.omarea.library.shell;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class q {

    public static class a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f765a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public int f766b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public int f767c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public int f768d;
    }

    private static int a(String str) {
        return Integer.parseInt(str.substring(str.indexOf(":") + 1, str.lastIndexOf(" ")).trim());
    }

    /* JADX WARN: Code duplicated, block: B:6:0x0021  */
    public a b() {
        String[] strArrSplit = com.omarea.common.shell.f.f471b.a("/proc/meminfo").split("\n");
        a aVar = new a();
        for (String str : strArrSplit) {
            if (str.startsWith("MemTotal") || str.startsWith("MemAvailable")) {
                a(str);
            } else if (str.startsWith("SwapCached")) {
                aVar.f765a = a(str);
            } else if (str.startsWith("SwapTotal")) {
                aVar.f766b = a(str);
            } else if (str.startsWith("SwapFree")) {
                aVar.f767c = a(str);
            } else if (str.startsWith("Buffers")) {
                a(str);
            } else if (str.startsWith("Dirty")) {
                aVar.f768d = a(str);
            }
        }
        return aVar;
    }
}
