package com.omarea.library.shell;

import android.util.Log;
import com.omarea.model.CpuClusterStatus;
import com.omarea.model.CpuStatus;
import com.omarea.vtools.SceneJNI;
import java.io.File;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class CpuFrequencyUtils {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private ArrayList<String[]> f696a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private SceneJNI f697b = new SceneJNI();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private int f698c = -1;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private int f699d = -1;
    private int e = -1;
    private int f = -1;

    private boolean A() {
        String strB = new r().b();
        return strB.equals("mt6895") || strB.equals("mt6983");
    }

    private boolean K() {
        if (this.e == -1) {
            if (com.omarea.common.shell.g.f472a.d("/proc/cpufreq/MT_CPU_DVFS_LL/cpufreq_freq")) {
                this.e = 1;
            } else {
                this.e = 0;
            }
        }
        return this.e == 1;
    }

    private boolean L() {
        if (this.f == -1) {
            if (!A()) {
                this.f = 0;
            } else if (com.omarea.common.shell.g.f472a.d("/proc/cpuhvfs/phyclk")) {
                this.f = 1;
            }
        }
        return this.f == 1;
    }

    private void c(ArrayList<AbstractMap.SimpleEntry<String, String>> arrayList, String str, String str2) {
        arrayList.add(new AbstractMap.SimpleEntry<>(str, str2));
    }

    private String l(String str) {
        long kernelPropLong = this.f697b.getKernelPropLong(str);
        if (kernelPropLong <= -1) {
            return "";
        }
        return "" + kernelPropLong;
    }

    private String r(String str) {
        return com.omarea.common.shell.f.f471b.a("/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor".replace("cpu0", str));
    }

    private String[] y() {
        String[] strArrSplit = com.omarea.common.shell.f.f471b.a("/proc/cpuhvfs/phyclk").split("\n");
        int length = strArrSplit.length;
        String[] strArr = new String[length];
        int i = 0;
        for (String str : strArrSplit) {
            if (str.contains("=")) {
                int i2 = Integer.parseInt(str.substring(str.indexOf("=") + 1).trim()) / 1000;
                int i3 = i2 % 10;
                if (i3 == 9) {
                    i2++;
                } else if (i3 == 1) {
                    i2--;
                }
                strArr[i] = "" + (i2 * 1000);
            }
            i++;
        }
        if (length < 2) {
            Log.e("@Scene", "mtk phyclk: " + strArrSplit);
        }
        return strArr;
    }

    public boolean B() {
        return new r().b().startsWith("mt");
    }

    public void C(int i, boolean z) {
        ArrayList arrayList = new ArrayList();
        if (d() && x()) {
            arrayList.add("echo 0 > /sys/devices/system/cpu/cpuhotplug/enabled;");
        }
        arrayList.add("chmod 0755 /sys/devices/system/cpu/cpu0/online".replace("cpu0", "cpu" + i));
        StringBuilder sb = new StringBuilder();
        sb.append("echo ");
        sb.append(z ? "1" : "0");
        sb.append(" > /sys/devices/system/cpu/cpu0/online".replace("cpu0", "cpu" + i));
        arrayList.add(sb.toString());
        com.omarea.common.shell.e.f469b.d(arrayList);
    }

    public void D(boolean z) {
        ArrayList arrayList = new ArrayList();
        arrayList.add("chmod 0664 /sys/kernel/hmp/boost");
        arrayList.add("echo " + (z ? 1 : 0) + " > /sys/kernel/hmp/boost");
        com.omarea.common.shell.e.f469b.d(arrayList);
    }

    public void E(int i) {
        ArrayList arrayList = new ArrayList();
        arrayList.add("chmod 0664 /sys/kernel/hmp/down_threshold;");
        arrayList.add("echo " + i + " > /sys/kernel/hmp/down_threshold;");
        com.omarea.common.shell.e.f469b.d(arrayList);
    }

    public void F(int i) {
        ArrayList arrayList = new ArrayList();
        arrayList.add("chmod 0664 /sys/kernel/hmp/up_threshold;");
        arrayList.add("echo " + i + " > /sys/kernel/hmp/up_threshold;");
        com.omarea.common.shell.e.f469b.d(arrayList);
    }

    public void G(boolean z) {
        ArrayList arrayList = new ArrayList();
        arrayList.add("chmod 0664 /sys/devices/system/cpu/cpuhotplug/enabled;");
        arrayList.add("echo " + (z ? 1 : 0) + " > /sys/devices/system/cpu/cpuhotplug/enabled;");
        com.omarea.common.shell.e.f469b.d(arrayList);
    }

    public void H(String str, Integer num) {
        if (num.intValue() >= h().size()) {
            return;
        }
        String[] strArr = h().get(num.intValue());
        ArrayList arrayList = new ArrayList();
        if (str != null) {
            for (String str2 : strArr) {
                StringBuilder sb = new StringBuilder();
                sb.append("chmod 0755 ");
                sb.append("/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor".replace("cpu0", "cpu" + str2));
                arrayList.add(sb.toString());
                StringBuilder sb2 = new StringBuilder();
                sb2.append("echo ");
                sb2.append(str);
                sb2.append(" > ");
                sb2.append("/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor".replace("cpu0", "cpu" + str2));
                arrayList.add(sb2.toString());
            }
            com.omarea.common.shell.e.f469b.d(arrayList);
        }
    }

    public void I(String str, Integer num) {
        if (num.intValue() >= h().size()) {
            return;
        }
        if (B() && a()) {
            com.omarea.common.shell.e.f469b.e("echo " + num + " " + str + " > /proc/ppm/policy/hard_userlimit_max_cpu_freq");
            return;
        }
        String[] strArr = h().get(num.intValue());
        ArrayList arrayList = new ArrayList();
        if (str != null) {
            arrayList.add("chmod 0664 /sys/module/msm_performance/parameters/cpu_max_freq");
            StringBuilder sb = new StringBuilder();
            for (String str2 : strArr) {
                String strReplace = "/sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq".replace("cpu0", "cpu" + str2);
                arrayList.add("chmod 0664 " + strReplace);
                arrayList.add("echo " + str + " > " + strReplace);
                sb.append(str2);
                sb.append(":");
                sb.append(str);
                sb.append(" ");
            }
            arrayList.add("echo " + sb.toString() + "> /sys/module/msm_performance/parameters/cpu_max_freq");
            if (strArr.length > 0) {
                String str3 = "/sys/devices/system/cpu/cpufreq/policy" + strArr[0] + "/scaling_max_freq";
                arrayList.add("chmod 0664 " + str3);
                arrayList.add("echo " + str + " > " + str3);
                StringBuilder sb2 = new StringBuilder();
                sb2.append("chmod 444 ");
                sb2.append(str3);
                arrayList.add(sb2.toString());
            }
            com.omarea.common.shell.e.f469b.d(arrayList);
        }
    }

    public void J(String str, Integer num) {
        if (num.intValue() >= h().size()) {
            return;
        }
        if (B() && a()) {
            com.omarea.common.shell.e.f469b.e("echo " + num + " " + str + " > /proc/ppm/policy/hard_userlimit_min_cpu_freq");
            return;
        }
        String[] strArr = h().get(num.intValue());
        ArrayList arrayList = new ArrayList();
        if (str != null) {
            for (String str2 : strArr) {
                String strReplace = "/sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq".replace("cpu0", "cpu" + str2);
                arrayList.add("chmod 0664 " + strReplace);
                arrayList.add("echo " + str + " > " + strReplace);
            }
            if (strArr.length > 0) {
                String str3 = "/sys/devices/system/cpu/cpufreq/policy" + strArr[0] + "/scaling_min_freq";
                arrayList.add("chmod 0664 " + str3);
                arrayList.add("echo " + str + " > " + str3);
                StringBuilder sb = new StringBuilder();
                sb.append("chmod 444 ");
                sb.append(str3);
                arrayList.add(sb.toString());
            }
            com.omarea.common.shell.e.f469b.d(arrayList);
        }
    }

    public boolean a() {
        if (this.f699d < 0) {
            if (com.omarea.common.shell.g.f472a.g("/proc/ppm")) {
                this.f699d = 1;
            } else {
                this.f699d = 0;
            }
        }
        return this.f699d > 0;
    }

    public ArrayList<AbstractMap.SimpleEntry<String, String>> b(CpuStatus cpuStatus) {
        ArrayList<AbstractMap.SimpleEntry<String, String>> arrayList = new ArrayList<>();
        if (cpuStatus != null) {
            new x().a(cpuStatus, arrayList);
            arrayList.addAll(arrayList);
            ArrayList<Boolean> arrayList2 = cpuStatus.coreOnline;
            char c2 = 0;
            if (arrayList2 != null && arrayList2.size() > 0) {
                if (d() && x()) {
                    c(arrayList, "/sys/devices/system/cpu/cpuhotplug/enabled", "0");
                }
                for (int i = 0; i < cpuStatus.coreOnline.size(); i++) {
                    c(arrayList, "/sys/devices/system/cpu/cpu0/online".replace("cpu0", "cpu" + i), cpuStatus.coreOnline.get(i).booleanValue() ? "1" : "0");
                }
            }
            ArrayList<CpuClusterStatus> arrayList3 = cpuStatus.cpuClusterStatuses;
            if (arrayList3 != null && arrayList3.size() > 0) {
                ArrayList<CpuClusterStatus> arrayList4 = cpuStatus.cpuClusterStatuses;
                if (arrayList4.size() <= h().size()) {
                    int i2 = 1;
                    if (B() && a()) {
                        for (int i3 = 0; i3 < arrayList4.size(); i3++) {
                            CpuClusterStatus cpuClusterStatus = arrayList4.get(i3);
                            c(arrayList, "/proc/ppm/policy/hard_userlimit_min_cpu_freq", String.format(Locale.getDefault(), "%d %s", Integer.valueOf(i3), cpuClusterStatus.min_freq));
                            c(arrayList, "/proc/ppm/policy/hard_userlimit_max_cpu_freq", String.format(Locale.getDefault(), "%d %s", Integer.valueOf(i3), cpuClusterStatus.max_freq));
                            c(arrayList, "/proc/ppm/policy/hard_userlimit_min_cpu_freq", String.format(Locale.getDefault(), "%d %s", Integer.valueOf(i3), cpuClusterStatus.min_freq));
                        }
                    } else {
                        int i4 = 0;
                        while (i4 < arrayList4.size()) {
                            CpuClusterStatus cpuClusterStatus2 = arrayList4.get(i4);
                            String[] strArr = h().get(i4);
                            if (strArr.length >= i2) {
                                String str = strArr[c2];
                                String str2 = cpuClusterStatus2.governor;
                                if (str2 != null && !str2.isEmpty()) {
                                    c(arrayList, "/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor".replace("cpu0", "cpu" + str), cpuClusterStatus2.governor);
                                }
                                StringBuilder sb = new StringBuilder();
                                String str3 = cpuClusterStatus2.max_freq;
                                if (str3 != null && !str3.isEmpty()) {
                                    c(arrayList, "/sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq".replace("cpu0", "cpu" + str), cpuClusterStatus2.max_freq);
                                    sb.append(str);
                                    sb.append(":");
                                    sb.append(cpuClusterStatus2.max_freq);
                                    sb.append(" ");
                                    c(arrayList, "/sys/devices/system/cpu/cpufreq/policy" + str + "/scaling_max_freq", cpuClusterStatus2.max_freq);
                                }
                                c(arrayList, "/sys/module/msm_performance/parameters/cpu_max_freq", sb.toString());
                                String str4 = cpuClusterStatus2.min_freq;
                                if (str4 != null && !str4.isEmpty()) {
                                    c(arrayList, "/sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq".replace("cpu0", "cpu" + str), cpuClusterStatus2.min_freq);
                                    c(arrayList, "/sys/devices/system/cpu/cpufreq/policy" + str + "/scaling_min_freq", cpuClusterStatus2.min_freq);
                                }
                                String str5 = cpuClusterStatus2.max_freq;
                                if (str5 != null && !str5.isEmpty()) {
                                    c(arrayList, "/sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq".replace("cpu0", "cpu" + str), cpuClusterStatus2.max_freq);
                                    c(arrayList, "#" + ("/sys/devices/system/cpu/cpufreq/policy" + str + "/scaling_max_freq"), cpuClusterStatus2.max_freq);
                                }
                            }
                            i4++;
                            c2 = 0;
                            i2 = 1;
                        }
                    }
                    for (int i5 = 0; i5 < 2; i5++) {
                        for (int i6 = 0; i6 < arrayList4.size(); i6++) {
                            HashMap<String, String> map = arrayList4.get(i6).governor_params;
                            if (map != null) {
                                String str6 = "/sys/devices/system/cpu/cpufreq/policy" + i6 + "/";
                                for (Map.Entry<String, String> entry : map.entrySet()) {
                                    c(arrayList, str6 + entry.getKey(), entry.getValue());
                                }
                            }
                        }
                    }
                }
            }
            arrayList.addAll(new n().c(cpuStatus));
            if (e()) {
                c(arrayList, "/sys/devices/system/cpu/cpuhotplug/enabled", "" + (cpuStatus.exynosHotplug ? 1 : 0));
                c(arrayList, "/sys/kernel/hmp/down_threshold", "" + cpuStatus.exynosHmpDown);
                c(arrayList, "/sys/kernel/hmp/up_threshold", "" + cpuStatus.exynosHmpUP);
                c(arrayList, "/sys/kernel/hmp/boost", "" + cpuStatus.exynosHmpBooster);
            }
            String str7 = cpuStatus.cpusetBackground;
            if (str7 != null && !str7.isEmpty()) {
                c(arrayList, "/dev/cpuset/background/cpus", "" + cpuStatus.cpusetBackground);
            }
            String str8 = cpuStatus.cpusetSysBackground;
            if (str8 != null && !str8.isEmpty()) {
                c(arrayList, "/dev/cpuset/system-background/cpus", "" + cpuStatus.cpusetSysBackground);
            }
            String str9 = cpuStatus.cpusetForeground;
            if (str9 != null && !str9.isEmpty()) {
                c(arrayList, "/dev/cpuset/foreground/cpus", "" + cpuStatus.cpusetForeground);
            }
            String str10 = cpuStatus.cpusetRestricted;
            if (str10 != null && !str10.isEmpty()) {
                c(arrayList, "/dev/cpuset/restricted/cpus", "" + cpuStatus.cpusetRestricted);
            }
            String str11 = cpuStatus.cpusetTopApp;
            if (str11 != null && !str11.isEmpty()) {
                c(arrayList, "/dev/cpuset/top-app/cpus", "" + cpuStatus.cpusetTopApp);
            }
        }
        return arrayList;
    }

    public boolean d() {
        return new File("/sys/devices/system/cpu/cpuhotplug").exists();
    }

    public boolean e() {
        return new File("/sys/kernel/hmp/down_threshold").exists() && new File("/sys/kernel/hmp/up_threshold").exists() && new File("/sys/kernel/hmp/boost").exists();
    }

    public String[] f(Integer num) {
        if (num.intValue() >= h().size()) {
            return new String[0];
        }
        String str = "cpu" + h().get(num.intValue())[0];
        String strReplace = "/sys/devices/system/cpu/cpu0/cpufreq/scaling_available_frequencies".replace("cpu0", str);
        if (new File(strReplace).exists()) {
            String[] strArrSplit = com.omarea.common.shell.f.f471b.a(strReplace).split("[ ]+");
            String strReplace2 = "/sys/devices/system/cpu/cpu0/cpufreq/scaling_boost_frequencies".replace("cpu0", str);
            if (!new File(strReplace2).exists()) {
                return strArrSplit;
            }
            String strTrim = com.omarea.common.shell.f.f471b.a(strReplace2).trim();
            if (strTrim.length() <= 0) {
                return strArrSplit;
            }
            String[] strArrSplit2 = strTrim.split("[ ]+");
            String[] strArr = new String[strArrSplit.length + strArrSplit2.length];
            System.arraycopy(strArrSplit, 0, strArr, 0, strArrSplit.length);
            System.arraycopy(strArrSplit2, 0, strArr, strArrSplit.length, strArrSplit2.length);
            return strArr;
        }
        if (!new File("/sys/devices/system/cpu/cpufreq/mp-cpufreq/cluster" + num + "_freq_table").exists()) {
            return new String[0];
        }
        return com.omarea.common.shell.f.f471b.a("/sys/devices/system/cpu/cpufreq/mp-cpufreq/cluster" + num + "_freq_table").split("[ ]+");
    }

    public String[] g(Integer num) {
        if (num.intValue() >= h().size()) {
            return new String[0];
        }
        return com.omarea.common.shell.f.f471b.a("/sys/devices/system/cpu/cpu0/cpufreq/scaling_available_governors".replace("cpu0", "cpu" + h().get(num.intValue())[0])).split("[ ]+");
    }

    public ArrayList<String[]> h() {
        ArrayList<String[]> arrayList = this.f696a;
        if (arrayList != null) {
            return arrayList;
        }
        synchronized (this) {
            this.f696a = new ArrayList<>();
            ArrayList arrayList2 = new ArrayList();
            int i = 0;
            while (true) {
                String strReplace = "/sys/devices/system/cpu/cpu0/cpufreq/related_cpus".replace("cpu0", "cpu" + i);
                if (!new File(strReplace).exists()) {
                    break;
                }
                String strTrim = com.omarea.common.shell.f.f471b.a(strReplace).trim();
                if (!arrayList2.contains(strTrim) && !strTrim.isEmpty()) {
                    arrayList2.add(strTrim);
                }
                i++;
            }
            for (int i2 = 0; i2 < arrayList2.size(); i2++) {
                this.f696a.add(((String) arrayList2.get(i2)).split("[ ]+"));
            }
        }
        return this.f696a;
    }

    public int i() {
        int i = this.f698c;
        if (i > -1) {
            return i;
        }
        int i2 = 0;
        while (true) {
            if (!new File("/sys/devices/system/cpu/cpu0/".replace("cpu0", "cpu" + i2)).exists()) {
                this.f698c = i2;
                return i2;
            }
            i2++;
        }
    }

    public HashMap<String, String> j(Integer num) {
        String str = "cpu" + num;
        String strR = r(str);
        return new h().a("/sys/devices/system/cpu/cpu0/".replace("cpu0", str) + "cpufreq/" + strR);
    }

    public boolean k(int i) {
        return com.omarea.common.shell.f.f471b.a("/sys/devices/system/cpu/cpu0/online".replace("cpu0", "cpu" + i)).equals("1");
    }

    public int m(Integer num) {
        try {
            return Integer.parseInt(com.omarea.common.shell.f.f471b.a("/sys/devices/system/cpu/cpu" + num + "/cpufreq/cpuinfo_max_freq"));
        } catch (Exception unused) {
            return -1;
        }
    }

    public String n(Integer num) {
        ArrayList<String[]> arrayListH = h();
        if (num.intValue() >= arrayListH.size()) {
            return "";
        }
        if (K() && arrayListH.size() <= 3) {
            ArrayList<String> arrayList = arrayListH.size() == 3 ? new ArrayList<String>() { // from class: com.omarea.library.shell.CpuFrequencyUtils.1
                {
                    add("MT_CPU_DVFS_LL");
                    add("MT_CPU_DVFS_L");
                    add("MT_CPU_DVFS_B");
                }
            } : new ArrayList<String>() { // from class: com.omarea.library.shell.CpuFrequencyUtils.2
                {
                    add("MT_CPU_DVFS_LL");
                    add("MT_CPU_DVFS_L");
                }
            };
            String lowerCase = com.omarea.common.shell.f.f471b.a("/proc/cpufreq/" + arrayList.get(num.intValue()) + "/cpufreq_freq").toLowerCase();
            return lowerCase.contains("khz") ? lowerCase.substring(0, lowerCase.indexOf("k")).trim() : "";
        }
        if (L()) {
            String[] strArrY = y();
            if (strArrY.length > num.intValue()) {
                return strArrY[num.intValue()];
            }
        }
        return l("/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq".replace("cpu0", "cpu" + arrayListH.get(num.intValue())[0]));
    }

    public String o(Integer num) {
        if (num.intValue() >= h().size()) {
            return "";
        }
        return com.omarea.common.shell.f.f471b.a("/sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq".replace("cpu0", "cpu" + h().get(num.intValue())[0]));
    }

    public String p(Integer num) {
        if (num.intValue() >= h().size()) {
            return "";
        }
        return com.omarea.common.shell.f.f471b.a("/sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq".replace("cpu0", "cpu" + h().get(num.intValue())[0]));
    }

    public String q(Integer num) {
        if (num.intValue() >= h().size()) {
            return "";
        }
        return com.omarea.common.shell.f.f471b.a("/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor".replace("cpu0", "cpu" + h().get(num.intValue())[0]));
    }

    public HashMap<String, String> s(Integer num) {
        return new h().a(t(num));
    }

    public String t(Integer num) {
        if (num.intValue() >= h().size()) {
            return null;
        }
        String str = "cpu" + h().get(num.intValue())[0];
        return "/sys/devices/system/cpu/cpu0/".replace("cpu0", str) + "cpufreq/" + r(str);
    }

    public boolean u() {
        String lowerCase = com.omarea.common.shell.f.f471b.a("/sys/kernel/hmp/boost").trim().toLowerCase();
        return Objects.equals(lowerCase, "1") || Objects.equals(lowerCase, "true") || Objects.equals(lowerCase, "enabled");
    }

    public int v() {
        String strTrim = com.omarea.common.shell.f.f471b.a("/sys/kernel/hmp/down_threshold").trim();
        if (Objects.equals(strTrim, "")) {
            return 0;
        }
        try {
            return Integer.parseInt(strTrim);
        } catch (Exception unused) {
            return 0;
        }
    }

    public int w() {
        String strTrim = com.omarea.common.shell.f.f471b.a("/sys/kernel/hmp/up_threshold").trim();
        if (Objects.equals(strTrim, "")) {
            return 0;
        }
        try {
            return Integer.parseInt(strTrim);
        } catch (Exception unused) {
            return 0;
        }
    }

    public boolean x() {
        String lowerCase = com.omarea.common.shell.f.f471b.a("/sys/devices/system/cpu/cpuhotplug/enabled").trim().toLowerCase();
        return Objects.equals(lowerCase, "1") || Objects.equals(lowerCase, "true") || Objects.equals(lowerCase, "enabled");
    }

    public String z(Integer num) {
        ArrayList<String[]> arrayListH = h();
        if (num.intValue() >= arrayListH.size()) {
            return "";
        }
        return com.omarea.common.shell.f.f471b.a("/sys/devices/system/cpu/cpu0/cpufreq/stats/time_in_state".replace("cpu0", "cpu" + arrayListH.get(num.intValue())[0]));
    }
}
