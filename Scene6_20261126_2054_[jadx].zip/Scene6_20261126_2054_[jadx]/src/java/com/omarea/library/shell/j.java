package com.omarea.library.shell;

import android.os.Build;
import android.os.SystemClock;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import kotlin.text.Regex;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class j {
    private static a g;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final HashMap<String, String> f745a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private b f746b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final Regex f747c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private final Regex f748d;
    private final boolean e;
    private Boolean f;

    public static final class a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private long f749a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private String f750b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private int f751c;

        public final String a() {
            return this.f750b;
        }

        public final int b() {
            return this.f751c;
        }

        public final long c() {
            return this.f749a;
        }

        public final void d(String str) {
        }

        public final void e(String str) {
            this.f750b = str;
        }

        public final void f(int i) {
            this.f751c = i;
        }

        public final void g(long j) {
            this.f749a = j;
        }

        public final void h(String str) {
        }
    }

    public j() {
        HashMap<String, String> map = new HashMap<>();
        if (Build.VERSION.SDK_INT < 31) {
            map.put("com.tencent.tmgp.sgame/com.tencent.tmgp.sgame.SGameActivity", "SurfaceView - com.tencent.tmgp.sgame/com.tencent.tmgp.sgame.SGameActivity#0");
            map.put("com.miHoYo.Yuanshen/com.miHoYo.GetMobileInfo.MainActivity", "SurfaceView - com.miHoYo.Yuanshen/com.miHoYo.GetMobileInfo.MainActivity#0");
        }
        kotlin.s sVar = kotlin.s.a;
        this.f745a = map;
        this.f747c = new Regex("[ \\t]+");
        this.f748d = new Regex("[\\s]+");
        this.e = true;
        this.f = Boolean.FALSE;
    }

    private final long a(String str) {
        Long lJ;
        List listSplit = this.f747c.split(str, 0);
        if (listSplit.size() != 3 || (lJ = kotlin.text.k.j((String) listSplit.get(1))) == null || lJ.longValue() <= 0 || lJ.longValue() == Long.MAX_VALUE) {
            return 0L;
        }
        return lJ.longValue() / ((long) 1000000);
    }

    public static /* synthetic */ a c(j jVar, boolean z, String str, int i, Object obj) {
        if ((i & 1) != 0) {
            z = false;
        }
        if ((i & 2) != 0) {
            str = null;
        }
        return jVar.b(z, str);
    }

    private final int d(String str) {
        String strE = com.omarea.common.shell.e.f469b.e("dumpsys SurfaceFlinger --latency '" + str + '\'');
        long jUptimeMillis = SystemClock.uptimeMillis() - ((long) 1000);
        int i = 0;
        if ((strE.length() > 0) && (!kotlin.jvm.internal.r.a(strE, "error"))) {
            List listW = kotlin.text.k.W(strE, new String[]{"\n"}, false, 0, 6, (Object) null);
            int size = listW.size();
            for (int i2 = 1; i2 < size; i2++) {
                if (a((String) listW.get(i2)) >= jUptimeMillis) {
                    i++;
                }
            }
        }
        return i;
    }

    /* JADX WARN: Code duplicated, block: B:13:0x0027  */
    /* JADX WARN: Code duplicated, block: B:15:0x0040  */
    public final a b(boolean z, String str) {
        String str2;
        int iD;
        int iD2;
        Object next;
        String strA;
        long jCurrentTimeMillis;
        a aVar;
        if (g != null) {
            if (str == null || str.length() == 0) {
                jCurrentTimeMillis = System.currentTimeMillis();
                aVar = g;
                kotlin.jvm.internal.r.b(aVar);
                if (Math.abs(jCurrentTimeMillis - aVar.c()) < 1000) {
                    return g;
                }
            } else {
                a aVar2 = g;
                kotlin.jvm.internal.r.b(aVar2);
                if (kotlin.jvm.internal.r.a(aVar2.a(), str)) {
                    jCurrentTimeMillis = System.currentTimeMillis();
                    aVar = g;
                    kotlin.jvm.internal.r.b(aVar);
                    if (Math.abs(jCurrentTimeMillis - aVar.c()) < 1000) {
                        return g;
                    }
                }
            }
        }
        if (this.f746b == null) {
            this.f746b = new b();
        }
        if (this.f == null) {
            this.f = Boolean.valueOf(com.omarea.common.shell.g.f472a.d("/sys/kernel/fpsgo/fstb/fpsgo_status"));
        }
        b bVar = this.f746b;
        String strB = bVar != null ? bVar.b() : null;
        if (strB == null || strB.length() == 0) {
            return null;
        }
        a aVar3 = new a();
        aVar3.d(strB);
        if (kotlin.text.k.y(strB, "/", false, 2, (Object) null)) {
            int iH = kotlin.text.k.H(strB, "/", 0, false, 6, (Object) null);
            if (strB == null) {
                throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
            }
            String strSubstring = strB.substring(0, iH);
            kotlin.jvm.internal.r.c(strSubstring, "(this as java.lang.Strin…ing(startIndex, endIndex)");
            aVar3.e(strSubstring);
        } else {
            aVar3.e(strB);
        }
        if (kotlin.jvm.internal.r.a(this.f, Boolean.TRUE) && kotlin.text.k.y(strB, "miHoYo", false, 2, (Object) null)) {
            List listW = kotlin.text.k.W(com.omarea.common.shell.g.f472a.i("/sys/kernel/fpsgo/fstb/fpsgo_status"), new String[]{"\n"}, false, 0, 6, (Object) null);
            if (listW.size() > 1) {
                try {
                    int size = listW.size();
                    for (int i = 1; i < size; i++) {
                        List listSplit = this.f748d.split((CharSequence) listW.get(i), 15);
                        if (listSplit.size() == 10 && kotlin.jvm.internal.r.a((String) listSplit.get(9), "2") && (strA = aVar3.a()) != null && kotlin.text.k.y(strA, (CharSequence) listSplit.get(2), false, 2, (Object) null)) {
                            aVar3.g(System.currentTimeMillis());
                            int i2 = Integer.parseInt((String) listSplit.get(3));
                            if (i2 < 0) {
                                i2 = 0;
                            }
                            aVar3.f(i2);
                            g = aVar3;
                            return aVar3;
                        }
                    }
                } catch (Exception unused) {
                }
            }
        }
        if (this.e && z && this.f745a.containsKey(strB)) {
            String str3 = this.f745a.get(strB);
            kotlin.jvm.internal.r.b(str3);
            kotlin.jvm.internal.r.c(str3, "hotGames.get(activity)!!");
            String str4 = str3;
            aVar3.g(System.currentTimeMillis());
            aVar3.f(d(str4));
            aVar3.h(str4);
        } else {
            List<String> listW2 = kotlin.text.k.W(com.omarea.common.shell.e.f469b.e("dumpsys SurfaceFlinger --list | grep '" + strB + '\''), new String[]{"\n"}, false, 0, 6, (Object) null);
            if (z) {
                if (Build.VERSION.SDK_INT < 31) {
                    Iterator it = listW2.iterator();
                    do {
                        if (!it.hasNext()) {
                            next = null;
                            break;
                        }
                        next = it.next();
                    } while (!kotlin.text.k.t((String) next, "SurfaceView - " + strB + "#0", false, 2, (Object) null));
                } else {
                    Iterator it2 = listW2.iterator();
                    do {
                        if (!it2.hasNext()) {
                            next = null;
                            break;
                        }
                        next = it2.next();
                    } while (!kotlin.text.k.t((String) next, "SurfaceView[" + strB + "](BLAST)#0", false, 2, (Object) null));
                }
                str2 = (String) next;
            } else {
                str2 = null;
            }
            if (str2 != null) {
                iD = d(str2);
                if (this.e && iD >= 29) {
                    this.f745a.put(strB, str2);
                }
            } else {
                iD = 0;
                for (String str5 : listW2) {
                    if (!kotlin.text.k.t(str5, "Background", false, 2, (Object) null) && !kotlin.text.k.y(str5, "AppWindowToken", false, 2, (Object) null) && !kotlin.text.k.y(str5, "WindowToken", false, 2, (Object) null) && (iD2 = d(str5)) > iD) {
                        aVar3.h(str5);
                        iD = iD2;
                    }
                }
            }
            aVar3.g(System.currentTimeMillis());
            aVar3.f(iD);
        }
        g = aVar3;
        return aVar3;
    }
}
