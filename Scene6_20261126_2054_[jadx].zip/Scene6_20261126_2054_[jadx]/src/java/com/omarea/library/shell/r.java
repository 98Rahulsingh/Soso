package com.omarea.library.shell;

import java.util.Locale;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class r {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private static String f769a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private static String f770b;

    public final String a() {
        if (f770b == null) {
            String strA = com.omarea.common.shell.f.f471b.a("/sys/devices/soc0/machine");
            if (strA != null) {
                if (strA.length() == 0) {
                    strA = t.f771a.a("ro.board.platform");
                }
            }
            if (!(strA == null || strA.length() == 0)) {
                f770b = strA;
            }
        }
        String str = f770b;
        if (str == null || str.length() == 0) {
            return "";
        }
        String str2 = f770b;
        kotlin.jvm.internal.r.b(str2);
        Locale locale = Locale.ENGLISH;
        kotlin.jvm.internal.r.c(locale, "Locale.ENGLISH");
        if (str2 == null) {
            throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
        }
        String lowerCase = str2.toLowerCase(locale);
        kotlin.jvm.internal.r.c(lowerCase, "(this as java.lang.String).toLowerCase(locale)");
        return lowerCase;
    }

    public final String b() {
        if (f769a == null) {
            String strA = t.f771a.a("ro.board.platform");
            Locale locale = Locale.ENGLISH;
            kotlin.jvm.internal.r.c(locale, "Locale.ENGLISH");
            if (strA == null) {
                throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
            }
            String lowerCase = strA.toLowerCase(locale);
            kotlin.jvm.internal.r.c(lowerCase, "(this as java.lang.String).toLowerCase(locale)");
            if (lowerCase.length() > 0) {
                String str = "mt6893";
                if (kotlin.jvm.internal.r.a(lowerCase, "mt6893")) {
                    String strA2 = com.omarea.common.shell.f.f471b.a("/sys/devices/system/cpu/cpu7/cpufreq/scaling_available_frequencies");
                    if (!kotlin.jvm.internal.r.a(strA2, "error") && !kotlin.text.k.y(strA2, "3000000", false, 2, (Object) null)) {
                        str = "mt6891";
                    }
                } else {
                    str = "mt6885";
                    if (kotlin.jvm.internal.r.a(lowerCase, "mt6885")) {
                        String strA3 = com.omarea.common.shell.f.f471b.a("/sys/devices/system/cpu/cpu4/cpufreq/scaling_available_frequencies");
                        if (kotlin.jvm.internal.r.a(strA3, "error") || kotlin.text.k.y(strA3, "2600000", false, 2, (Object) null)) {
                            str = "mt6889";
                        }
                    } else {
                        if (kotlin.jvm.internal.r.a(lowerCase, "lito")) {
                            return a();
                        }
                        if (kotlin.jvm.internal.r.a(lowerCase, "lahaina")) {
                            String strA4 = a();
                            return kotlin.jvm.internal.r.a(strA4, "sm8350") ? "lahaina" : strA4;
                        }
                        if (kotlin.jvm.internal.r.a(lowerCase, "waipio")) {
                            lowerCase = "taro";
                        }
                        f769a = lowerCase;
                    }
                }
                f769a = str;
            }
        }
        String str2 = f769a;
        return str2 != null ? str2 : "";
    }
}
