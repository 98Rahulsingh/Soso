package com.omarea.library.shell;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class l {
    public final void a() {
        com.omarea.common.shell.e.f469b.c("fstrim /data\nfstrim /data\nfstrim /system\nfstrim /system\nfstrim /cache\nfstrim /cache\nsm fstrim\n");
    }
}
