package com.omarea.library.shell;

import java.util.ArrayList;
import java.util.List;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlinx.coroutines.h0;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
@kotlin.coroutines.jvm.internal.d(c = "com.omarea.library.shell.FpsUtils$currentFpsLegend$1", f = "FpsUtils.kt", l = {}, m = "invokeSuspend")
final class FpsUtils$currentFpsLegend$1 extends SuspendLambda implements kotlin.jvm.b.p<h0, kotlin.coroutines.c<? super kotlin.s>, Object> {
    final /* synthetic */ com.omarea.common.shell.b $keepShell;
    int label;
    private h0 p$;
    final /* synthetic */ FpsUtils this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    FpsUtils$currentFpsLegend$1(FpsUtils fpsUtils, com.omarea.common.shell.b bVar, kotlin.coroutines.c cVar) {
        super(2, cVar);
        this.this$0 = fpsUtils;
        this.$keepShell = bVar;
    }

    public final kotlin.coroutines.c<kotlin.s> create(Object obj, kotlin.coroutines.c<?> cVar) {
        kotlin.jvm.internal.r.d(cVar, "completion");
        FpsUtils$currentFpsLegend$1 fpsUtils$currentFpsLegend$1 = new FpsUtils$currentFpsLegend$1(this.this$0, this.$keepShell, cVar);
        fpsUtils$currentFpsLegend$1.p$ = (h0) obj;
        return fpsUtils$currentFpsLegend$1;
    }

    public final Object invoke(Object obj, Object obj2) {
        return create(obj, (kotlin.coroutines.c) obj2).invokeSuspend(kotlin.s.a);
    }

    public final Object invokeSuspend(Object obj) {
        kotlin.coroutines.intrinsics.a.d();
        if (this.label != 0) {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        kotlin.h.b(obj);
        try {
            String strC = this.$keepShell.c("find /sys -name measured_fps 2>/dev/null");
            int length = strC.length() - 1;
            int i = 0;
            boolean z = false;
            while (i <= length) {
                boolean zBooleanValue = kotlin.coroutines.jvm.internal.a.a(kotlin.jvm.internal.r.e(kotlin.coroutines.jvm.internal.a.b(strC.charAt(!z ? i : length)).charValue(), 32) <= 0).booleanValue();
                if (z) {
                    if (!zBooleanValue) {
                        break;
                    }
                    length--;
                } else if (zBooleanValue) {
                    i++;
                } else {
                    z = true;
                }
            }
            List listW = kotlin.text.k.W(strC.subSequence(i, length + 1).toString(), new String[]{"\n"}, false, 0, 6, (Object) null);
            ArrayList arrayList = new ArrayList();
            for (Object obj2 : listW) {
                if (kotlin.coroutines.jvm.internal.a.a(kotlin.text.k.y((String) obj2, "crtc", false, 2, (Object) null)).booleanValue()) {
                    arrayList.add(obj2);
                }
            }
            String str = (String) kotlin.collections.q.I(arrayList);
            if (str != null) {
                this.this$0.f700a = str;
            }
            if (this.this$0.f700a == null || kotlin.jvm.internal.r.a(this.this$0.f700a, "")) {
                String strC2 = this.$keepShell.c("find /sys -name fps 2>/dev/null");
                int length2 = strC2.length() - 1;
                int i2 = 0;
                boolean z2 = false;
                while (i2 <= length2) {
                    boolean zBooleanValue2 = kotlin.coroutines.jvm.internal.a.a(kotlin.jvm.internal.r.e(kotlin.coroutines.jvm.internal.a.b(strC2.charAt(!z2 ? i2 : length2)).charValue(), 32) <= 0).booleanValue();
                    if (z2) {
                        if (!zBooleanValue2) {
                            break;
                        }
                        length2--;
                    } else if (zBooleanValue2) {
                        i2++;
                    } else {
                        z2 = true;
                    }
                }
                List listW2 = kotlin.text.k.W(strC2.subSequence(i2, length2 + 1).toString(), new String[]{"\n"}, false, 0, 6, (Object) null);
                ArrayList arrayList2 = new ArrayList();
                for (Object obj3 : listW2) {
                    if (kotlin.coroutines.jvm.internal.a.a(kotlin.text.k.y((String) obj3, "crtc", false, 2, (Object) null)).booleanValue()) {
                        arrayList2.add(obj3);
                    }
                }
                String str2 = (String) kotlin.collections.q.I(arrayList2);
                if (str2 != null) {
                    this.this$0.f700a = str2;
                }
            }
            if (this.this$0.f700a == null) {
                this.this$0.f700a = "";
            }
        } catch (Exception unused) {
            this.this$0.f700a = "";
        }
        return kotlin.s.a;
    }
}
