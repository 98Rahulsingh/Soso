package com.omarea.library.shell;

import android.content.Context;
import android.content.SharedPreferences;
import com.omarea.common.net.Daemon;
import com.omarea.model.ProcessInfo;
import java.util.ArrayList;
import java.util.Arrays;
import kotlin.text.Regex;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class ProcessUtils {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final TripleCacheValue f704a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final TripleCacheValue f705b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final ArrayList<String> f706c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private final Context f707d;

    public static final class a extends TripleCacheValue {
        a(Context context, String str) {
            super(context, str);
        }

        @Override // com.omarea.library.shell.TripleCacheValue
        public String f() {
            String strB = new com.omarea.e.b(ProcessUtils.this.f707d).b();
            String str = strB + " top -o %CPU,RES,SWAP,NAME,PID,USER,S,COMMAND,CMDLINE -q -b -n 1 -m 65535";
            return strB + " ps -e -o %CPU,RES,SWAP,NAME,PID,USER,S,COMMAND,CMDLINE";
        }

        @Override // com.omarea.library.shell.TripleCacheValue
        protected void h(SharedPreferences sharedPreferences) {
            kotlin.jvm.internal.r.d(sharedPreferences, "storage");
            if (toString().length() == 0) {
                super.h(sharedPreferences);
            }
        }
    }

    public static final class b extends TripleCacheValue {
        b(Context context, String str) {
            super(context, str);
        }

        @Override // com.omarea.library.shell.TripleCacheValue
        public String f() {
            String strB = new com.omarea.e.b(ProcessUtils.this.f707d).b();
            String str = strB + " top -o %CPU,RES,SWAP,NAME,PID,USER,S,COMMAND,CMDLINE -q -b -n 1 -m 65535";
            return strB + " ps -e -o %CPU,RES,SWAP,NAME,PID,USER,S,COMMAND,CMDLINE";
        }

        @Override // com.omarea.library.shell.TripleCacheValue
        protected void h(SharedPreferences sharedPreferences) {
            kotlin.jvm.internal.r.d(sharedPreferences, "storage");
            if (toString().length() == 0) {
                super.h(sharedPreferences);
            }
        }
    }

    public ProcessUtils(Context context) {
        kotlin.jvm.internal.r.d(context, "context");
        this.f707d = context;
        this.f704a = new b(context, "ProcessUtilsList");
        this.f705b = new a(this.f707d, "ProcessUtilsDetail");
        this.f706c = new ArrayList<String>() { // from class: com.omarea.library.shell.ProcessUtils$excludeProcess$1
            {
                add("toybox-outside");
                add("toybox-outside64");
                add("ps");
                add("top");
                add("com.omarea.vtools");
            }

            @Override // java.util.ArrayList, java.util.AbstractCollection, java.util.Collection, java.util.List
            public final /* bridge */ boolean contains(Object obj) {
                if (obj instanceof String) {
                    return contains((String) obj);
                }
                return false;
            }

            public /* bridge */ boolean contains(String str) {
                return super.contains((Object) str);
            }

            public /* bridge */ int getSize() {
                return super.size();
            }

            @Override // java.util.ArrayList, java.util.AbstractList, java.util.List
            public final /* bridge */ int indexOf(Object obj) {
                if (obj instanceof String) {
                    return indexOf((String) obj);
                }
                return -1;
            }

            public /* bridge */ int indexOf(String str) {
                return super.indexOf((Object) str);
            }

            @Override // java.util.ArrayList, java.util.AbstractList, java.util.List
            public final /* bridge */ int lastIndexOf(Object obj) {
                if (obj instanceof String) {
                    return lastIndexOf((String) obj);
                }
                return -1;
            }

            public /* bridge */ int lastIndexOf(String str) {
                return super.lastIndexOf((Object) str);
            }

            @Override // java.util.ArrayList, java.util.AbstractList, java.util.List
            public final /* bridge */ String remove(int i) {
                return removeAt(i);
            }

            @Override // java.util.ArrayList, java.util.AbstractCollection, java.util.Collection, java.util.List
            public final /* bridge */ boolean remove(Object obj) {
                if (obj instanceof String) {
                    return remove((String) obj);
                }
                return false;
            }

            public /* bridge */ boolean remove(String str) {
                return super.remove((Object) str);
            }

            public /* bridge */ String removeAt(int i) {
                return (String) super.remove(i);
            }

            @Override // java.util.ArrayList, java.util.AbstractCollection, java.util.Collection, java.util.List
            public final /* bridge */ int size() {
                return getSize();
            }
        };
    }

    private final ProcessInfo e(String str) {
        Object[] array = new Regex(" +").split(str, 0).toArray(new String[0]);
        if (array == null) {
            throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T>");
        }
        String[] strArr = (String[]) array;
        if (strArr.length >= 6) {
            try {
                ProcessInfo processInfo = new ProcessInfo();
                processInfo.cpu = Float.parseFloat(strArr[0]);
                processInfo.res = g(strArr[1]);
                processInfo.swap = g(strArr[2]);
                String str2 = strArr[3];
                processInfo.name = str2;
                if (this.f706c.contains(str2)) {
                    return null;
                }
                processInfo.pid = Integer.parseInt(strArr[4]);
                processInfo.user = strArr[5];
                processInfo.state = strArr[6];
                String str3 = strArr[7];
                processInfo.command = str3;
                kotlin.jvm.internal.r.c(str3, "processInfo.command");
                int iH = kotlin.text.k.H(str, str3, 0, false, 6, (Object) null) + processInfo.command.length();
                if (str == null) {
                    throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                }
                String strSubstring = str.substring(iH);
                kotlin.jvm.internal.r.c(strSubstring, "(this as java.lang.String).substring(startIndex)");
                int length = strSubstring.length() - 1;
                int i = 0;
                boolean z = false;
                while (i <= length) {
                    boolean z2 = kotlin.jvm.internal.r.e(strSubstring.charAt(!z ? i : length), 32) <= 0;
                    if (z) {
                        if (!z2) {
                            break;
                        }
                        length--;
                    } else if (z2) {
                        i++;
                    } else {
                        z = true;
                    }
                }
                processInfo.cmdline = strSubstring.subSequence(i, length + 1).toString();
                return processInfo;
            } catch (Exception unused) {
            }
        }
        return null;
    }

    private final long g(String str) {
        double d2;
        double d3;
        double d4;
        if (kotlin.text.k.y(str, "K", false, 2, (Object) null)) {
            int iH = kotlin.text.k.H(str, "K", 0, false, 6, (Object) null);
            if (str == null) {
                throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
            }
            String strSubstring = str.substring(0, iH);
            kotlin.jvm.internal.r.c(strSubstring, "(this as java.lang.Strin…ing(startIndex, endIndex)");
            d4 = Double.parseDouble(strSubstring);
        } else {
            if (kotlin.text.k.y(str, "M", false, 2, (Object) null)) {
                int iH2 = kotlin.text.k.H(str, "M", 0, false, 6, (Object) null);
                if (str == null) {
                    throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                }
                String strSubstring2 = str.substring(0, iH2);
                kotlin.jvm.internal.r.c(strSubstring2, "(this as java.lang.Strin…ing(startIndex, endIndex)");
                d2 = Double.parseDouble(strSubstring2);
                d3 = 1024;
            } else {
                if (!kotlin.text.k.y(str, "G", false, 2, (Object) null)) {
                    return Long.parseLong(str) / ((long) 1024);
                }
                int iH3 = kotlin.text.k.H(str, "G", 0, false, 6, (Object) null);
                if (str == null) {
                    throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                }
                String strSubstring3 = str.substring(0, iH3);
                kotlin.jvm.internal.r.c(strSubstring3, "(this as java.lang.Strin…ing(startIndex, endIndex)");
                d2 = Double.parseDouble(strSubstring3);
                d3 = 1048576;
            }
            d4 = d2 * d3;
        }
        return (long) d4;
    }

    /* JADX WARN: Type inference failed for: r2v4, types: [boolean] */
    public final ArrayList<ProcessInfo> b() {
        ArrayList<ProcessInfo> arrayList = new ArrayList<>();
        String string = this.f704a.toString();
        if (string.length() > 0) {
            ?? T = kotlin.text.k.t(string, "ps", false, 2, (Object) null);
            Object[] array = new Regex("\n").split(Daemon.E.a().j0(string, 3000), 0).toArray(new String[0]);
            if (array == null) {
                throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T>");
            }
            int i = 0;
            for (String str : (String[]) array) {
                if (i >= T) {
                    i++;
                    int length = str.length() - 1;
                    int i2 = 0;
                    boolean z = false;
                    while (i2 <= length) {
                        boolean z2 = kotlin.jvm.internal.r.e(str.charAt(!z ? i2 : length), 32) <= 0;
                        if (z) {
                            if (!z2) {
                                break;
                            }
                            length--;
                        } else if (z2) {
                            i2++;
                        } else {
                            z = true;
                        }
                    }
                    ProcessInfo processInfoE = e(str.subSequence(i2, length + 1).toString());
                    if (processInfoE != null) {
                        arrayList.add(processInfoE);
                    }
                }
            }
        }
        return arrayList;
    }

    public final ProcessInfo c(int i) {
        boolean z;
        String string = this.f705b.toString();
        boolean z2 = false;
        if (string.length() > 0) {
            Object[] array = new Regex("\n").split(Daemon.E.a().j0(string + i, 5000), 0).toArray(new String[0]);
            if (array == null) {
                throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T>");
            }
            String[] strArr = (String[]) array;
            if (strArr.length > 1) {
                String str = strArr[1];
                int length = str.length() - 1;
                int i2 = 0;
                boolean z3 = false;
                while (i2 <= length) {
                    boolean z4 = kotlin.jvm.internal.r.e(str.charAt(!z3 ? i2 : length), 32) <= 0;
                    if (z3) {
                        if (!z4) {
                            break;
                        }
                        length--;
                    } else if (z4) {
                        i2++;
                    } else {
                        z3 = true;
                    }
                }
                ProcessInfo processInfoE = e(str.subSequence(i2, length + 1).toString());
                if (processInfoE != null) {
                    processInfoE.cpuSet = com.omarea.common.shell.f.f471b.a("/proc/" + i + "/cpuset");
                    processInfoE.cGroup = com.omarea.common.shell.f.f471b.a("/proc/" + i + "/cgroup");
                    processInfoE.oomAdj = com.omarea.common.shell.f.f471b.a("/proc/" + i + "/oom_adj");
                    processInfoE.oomScore = com.omarea.common.shell.f.f471b.a("/proc/" + i + "/oom_score");
                    processInfoE.oomScoreAdj = com.omarea.common.shell.f.f471b.a("/proc/" + i + "/oom_score_adj");
                    for (String str2 : kotlin.text.k.W(com.omarea.common.shell.f.f471b.a("/proc/" + i + "/status"), new String[]{"\n"}, false, 0, 6, (Object) null)) {
                        if (kotlin.text.k.t(str2, "Cpus_allowed", z2, 2, (Object) null)) {
                            int iH = kotlin.text.k.H(str2, ":", 0, false, 6, (Object) null) + 1;
                            if (str2 == null) {
                                throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                            }
                            String strSubstring = str2.substring(iH);
                            kotlin.jvm.internal.r.c(strSubstring, "(this as java.lang.String).substring(startIndex)");
                            if (strSubstring == null) {
                                throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
                            }
                            processInfoE.cpusAllowed = kotlin.text.k.k0(strSubstring).toString();
                        } else {
                            if (kotlin.text.k.t(str2, "State", false, 2, (Object) null)) {
                                int iH2 = kotlin.text.k.H(str2, ":", 0, false, 6, (Object) null) + 1;
                                if (str2 == null) {
                                    throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                                }
                                String strSubstring2 = str2.substring(iH2);
                                kotlin.jvm.internal.r.c(strSubstring2, "(this as java.lang.String).substring(startIndex)");
                                if (strSubstring2 == null) {
                                    throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
                                }
                                String string2 = kotlin.text.k.k0(strSubstring2).toString();
                                if (kotlin.text.k.y(string2, "(", false, 2, (Object) null)) {
                                    z = false;
                                    String str3 = (String) kotlin.text.k.W(string2, new String[]{"("}, false, 0, 6, (Object) null).get(0);
                                    if (str3 == null) {
                                        throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
                                    }
                                    string2 = kotlin.text.k.k0(str3).toString();
                                } else {
                                    z = false;
                                }
                                processInfoE.state = string2;
                            }
                            z2 = z;
                        }
                        z = false;
                        z2 = z;
                    }
                }
                return processInfoE;
            }
        }
        return null;
    }

    public final void d(int i) {
        Daemon.E.a().j0("kill -9 " + i, 3000);
    }

    public final void f(ProcessInfo processInfo) {
        String strSubstring;
        kotlin.jvm.internal.r.d(processInfo, "processInfo");
        String str = processInfo.name;
        kotlin.jvm.internal.r.c(str, "processInfo.name");
        if (kotlin.text.k.y(str, ":", false, 2, (Object) null)) {
            String str2 = processInfo.name;
            kotlin.jvm.internal.r.c(str2, "processInfo.name");
            String str3 = processInfo.name;
            kotlin.jvm.internal.r.c(str3, "processInfo.name");
            int iH = kotlin.text.k.H(str3, ":", 0, false, 6, (Object) null);
            if (str2 == null) {
                throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
            }
            strSubstring = str2.substring(0, iH);
            kotlin.jvm.internal.r.c(strSubstring, "(this as java.lang.Strin…ing(startIndex, endIndex)");
        } else {
            strSubstring = processInfo.name;
        }
        Daemon daemonA = Daemon.E.a();
        kotlin.jvm.internal.w wVar = kotlin.jvm.internal.w.a;
        String str4 = String.format("killall -9 %s;am force-stop %s;am kill %s", Arrays.copyOf(new Object[]{strSubstring, strSubstring, strSubstring}, 3));
        kotlin.jvm.internal.r.c(str4, "java.lang.String.format(format, *args)");
        daemonA.j0(str4, 3000);
        d(processInfo.pid);
    }

    public final boolean h() {
        if (!(this.f704a.toString().length() == 0)) {
            if (!(this.f705b.toString().length() == 0)) {
                return true;
            }
        }
        return false;
    }
}
