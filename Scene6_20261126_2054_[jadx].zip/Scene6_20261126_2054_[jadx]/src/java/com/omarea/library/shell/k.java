package com.omarea.library.shell;

import android.os.Build;
import android.os.SystemClock;
import android.util.Log;
import com.omarea.model.FpsData;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import kotlin.text.Regex;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class k {
    private static a f;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final HashMap<String, String> f752a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final HashMap<String, String> f753b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private b f754c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private final Regex f755d;
    private final boolean e;

    public static final class a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private long f756a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private String f757b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private double f758c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        private int f759d;
        private int e;
        private int f;

        public final String a() {
            return this.f757b;
        }

        public final int b() {
            return this.e;
        }

        public final double c() {
            return this.f758c;
        }

        public final int d() {
            return this.f759d;
        }

        public final int e() {
            return this.f;
        }

        public final long f() {
            return this.f756a;
        }

        public final void g(String str) {
        }

        public final void h(String str) {
            this.f757b = str;
        }

        public final void i(int i) {
            this.e = i;
        }

        public final void j(double d2) {
            this.f758c = d2;
        }

        public final void k(int[] iArr) {
            kotlin.jvm.internal.r.d(iArr, "<set-?>");
        }

        public final void l(int i) {
            this.f759d = i;
        }

        public final void m(int i) {
            this.f = i;
        }

        public final void n(long j) {
            this.f756a = j;
        }

        public final void o(String str) {
        }
    }

    public k() {
        HashMap<String, String> map = new HashMap<>();
        int i = Build.VERSION.SDK_INT;
        map.put("com.netease.moba/com.netease.g78.Client", "com.netease.moba/com.netease.g78.Client#0");
        kotlin.s sVar = kotlin.s.a;
        this.f752a = map;
        HashMap<String, String> map2 = new HashMap<>();
        if (Build.VERSION.SDK_INT < 31) {
            map2.put("com.tencent.tmgp.sgame/com.tencent.tmgp.sgame.SGameActivity", "SurfaceView - com.tencent.tmgp.sgame/com.tencent.tmgp.sgame.SGameActivity#0");
            map2.put("com.miHoYo.Yuanshen/com.miHoYo.GetMobileInfo.MainActivity", "SurfaceView - com.miHoYo.Yuanshen/com.miHoYo.GetMobileInfo.MainActivity#0");
        }
        kotlin.s sVar2 = kotlin.s.a;
        this.f753b = map2;
        this.f754c = new b();
        this.f755d = new Regex("[ \\t]+");
        this.e = true;
    }

    private final long b(String str) {
        Long lJ;
        List listSplit = this.f755d.split(str, 0);
        if (listSplit.size() != 3 || (lJ = kotlin.text.k.j((String) listSplit.get(1))) == null || lJ.longValue() <= 0 || lJ.longValue() == Long.MAX_VALUE) {
            return 0L;
        }
        return lJ.longValue() / ((long) 1000);
    }

    /* JADX WARN: Code duplicated, block: B:25:0x00bc  */
    /* JADX WARN: Code duplicated, block: B:27:0x00c0  */
    /* JADX WARN: Code duplicated, block: B:29:0x00c6  */
    /* JADX WARN: Code duplicated, block: B:31:0x00cc  */
    /* JADX WARN: Code duplicated, block: B:32:0x00ce  */
    /* JADX WARN: Code duplicated, block: B:34:0x00d1  */
    /* JADX WARN: Code duplicated, block: B:39:0x00e4  */
    /* JADX WARN: Code duplicated, block: B:41:0x00e9  */
    /* JADX WARN: Code duplicated, block: B:53:0x011a  */
    /* JADX WARN: Code duplicated, block: B:55:0x0128  */
    /* JADX WARN: Code duplicated, block: B:58:0x0134  */
    /* JADX WARN: Code duplicated, block: B:77:0x018f  */
    /* JADX WARN: Code duplicated, block: B:79:0x0196  */
    /* JADX WARN: Code duplicated, block: B:88:0x01a9 A[EDGE_INSN: B:88:0x01a9->B:82:0x01a9 BREAK  A[LOOP:0: B:10:0x0076->B:81:0x01a3], SYNTHETIC] */
    private final FpsData d(String str) {
        long jB;
        int i;
        long j;
        long j2;
        int i2;
        int size;
        int i3;
        boolean z;
        String strE = com.omarea.common.shell.e.f469b.e("dumpsys SurfaceFlinger --latency '" + str + '\'');
        FpsData fpsData = new FpsData();
        fpsData.window = str;
        int i4 = 0;
        if ((strE.length() > 0) && (!kotlin.jvm.internal.r.a(strE, "error"))) {
            List listW = kotlin.text.k.W(strE, new String[]{"\n"}, false, 0, 6, (Object) null);
            int i5 = 16666666;
            ArrayList arrayList = new ArrayList();
            long jUptimeMillis = SystemClock.uptimeMillis();
            long j3 = jUptimeMillis - ((long) 1010);
            long j4 = jUptimeMillis - ((long) 10);
            ArrayList arrayList2 = new ArrayList();
            int size2 = listW.size();
            boolean z2 = false;
            int i6 = 0;
            String str2 = "";
            long jB2 = 0;
            long j5 = 0;
            for (int i7 = 0; i7 < size2; i7++) {
                String str3 = (String) listW.get(i7);
                if (z2) {
                    jB = b(str3);
                    i = i5;
                    j = 1000;
                    j2 = jB / j;
                    if (j2 >= j4) {
                        break;
                    }
                    if (j2 >= j3) {
                        if (jB2 == 0) {
                            if (str2.length() > 0) {
                                z = true;
                            } else {
                                z = false;
                            }
                            if (z) {
                                str3 = str2;
                                jB2 = b(str3) / j;
                                if (jB2 >= 1 || jB2 > j3) {
                                }
                            } else {
                                str3 = str2;
                            }
                            jB2 = j3;
                        } else {
                            str3 = str2;
                        }
                        if (i7 > 0 || j5 <= 0 || (i2 = (int) (jB - j5)) > 1000000) {
                            i2 = i;
                        } else if (i2 < 0) {
                            Log.e("@Scene", "" + i2);
                            i2 = i;
                        } else if (fpsData.MaxFrameTime < i2) {
                            fpsData.MaxFrameTime = i2;
                        }
                        arrayList.add(Integer.valueOf(i2));
                        i6++;
                    } else {
                        i2 = -1;
                    }
                    str2 = str3;
                    size = arrayList2.size();
                    if (size <= 2) {
                        if (j2 < j3 && i2 > 40000) {
                            int iIntValue = ((Number) arrayList2.get(0)).intValue();
                            Object obj = arrayList2.get(1);
                            kotlin.jvm.internal.r.c(obj, "prevFrameDuration[1]");
                            int iIntValue2 = iIntValue + ((Number) obj).intValue();
                            Object obj2 = arrayList2.get(2);
                            kotlin.jvm.internal.r.c(obj2, "prevFrameDuration[2]");
                            int iIntValue3 = (iIntValue2 + ((Number) obj2).intValue()) / 3;
                            boolean z3 = iIntValue3 > 0 && i2 > iIntValue3 * 2;
                            boolean z4 = z3 && i2 > 80000;
                            if (z3) {
                                i3 = 1;
                                fpsData.Jank++;
                            } else {
                                i3 = 1;
                            }
                            if (z4) {
                                fpsData.BigJank += i3;
                            }
                        }
                        arrayList2.remove(size - 1);
                    }
                    Integer numValueOf = Integer.valueOf(i2);
                    i4 = 0;
                    arrayList2.add(0, numValueOf);
                    j5 = jB;
                    i5 = i;
                } else {
                    if ((str3.length() == 0 ? 1 : i4) == 0) {
                        try {
                            Integer.parseInt(String.valueOf(str3.charAt(i4)));
                            i5 = Integer.parseInt(str3) / 1000;
                            fpsData.MaxFrameTime = i5 / 1000;
                            z2 = true;
                            jB = b(str3);
                            i = i5;
                            j = 1000;
                            j2 = jB / j;
                            if (j2 >= j4) {
                                break;
                                break;
                            }
                            if (j2 >= j3) {
                                if (jB2 == 0) {
                                    if (str2.length() > 0) {
                                        z = true;
                                    } else {
                                        z = false;
                                    }
                                    if (z) {
                                        str3 = str2;
                                        jB2 = b(str3) / j;
                                        if (jB2 >= 1) {
                                        }
                                    } else {
                                        str3 = str2;
                                    }
                                    jB2 = j3;
                                } else {
                                    str3 = str2;
                                }
                                if (i7 > 0) {
                                    i2 = i;
                                } else {
                                    i2 = i;
                                }
                                arrayList.add(Integer.valueOf(i2));
                                i6++;
                            } else {
                                i2 = -1;
                            }
                            str2 = str3;
                            size = arrayList2.size();
                            if (size <= 2) {
                                if (j2 < j3) {
                                }
                                arrayList2.remove(size - 1);
                            }
                            Integer numValueOf2 = Integer.valueOf(i2);
                            i4 = 0;
                            arrayList2.add(0, numValueOf2);
                            j5 = jB;
                            i5 = i;
                        } catch (Exception unused) {
                            i4 = 0;
                        }
                    }
                    i4 = 0;
                }
            }
            fpsData.FrameNumber = i6;
            fpsData.FrameTimeMS = kotlin.collections.q.T(arrayList);
        }
        return fpsData;
    }

    private final boolean e(String str) {
        return kotlin.text.k.t(str, "Background", false, 2, (Object) null) || kotlin.text.k.y(str, "AppWindowToken", false, 2, (Object) null) || kotlin.text.k.y(str, "WindowToken", false, 2, (Object) null);
    }

    public final void a() {
        this.f753b.clear();
    }

    /* JADX WARN: Code duplicated, block: B:13:0x0027  */
    /* JADX WARN: Code duplicated, block: B:15:0x0040  */
    public final a c(boolean z, String str) {
        ArrayList arrayList;
        long jCurrentTimeMillis;
        a aVar;
        if (f != null) {
            if (str == null || str.length() == 0) {
                jCurrentTimeMillis = System.currentTimeMillis();
                aVar = f;
                kotlin.jvm.internal.r.b(aVar);
                if (Math.abs(jCurrentTimeMillis - aVar.f()) < 1000) {
                    return f;
                }
            } else {
                a aVar2 = f;
                kotlin.jvm.internal.r.b(aVar2);
                if (kotlin.jvm.internal.r.a(aVar2.a(), str)) {
                    jCurrentTimeMillis = System.currentTimeMillis();
                    aVar = f;
                    kotlin.jvm.internal.r.b(aVar);
                    if (Math.abs(jCurrentTimeMillis - aVar.f()) < 1000) {
                        return f;
                    }
                }
            }
        }
        String strB = this.f754c.b();
        ArrayList<String> arrayList2 = null;
        if (strB.length() == 0) {
            return null;
        }
        a aVar3 = new a();
        aVar3.g(strB);
        if (kotlin.text.k.y(strB, "/", false, 2, (Object) null)) {
            int iH = kotlin.text.k.H(strB, "/", 0, false, 6, (Object) null);
            if (strB == null) {
                throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
            }
            String strSubstring = strB.substring(0, iH);
            kotlin.jvm.internal.r.c(strSubstring, "(this as java.lang.Strin…ing(startIndex, endIndex)");
            aVar3.h(strSubstring);
        } else {
            aVar3.h(strB);
        }
        String str2 = this.f752a.get(strB);
        if (str2 == null) {
            if (this.e && z && this.f753b.containsKey(strB)) {
                String str3 = this.f753b.get(strB);
                kotlin.jvm.internal.r.b(str3);
                str2 = str3;
            } else {
                str2 = null;
            }
        }
        double d2 = 0.0d;
        if (str2 != null) {
            aVar3.n(System.currentTimeMillis());
            FpsData fpsDataD = d(str2);
            aVar3.j(fpsDataD.FrameNumber);
            int[] iArr = fpsDataD.FrameTimeMS;
            kotlin.jvm.internal.r.c(iArr, "FrameTimeMS");
            aVar3.k(iArr);
            aVar3.l(fpsDataD.Jank);
            aVar3.i(fpsDataD.BigJank);
            aVar3.m(fpsDataD.MaxFrameTime);
            aVar3.o(str2);
            a aVar4 = f;
            if (aVar4 != null && aVar4.c() == 0.0d && aVar3.c() == 0.0d) {
                a();
            }
            f = aVar3;
            return aVar3;
        }
        List<String> listW = kotlin.text.k.W(com.omarea.common.shell.e.f469b.e("dumpsys SurfaceFlinger --list | grep '" + strB + '\''), new String[]{"\n"}, false, 0, 6, (Object) null);
        if (z) {
            if (Build.VERSION.SDK_INT >= 31) {
                arrayList = new ArrayList();
                for (Object obj : listW) {
                    if (kotlin.text.k.t((String) obj, "SurfaceView[" + strB + "](BLAST)#", false, 2, (Object) null)) {
                        arrayList.add(obj);
                    }
                }
            } else {
                arrayList = new ArrayList();
                for (Object obj2 : listW) {
                    if (kotlin.text.k.t((String) obj2, "SurfaceView - " + strB + '#', false, 2, (Object) null)) {
                        arrayList.add(obj2);
                    }
                }
            }
            arrayList2 = arrayList;
        }
        if (arrayList2 == null || arrayList2.size() <= 0) {
            for (String str4 : listW) {
                if (!e(str4)) {
                    FpsData fpsDataD2 = d(str4);
                    if (fpsDataD2.FrameNumber > d2) {
                        aVar3.o(str4);
                        d2 = fpsDataD2.FrameNumber;
                        aVar3.j(d2);
                        int[] iArr2 = fpsDataD2.FrameTimeMS;
                        kotlin.jvm.internal.r.c(iArr2, "fps.FrameTimeMS");
                        aVar3.k(iArr2);
                        aVar3.l(fpsDataD2.Jank);
                        aVar3.i(fpsDataD2.BigJank);
                        aVar3.m(fpsDataD2.MaxFrameTime);
                    }
                }
            }
        } else {
            for (String str5 : arrayList2) {
                FpsData fpsDataD3 = d(str5);
                if (fpsDataD3.FrameNumber > aVar3.c()) {
                    aVar3.o(str5);
                    int[] iArr3 = fpsDataD3.FrameTimeMS;
                    kotlin.jvm.internal.r.c(iArr3, "fps.FrameTimeMS");
                    aVar3.k(iArr3);
                    aVar3.l(fpsDataD3.Jank);
                    aVar3.i(fpsDataD3.BigJank);
                    aVar3.j(fpsDataD3.FrameNumber);
                    aVar3.m(fpsDataD3.MaxFrameTime);
                    if (this.e && fpsDataD3.FrameNumber >= 20) {
                        this.f753b.put(strB, str5);
                        break;
                    }
                }
            }
        }
        aVar3.n(System.currentTimeMillis());
        f = aVar3;
        return aVar3;
    }
}
