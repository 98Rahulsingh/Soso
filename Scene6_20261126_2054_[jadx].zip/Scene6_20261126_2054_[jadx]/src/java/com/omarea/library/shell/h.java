package com.omarea.library.shell;

import java.util.HashMap;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class h {
    public final HashMap<String, String> a(String str) {
        String strSubstring;
        kotlin.jvm.internal.r.d(str, "dir");
        HashMap<String, String> map = new HashMap<>();
        StringBuilder sb = new StringBuilder("if [[ -e " + str + " ]]; then\n");
        sb.append("cd " + str + '\n');
        sb.append("for item in `ls`\ndo\n\tif [[ -f $item ]] then\n\t\techo \"$item:`cat $item`\"\n\t\techo '----'\n\tfi\ndone\n");
        sb.append("\nfi\n");
        com.omarea.common.shell.e eVar = com.omarea.common.shell.e.f469b;
        String string = sb.toString();
        kotlin.jvm.internal.r.c(string, "cmds.toString()");
        String strC = eVar.c(string);
        if (!kotlin.jvm.internal.r.a(strC, "error")) {
            for (String str2 : kotlin.text.k.W(strC, new String[]{"----"}, false, 0, 6, (Object) null)) {
                if (str2 == null) {
                    throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
                }
                String string2 = kotlin.text.k.k0(str2).toString();
                if (!(string2.length() == 0) && kotlin.text.k.H(string2, ":", 0, false, 6, (Object) null) > -1) {
                    int iH = kotlin.text.k.H(string2, ":", 0, false, 6, (Object) null);
                    if (string2 == null) {
                        throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                    }
                    String strSubstring2 = string2.substring(0, iH);
                    kotlin.jvm.internal.r.c(strSubstring2, "(this as java.lang.Strin…ing(startIndex, endIndex)");
                    if (iH < string2.length() - 1) {
                        int i = iH + 1;
                        if (string2 == null) {
                            throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                        }
                        strSubstring = string2.substring(i);
                        kotlin.jvm.internal.r.c(strSubstring, "(this as java.lang.String).substring(startIndex)");
                    } else {
                        strSubstring = "";
                    }
                    map.put(strSubstring2, strSubstring);
                }
            }
        }
        return map;
    }
}
