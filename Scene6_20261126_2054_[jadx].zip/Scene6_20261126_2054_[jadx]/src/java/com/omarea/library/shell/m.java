package com.omarea.library.shell;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class m {
    public void a() {
        com.omarea.common.shell.e.f469b.c("pm disable com.google.android.gsf 2> /dev/null\npm disable com.google.android.gsf.login 2> /dev/null\npm disable com.google.android.gms 2> /dev/null\npm disable com.android.vending 2> /dev/null\npm disable com.google.android.play.games 2> /dev/null\npm disable com.google.android.syncadapters.contacts 2> /dev/null");
    }

    public void b() {
        com.omarea.common.shell.e.f469b.c("pm enable com.google.android.gsf 2> /dev/null\npm enable com.google.android.gsf.login 2> /dev/null\npm enable com.google.android.gms 2> /dev/null\npm enable com.android.vending 2> /dev/null\npm enable com.google.android.play.games 2> /dev/null\npm enable com.google.android.syncadapters.contacts 2> /dev/null");
    }
}
