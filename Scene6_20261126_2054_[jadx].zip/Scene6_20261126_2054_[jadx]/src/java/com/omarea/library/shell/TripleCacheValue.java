package com.omarea.library.shell;

import android.content.Context;
import android.content.SharedPreferences;
import kotlin.coroutines.CoroutineContext;
import kotlinx.coroutines.CoroutineStart;
import kotlinx.coroutines.h1;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public abstract class TripleCacheValue {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private String f715a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final Context f716b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final String f717c;

    public TripleCacheValue(Context context, String str) {
        kotlin.jvm.internal.r.d(context, "context");
        kotlin.jvm.internal.r.d(str, "storageKey");
        this.f716b = context;
        this.f717c = str;
    }

    private final void d(SharedPreferences sharedPreferences) {
        String strF = f();
        this.f715a = strF;
        if (strF != null) {
            if ((strF.length() > 0) && (!kotlin.jvm.internal.r.a(this.f715a, "error"))) {
                sharedPreferences.edit().putString(this.f717c, this.f715a).apply();
            }
        }
    }

    private final String e() {
        if (this.f715a == null) {
            SharedPreferences sharedPreferences = this.f716b.getSharedPreferences("TripleCacheValues", 0);
            if (sharedPreferences.contains(this.f717c)) {
                this.f715a = sharedPreferences.getString(this.f717c, "");
                kotlin.jvm.internal.r.c(sharedPreferences, "storage");
                h(sharedPreferences);
            } else {
                kotlin.jvm.internal.r.c(sharedPreferences, "storage");
                d(sharedPreferences);
            }
        }
        return this.f715a;
    }

    public abstract String f();

    public final void g() {
        this.f715a = null;
        this.f716b.getSharedPreferences("TripleCacheValues", 0).edit().remove(this.f717c).apply();
        e();
    }

    protected void h(SharedPreferences sharedPreferences) {
        kotlin.jvm.internal.r.d(sharedPreferences, "storage");
        kotlinx.coroutines.f.d(h1.f, (CoroutineContext) null, (CoroutineStart) null, new TripleCacheValue$refreshCache$1(this, sharedPreferences, null), 3, (Object) null);
    }

    public final int i() {
        String strE = e();
        if (strE == null || strE.length() == 0) {
            return 0;
        }
        return Integer.parseInt(strE);
    }

    public String toString() {
        String strE = e();
        return strE != null ? strE : "";
    }
}
