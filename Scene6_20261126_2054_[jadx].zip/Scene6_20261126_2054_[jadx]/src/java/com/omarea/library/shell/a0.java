package com.omarea.library.shell;

import com.omarea.common.net.Daemon;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class a0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private int f718a = 1;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private ArrayList<a> f719b;

    public static final class a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private int f720a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private long f721b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private double f722c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public String f723d;

        public final String a() {
            String str = this.f723d;
            if (str != null) {
                return str;
            }
            kotlin.jvm.internal.r.q("comm");
            throw null;
        }

        public final long b() {
            return this.f721b;
        }

        public final double c() {
            return this.f722c;
        }

        public final int d() {
            return this.f720a;
        }

        public final void e(String str) {
            kotlin.jvm.internal.r.d(str, "<set-?>");
            this.f723d = str;
        }

        public final void f(long j) {
            this.f721b = j;
        }

        public final void g(double d2) {
            this.f722c = d2;
        }

        public final void h(int i) {
            this.f720a = i;
        }
    }

    public static final class b {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private int f724a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private long f725b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private double f726c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        private double f727d;
        public String e;

        public final String a() {
            String str = this.e;
            if (str != null) {
                return str;
            }
            kotlin.jvm.internal.r.q("comm");
            throw null;
        }

        public final long b() {
            return this.f725b;
        }

        public final double c() {
            return this.f726c;
        }

        public final double d() {
            return this.f727d;
        }

        public final int e() {
            return this.f724a;
        }

        public final void f(String str) {
            kotlin.jvm.internal.r.d(str, "<set-?>");
            this.e = str;
        }

        public final void g(long j) {
            this.f725b = j;
        }

        public final void h(double d2) {
            this.f726c = d2;
        }

        public final void i(double d2) {
            this.f727d = d2;
        }

        public final void j(int i) {
            this.f724a = i;
        }
    }

    public final void a() {
        ArrayList<a> arrayList = this.f719b;
        if (arrayList != null) {
            arrayList.clear();
        }
        this.f719b = null;
    }

    public final a[] b() throws JSONException {
        ArrayList arrayList = new ArrayList();
        JSONArray jSONArrayY0 = Daemon.E.a().y0(this.f718a);
        if (jSONArrayY0 != null) {
            int length = jSONArrayY0.length();
            if (length > 15) {
                length = 15;
            }
            for (int i = 0; i < length; i++) {
                JSONObject jSONObject = jSONArrayY0.getJSONObject(i);
                a aVar = new a();
                aVar.h(jSONObject.getInt("pid"));
                aVar.g(((double) ((int) (jSONObject.getDouble("load") * ((double) 10)))) / 10.0d);
                String string = jSONObject.getString("comm");
                kotlin.jvm.internal.r.c(string, "item.getString(\"comm\")");
                aVar.e(string);
                aVar.f(jSONObject.getLong("duration"));
                kotlin.s sVar = kotlin.s.a;
                arrayList.add(aVar);
            }
        }
        Object[] array = arrayList.toArray(new a[0]);
        if (array != null) {
            return (a[]) array;
        }
        throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T>");
    }

    public final a0 c(int i) {
        if (this.f718a != i) {
            this.f718a = i;
            a();
        }
        return this;
    }
}
