package com.omarea.library.shell;

import android.content.SharedPreferences;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlinx.coroutines.h0;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
@kotlin.coroutines.jvm.internal.d(c = "com.omarea.library.shell.TripleCacheValue$refreshCache$1", f = "TripleCacheValue.kt", l = {}, m = "invokeSuspend")
final class TripleCacheValue$refreshCache$1 extends SuspendLambda implements kotlin.jvm.b.p<h0, kotlin.coroutines.c<? super kotlin.s>, Object> {
    final /* synthetic */ SharedPreferences $storage;
    int label;
    private h0 p$;
    final /* synthetic */ TripleCacheValue this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    TripleCacheValue$refreshCache$1(TripleCacheValue tripleCacheValue, SharedPreferences sharedPreferences, kotlin.coroutines.c cVar) {
        super(2, cVar);
        this.this$0 = tripleCacheValue;
        this.$storage = sharedPreferences;
    }

    public final kotlin.coroutines.c<kotlin.s> create(Object obj, kotlin.coroutines.c<?> cVar) {
        kotlin.jvm.internal.r.d(cVar, "completion");
        TripleCacheValue$refreshCache$1 tripleCacheValue$refreshCache$1 = new TripleCacheValue$refreshCache$1(this.this$0, this.$storage, cVar);
        tripleCacheValue$refreshCache$1.p$ = (h0) obj;
        return tripleCacheValue$refreshCache$1;
    }

    public final Object invoke(Object obj, Object obj2) {
        return create(obj, (kotlin.coroutines.c) obj2).invokeSuspend(kotlin.s.a);
    }

    /* JADX WARN: Code duplicated, block: B:16:0x0056  */
    public final Object invokeSuspend(Object obj) {
        SharedPreferences.Editor editorRemove;
        kotlin.coroutines.intrinsics.a.d();
        if (this.label != 0) {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        kotlin.h.b(obj);
        String strF = this.this$0.f();
        if (!kotlin.jvm.internal.r.a(this.this$0.f715a, strF)) {
            this.this$0.f715a = strF;
            String str = this.this$0.f715a;
            if (str == null) {
                editorRemove = this.$storage.edit().remove(this.this$0.f717c);
            } else {
                if ((str.length() > 0) && (!kotlin.jvm.internal.r.a(this.this$0.f715a, "error"))) {
                    editorRemove = this.$storage.edit().putString(this.this$0.f717c, strF);
                } else {
                    editorRemove = this.$storage.edit().remove(this.this$0.f717c);
                }
            }
            editorRemove.apply();
        }
        return kotlin.s.a;
    }
}
