package com.omarea.library.shell;

import android.content.Context;
import android.content.SharedPreferences;
import com.omarea.common.net.Daemon;
import com.omarea.model.ProcessInfo;
import java.util.ArrayList;
import java.util.Arrays;
import kotlin.text.Regex;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class ProcessUtilsSimple {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final a f710a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final ArrayList<String> f711b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final Regex f712c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private final Context f713d;

    public static final class a extends TripleCacheValue {
        a(Context context, String str) {
            super(context, str);
        }

        @Override // com.omarea.library.shell.TripleCacheValue
        public String f() {
            String strB = new com.omarea.e.b(ProcessUtilsSimple.this.f713d).b();
            String str = strB + " top -o %CPU,NAME,COMMAND,PID -q -b -n 1 -m 65535";
            return strB + " ps -e -o %CPU,NAME,COMMAND,PID";
        }

        @Override // com.omarea.library.shell.TripleCacheValue
        protected void h(SharedPreferences sharedPreferences) {
            kotlin.jvm.internal.r.d(sharedPreferences, "storage");
            if (toString().length() == 0) {
                super.h(sharedPreferences);
            }
        }
    }

    public ProcessUtilsSimple(Context context) {
        kotlin.jvm.internal.r.d(context, "context");
        this.f713d = context;
        this.f710a = new a(context, "ProcessUtils2CMD");
        this.f711b = new ArrayList<String>() { // from class: com.omarea.library.shell.ProcessUtilsSimple$excludeProcess$1
            {
                add(com.omarea.e.b.f546d.a());
                add("ps");
                add("top");
                add("com.omarea.vtools");
            }

            @Override // java.util.ArrayList, java.util.AbstractCollection, java.util.Collection, java.util.List
            public final /* bridge */ boolean contains(Object obj) {
                if (obj instanceof String) {
                    return contains((String) obj);
                }
                return false;
            }

            public /* bridge */ boolean contains(String str) {
                return super.contains((Object) str);
            }

            public /* bridge */ int getSize() {
                return super.size();
            }

            @Override // java.util.ArrayList, java.util.AbstractList, java.util.List
            public final /* bridge */ int indexOf(Object obj) {
                if (obj instanceof String) {
                    return indexOf((String) obj);
                }
                return -1;
            }

            public /* bridge */ int indexOf(String str) {
                return super.indexOf((Object) str);
            }

            @Override // java.util.ArrayList, java.util.AbstractList, java.util.List
            public final /* bridge */ int lastIndexOf(Object obj) {
                if (obj instanceof String) {
                    return lastIndexOf((String) obj);
                }
                return -1;
            }

            public /* bridge */ int lastIndexOf(String str) {
                return super.lastIndexOf((Object) str);
            }

            @Override // java.util.ArrayList, java.util.AbstractList, java.util.List
            public final /* bridge */ String remove(int i) {
                return removeAt(i);
            }

            @Override // java.util.ArrayList, java.util.AbstractCollection, java.util.Collection, java.util.List
            public final /* bridge */ boolean remove(Object obj) {
                if (obj instanceof String) {
                    return remove((String) obj);
                }
                return false;
            }

            public /* bridge */ boolean remove(String str) {
                return super.remove((Object) str);
            }

            public /* bridge */ String removeAt(int i) {
                return (String) super.remove(i);
            }

            @Override // java.util.ArrayList, java.util.AbstractCollection, java.util.Collection, java.util.List
            public final /* bridge */ int size() {
                return getSize();
            }
        };
        this.f712c = new Regex(".*\\..*");
    }

    private final boolean c(ProcessInfo processInfo) {
        String str = processInfo.command;
        kotlin.jvm.internal.r.c(str, "processInfo.command");
        if (!kotlin.text.k.y(str, "app_process", false, 2, (Object) null)) {
            return false;
        }
        String str2 = processInfo.name;
        kotlin.jvm.internal.r.c(str2, "processInfo.name");
        return this.f712c.matches(str2);
    }

    private final void d(int i) {
        Daemon.E.a().j0("kill -9 " + i, 3000);
    }

    private final ProcessInfo f(String str) {
        Object[] array = new Regex(" +").split(str, 0).toArray(new String[0]);
        if (array == null) {
            throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T>");
        }
        String[] strArr = (String[]) array;
        if (strArr.length >= 3) {
            try {
                ProcessInfo processInfo = new ProcessInfo();
                processInfo.cpu = Float.parseFloat(strArr[0]);
                String str2 = strArr[1];
                processInfo.name = str2;
                if (this.f711b.contains(str2)) {
                    return null;
                }
                processInfo.command = strArr[2];
                processInfo.pid = Integer.parseInt(strArr[3]);
                return processInfo;
            } catch (Exception unused) {
            }
        }
        return null;
    }

    /* JADX WARN: Type inference failed for: r2v4, types: [boolean] */
    public final ArrayList<ProcessInfo> b() {
        ArrayList<ProcessInfo> arrayList = new ArrayList<>();
        String string = this.f710a.toString();
        if (string.length() > 0) {
            ?? T = kotlin.text.k.t(string, "ps", false, 2, (Object) null);
            Object[] array = new Regex("\n").split(Daemon.E.a().j0(string, 5000), 0).toArray(new String[0]);
            if (array == null) {
                throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T>");
            }
            int i = 0;
            for (String str : (String[]) array) {
                if (i >= T) {
                    i++;
                    int length = str.length() - 1;
                    int i2 = 0;
                    boolean z = false;
                    while (i2 <= length) {
                        boolean z2 = kotlin.jvm.internal.r.e(str.charAt(!z ? i2 : length), 32) <= 0;
                        if (z) {
                            if (!z2) {
                                break;
                            }
                            length--;
                        } else if (z2) {
                            i2++;
                        } else {
                            z = true;
                        }
                    }
                    ProcessInfo processInfoF = f(str.subSequence(i2, length + 1).toString());
                    if (processInfoF != null) {
                        arrayList.add(processInfoF);
                    }
                }
            }
        }
        return arrayList;
    }

    public final void e(ProcessInfo processInfo) {
        String strSubstring;
        kotlin.jvm.internal.r.d(processInfo, "processInfo");
        if (!c(processInfo)) {
            d(processInfo.pid);
            return;
        }
        String str = processInfo.name;
        kotlin.jvm.internal.r.c(str, "processInfo.name");
        if (kotlin.text.k.y(str, ":", false, 2, (Object) null)) {
            String str2 = processInfo.name;
            kotlin.jvm.internal.r.c(str2, "processInfo.name");
            String str3 = processInfo.name;
            kotlin.jvm.internal.r.c(str3, "processInfo.name");
            int iH = kotlin.text.k.H(str3, ":", 0, false, 6, (Object) null);
            if (str2 == null) {
                throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
            }
            strSubstring = str2.substring(0, iH);
            kotlin.jvm.internal.r.c(strSubstring, "(this as java.lang.Strin…ing(startIndex, endIndex)");
        } else {
            strSubstring = processInfo.name;
        }
        Daemon daemonA = Daemon.E.a();
        kotlin.jvm.internal.w wVar = kotlin.jvm.internal.w.a;
        String str4 = String.format("killall -9 %s;am force-stop %s;am kill %s", Arrays.copyOf(new Object[]{strSubstring, strSubstring, strSubstring}, 3));
        kotlin.jvm.internal.r.c(str4, "java.lang.String.format(format, *args)");
        daemonA.j0(str4, 3000);
    }

    public final void g(ProcessInfo processInfo) {
        String strSubstring;
        kotlin.jvm.internal.r.d(processInfo, "processInfo");
        String str = processInfo.name;
        kotlin.jvm.internal.r.c(str, "processInfo.name");
        if (kotlin.text.k.y(str, ":", false, 2, (Object) null)) {
            String str2 = processInfo.name;
            kotlin.jvm.internal.r.c(str2, "processInfo.name");
            String str3 = processInfo.name;
            kotlin.jvm.internal.r.c(str3, "processInfo.name");
            int iH = kotlin.text.k.H(str3, ":", 0, false, 6, (Object) null);
            if (str2 == null) {
                throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
            }
            strSubstring = str2.substring(0, iH);
            kotlin.jvm.internal.r.c(strSubstring, "(this as java.lang.Strin…ing(startIndex, endIndex)");
        } else {
            strSubstring = processInfo.name;
        }
        Daemon daemonA = Daemon.E.a();
        kotlin.jvm.internal.w wVar = kotlin.jvm.internal.w.a;
        String str4 = String.format("killall -9 %s;am force-stop %s;am kill %s", Arrays.copyOf(new Object[]{strSubstring, strSubstring, strSubstring}, 3));
        kotlin.jvm.internal.r.c(str4, "java.lang.String.format(format, *args)");
        daemonA.j0(str4, 3000);
        d(processInfo.pid);
    }

    public final boolean h() {
        return this.f710a.toString().length() > 0;
    }
}
