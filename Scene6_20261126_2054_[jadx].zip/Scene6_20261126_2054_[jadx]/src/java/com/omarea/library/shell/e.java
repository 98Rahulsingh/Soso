package com.omarea.library.shell;

import android.util.Log;
import java.util.HashMap;
import java.util.Iterator;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private static String f736a = "";

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private static HashMap<Integer, Double> f737b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private static Long f738c;

    public e() {
        f736a = e();
    }

    private long a(String[] strArr) {
        return Long.parseLong(strArr[4]) + Long.parseLong(strArr[5]);
    }

    private long b(String[] strArr) {
        long j = 0;
        if (strArr.length == 11) {
            for (int i = 1; i < 8; i++) {
                j += Long.parseLong(strArr[i]);
            }
        }
        return j;
    }

    private int c(String[] strArr) {
        if (strArr[0].equals("cpu")) {
            return -1;
        }
        return Integer.parseInt(strArr[0].substring(3));
    }

    private String e() {
        String[] strArrSplit = com.omarea.common.shell.f.f471b.a("/proc/stat").split("\n");
        StringBuilder sb = new StringBuilder();
        for (String str : strArrSplit) {
            if (str.startsWith("cpu")) {
                if (sb.length() > 0) {
                    sb.append("\n");
                }
                sb.append(str);
            }
        }
        return sb.toString();
    }

    public HashMap<Integer, Double> d() {
        String[] strArrSplit;
        Integer numValueOf;
        Double dValueOf;
        synchronized ("/proc/stat") {
            if (f737b != null && System.currentTimeMillis() - f738c.longValue() < 500) {
                return f737b;
            }
            HashMap<Integer, Double> map = new HashMap<>();
            String strE = e();
            if (strE.equals("error") || !strE.startsWith("cpu")) {
                return map;
            }
            try {
                if (f736a.isEmpty()) {
                    f736a = strE;
                    Thread.sleep(100L);
                    return d();
                }
                String[] strArrSplit2 = strE.split("\n");
                String[] strArrSplit3 = f736a.split("\n");
                for (String str : strArrSplit2) {
                    String[] strArrSplit4 = str.replaceAll(" {2}", " ").split(" ");
                    int length = strArrSplit3.length;
                    int i = 0;
                    while (true) {
                        if (i >= length) {
                            strArrSplit = null;
                            break;
                        }
                        String str2 = strArrSplit3[i];
                        if (str2.startsWith(strArrSplit4[0] + " ")) {
                            strArrSplit = str2.replaceAll(" {2}", " ").split(" ");
                            break;
                        }
                        i++;
                    }
                    if (strArrSplit == null || strArrSplit.length == 0) {
                        numValueOf = Integer.valueOf(c(strArrSplit4));
                        dValueOf = Double.valueOf(0.0d);
                    } else {
                        long jB = b(strArrSplit4);
                        long jA = a(strArrSplit4);
                        long jB2 = b(strArrSplit);
                        long jA2 = a(strArrSplit);
                        long j = jB - jB2;
                        if (j == 0) {
                            numValueOf = Integer.valueOf(c(strArrSplit4));
                            dValueOf = Double.valueOf(0.0d);
                        } else {
                            long j2 = jA - jA2;
                            if (j2 < 1) {
                                numValueOf = Integer.valueOf(c(strArrSplit4));
                                dValueOf = Double.valueOf(100.0d);
                            } else {
                                numValueOf = Integer.valueOf(c(strArrSplit4));
                                dValueOf = Double.valueOf(100.0d - ((j2 * 100.0d) / j));
                            }
                        }
                    }
                    map.put(numValueOf, dValueOf);
                }
                String str3 = f736a;
                f736a = "";
                f738c = 0L;
                f737b = null;
                Iterator<Double> it = map.values().iterator();
                while (it.hasNext()) {
                    if (it.next().doubleValue() > 0.0d) {
                        f736a = strE;
                        f738c = Long.valueOf(System.currentTimeMillis());
                        f737b = map;
                        break;
                    }
                    Log.e("@Scene - prev", str3);
                    Log.e("@Scene - current", strE);
                }
                return map;
            } catch (Exception e) {
                f736a = "";
                f738c = 0L;
                f737b = null;
                Log.e("@Scene", strE + "\n" + e.getMessage());
                return map;
            }
        }
    }
}
