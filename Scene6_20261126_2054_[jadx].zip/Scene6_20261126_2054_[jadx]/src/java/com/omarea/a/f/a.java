package com.omarea.a.f;

import kotlin.jvm.internal.r;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private String f367a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private String f368b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private boolean f369c;

    public final boolean a() {
        return this.f369c;
    }

    public final String b() {
        return this.f367a;
    }

    public final String c() {
        return this.f368b;
    }

    public final void d(boolean z) {
        this.f369c = z;
    }

    public final void e(String str) {
        this.f367a = str;
    }

    public final void f(String str) {
        this.f368b = str;
    }

    public String toString() {
        String str;
        String str2 = this.f367a;
        if (str2 == null || str2.length() == 0) {
            String str3 = this.f368b;
            if (str3 == null || str3.length() == 0) {
                return "";
            }
            str = this.f368b;
        } else {
            str = this.f367a;
        }
        r.b(str);
        return str;
    }
}
