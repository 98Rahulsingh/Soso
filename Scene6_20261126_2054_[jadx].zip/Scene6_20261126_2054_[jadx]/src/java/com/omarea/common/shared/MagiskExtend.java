package com.omarea.common.shared;

import android.content.Context;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class MagiskExtend {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private static String f444a = "/data/adb/modules";

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private static String f445b = "scene_systemless";

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static String f446c = f444a + "/" + f445b + "/";

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private static final String f447d = f446c + "system.prop";
    private static int e;
    private static int f;

    static {
        String str = f446c + "service.sh";
        e = -1;
        f = 0;
    }

    public static void a(String str) {
        if (com.omarea.common.shell.g.f472a.g(str)) {
            com.omarea.common.shell.g.f472a.j(b(str), "");
        }
    }

    public static String b(String str) {
        StringBuilder sb = new StringBuilder();
        String str2 = f446c;
        sb.append(str2.substring(0, str2.length() - 1));
        if (str.startsWith("/vendor") || str.startsWith("/product")) {
            str = "/system" + str;
        }
        sb.append(str);
        return sb.toString();
    }

    public static void c(Context context) {
        j("id=scene_systemless\nname=Scene的附加模块\nversion=v1\nversionCode=1\nauthor=嘟嘟ski\ndescription=Scene的辅助模块，使用Scene部分功能时可免于直接操作系统文件\nminMagisk=17000\n", "module.prop", context);
        j("# This file will be read by resetprop\n# 示例: 更改 dpi\n# ro.sf.lcd_density=410\n# vendor.display.lcd_density=410\n", "system.prop", context);
        j("#!/system/bin/sh\n# 请不要硬编码/magisk/modname/...;相反，请使用$MODDIR/...\n# 这将使您的脚本兼容，即使Magisk以后改变挂载点\nMODDIR=${0%/*}\n\n# 该脚本将在设备开机后作为延迟服务启动\n\n# 下面，你也可以添加一些自己的代码\n", "service.sh", context);
        j("#!/system/bin/sh\n# 请不要硬编码/magisk/modname/...;相反，请使用$MODDIR/...\n# 这将使您的脚本兼容，即使Magisk以后改变挂载点\nMODDIR=${0%/*}\n\n# 此脚本将在post-fs-data模式下执行\n", "post-fs-data.sh", context);
    }

    public static boolean d() {
        if (e == -1 || f < 1) {
            String strE = com.omarea.common.shell.e.f469b.e("magisk -V");
            if (strE.equals("error")) {
                e = 0;
            } else {
                try {
                    int i = Integer.parseInt(strE) / 1000;
                    f = i;
                    e = i >= 19 ? 1 : 0;
                } catch (Exception unused) {
                }
            }
        }
        return e == 1;
    }

    public static boolean e() {
        if (d()) {
            if (com.omarea.common.shell.g.f472a.d(f446c + "module.prop")) {
                return true;
            }
        }
        return false;
    }

    private static String f(LinkedHashMap<String, String> linkedHashMap) {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, String> entry : linkedHashMap.entrySet()) {
            sb.append(entry.getKey());
            sb.append("=");
            sb.append(entry.getValue());
            sb.append("\n");
        }
        return sb.toString();
    }

    public static boolean g(String str, String str2) {
        if (!com.omarea.common.shell.g.f472a.g(str2)) {
            return false;
        }
        String strB = b(str);
        String parent = new File(strB).getParent();
        com.omarea.common.shell.e.f469b.c("mkdir -p \"" + parent + "\"\ncp \"" + str2 + "\" \"" + strB + "\"\nchmod 777 \"" + strB + "\"");
        return true;
    }

    public static boolean h(String str, String str2) {
        String[] strArrSplit = com.omarea.common.shell.g.f472a.i(f447d).trim().split("\n");
        ArrayList arrayList = new ArrayList();
        boolean z = false;
        for (String str3 : strArrSplit) {
            String str4 = str + "=";
            if (str3.startsWith(str4)) {
                arrayList.add(str4 + str2);
                z = true;
            } else {
                arrayList.add(str3);
            }
        }
        if (!z) {
            arrayList.add(str + "=" + str2);
        }
        StringBuilder sb = new StringBuilder();
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            sb.append((String) it.next());
            sb.append("\n");
        }
        return com.omarea.common.shell.g.f472a.j(f447d, sb.toString());
    }

    public static boolean i(String str, String str2, final String str3, final String str4, final String str5, final int i) {
        if (!d() || !com.omarea.common.shell.g.f472a.g(str2)) {
            return false;
        }
        String strF = f(new LinkedHashMap<String, String>() { // from class: com.omarea.common.shared.MagiskExtend.1
            {
                put("id", str3);
                put("name", str4);
                put("version", str5);
                put("versionCode", "" + i);
                put("author", "嘟嘟ski(SCENE)");
                put("description", "用于将第三方应用转换成系统应用的模块，由Scene创建并添加");
            }
        });
        StringBuilder sb = new StringBuilder();
        sb.append(f444a);
        sb.append("/");
        sb.append(str3);
        if (str.startsWith("/vendor") || str.startsWith("/product")) {
            str = "/system" + str;
        }
        sb.append(str);
        String string = sb.toString();
        String parent = new File(string).getParent();
        com.omarea.common.shell.e.f469b.c("mkdir -p \"" + parent + "\"\necho \"" + strF + "\" > \"" + f444a + "/" + str3 + "/module.prop\"\ncp -pdrf \"" + str2 + "\" \"" + string + "\"\nchmod -R 777 \"" + string + "\"");
        return true;
    }

    private static void j(String str, String str2, Context context) {
        if (!e()) {
            com.omarea.common.shell.e.f469b.e("mkdir -p " + f446c);
        }
        if (d.f450b.h(str.getBytes(), str2, context)) {
            String strB = d.f450b.b(context, str2);
            String str3 = f446c + str2;
            com.omarea.common.shell.e.f469b.c("cp " + strB + " " + str3 + "\nchmod 777 " + str3);
            File file = new File(strB);
            if (file.exists()) {
                file.delete();
            }
        }
    }
}
