package com.omarea.common.shared;

import android.content.Context;
import android.content.res.Resources;
import java.util.List;
import java.util.Locale;
import kotlin.jvm.internal.r;
import kotlin.text.Regex;
import kotlin.text.RegexOption;
import kotlin.text.k;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class g {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final Regex f454a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final Regex f455b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final Context f456c;

    public g(Context context) {
        r.d(context, "context");
        this.f456c = context;
        this.f454a = new Regex("^@(string|dimen):[_a-z]+.*", RegexOption.IGNORE_CASE);
        this.f455b = new Regex("^@(string|dimen)/[_a-z]+.*", RegexOption.IGNORE_CASE);
    }

    /* JADX WARN: Code duplicated, block: B:11:0x0037  */
    public final String a(String str) {
        Character chValueOf;
        char c2;
        r.d(str, "originRow");
        String string = k.k0(str).toString();
        if (k.t(string, "@", false, 2, (Object) null)) {
            if (this.f454a.matches(string)) {
                c2 = ':';
            } else if (this.f455b.matches(string)) {
                c2 = '/';
            } else {
                chValueOf = null;
            }
            chValueOf = Character.valueOf(c2);
        } else {
            chValueOf = null;
        }
        if (chValueOf != null) {
            Resources resources = this.f456c.getResources();
            int iG = k.G(string, chValueOf.charValue(), 0, false, 6, (Object) null);
            if (string == null) {
                throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
            }
            String strSubstring = string.substring(1, iG);
            r.c(strSubstring, "(this as java.lang.Strin…ing(startIndex, endIndex)");
            Locale locale = Locale.ENGLISH;
            r.c(locale, "Locale.ENGLISH");
            if (strSubstring == null) {
                throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
            }
            String lowerCase = strSubstring.toLowerCase(locale);
            r.c(lowerCase, "(this as java.lang.String).toLowerCase(locale)");
            int iG2 = k.G(string, chValueOf.charValue(), 0, false, 6, (Object) null) + 1;
            if (string == null) {
                throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
            }
            String strSubstring2 = string.substring(iG2);
            r.c(strSubstring2, "(this as java.lang.String).substring(startIndex)");
            try {
                int identifier = resources.getIdentifier(strSubstring2, lowerCase, this.f456c.getPackageName());
                int iHashCode = lowerCase.hashCode();
                if (iHashCode != -891985903) {
                    if (iHashCode == 95588145 && lowerCase.equals("dimen")) {
                        return String.valueOf(resources.getDimension(identifier));
                    }
                } else if (lowerCase.equals("string")) {
                    String string2 = resources.getString(identifier);
                    r.c(string2, "resources.getString(id)");
                    return string2;
                }
            } catch (Exception unused) {
                if (k.y(string, "[(", false, 2, (Object) null) && k.y(string, ")]", false, 2, (Object) null)) {
                    int iH = k.H(string, "[(", 0, false, 6, (Object) null) + 2;
                    int iH2 = k.H(string, ")]", 0, false, 6, (Object) null);
                    if (string == null) {
                        throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                    }
                    String strSubstring3 = string.substring(iH, iH2);
                    r.c(strSubstring3, "(this as java.lang.Strin…ing(startIndex, endIndex)");
                    return strSubstring3;
                }
            }
        }
        return str;
    }

    public final String b(List<String> list) {
        r.d(list, "rows");
        StringBuilder sb = new StringBuilder();
        int i = 0;
        for (String str : list) {
            if (i > 0) {
                sb.append("\n");
            }
            sb.append(a(str));
            i++;
        }
        String string = sb.toString();
        r.c(string, "builder.toString()");
        return string;
    }
}
