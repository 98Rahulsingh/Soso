package com.omarea.common.shared;

import android.content.Context;
import android.content.pm.PackageInfo;
import java.security.MessageDigest;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class h {
    private String a(byte[] bArr) {
        try {
            MessageDigest messageDigest = MessageDigest.getInstance("MD5");
            messageDigest.update(bArr);
            byte[] bArrDigest = messageDigest.digest();
            StringBuilder sb = new StringBuilder();
            for (byte b2 : bArrDigest) {
                String hexString = Integer.toHexString(b2 & 255);
                if (hexString.length() < 2) {
                    sb.append(0);
                }
                sb.append(hexString);
            }
            return sb.toString();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private String b(Context context) {
        return context.getApplicationInfo().packageName;
    }

    private String c(Context context, String str) {
        byte[] byteArray = null;
        try {
            PackageInfo packageInfo = context.getPackageManager().getPackageInfo(str, 64);
            for (int i = 0; i < packageInfo.signatures.length && (byteArray = packageInfo.signatures[i].toByteArray()) == null; i++) {
            }
            return a(byteArray);
        } catch (Exception unused) {
            return "";
        }
    }

    public String d(Context context) {
        return c(context, b(context));
    }
}
