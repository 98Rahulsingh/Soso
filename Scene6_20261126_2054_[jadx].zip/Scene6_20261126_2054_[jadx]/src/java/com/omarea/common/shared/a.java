package com.omarea.common.shared;

import android.content.Context;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import kotlin.jvm.internal.r;
import kotlin.text.Regex;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final a f448a = new a();

    private a() {
    }

    public final String a(Context context, String str) {
        r.d(context, "context");
        r.d(str, "fileName");
        try {
            byte[] bArrB = b(context, str);
            Charset charsetDefaultCharset = Charset.defaultCharset();
            r.c(charsetDefaultCharset, "Charset.defaultCharset()");
            return new Regex("\r").replace(new Regex("\r\t").replace(new Regex("\r\n").replace(new String(bArrB, charsetDefaultCharset), "\n"), "\t"), "\n");
        } catch (Exception unused) {
            return "";
        }
    }

    public final byte[] b(Context context, String str) throws IOException {
        r.d(context, "context");
        r.d(str, "fileName");
        InputStream inputStreamOpen = context.getAssets().open(str);
        r.c(inputStreamOpen, "context.assets.open(fileName)");
        return kotlin.io.a.c(inputStreamOpen);
    }
}
