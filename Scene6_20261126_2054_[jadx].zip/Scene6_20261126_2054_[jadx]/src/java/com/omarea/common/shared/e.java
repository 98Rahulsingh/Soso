package com.omarea.common.shared;

import android.content.Context;
import android.widget.Toast;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import kotlin.jvm.internal.r;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class e<T extends Serializable> {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final String f451a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final Context f452b;

    public e(Context context) {
        r.d(context, "context");
        this.f452b = context;
        this.f451a = "objects/";
    }

    public boolean a(String str) {
        r.d(str, "configFile");
        return new File(b(str)).exists();
    }

    protected final String b(String str) {
        r.d(str, "configFile");
        return d.f450b.b(this.f452b, this.f451a + str);
    }

    /* JADX WARN: Code duplicated, block: B:19:0x0040 A[Catch: Exception -> 0x0043, TRY_LEAVE, TryCatch #6 {Exception -> 0x0043, blocks: (B:17:0x003b, B:19:0x0040), top: B:35:0x003b }] */
    /* JADX WARN: Code duplicated, block: B:25:0x004d A[Catch: Exception -> 0x0050, TRY_LEAVE, TryCatch #0 {Exception -> 0x0050, blocks: (B:23:0x0048, B:25:0x004d), top: B:31:0x0048 }] */
    public T c(String str) throws Throwable {
        ObjectInputStream objectInputStream;
        Throwable th;
        FileInputStream fileInputStream;
        r.d(str, "configFile");
        File file = new File(b(str));
        if (file.exists()) {
            try {
                fileInputStream = new FileInputStream(file);
                try {
                    objectInputStream = new ObjectInputStream(fileInputStream);
                    try {
                        T t = (T) objectInputStream.readObject();
                        try {
                            objectInputStream.close();
                            fileInputStream.close();
                        } catch (Exception unused) {
                        }
                        return t;
                    } catch (Exception unused2) {
                        if (objectInputStream != null) {
                            try {
                                objectInputStream.close();
                                if (fileInputStream != null) {
                                    fileInputStream.close();
                                }
                            } catch (Exception unused3) {
                            }
                        } else if (fileInputStream != null) {
                            fileInputStream.close();
                        }
                        return null;
                    } catch (Throwable th2) {
                        th = th2;
                        if (objectInputStream != null) {
                            try {
                                objectInputStream.close();
                                if (fileInputStream != null) {
                                    fileInputStream.close();
                                }
                            } catch (Exception unused4) {
                                throw th;
                            }
                        } else if (fileInputStream != null) {
                            fileInputStream.close();
                        }
                        throw th;
                    }
                } catch (Exception unused5) {
                    objectInputStream = null;
                } catch (Throwable th3) {
                    th = th3;
                    objectInputStream = null;
                }
            } catch (Exception unused6) {
                fileInputStream = null;
                objectInputStream = null;
            } catch (Throwable th4) {
                objectInputStream = null;
                th = th4;
                fileInputStream = null;
            }
        }
        return null;
    }

    public void d(String str) {
        r.d(str, "configFile");
        File file = new File(b(str));
        if (file.exists()) {
            file.delete();
        }
    }

    /* JADX WARN: Code duplicated, block: B:26:0x0051 A[Catch: Exception -> 0x0054, TRY_LEAVE, TryCatch #7 {Exception -> 0x0054, blocks: (B:24:0x004c, B:26:0x0051), top: B:46:0x004c }] */
    /* JADX WARN: Code duplicated, block: B:33:0x005d A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:34:0x005f A[Catch: Exception -> 0x0062, TRY_LEAVE, TryCatch #8 {Exception -> 0x0062, blocks: (B:32:0x005a, B:34:0x005f), top: B:48:0x005a }] */
    /* JADX WARN: Code duplicated, block: B:48:0x005a A[EXC_TOP_SPLITTER, SYNTHETIC] */
    public boolean e(T t, String str) throws Throwable {
        FileOutputStream fileOutputStream;
        ObjectOutputStream objectOutputStream;
        r.d(str, "configFile");
        File file = new File(b(str));
        File parentFile = file.getParentFile();
        if (!parentFile.exists()) {
            parentFile.mkdirs();
        }
        if (t == null) {
            if (file.exists()) {
                file.delete();
            }
            return true;
        }
        ObjectOutputStream objectOutputStream2 = null;
        objectOutputStream2 = null;
        FileOutputStream fileOutputStream2 = null;
        try {
            fileOutputStream = new FileOutputStream(file);
            try {
                objectOutputStream = new ObjectOutputStream(fileOutputStream);
                try {
                    objectOutputStream.writeObject(t);
                    try {
                        objectOutputStream.close();
                        fileOutputStream.close();
                    } catch (Exception unused) {
                    }
                    return true;
                } catch (Exception unused2) {
                    fileOutputStream2 = fileOutputStream;
                    try {
                        Toast.makeText(this.f452b, "存储配置失败！", 0).show();
                        if (objectOutputStream != null) {
                            try {
                                objectOutputStream.close();
                                if (fileOutputStream2 != null) {
                                    fileOutputStream2.close();
                                }
                            } catch (Exception unused3) {
                                return false;
                            }
                        } else if (fileOutputStream2 != null) {
                            fileOutputStream2.close();
                        }
                        return false;
                    } catch (Throwable th) {
                        th = th;
                        fileOutputStream = fileOutputStream2;
                        objectOutputStream2 = objectOutputStream;
                        if (objectOutputStream2 != null) {
                            try {
                                objectOutputStream2.close();
                                if (fileOutputStream != null) {
                                    fileOutputStream.close();
                                }
                            } catch (Exception unused4) {
                                throw th;
                            }
                        } else if (fileOutputStream != null) {
                            fileOutputStream.close();
                        }
                        throw th;
                    }
                } catch (Throwable th2) {
                    th = th2;
                    objectOutputStream2 = objectOutputStream;
                    if (objectOutputStream2 != null) {
                        objectOutputStream2.close();
                        if (fileOutputStream != null) {
                            fileOutputStream.close();
                        }
                    } else if (fileOutputStream != null) {
                        fileOutputStream.close();
                    }
                    throw th;
                }
            } catch (Exception unused5) {
                objectOutputStream = null;
            } catch (Throwable th3) {
                th = th3;
                if (objectOutputStream2 != null) {
                    objectOutputStream2.close();
                    if (fileOutputStream != null) {
                        fileOutputStream.close();
                    }
                } else if (fileOutputStream != null) {
                    fileOutputStream.close();
                }
                throw th;
            }
        } catch (Exception unused6) {
            objectOutputStream = null;
        } catch (Throwable th4) {
            th = th4;
            fileOutputStream = null;
        }
    }
}
