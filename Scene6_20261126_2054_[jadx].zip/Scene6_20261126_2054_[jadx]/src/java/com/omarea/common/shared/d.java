package com.omarea.common.shared;

import android.content.Context;
import android.content.res.AssetManager;
import android.os.Environment;
import android.util.Log;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import kotlin.jvm.internal.r;
import kotlin.text.Regex;
import kotlin.text.k;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private static final String f449a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final d f450b = new d();

    static {
        File externalStorageDirectory = Environment.getExternalStorageDirectory();
        r.c(externalStorageDirectory, "Environment.getExternalStorageDirectory()");
        String absolutePath = externalStorageDirectory.getAbsolutePath();
        r.c(absolutePath, "Environment.getExternalS…eDirectory().absolutePath");
        f449a = absolutePath;
    }

    private d() {
    }

    private final byte[] d(Context context, String str) {
        try {
            InputStream inputStreamOpen = context.getAssets().open(str);
            byte[] bArr = new byte[inputStreamOpen.available()];
            int i = inputStreamOpen.read(bArr);
            if (i < 0) {
                i = 0;
            }
            String strReplace = new Regex("\r\t").replace(new Regex("\r\n").replace(new String(bArr, 0, i, kotlin.text.d.a), "\n"), "\t");
            Charset charset = kotlin.text.d.a;
            if (strReplace == null) {
                throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
            }
            byte[] bytes = strReplace.getBytes(charset);
            r.c(bytes, "(this as java.lang.String).getBytes(charset)");
            return bytes;
        } catch (Exception e) {
            Log.e("script-parse", "" + e.getMessage());
            byte[] bytes2 = "".getBytes(kotlin.text.d.a);
            r.c(bytes2, "(this as java.lang.String).getBytes(charset)");
            return bytes2;
        }
    }

    public final String a(Context context) {
        r.d(context, "context");
        StringBuilder sb = new StringBuilder();
        File filesDir = context.getFilesDir();
        r.c(filesDir, "context.filesDir");
        sb.append(filesDir.getAbsolutePath());
        sb.append("/");
        return sb.toString();
    }

    public final String b(Context context, String str) {
        r.d(context, "context");
        r.d(str, "outName");
        StringBuilder sb = new StringBuilder();
        sb.append(a(context));
        if (k.t(str, "/", false, 2, (Object) null)) {
            str = str.substring(1, str.length());
            r.c(str, "(this as java.lang.Strin…ing(startIndex, endIndex)");
        }
        sb.append(str);
        return sb.toString();
    }

    public final String c(Context context, String str, boolean z) {
        r.d(context, "context");
        r.d(str, "file");
        File externalFilesDir = context.getExternalFilesDir(null);
        r.c(externalFilesDir, "context.getExternalFilesDir(null)");
        File parentFile = externalFilesDir.getParentFile();
        if (parentFile == null) {
            parentFile = new File(f449a + "/Android/data/" + context.getPackageName());
        }
        if (!parentFile.exists()) {
            parentFile.mkdirs();
        }
        StringBuilder sb = new StringBuilder();
        sb.append(parentFile.getAbsolutePath());
        sb.append("/");
        if (!z) {
            str = str.substring(0, k.N(str, ".", 0, false, 6, (Object) null) > 0 ? k.N(str, ".", 0, false, 6, (Object) null) : str.length());
            r.c(str, "(this as java.lang.Strin…ing(startIndex, endIndex)");
        }
        sb.append(str);
        String string = sb.toString();
        File parentFile2 = new File(string).getParentFile();
        if (!parentFile2.exists()) {
            parentFile2.mkdirs();
        }
        return string;
    }

    public final String e(Context context, String str, boolean z) {
        InputStream inputStreamOpen;
        r.d(context, "context");
        r.d(str, "file");
        try {
            if (k.t(str, "file:///android_asset/", false, 2, (Object) null)) {
                AssetManager assets = context.getAssets();
                String strSubstring = str.substring(22);
                r.c(strSubstring, "(this as java.lang.String).substring(startIndex)");
                inputStreamOpen = assets.open(strSubstring);
            } else {
                inputStreamOpen = context.getAssets().open(str);
            }
            String strC = c(context, str, z);
            FileOutputStream fileOutputStream = new FileOutputStream(strC);
            byte[] bArr = new byte[20480];
            while (true) {
                int i = inputStreamOpen.read(bArr);
                if (i <= 0) {
                    fileOutputStream.close();
                    inputStreamOpen.close();
                    File file = new File(strC);
                    file.setWritable(true, false);
                    file.setExecutable(true, false);
                    file.setReadable(true, false);
                    return strC;
                }
                fileOutputStream.write(bArr, 0, i);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return null;
        } catch (IOException e2) {
            e2.printStackTrace();
            return null;
        }
    }

    public final String f(Context context, byte[] bArr, String str) {
        r.d(context, "context");
        r.d(bArr, "bytes");
        r.d(str, "outName");
        try {
            String strC = c(context, str, true);
            FileOutputStream fileOutputStream = new FileOutputStream(strC);
            fileOutputStream.write(bArr, 0, bArr.length);
            fileOutputStream.close();
            File file = new File(strC);
            file.setWritable(true, false);
            file.setExecutable(true, false);
            file.setReadable(true, false);
            return strC;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return null;
        } catch (IOException e2) {
            e2.printStackTrace();
            return null;
        }
    }

    public final String g(AssetManager assetManager, String str, String str2, Context context) {
        r.d(assetManager, "assetManager");
        r.d(str, "file");
        r.d(str2, "outName");
        r.d(context, "context");
        try {
            if (k.t(str, "file:///android_asset/", false, 2, (Object) null)) {
                str = str.substring(22);
                r.c(str, "(this as java.lang.String).substring(startIndex)");
            }
            InputStream inputStreamOpen = assetManager.open(str);
            File file = new File(a(context));
            if (!file.exists()) {
                file.mkdirs();
            }
            String strB = b(context, str2);
            File parentFile = new File(strB).getParentFile();
            if (!parentFile.exists()) {
                parentFile.mkdirs();
            }
            FileOutputStream fileOutputStream = new FileOutputStream(strB);
            byte[] bArr = new byte[20480];
            while (true) {
                int i = inputStreamOpen.read(bArr);
                if (i <= 0) {
                    fileOutputStream.close();
                    inputStreamOpen.close();
                    File file2 = new File(strB);
                    file2.setWritable(true, false);
                    file2.setExecutable(true, false);
                    file2.setReadable(true, false);
                    return strB;
                }
                fileOutputStream.write(bArr, 0, i);
            }
        } catch (IOException e) {
            Log.e("writePrivateFile", "" + e.getMessage(), e.getCause());
            e.printStackTrace();
            return null;
        }
    }

    public final boolean h(byte[] bArr, String str, Context context) {
        r.d(bArr, "bytes");
        r.d(str, "outName");
        r.d(context, "context");
        try {
            File file = new File(a(context));
            if (!file.exists()) {
                file.mkdirs();
            }
            String strB = b(context, str);
            File parentFile = new File(strB).getParentFile();
            if (!parentFile.exists()) {
                parentFile.mkdirs();
            }
            FileOutputStream fileOutputStream = new FileOutputStream(strB);
            fileOutputStream.write(bArr, 0, bArr.length);
            fileOutputStream.close();
            new File(strB).setExecutable(true, false);
            File file2 = new File(strB);
            file2.setWritable(true, false);
            file2.setExecutable(true, false);
            file2.setReadable(true, false);
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    public final String i(String str, String str2, Context context) {
        r.d(str, "file");
        r.d(str2, "outName");
        r.d(context, "context");
        byte[] bArrD = d(context, str);
        if (bArrD.length <= 0 || !h(bArrD, str2, context)) {
            return null;
        }
        return b(context, str2);
    }
}
