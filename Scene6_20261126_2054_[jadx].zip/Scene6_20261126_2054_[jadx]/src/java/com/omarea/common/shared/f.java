package com.omarea.common.shared;

import android.content.Context;
import java.io.InputStream;
import java.nio.charset.Charset;
import kotlin.jvm.internal.r;
import kotlin.text.Regex;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final f f453a = new f();

    private f() {
    }

    public final byte[] a(Context context, int i) {
        r.d(context, "context");
        InputStream inputStreamOpenRawResource = context.getResources().openRawResource(i);
        r.c(inputStreamOpenRawResource, "context.resources.openRawResource(id)");
        return kotlin.io.a.c(inputStreamOpenRawResource);
    }

    public final String b(Context context, int i) {
        r.d(context, "context");
        try {
            byte[] bArrA = a(context, i);
            Charset charsetDefaultCharset = Charset.defaultCharset();
            r.c(charsetDefaultCharset, "Charset.defaultCharset()");
            return new Regex("\r").replace(new Regex("\r\t").replace(new Regex("\r\n").replace(new String(bArrA, charsetDefaultCharset), "\n"), "\t"), "\n");
        } catch (Exception unused) {
            return "";
        }
    }
}
