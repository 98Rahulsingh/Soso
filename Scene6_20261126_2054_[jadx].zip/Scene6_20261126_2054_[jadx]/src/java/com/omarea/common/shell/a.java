package com.omarea.common.shell;

import android.os.Handler;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.Charset;
import kotlin.jvm.internal.r;
import kotlin.text.k;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private Process f461a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private Handler f462b;

    /* JADX INFO: renamed from: com.omarea.common.shell.a$a, reason: collision with other inner class name */
    static final class RunnableC0045a implements Runnable {
        RunnableC0045a() {
        }

        @Override // java.lang.Runnable
        public final void run() {
            try {
                Process processD = a.this.d();
                r.b(processD);
                InputStream inputStream = processD.getInputStream();
                r.c(inputStream, "process!!.inputStream");
                Reader inputStreamReader = new InputStreamReader(inputStream, kotlin.text.d.a);
                BufferedReader bufferedReader = inputStreamReader instanceof BufferedReader ? (BufferedReader) inputStreamReader : new BufferedReader(inputStreamReader, 8192);
                while (true) {
                    String line = bufferedReader.readLine();
                    r.c(line, "reader.readLine()");
                    if (line == null) {
                        a.this.a();
                        return;
                    } else {
                        String string = k.k0(line).toString();
                        if (string.length() > 0) {
                            a.this.c().sendMessage(a.this.c().obtainMessage(1, string));
                        }
                    }
                }
            } catch (Exception e) {
                System.out.print((Object) e.getMessage());
            }
        }
    }

    static final class b implements Runnable {
        b() {
        }

        @Override // java.lang.Runnable
        public final void run() {
            try {
                Process processD = a.this.d();
                r.b(processD);
                InputStream errorStream = processD.getErrorStream();
                r.c(errorStream, "process!!.errorStream");
                Reader inputStreamReader = new InputStreamReader(errorStream, kotlin.text.d.a);
                BufferedReader bufferedReader = inputStreamReader instanceof BufferedReader ? (BufferedReader) inputStreamReader : new BufferedReader(inputStreamReader, 8192);
                while (true) {
                    String line = bufferedReader.readLine();
                    r.c(line, "reader.readLine()");
                    if (line == null) {
                        throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
                    }
                    String string = k.k0(line).toString();
                    if (string.length() > 0) {
                        a.this.c().sendMessage(a.this.c().obtainMessage(5, string));
                    }
                }
            } catch (Exception e) {
                System.out.print((Object) e.getMessage());
            }
        }
    }

    static final class c implements Runnable {
        c() {
        }

        @Override // java.lang.Runnable
        public final void run() {
            Handler handlerC;
            Handler handlerC2;
            Boolean bool;
            Process processD = a.this.d();
            r.b(processD);
            if (processD.waitFor() == 0) {
                handlerC = a.this.c();
                handlerC2 = a.this.c();
                bool = Boolean.TRUE;
            } else {
                handlerC = a.this.c();
                handlerC2 = a.this.c();
                bool = Boolean.FALSE;
            }
            handlerC.sendMessage(handlerC2.obtainMessage(10, bool));
            a.this.a();
        }
    }

    public a(Handler handler) {
        r.d(handler, "handler");
        this.f462b = handler;
    }

    private final a e() {
        try {
            if (this.f461a == null) {
                this.f461a = i.e();
            }
            new Thread(new RunnableC0045a()).start();
            new Thread(new b()).start();
            this.f462b.sendMessage(this.f462b.obtainMessage(0, Boolean.TRUE));
        } catch (Exception unused) {
            Handler handler = this.f462b;
            handler.sendMessage(handler.obtainMessage(0, Boolean.FALSE));
        }
        return this;
    }

    public final void a() {
        try {
            if (this.f461a != null) {
                Process process = this.f461a;
                r.b(process);
                process.getOutputStream().close();
                Process process2 = this.f461a;
                r.b(process2);
                process2.destroy();
            }
        } catch (Exception unused) {
        }
    }

    public final a b(String str) throws IOException {
        r.d(str, "cmd");
        if (this.f461a == null) {
            e();
        }
        Process process = this.f461a;
        if (process == null) {
            Handler handler = this.f462b;
            handler.handleMessage(handler.obtainMessage(-1));
            return this;
        }
        r.b(process);
        OutputStream outputStream = process.getOutputStream();
        Charset charsetForName = Charset.forName("UTF-8");
        r.c(charsetForName, "Charset.forName(\"UTF-8\")");
        byte[] bytes = "\n\n".getBytes(charsetForName);
        r.c(bytes, "(this as java.lang.String).getBytes(charset)");
        outputStream.write(bytes);
        Charset charsetForName2 = Charset.forName("UTF-8");
        r.c(charsetForName2, "Charset.forName(\"UTF-8\")");
        byte[] bytes2 = str.getBytes(charsetForName2);
        r.c(bytes2, "(this as java.lang.String).getBytes(charset)");
        outputStream.write(bytes2);
        Charset charsetForName3 = Charset.forName("UTF-8");
        r.c(charsetForName3, "Charset.forName(\"UTF-8\")");
        byte[] bytes3 = "\n\n".getBytes(charsetForName3);
        r.c(bytes3, "(this as java.lang.String).getBytes(charset)");
        outputStream.write(bytes3);
        outputStream.flush();
        return this;
    }

    public final Handler c() {
        return this.f462b;
    }

    public final Process d() {
        return this.f461a;
    }

    public final void f() throws IOException {
        Process process = this.f461a;
        if (process == null) {
            return;
        }
        r.b(process);
        OutputStream outputStream = process.getOutputStream();
        r.c(outputStream, "outputStream");
        Writer outputStreamWriter = new OutputStreamWriter(outputStream, kotlin.text.d.a);
        BufferedWriter bufferedWriter = outputStreamWriter instanceof BufferedWriter ? (BufferedWriter) outputStreamWriter : new BufferedWriter(outputStreamWriter, 8192);
        bufferedWriter.write("exit\nexit\nexit\n");
        bufferedWriter.write("\n\n");
        bufferedWriter.flush();
        new Thread(new c()).start();
    }
}
