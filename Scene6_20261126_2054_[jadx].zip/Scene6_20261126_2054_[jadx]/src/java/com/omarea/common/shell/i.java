package com.omarea.common.shell;

import android.os.Build;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class i {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private static String f473a = "";

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private static String f474b = "";

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private static String f475c = "";

    private static String a() {
        String str = f473a;
        if (str == null || str.isEmpty()) {
            return null;
        }
        if (f474b.isEmpty()) {
            try {
                Process processExec = Runtime.getRuntime().exec("sh");
                OutputStream outputStream = processExec.getOutputStream();
                outputStream.write("echo $PATH".getBytes());
                outputStream.flush();
                outputStream.close();
                InputStream inputStream = processExec.getInputStream();
                byte[] bArr = new byte[16384];
                int i = inputStream.read(bArr);
                inputStream.close();
                processExec.destroy();
                String strTrim = new String(bArr, 0, i).trim();
                if (strTrim.length() <= 0) {
                    throw new RuntimeException("未能获取到$PATH参数");
                }
                f474b = strTrim;
            } catch (Exception unused) {
                f474b = "/sbin:/system/sbin:/system/bin:/system/xbin:/odm/bin:/vendor/bin:/vendor/xbin";
            }
        }
        return "PATH=" + f474b + ":" + f473a;
    }

    private static Process b(String str) throws IOException {
        String strA = a();
        Process processExec = Runtime.getRuntime().exec(str);
        if (strA != null) {
            OutputStream outputStream = processExec.getOutputStream();
            outputStream.write("export ".getBytes());
            outputStream.write(strA.getBytes());
            outputStream.write("\n".getBytes());
            outputStream.flush();
        }
        return processExec;
    }

    public static Process c() {
        return b("sh");
    }

    public static String d() {
        if (f475c.isEmpty()) {
            f475c = (Build.VERSION.SDK_INT < 30 || !f()) ? "su" : "magisk su -mm";
        }
        return f475c;
    }

    public static Process e() {
        return b(d());
    }

    private static boolean f() {
        try {
            Process processExec = Runtime.getRuntime().exec("magisk -v");
            OutputStream outputStream = processExec.getOutputStream();
            outputStream.write("exit 0\nexit 0".getBytes());
            outputStream.flush();
            outputStream.close();
            InputStream inputStream = processExec.getInputStream();
            byte[] bArr = new byte[16384];
            int i = inputStream.read(bArr);
            inputStream.close();
            processExec.destroy();
            return new String(bArr, 0, i).trim().contains("MAGISK");
        } catch (Exception unused) {
            return false;
        }
    }

    public static void g(String str) {
        try {
            File file = new File(str);
            if (!file.exists()) {
                file.mkdirs();
            }
        } catch (Exception unused) {
        }
        f473a = str;
    }

    public static void h(String str) {
        f475c = str;
    }
}
