package com.omarea.common.shell;

import com.omarea.common.net.Daemon;
import java.io.File;
import java.util.ArrayList;
import kotlin.jvm.internal.r;
import org.json.JSONException;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class g {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final g f472a = new g();

    private g() {
    }

    public final void a(String str) {
        r.d(str, "path");
        if (str.length() > 0) {
            e.f469b.c("rm -rf \"" + str + '\"');
        }
    }

    public final boolean b(String str) {
        r.d(str, "path");
        File file = new File(str);
        if (file.exists() && file.isDirectory()) {
            return true;
        }
        return e.f469b.f().c0(str);
    }

    public final boolean c(String str, String str2) {
        r.d(str, "path1");
        r.d(str2, "path2");
        if (str.equals(str2)) {
            return true;
        }
        return e.f469b.c("if [[ -f \"" + str + "\" ]] && [[ -f \"" + str2 + "\" ]]; then\nif [[ `md5sum -b \"" + str + "\"` = `md5sum -b \"" + str2 + "\"` ]]; then\n echo 1\nfi\nfi").equals("1");
    }

    public final boolean d(String str) {
        r.d(str, "path");
        File file = new File(str);
        if (file.exists() && file.isFile()) {
            return true;
        }
        return Daemon.m0(e.f469b.f(), str, false, 2, null);
    }

    public final boolean e(String str) {
        r.d(str, "path");
        return e.f469b.f().l0(str, true);
    }

    public final long f(String str) {
        r.d(str, "path");
        return e.f469b.f().n0(str);
    }

    public final boolean g(String str) {
        r.d(str, "path");
        return e.f469b.f().E0(str);
    }

    public final ArrayList<com.omarea.common.net.e> h(String str) throws JSONException {
        ArrayList<com.omarea.common.net.e> arrayListA;
        r.d(str, "path");
        com.omarea.common.net.f fVarF0 = Daemon.E.a().F0(str);
        return (fVarF0 == null || (arrayListA = fVarF0.a()) == null) ? new ArrayList<>() : arrayListA;
    }

    public final String i(String str) {
        r.d(str, "path");
        return f.f471b.a(str);
    }

    public final boolean j(String str, String str2) {
        r.d(str, "path");
        r.d(str2, "text");
        return Daemon.E.a().e1(str, str2);
    }
}
