package com.omarea.common.shell;

import com.omarea.common.net.Daemon;
import java.util.Iterator;
import java.util.List;
import kotlin.jvm.internal.r;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class e {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final e f469b = new e();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private static final b f468a = new b();

    private e() {
    }

    public final boolean a() {
        return f468a.a();
    }

    public final void b(String str) {
        r.d(str, "cmd");
        f468a.b(str);
    }

    public final String c(String str) {
        r.d(str, "cmd");
        return f468a.c(str);
    }

    public final boolean d(List<String> list) {
        r.d(list, "commands");
        StringBuilder sb = new StringBuilder();
        Iterator<String> it = list.iterator();
        while (it.hasNext()) {
            sb.append(it.next());
            sb.append("\n\n");
        }
        String string = sb.toString();
        r.c(string, "stringBuilder.toString()");
        return !r.a(c(string), "error");
    }

    public final String e(String str) {
        r.d(str, "cmd");
        return f468a.d(str);
    }

    public final Daemon f() {
        return f468a.e();
    }

    public final b g() {
        return f468a;
    }
}
