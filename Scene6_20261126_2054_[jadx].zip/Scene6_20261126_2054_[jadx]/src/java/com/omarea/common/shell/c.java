package com.omarea.common.shell;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import java.io.BufferedWriter;
import java.util.HashMap;
import java.util.concurrent.locks.ReentrantLock;
import kotlin.jvm.internal.o;
import kotlin.jvm.internal.r;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class c extends h {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private Process f464a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private BufferedWriter f465b;

    static {
        new HashMap();
    }

    public c(Context context, boolean z) {
        new Handler(Looper.getMainLooper());
        new ReentrantLock();
    }

    public /* synthetic */ c(Context context, boolean z, int i, o oVar) {
        this(context, (i & 2) != 0 ? true : z);
    }

    public final void a() {
        try {
            if (this.f465b != null) {
                BufferedWriter bufferedWriter = this.f465b;
                r.b(bufferedWriter);
                bufferedWriter.close();
            }
            this.f465b = null;
        } catch (Exception unused) {
        }
        this.f465b = null;
        try {
            Process process = this.f464a;
            r.b(process);
            process.destroy();
        } catch (Exception unused2) {
        }
        this.f464a = null;
    }
}
