package com.omarea.common.shell;

import com.omarea.common.net.Daemon;
import kotlin.jvm.internal.r;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final Daemon f463a = Daemon.E.a();

    public final boolean a() {
        return this.f463a.X();
    }

    public final void b(String str) {
        r.d(str, "cmd");
        this.f463a.f0(str);
    }

    public final String c(String str) {
        r.d(str, "cmd");
        return this.f463a.g0(str);
    }

    public final String d(String str) {
        r.d(str, "cmd");
        return this.f463a.i0(str);
    }

    public final Daemon e() {
        return this.f463a;
    }
}
