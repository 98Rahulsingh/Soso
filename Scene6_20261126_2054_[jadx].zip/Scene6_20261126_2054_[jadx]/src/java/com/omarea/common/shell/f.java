package com.omarea.common.shell;

import com.omarea.common.net.Daemon;
import java.io.File;
import java.nio.charset.Charset;
import java.util.ArrayList;
import kotlin.jvm.internal.r;
import kotlin.text.k;
import org.json.JSONArray;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class f {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final f f471b = new f();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private static final ArrayList<String> f470a = new ArrayList<>();

    private f() {
    }

    public final String a(String str) {
        r.d(str, "propName");
        if (!f470a.contains(str)) {
            File file = new File(str);
            if (file.exists() && file.canRead()) {
                try {
                    Charset charsetDefaultCharset = Charset.defaultCharset();
                    r.c(charsetDefaultCharset, "Charset.defaultCharset()");
                    String strB = kotlin.io.e.b(file, charsetDefaultCharset);
                    if (strB != null) {
                        return k.k0(strB).toString();
                    }
                    throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
                } catch (Exception unused) {
                }
            }
            f470a.add(str);
        }
        String strU0 = Daemon.E.a().u0(str);
        return strU0.equals("error") ? "" : strU0;
    }

    public final boolean b(String str, String str2) {
        r.d(str, "propName");
        r.d(str2, "value");
        return !r.a(Daemon.E.a().O0(str, str2), "error");
    }

    public final void c(JSONArray jSONArray) {
        r.d(jSONArray, "jsonArray");
        Daemon daemonA = Daemon.E.a();
        String string = jSONArray.toString();
        r.c(string, "jsonArray.toString()");
        daemonA.P0(string);
    }
}
