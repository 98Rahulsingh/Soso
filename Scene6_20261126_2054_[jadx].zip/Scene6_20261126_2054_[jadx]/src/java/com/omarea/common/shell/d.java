package com.omarea.common.shell;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final byte[] f466a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final byte[] f467b;
}
