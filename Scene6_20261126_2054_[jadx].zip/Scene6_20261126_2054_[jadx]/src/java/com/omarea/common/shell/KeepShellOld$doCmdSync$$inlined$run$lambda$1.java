package com.omarea.common.shell;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.Charset;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.b.p;
import kotlin.jvm.internal.r;
import kotlin.s;
import kotlinx.coroutines.h0;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
final class KeepShellOld$doCmdSync$$inlined$run$lambda$1 extends SuspendLambda implements p<h0, kotlin.coroutines.c<? super s>, Object> {
    final /* synthetic */ String $cmd$inlined;
    final /* synthetic */ OutputStream $this_run;
    int label;
    private h0 p$;
    final /* synthetic */ d this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    KeepShellOld$doCmdSync$$inlined$run$lambda$1(OutputStream outputStream, kotlin.coroutines.c cVar, d dVar, String str) {
        super(2, cVar);
        this.$this_run = outputStream;
        this.this$0 = dVar;
        this.$cmd$inlined = str;
    }

    public final kotlin.coroutines.c<s> create(Object obj, kotlin.coroutines.c<?> cVar) {
        r.d(cVar, "completion");
        KeepShellOld$doCmdSync$$inlined$run$lambda$1 keepShellOld$doCmdSync$$inlined$run$lambda$1 = new KeepShellOld$doCmdSync$$inlined$run$lambda$1(this.$this_run, cVar, this.this$0, this.$cmd$inlined);
        keepShellOld$doCmdSync$$inlined$run$lambda$1.p$ = (h0) obj;
        return keepShellOld$doCmdSync$$inlined$run$lambda$1;
    }

    public final Object invoke(Object obj, Object obj2) {
        return create(obj, (kotlin.coroutines.c) obj2).invokeSuspend(s.a);
    }

    public final Object invokeSuspend(Object obj) throws IOException {
        kotlin.coroutines.intrinsics.a.d();
        if (this.label != 0) {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        kotlin.h.b(obj);
        this.$this_run.write(this.this$0.f466a);
        OutputStream outputStream = this.$this_run;
        String str = this.$cmd$inlined;
        Charset charsetDefaultCharset = Charset.defaultCharset();
        r.c(charsetDefaultCharset, "Charset.defaultCharset()");
        if (str == null) {
            throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
        }
        byte[] bytes = str.getBytes(charsetDefaultCharset);
        r.c(bytes, "(this as java.lang.String).getBytes(charset)");
        outputStream.write(bytes);
        this.$this_run.write(this.this$0.f467b);
        this.$this_run.flush();
        return s.a;
    }
}
