package com.omarea.common.shell;

import java.util.concurrent.FutureTask;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.b.p;
import kotlin.jvm.internal.r;
import kotlin.s;
import kotlinx.coroutines.h0;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
@kotlin.coroutines.jvm.internal.d(c = "com.omarea.common.shell.AsynSuShellUtil2$start$1", f = "AsynSuShellUtil2.kt", l = {}, m = "invokeSuspend")
final class AsynSuShellUtil2$start$1 extends SuspendLambda implements p<h0, kotlin.coroutines.c<? super s>, Object> {
    final /* synthetic */ FutureTask $task;
    int label;
    private h0 p$;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    AsynSuShellUtil2$start$1(FutureTask futureTask, kotlin.coroutines.c cVar) {
        super(2, cVar);
        this.$task = futureTask;
    }

    public final kotlin.coroutines.c<s> create(Object obj, kotlin.coroutines.c<?> cVar) {
        r.d(cVar, "completion");
        AsynSuShellUtil2$start$1 asynSuShellUtil2$start$1 = new AsynSuShellUtil2$start$1(this.$task, cVar);
        asynSuShellUtil2$start$1.p$ = (h0) obj;
        return asynSuShellUtil2$start$1;
    }

    public final Object invoke(Object obj, Object obj2) {
        return create(obj, (kotlin.coroutines.c) obj2).invokeSuspend(s.a);
    }

    public final Object invokeSuspend(Object obj) {
        kotlin.coroutines.intrinsics.a.d();
        if (this.label != 0) {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        kotlin.h.b(obj);
        this.$task.run();
        return s.a;
    }
}
