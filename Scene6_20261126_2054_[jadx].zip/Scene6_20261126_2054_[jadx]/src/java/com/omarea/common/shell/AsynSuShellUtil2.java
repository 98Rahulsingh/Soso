package com.omarea.common.shell;

import com.omarea.common.net.Daemon;
import java.util.concurrent.Callable;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;
import kotlin.coroutines.CoroutineContext;
import kotlin.jvm.internal.r;
import kotlinx.coroutines.CoroutineStart;
import kotlinx.coroutines.i0;
import kotlinx.coroutines.w0;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class AsynSuShellUtil2 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private com.omarea.common.net.b f457a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final String f458b;

    static final class a<V> implements Callable<Boolean> {

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final /* synthetic */ String f460b;

        a(String str) {
            this.f460b = str;
        }

        @Override // java.util.concurrent.Callable
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public final Boolean call() {
            return Boolean.valueOf(Daemon.E.a().o0(this.f460b, AsynSuShellUtil2.this.b()));
        }
    }

    public AsynSuShellUtil2(com.omarea.common.net.b bVar, String str) {
        r.d(bVar, "handlerDaemon");
        r.d(str, "cmd");
        this.f457a = bVar;
        this.f458b = str;
    }

    private final AsynSuShellUtil2 c(String str) {
        Boolean bool;
        FutureTask futureTask = new FutureTask(new a(str));
        kotlinx.coroutines.f.d(i0.a(w0.b()), (CoroutineContext) null, (CoroutineStart) null, new AsynSuShellUtil2$start$1(futureTask, null), 3, (Object) null);
        try {
            bool = (Boolean) futureTask.get(100L, TimeUnit.MILLISECONDS);
        } catch (Exception unused) {
            bool = Boolean.FALSE;
        }
        r.c(bool, "connected");
        if (bool.booleanValue()) {
            return this;
        }
        return null;
    }

    public final AsynSuShellUtil2 a() {
        c(this.f458b);
        return this;
    }

    public final com.omarea.common.net.b b() {
        return this.f457a;
    }

    public final void d() {
    }
}
