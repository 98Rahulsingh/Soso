package com.omarea.common.net;

import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.nio.charset.Charset;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.h;
import kotlin.jvm.b.p;
import kotlin.jvm.internal.r;
import kotlin.s;
import kotlinx.coroutines.h0;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
@kotlin.coroutines.jvm.internal.d(c = "com.omarea.common.net.Daemon$socketSendRequest$3", f = "Daemon.kt", l = {}, m = "invokeSuspend")
final class Daemon$socketSendRequest$3 extends SuspendLambda implements p<h0, kotlin.coroutines.c<? super s>, Object> {
    final /* synthetic */ byte[] $content;
    final /* synthetic */ SocketChannel $socketChannel;
    int label;
    private h0 p$;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    Daemon$socketSendRequest$3(SocketChannel socketChannel, byte[] bArr, kotlin.coroutines.c cVar) {
        super(2, cVar);
        this.$socketChannel = socketChannel;
        this.$content = bArr;
    }

    public final kotlin.coroutines.c<s> create(Object obj, kotlin.coroutines.c<?> cVar) {
        r.d(cVar, "completion");
        Daemon$socketSendRequest$3 daemon$socketSendRequest$3 = new Daemon$socketSendRequest$3(this.$socketChannel, this.$content, cVar);
        daemon$socketSendRequest$3.p$ = (h0) obj;
        return daemon$socketSendRequest$3;
    }

    public final Object invoke(Object obj, Object obj2) {
        return create(obj, (kotlin.coroutines.c) obj2).invokeSuspend(s.a);
    }

    public final Object invokeSuspend(Object obj) {
        kotlin.coroutines.intrinsics.a.d();
        if (this.label != 0) {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        h.b(obj);
        try {
            SocketChannel socketChannel = this.$socketChannel;
            String str = new String(this.$content, kotlin.text.d.a) + ";";
            Charset charset = kotlin.text.d.a;
            if (str == null) {
                throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
            }
            byte[] bytes = str.getBytes(charset);
            r.c(bytes, "(this as java.lang.String).getBytes(charset)");
            socketChannel.write(ByteBuffer.wrap(bytes));
            return s.a;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
