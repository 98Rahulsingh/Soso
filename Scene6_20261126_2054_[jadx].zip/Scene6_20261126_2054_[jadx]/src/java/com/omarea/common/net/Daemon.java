package com.omarea.common.net;

import android.os.Build;
import android.util.Base64;
import android.util.Log;
import com.omarea.common.shell.i;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.channels.NotYetConnectedException;
import java.nio.channels.SocketChannel;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;
import kotlin.Result;
import kotlin.collections.q;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.h;
import kotlin.jvm.b.l;
import kotlin.jvm.b.p;
import kotlin.jvm.internal.Ref;
import kotlin.jvm.internal.o;
import kotlin.jvm.internal.r;
import kotlin.s;
import kotlin.text.Regex;
import kotlin.text.k;
import kotlinx.coroutines.CoroutineStart;
import kotlinx.coroutines.h0;
import kotlinx.coroutines.h1;
import kotlinx.coroutines.i0;
import kotlinx.coroutines.w0;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class Daemon extends g implements com.omarea.common.net.b {
    private static com.omarea.common.net.d C = null;
    private static String D = null;
    private static final int t = 8;
    private static Daemon u;
    private final int e;
    private final int f;
    private final String g;
    private boolean h;
    private final com.omarea.common.net.a i;
    private int j;
    private final ConcurrentHashMap<String, l<String, s>> k;
    private int l;
    private boolean m;
    private boolean n;
    private long o;
    private final ArrayList<SocketChannel> p;
    private String q;
    private boolean r;
    private boolean s;
    public static final a E = new a(null);
    private static Status v = Status.STATUS_STOP;
    private static String w = "";
    private static String x = "8765";
    private static String y = "2.1.8";
    private static int z = 8766;
    private static String A = "";
    private static String B = "omarea.com";

    public enum Status {
        STATUS_STOP,
        STATUS_STARTING,
        STATUS_RUNNING,
        STATUS_ERROR
    }

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(o oVar) {
            this();
        }

        public final Daemon a() {
            if (Daemon.u == null) {
                Daemon.u = new Daemon(null);
            }
            Daemon daemon = Daemon.u;
            r.b(daemon);
            return daemon;
        }

        public final boolean b() {
            return Daemon.E.a().v0() != null || Daemon.v == Status.STATUS_RUNNING;
        }

        public final String c() {
            String str = Daemon.D;
            int iHashCode = str.hashCode();
            if (iHashCode != 96415) {
                if (iHashCode == 3506402 && str.equals("root") && !b()) {
                    return "basic";
                }
            } else if (str.equals("adb") && !b()) {
                return "basic";
            }
            return Daemon.D;
        }

        public final void d(String str, String str2) {
            r.d(str, "path");
            r.d(str2, "port");
            Daemon.w = str;
            if (str2.length() > 0) {
                Daemon.x = str2;
            }
        }

        public final String e(String str) {
            r.d(str, "key");
            Daemon.A = str;
            return Daemon.v == Status.STATUS_RUNNING ? a().W(str) : "";
        }

        public final void f(String str) {
            r.d(str, "token");
            Daemon.B = str;
            String str2 = Daemon.B;
            Charset charset = kotlin.text.d.a;
            if (str2 == null) {
                throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
            }
            byte[] bytes = str2.getBytes(charset);
            r.c(bytes, "(this as java.lang.String).getBytes(charset)");
            Daemon.N(bytes);
        }

        public final void g(com.omarea.common.net.d dVar) {
            r.d(dVar, "signalHandler");
            Daemon.C = dVar;
        }

        public final boolean h(String str) {
            r.d(str, "mode");
            int iHashCode = str.hashCode();
            if (iHashCode == 96415 ? !str.equals("adb") : iHashCode == 3506402 ? !str.equals("root") : !(iHashCode == 93508654 && str.equals("basic"))) {
                Daemon.D = "basic";
                return false;
            }
            if (a().a1(str)) {
                Daemon.D = str;
                return true;
            }
            Log.e("Scene", "setWorkingMode(" + str + ") Fail!");
            return false;
        }
    }

    public static final class b {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private int f420a = Daemon.t;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private int f421b = 1;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private ByteBuffer f422c = ByteBuffer.allocate(Daemon.t);

        public final ByteBuffer a() {
            return this.f422c;
        }

        public final int b() {
            return this.f420a;
        }

        public final int c() {
            return this.f421b;
        }

        public final void d(ByteBuffer byteBuffer) {
            this.f422c = byteBuffer;
        }

        public final void e(int i) {
            this.f420a = i;
        }

        public final void f(int i) {
            this.f421b = i;
        }
    }

    static final class c<V> implements Callable<String> {

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final /* synthetic */ String f424b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        final /* synthetic */ String f425c;

        c(String str, String str2) {
            this.f424b = str;
            this.f425c = str2;
        }

        @Override // java.util.concurrent.Callable
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public final String call() {
            return Daemon.this.B0(this.f424b, this.f425c);
        }
    }

    public static final class d extends Thread {
        final /* synthetic */ SocketChannel g;
        final /* synthetic */ com.omarea.common.net.b h;

        d(SocketChannel socketChannel, com.omarea.common.net.b bVar) {
            this.g = socketChannel;
            this.h = bVar;
        }

        @Override // java.lang.Thread, java.lang.Runnable
        public void run() {
            int i;
            ByteBuffer byteBufferAllocate;
            setName("ResponseHandler");
            ByteBuffer byteBufferAllocate2 = ByteBuffer.allocate(4096);
            try {
                b bVar = new b();
                ArrayList arrayList = new ArrayList();
                while (true) {
                    byteBufferAllocate2.clear();
                    try {
                        i = this.g.read(byteBufferAllocate2);
                    } catch (NotYetConnectedException unused) {
                        i = -1;
                    }
                    if (i == -1) {
                        break;
                    }
                    byteBufferAllocate2.flip();
                    while (true) {
                        int iB = bVar.b();
                        if (iB == 0) {
                            iB = Daemon.t;
                        }
                        if (i >= iB) {
                            byte[] bArr = new byte[iB];
                            byteBufferAllocate2.get(bArr, 0, iB);
                            i -= iB;
                            ByteBuffer byteBufferA = bVar.a();
                            byteBufferA.put(bArr);
                            byteBufferA.flip();
                            byte[] bArrArray = bVar.a().array();
                            r.c(bArrArray, "slice.buffer.array()");
                            String str = new String(bArrArray, kotlin.text.d.a);
                            if (bVar.c() == 1) {
                                bVar.f(2);
                                bVar.e(Integer.parseInt(k.k0(str).toString()));
                                byteBufferAllocate = ByteBuffer.allocate(bVar.b());
                            } else {
                                arrayList.add(str);
                                bVar.e(Daemon.t);
                                bVar.f(1);
                                byteBufferAllocate = ByteBuffer.allocate(Daemon.t);
                            }
                            bVar.d(byteBufferAllocate);
                        } else if (i > 0) {
                            byte[] bArr2 = new byte[i];
                            byteBufferAllocate2.get(bArr2, 0, i);
                            bVar.e(bVar.b() - i);
                            bVar.a().put(bArr2);
                            i = 0;
                        }
                    }
                    Daemon daemon = Daemon.this;
                    com.omarea.common.net.b bVar2 = this.h;
                    ArrayList arrayList2 = new ArrayList();
                    arrayList2.addAll(arrayList);
                    s sVar = s.a;
                    daemon.V0(bVar2, arrayList2);
                    arrayList.clear();
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                this.h.d(this.g);
            }
        }
    }

    static final class e<V> implements Callable<Boolean> {
        e() {
        }

        @Override // java.util.concurrent.Callable
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public final Boolean call() {
            boolean zO0;
            try {
                zO0 = Daemon.this.o0("@version:" + Daemon.y, Daemon.this);
            } catch (Exception unused) {
                zO0 = false;
            }
            return Boolean.valueOf(zO0);
        }
    }

    static {
        Charset charset = kotlin.text.d.a;
        if ("omarea.com" == 0) {
            throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
        }
        r.c("omarea.com".getBytes(charset), "(this as java.lang.String).getBytes(charset)");
        D = "basic";
    }

    private Daemon() {
        super(Proxy.NO_PROXY);
        this.e = 1000;
        this.f = 3600000;
        this.g = "exec-shell";
        this.i = new com.omarea.common.net.a();
        this.k = new ConcurrentHashMap<>();
        this.p = new ArrayList<>();
        this.q = "";
    }

    public /* synthetic */ Daemon(o oVar) {
        this();
    }

    public static /* synthetic */ String A0(Daemon daemon, String str, String str2, int i, int i2, Object obj) {
        if ((i2 & 4) != 0) {
            i = daemon.j();
        }
        return daemon.z0(str, str2, i);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final String B0(String str, String str2) throws Throwable {
        try {
            HttpURLConnection httpURLConnectionY = Y(str, str2);
            f1();
            r.b(httpURLConnectionY);
            String strP = p(httpURLConnectionY);
            if (strP != null) {
                return k.k0(strP).toString();
            }
            throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
        } catch (EOFException unused) {
            return "error";
        } catch (Exception e2) {
            if ((e2.getCause() instanceof EOFException) || v != Status.STATUS_RUNNING) {
                return "error";
            }
            if (System.currentTimeMillis() - this.o > 5000) {
                this.o = System.currentTimeMillis();
            }
            Log.e("Scene", "执行出现错误 " + str + ' ' + str2 + " >> " + e2.getMessage());
            e2.printStackTrace();
            return "error";
        }
    }

    private final String C0(String str) {
        return T0("path-basic-info", str, 1000);
    }

    public static /* synthetic */ String I0(Daemon daemon, String str, int i, Object obj) {
        if ((i & 1) != 0) {
            str = "custom-cache";
        }
        return daemon.H0(str);
    }

    public static final /* synthetic */ void N(byte[] bArr) {
    }

    private final String T0(final String str, final String str2, Integer num) {
        if (this.h && !this.r) {
            if ((num != null ? num.intValue() : 0) != 0 && this.l < 4) {
                final SocketChannel socketChannelV0 = v0();
                if (socketChannelV0 != null && socketChannelV0.isConnected()) {
                    String string = UUID.randomUUID().toString();
                    r.c(string, "UUID.randomUUID().toString()");
                    if (string == null) {
                        throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                    }
                    final String strSubstring = string.substring(0, 8);
                    r.c(strSubstring, "(this as java.lang.Strin…ing(startIndex, endIndex)");
                    final Ref.ObjectRef objectRef = new Ref.ObjectRef();
                    objectRef.element = "";
                    FutureTask futureTask = new FutureTask(new Callable<String>() { // from class: com.omarea.common.net.Daemon$socketApiRequest$callable$1

                        /* JADX INFO: renamed from: com.omarea.common.net.Daemon$socketApiRequest$callable$1$1, reason: invalid class name */
                        @kotlin.coroutines.jvm.internal.d(c = "com.omarea.common.net.Daemon$socketApiRequest$callable$1$1", f = "Daemon.kt", l = {273}, m = "invokeSuspend")
                        static final class AnonymousClass1 extends SuspendLambda implements p<h0, kotlin.coroutines.c<? super String>, Object> {
                            Object L$0;
                            Object L$1;
                            int label;
                            private h0 p$;

                            AnonymousClass1(kotlin.coroutines.c cVar) {
                                super(2, cVar);
                            }

                            public final kotlin.coroutines.c<s> create(Object obj, kotlin.coroutines.c<?> cVar) {
                                r.d(cVar, "completion");
                                AnonymousClass1 anonymousClass1 = new AnonymousClass1(cVar);
                                anonymousClass1.p$ = (h0) obj;
                                return anonymousClass1;
                            }

                            public final Object invoke(Object obj, Object obj2) {
                                return create(obj, (kotlin.coroutines.c) obj2).invokeSuspend(s.a);
                            }

                            public final Object invokeSuspend(Object obj) throws JSONException {
                                Ref.ObjectRef objectRef;
                                Object objD = kotlin.coroutines.intrinsics.a.d();
                                int i = this.label;
                                if (i == 0) {
                                    h.b(obj);
                                    h0 h0Var = this.p$;
                                    Daemon$socketApiRequest$callable$1 daemon$socketApiRequest$callable$1 = Daemon$socketApiRequest$callable$1.this;
                                    Ref.ObjectRef objectRef2 = objectRef;
                                    Daemon daemon = daemon$socketApiRequest$callable$1.f429a;
                                    SocketChannel socketChannel = socketChannelV0;
                                    String str = strSubstring;
                                    String str2 = str;
                                    String str3 = str2;
                                    this.L$0 = h0Var;
                                    this.L$1 = objectRef2;
                                    this.label = 1;
                                    obj = daemon.W0(socketChannel, str, str2, str3, this);
                                    if (obj == objD) {
                                        return objD;
                                    }
                                    objectRef = objectRef2;
                                } else {
                                    if (i != 1) {
                                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                    }
                                    objectRef = (Ref.ObjectRef) this.L$1;
                                    h.b(obj);
                                }
                                objectRef.element = (String) obj;
                                return (String) objectRef.element;
                            }
                        }

                        @Override // java.util.concurrent.Callable
                        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
                        public final String call() {
                            return (String) kotlinx.coroutines.f.f((CoroutineContext) null, new AnonymousClass1(null), 1, (Object) null);
                        }
                    });
                    kotlinx.coroutines.f.d(h1.f, w0.b(), (CoroutineStart) null, new Daemon$socketApiRequest$1(futureTask, null), 2, (Object) null);
                    try {
                        Object obj = futureTask.get(1000L, TimeUnit.MILLISECONDS);
                        r.c(obj, "task.get(1000, TimeUnit.MILLISECONDS)");
                        return (String) obj;
                    } catch (Exception unused) {
                        return "error";
                    }
                }
                if (socketChannelV0 != null && !socketChannelV0.isConnected()) {
                    d(socketChannelV0);
                }
                f1();
            }
        }
        return (num == null || num.intValue() <= 0) ? A0(this, str, str2, 0, 4, null) : z0(str, str2, num.intValue());
    }

    static /* synthetic */ String U0(Daemon daemon, String str, String str2, Integer num, int i, Object obj) {
        if ((i & 4) != 0) {
            num = null;
        }
        return daemon.T0(str, str2, num);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void V0(com.omarea.common.net.b bVar, ArrayList<String> arrayList) {
        if (arrayList.size() < 1) {
            return;
        }
        kotlinx.coroutines.f.d(h1.f, w0.a(), (CoroutineStart) null, new Daemon$socketReplyDecode$1(arrayList, bVar, null), 2, (Object) null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void X0(SocketChannel socketChannel, byte[] bArr) {
        kotlinx.coroutines.f.d(h1.f, w0.b(), (CoroutineStart) null, new Daemon$socketSendRequest$3(socketChannel, bArr, null), 2, (Object) null);
    }

    private final HttpURLConnection Y(String str, String str2) throws Throwable {
        if (v == Status.STATUS_STOP || v == Status.STATUS_STARTING) {
            if (v == Status.STATUS_STOP && r.a(D, "root")) {
                Z0();
            } else {
                if (!r.a(D, "adb")) {
                    return null;
                }
                j1(50L);
            }
        }
        return super.h(t0(str), e0(str2));
    }

    private final void Y0(SocketChannel socketChannel, com.omarea.common.net.b bVar) {
        new d(socketChannel, bVar).start();
    }

    private final void Z() {
        if (this.s) {
            return;
        }
        try {
            ServerSocket serverSocket = new ServerSocket(8767);
            this.s = true;
            kotlinx.coroutines.f.d(i0.a(w0.b()), (CoroutineContext) null, (CoroutineStart) null, new Daemon$daemonWatch$1(this, serverSocket, null), 3, (Object) null);
        } catch (Exception unused) {
        } finally {
            this.s = false;
        }
    }

    /* JADX WARN: Code duplicated, block: B:51:0x017a  */
    /* JADX WARN: Code duplicated, block: B:52:0x0184 A[Catch: all -> 0x019e, Exception -> 0x01a1, TRY_ENTER, TryCatch #3 {all -> 0x019e, blocks: (B:16:0x005a, B:18:0x0080, B:20:0x0098, B:22:0x00a3, B:24:0x00a7, B:26:0x00ad, B:28:0x00bd, B:30:0x00ce, B:32:0x00d9, B:33:0x00f0, B:35:0x00f6, B:37:0x0104, B:39:0x0111, B:46:0x0147, B:48:0x014d, B:49:0x0174, B:52:0x0184, B:54:0x018a, B:29:0x00c0, B:42:0x0128, B:21:0x00a0, B:56:0x0196, B:57:0x019d), top: B:79:0x005a }] */
    /* JADX WARN: Code duplicated, block: B:54:0x018a A[Catch: all -> 0x019e, Exception -> 0x01a1, TRY_LEAVE, TryCatch #3 {all -> 0x019e, blocks: (B:16:0x005a, B:18:0x0080, B:20:0x0098, B:22:0x00a3, B:24:0x00a7, B:26:0x00ad, B:28:0x00bd, B:30:0x00ce, B:32:0x00d9, B:33:0x00f0, B:35:0x00f6, B:37:0x0104, B:39:0x0111, B:46:0x0147, B:48:0x014d, B:49:0x0174, B:52:0x0184, B:54:0x018a, B:29:0x00c0, B:42:0x0128, B:21:0x00a0, B:56:0x0196, B:57:0x019d), top: B:79:0x005a }] */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v47 */
    /* JADX WARN: Type inference failed for: r0v48 */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.StringBuilder] */
    /* JADX WARN: Type inference failed for: r11v0 */
    /* JADX WARN: Type inference failed for: r11v1 */
    /* JADX WARN: Type inference failed for: r11v12 */
    /* JADX WARN: Type inference failed for: r11v13 */
    /* JADX WARN: Type inference failed for: r11v3, types: [java.lang.Process] */
    /* JADX WARN: Type inference failed for: r11v4 */
    /* JADX WARN: Type inference failed for: r11v6 */
    /* JADX WARN: Type inference failed for: r2v0, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r2v1 */
    /* JADX WARN: Type inference failed for: r2v2, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r2v5, types: [com.omarea.common.net.Daemon$Status, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r7v1, types: [java.lang.StringBuilder] */
    private final boolean Z0() throws Throwable {
        ?? sb;
        int i;
        StringBuilder sb2;
        ?? r2 = "";
        long jCurrentTimeMillis = System.currentTimeMillis();
        if (w.length() == 0) {
            Log.e("Scene", "启动流程错误，在启动Daemon进程前未设置Daemon程序文件路径");
            return false;
        }
        v = Status.STATUS_STARTING;
        ?? r11 = 0;
        str = null;
        String str = null;
        Process process = null;
        try {
            try {
                j1(32L);
                if (v == Status.STATUS_RUNNING) {
                    sb2 = new StringBuilder();
                } else {
                    Z();
                    Process processE = i.e();
                    try {
                        try {
                            r.b(processE);
                            OutputStream outputStream = processE.getOutputStream();
                            r.b(outputStream);
                            String str2 = "sh " + w + " 2>&1\nsleep 0.15;echo -n 'PID:';pgrep scene-daemon;\nexit 0\nexti 0\n";
                            Charset charset = kotlin.text.d.a;
                            if (str2 == null) {
                                throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                            }
                            byte[] bytes = str2.getBytes(charset);
                            r.c(bytes, "(this as java.lang.String).getBytes(charset)");
                            outputStream.write(bytes);
                            outputStream.flush();
                            outputStream.close();
                            if (Build.VERSION.SDK_INT >= 26) {
                                processE.waitFor(15L, TimeUnit.SECONDS);
                            } else {
                                processE.waitFor();
                            }
                            try {
                                String strC = (Build.VERSION.SDK_INT < 26 || !processE.isAlive()) ? kotlin.io.k.c(new InputStreamReader(processE.getInputStream())) : "wait timeout";
                                this.q = strC;
                                if (k.y(this.q, "Scene-Daemon OK", false, 2, (Object) null)) {
                                    for (String str3 : k.W(this.q, new String[]{"\n"}, false, 0, 6, (Object) null)) {
                                        if (k.t(str3, "PID:", false, 2, (Object) null) && new Regex("[0-9]+").containsMatchIn(str3)) {
                                            j1(150L);
                                            f1();
                                            v = Status.STATUS_RUNNING;
                                            processE.destroy();
                                            sb2 = new StringBuilder();
                                        }
                                    }
                                    for (i = 0; i < 20 && v == Status.STATUS_STARTING; i++) {
                                        Log.e("@Scene", "ReConnect " + (System.currentTimeMillis() - jCurrentTimeMillis) + "  " + v);
                                        j1(200L);
                                    }
                                    if (v == Status.STATUS_RUNNING) {
                                        if (v == Status.STATUS_STARTING) {
                                            f1();
                                        }
                                        processE.destroy();
                                        sb = new StringBuilder();
                                        r11 = str;
                                        sb.append("");
                                        sb.append(System.currentTimeMillis() - jCurrentTimeMillis);
                                        sb.append("  ");
                                        r2 = v;
                                        sb.append(r2);
                                        Log.e("@Scene", sb.toString());
                                        return false;
                                    }
                                    processE.destroy();
                                    sb2 = new StringBuilder();
                                } else {
                                    while (i < 20) {
                                        Log.e("@Scene", "ReConnect " + (System.currentTimeMillis() - jCurrentTimeMillis) + "  " + v);
                                        j1(200L);
                                    }
                                    if (v == Status.STATUS_RUNNING) {
                                        if (v == Status.STATUS_STARTING) {
                                            f1();
                                        }
                                        processE.destroy();
                                        sb = new StringBuilder();
                                        r11 = str;
                                        sb.append("");
                                        sb.append(System.currentTimeMillis() - jCurrentTimeMillis);
                                        sb.append("  ");
                                        r2 = v;
                                        sb.append(r2);
                                        Log.e("@Scene", sb.toString());
                                        return false;
                                    }
                                    processE.destroy();
                                    sb2 = new StringBuilder();
                                }
                            } catch (Exception e2) {
                                StringBuilder sb3 = new StringBuilder();
                                str = "Start Daemon";
                                sb3.append("Start Daemon");
                                sb3.append(e2.getMessage());
                                Log.e("@Scene", sb3.toString());
                            }
                        } catch (Throwable th) {
                            th = th;
                            r11 = processE;
                            if (r11 != 0) {
                                r11.destroy();
                            }
                            Log.e("@Scene", r2 + (System.currentTimeMillis() - jCurrentTimeMillis) + "  " + v);
                            throw th;
                        }
                    } catch (Exception unused) {
                        process = processE;
                        v = Status.STATUS_ERROR;
                        if (process != null) {
                            process.destroy();
                        }
                        sb = new StringBuilder();
                        r11 = process;
                    }
                }
                sb2.append("");
                sb2.append(System.currentTimeMillis() - jCurrentTimeMillis);
                sb2.append("  ");
                sb2.append(v);
                Log.e("@Scene", sb2.toString());
                return true;
            } catch (Throwable th2) {
                th = th2;
            }
        } catch (Exception unused2) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final boolean a1(String str) {
        j1(32L);
        if (i1(str)) {
            return true;
        }
        v = Status.STATUS_STOP;
        if (r.a(str, "root")) {
            return Z0() || i1(str);
        }
        if (!r.a(str, "adb")) {
            return true;
        }
        k1(this, 0L, 1, null);
        return i1(str);
    }

    public static /* synthetic */ String b0(Daemon daemon, String str, int i, Object obj) {
        if ((i & 1) != 0) {
            str = "all";
        }
        return daemon.a0(str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final byte[] e0(String str) throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("key", A);
        jSONObject.put("content", str);
        jSONObject.put("length", str.length());
        com.omarea.common.net.a aVar = this.i;
        String string = jSONObject.toString();
        r.c(string, "request.toString()");
        Charset charset = kotlin.text.d.a;
        if (string == null) {
            throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
        }
        byte[] bytes = string.getBytes(charset);
        r.c(bytes, "(this as java.lang.String).getBytes(charset)");
        String str2 = B;
        Charset charset2 = kotlin.text.d.a;
        if (str2 == null) {
            throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
        }
        byte[] bytes2 = str2.getBytes(charset2);
        r.c(bytes2, "(this as java.lang.String).getBytes(charset)");
        byte[] bArrEncode = Base64.encode(aVar.b(bytes, bytes2), 11);
        r.c(bArrEncode, "Base64.encode(\n         …Base64.URL_SAFE\n        )");
        return bArrEncode;
    }

    private final void f1() {
        if (this.r) {
            return;
        }
        SocketChannel socketChannelV0 = v0();
        if (socketChannelV0 != null) {
            if (socketChannelV0.isConnected()) {
                return;
            } else {
                d(socketChannelV0);
            }
        }
        this.r = true;
        kotlinx.coroutines.f.d(i0.a(w0.a()), (CoroutineContext) null, (CoroutineStart) null, new Daemon$tryReconnect$1(this, null), 3, (Object) null);
    }

    public static /* synthetic */ String h1(Daemon daemon, String str, int i, Object obj) {
        if ((i & 1) != 0) {
            str = "";
        }
        return daemon.g1(str);
    }

    private final boolean i1(String str) {
        if (v == Status.STATUS_RUNNING) {
            return r.a(g1(str), str);
        }
        return false;
    }

    public static /* synthetic */ boolean k1(Daemon daemon, long j, int i, Object obj) {
        if ((i & 1) != 0) {
            j = 0;
        }
        return daemon.j1(j);
    }

    public static /* synthetic */ boolean m0(Daemon daemon, String str, boolean z2, int i, Object obj) {
        if ((i & 2) != 0) {
            z2 = false;
        }
        return daemon.l0(str, z2);
    }

    private final com.omarea.common.net.c q0(SocketChannel socketChannel) {
        return new Daemon$getDaemonConnectHandler$1(this, socketChannel);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final String t0(String str) {
        return "http://127.0.0.1:" + x + '/' + str;
    }

    public final com.omarea.common.net.e D0(String str) {
        r.d(str, "path");
        String strZ0 = z0("path-detail-info", str, 10000);
        if (!(strZ0.length() > 0) || !(!r.a(strZ0, "error"))) {
            return null;
        }
        try {
            return new com.omarea.common.net.e(new JSONObject(strZ0));
        } catch (Exception unused) {
            return null;
        }
    }

    public final boolean E0(String str) {
        r.d(str, "path");
        String strC0 = C0(str);
        return k.t(strC0, "dir", false, 2, (Object) null) || k.t(strC0, "file", false, 2, (Object) null);
    }

    public final f F0(String str) throws JSONException {
        r.d(str, "path");
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("dir", str);
        jSONObject.put("suffix", "");
        s sVar = s.a;
        String string = jSONObject.toString();
        r.c(string, "JSONObject().apply {\n   … \"\")\n        }.toString()");
        String strZ0 = z0("path-list", string, 10000);
        if (!(strZ0.length() > 0) || !(!r.a(strZ0, "error"))) {
            return null;
        }
        try {
            return new f(new JSONObject(strZ0));
        } catch (Exception unused) {
            return null;
        }
    }

    public final boolean G0(DaemonEvent daemonEvent, String str) {
        r.d(daemonEvent, "event");
        r.d(str, "data");
        return T0("event", daemonEvent.name() + '|' + str, 1000).equals("success");
    }

    public final String H0(String str) {
        r.d(str, "action");
        return z0("scheduler-refresh", str, 2000);
    }

    public final String J0(String str, String str2, String str3, boolean z2, boolean z3) throws JSONException {
        r.d(str, "category");
        r.d(str2, "scene");
        r.d(str3, "mode");
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("category", str);
        jSONObject.put("scene", str2);
        jSONObject.put("mode", str3);
        jSONObject.put("force", z2);
        jSONObject.put("logger", z3);
        s sVar = s.a;
        String string = jSONObject.toString();
        r.c(string, "(JSONObject().apply{\n   …er)\n        }).toString()");
        return T0("mode-switch", string, 2000);
    }

    public final void L0(int i) {
        if (i != this.j) {
            this.j = i;
            kotlinx.coroutines.f.d(i0.a(w0.b()), (CoroutineContext) null, (CoroutineStart) null, new Daemon$schedulerViews$1(this, i, null), 3, (Object) null);
        }
    }

    public final void M0(Boolean bool) {
        if (bool != null) {
            this.m = r.a(bool, Boolean.TRUE);
        }
        if (E.b()) {
            kotlinx.coroutines.f.d(i0.a(w0.b()), (CoroutineContext) null, (CoroutineStart) null, new Daemon$setAccessibilityDaemon$1(this, bool, null), 3, (Object) null);
        }
    }

    public final void N0(Boolean bool) {
        if (bool != null) {
            this.n = r.a(bool, Boolean.TRUE);
        }
        if (E.b()) {
            kotlinx.coroutines.f.d(i0.a(w0.b()), (CoroutineContext) null, (CoroutineStart) null, new Daemon$setDamonAuto$1(this, null), 3, (Object) null);
        }
    }

    public final String O0(String str, String str2) {
        r.d(str, "prop");
        r.d(str2, "value");
        return T0("set-kernel-prop", str + '|' + str2, 3000);
    }

    public final String P0(String str) {
        r.d(str, "content");
        return T0("set-kernel-props", str, 15000);
    }

    public final void Q0(boolean z2) {
        this.h = z2;
    }

    public final String R0(String str, int i) throws JSONException {
        r.d(str, "shell");
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("shell", str);
        jSONObject.put("delay", i);
        String string = jSONObject.toString();
        r.c(string, "task.toString()");
        return T0("shell-delayed-add", string, 1000);
    }

    public final void S0(String str) {
        r.d(str, "taskId");
        T0("shell-delayed-remove", str, 1000);
    }

    public final String W(String str) {
        r.d(str, "code");
        Charset charsetDefaultCharset = Charset.defaultCharset();
        r.c(charsetDefaultCharset, "Charset.defaultCharset()");
        byte[] bytes = str.getBytes(charsetDefaultCharset);
        r.c(bytes, "(this as java.lang.String).getBytes(charset)");
        return z0("activate", new String(bytes, kotlin.text.d.a), 3000);
    }

    final /* synthetic */ Object W0(SocketChannel socketChannel, String str, String str2, String str3, kotlin.coroutines.c<? super String> cVar) throws JSONException {
        final kotlinx.coroutines.l lVar = new kotlinx.coroutines.l(kotlin.coroutines.intrinsics.a.c(cVar), 1);
        lVar.u();
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("id", str);
        jSONObject.put("api", str2);
        jSONObject.put("content", str3);
        this.k.put(str, new l<String, s>() { // from class: com.omarea.common.net.Daemon$socketSendRequest$2$1
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(1);
            }

            public /* bridge */ /* synthetic */ Object invoke(Object obj) {
                invoke((String) obj);
                return s.a;
            }

            public final void invoke(String str4) {
                r.d(str4, "it");
                kotlinx.coroutines.k kVar = lVar;
                Result.a aVar = Result.Companion;
                kVar.resumeWith(Result.constructor-impl(str4));
            }
        });
        X0(socketChannel, e0("@Api:" + jSONObject));
        Object objS = lVar.s();
        if (objS == kotlin.coroutines.intrinsics.a.d()) {
            kotlin.coroutines.jvm.internal.f.c(cVar);
        }
        return objS;
    }

    public final boolean X() throws Throwable {
        if (v != Status.STATUS_RUNNING) {
            Z0();
        }
        return r.a(g1("root"), "root");
    }

    @Override // com.omarea.common.net.b
    public void a(SocketChannel socketChannel) {
        r.d(socketChannel, "socketChannel");
        Log.e("Scene", "Daemon [onConnectFail]");
    }

    public final String a0(String str) {
        r.d(str, "action");
        return z0("dex2oat-clear", str, 2000);
    }

    /* JADX WARN: Code duplicated, block: B:49:0x018a A[Catch: Exception -> 0x01c0, TryCatch #0 {Exception -> 0x01c0, blocks: (B:9:0x0030, B:10:0x003f, B:14:0x004e, B:19:0x0091, B:21:0x0098, B:20:0x0096, B:25:0x00b6, B:36:0x0134, B:40:0x014d, B:41:0x016b, B:43:0x0171, B:47:0x0186, B:49:0x018a, B:51:0x0193, B:52:0x01a5), top: B:56:0x0023 }] */
    /* JADX WARN: Code duplicated, block: B:51:0x0193 A[Catch: Exception -> 0x01c0, TryCatch #0 {Exception -> 0x01c0, blocks: (B:9:0x0030, B:10:0x003f, B:14:0x004e, B:19:0x0091, B:21:0x0098, B:20:0x0096, B:25:0x00b6, B:36:0x0134, B:40:0x014d, B:41:0x016b, B:43:0x0171, B:47:0x0186, B:49:0x018a, B:51:0x0193, B:52:0x01a5), top: B:56:0x0023 }] */
    /* JADX WARN: Code duplicated, block: B:52:0x01a5 A[Catch: Exception -> 0x01c0, TRY_LEAVE, TryCatch #0 {Exception -> 0x01c0, blocks: (B:9:0x0030, B:10:0x003f, B:14:0x004e, B:19:0x0091, B:21:0x0098, B:20:0x0096, B:25:0x00b6, B:36:0x0134, B:40:0x014d, B:41:0x016b, B:43:0x0171, B:47:0x0186, B:49:0x018a, B:51:0x0193, B:52:0x01a5), top: B:56:0x0023 }] */
    /*  JADX ERROR: JadxRuntimeException in pass: IfRegionVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v5 java.lang.Object, still in use, count: 2, list:
          (r5v5 java.lang.Object) from 0x0186: PHI (r5 I:??) = (r5v2 java.lang.Object), (r5v5 java.lang.Object) binds: [B:46:0x0185, B:45:0x0184] A[DONT_GENERATE, DONT_INLINE]
          (r5v5 java.lang.Object) from 0x0176: CHECK_CAST (java.util.Map$Entry) (r5v5 java.lang.Object)
        	at jadx.core.utils.InsnRemover.removeSsaVar(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:179)
        	at jadx.core.utils.InsnRemover.unbindResult(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:22)
        	at jadx.core.utils.InsnRemover.unbindInsn(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:4)
        	at jadx.core.dex.visitors.regions.TernaryMod.makeTernaryInsn(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:222)
        	at jadx.core.dex.visitors.regions.TernaryMod.processRegion(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:7)
        	at jadx.core.dex.visitors.regions.TernaryMod.enterRegion(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:1)
        	at jadx.core.dex.visitors.regions.DepthRegionTraversal.traverseInternal(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:58)
        	at jadx.core.dex.visitors.regions.DepthRegionTraversal.traverse(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:5)
        	at jadx.core.dex.visitors.regions.TernaryMod.process(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:3)
        	at jadx.core.dex.visitors.regions.IfRegionVisitor.process(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:1)
        	at jadx.core.dex.visitors.regions.IfRegionVisitor.visit(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:8)
        */
    @Override // com.omarea.common.net.b
    public void b(java.lang.String r17, java.lang.String r18) {
        /*
            Method dump skipped, instruction units count: 468
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.omarea.common.net.Daemon.b(java.lang.String, java.lang.String):void");
    }

    public final boolean b1(DaemonTask daemonTask) {
        r.d(daemonTask, "task");
        String string = daemonTask.toTaskObject().toString();
        r.c(string, "task.toTaskObject().toString()");
        return z0("task-add", string, 1000).equals("success");
    }

    @Override // com.omarea.common.net.b
    public void c(SocketChannel socketChannel, com.omarea.common.net.c cVar) {
        r.d(socketChannel, "socketChannel");
        r.d(cVar, "command");
        ArrayList<SocketChannel> arrayList = this.p;
        ArrayList<SocketChannel> arrayList2 = new ArrayList();
        for (Object obj : arrayList) {
            arrayList2.add(obj);
        }
        this.p.clear();
        this.p.add(socketChannel);
        for (SocketChannel socketChannel2 : arrayList2) {
        }
        v = Status.STATUS_RUNNING;
        Log.i("Scene", "Daemon [onConnected]");
        if (A.length() > 0) {
            kotlinx.coroutines.f.d(i0.a(w0.a()), (CoroutineContext) null, (CoroutineStart) null, new Daemon$onConnected$2(this, null), 3, (Object) null);
        }
        com.omarea.common.net.d dVar = C;
        if (dVar != null) {
            kotlinx.coroutines.f.d(i0.a(w0.a()), (CoroutineContext) null, (CoroutineStart) null, new Daemon$onConnected$$inlined$run$lambda$1(dVar, null, this), 3, (Object) null);
        }
        M0(Boolean.valueOf(this.m));
        N0(Boolean.valueOf(this.n));
    }

    public final boolean c0(String str) {
        r.d(str, "path");
        return k.t(C0(str), "dir", false, 2, (Object) null);
    }

    public final List<DaemonTask> c1() {
        String strZ0 = z0("task-list", "", 1000);
        ArrayList arrayList = new ArrayList();
        try {
            JSONArray jSONArray = new JSONArray(strZ0);
            int length = jSONArray.length();
            for (int i = 0; i < length; i++) {
                Object obj = jSONArray.get(i);
                if ((obj instanceof JSONObject) && ((JSONObject) obj).has("model") && r.a(((JSONObject) obj).get("model"), "DaemonTaskDaily")) {
                    arrayList.add(new DaemonTaskDaily("").parseTaskObject((JSONObject) obj));
                }
            }
        } catch (Exception e2) {
            e2.getStackTrace();
        }
        return arrayList;
    }

    @Override // com.omarea.common.net.b
    public void d(SocketChannel socketChannel) {
        r.d(socketChannel, "socketChannel");
        if (this.p.contains(socketChannel)) {
            Collection<l<String, s>> collectionValues = this.k.values();
            r.c(collectionValues, "asyncTaskList.values");
            if (this.p.size() == 1 && collectionValues.size() > 0) {
                ArrayList arrayList = new ArrayList();
                arrayList.addAll(collectionValues);
                this.k.clear();
                kotlinx.coroutines.f.d(i0.a(w0.a()), (CoroutineContext) null, (CoroutineStart) null, new Daemon$onDisconnect$1(arrayList, null), 3, (Object) null);
            }
            this.p.remove(socketChannel);
        }
        if (this.p.size() < 1) {
            v = Status.STATUS_STOP;
        }
        Log.e("Scene", "Daemon [onDisconnect]");
    }

    public final String d0(String str) {
        r.d(str, "serviceName");
        return T0("dumpsys", str, 5000);
    }

    public final boolean d1(DaemonTask daemonTask) {
        r.d(daemonTask, "task");
        return z0("task-remove", daemonTask.getTaskId(), 1000).equals("success");
    }

    @Override // com.omarea.common.net.b
    public void e(String str, String str2) {
        r.d(str, "type");
        r.d(str2, "error");
        if (r.a(str2, "exit")) {
            v = Status.STATUS_STOP;
        } else if (r.a(str2, "license")) {
            r.a(D, "root");
        }
    }

    public final boolean e1(String str, String str2) throws JSONException {
        r.d(str, "path");
        r.d(str2, "text");
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("path", str);
        jSONObject.put("text", str2);
        s sVar = s.a;
        String string = jSONObject.toString();
        r.c(string, "JSONObject().apply {\n   …ext)\n        }.toString()");
        return r.a(A0(this, "text-write", string, 0, 4, null), "true");
    }

    @Override // com.omarea.common.net.b
    public void f(int i) {
    }

    public final void f0(String str) {
        r.d(str, "shell");
        kotlinx.coroutines.f.d(h1.f, w0.b(), (CoroutineStart) null, new Daemon$execIgnoreResult$1(this, str, null), 2, (Object) null);
    }

    public final String g0(String str) {
        r.d(str, "shell");
        return U0(this, this.g, str, null, 4, null);
    }

    public final String g1(String str) {
        r.d(str, "target");
        return T0("user-group", str, 1000);
    }

    public final String h0(String str, int i) {
        r.d(str, "shell");
        return T0(this.g, str, Integer.valueOf(i));
    }

    @Override // com.omarea.common.net.g
    protected int i() {
        return this.e;
    }

    public final String i0(String str) {
        r.d(str, "shell");
        return T0(this.g, str, 2000);
    }

    @Override // com.omarea.common.net.g
    protected int j() {
        return this.f;
    }

    public final String j0(String str, int i) {
        r.d(str, "shell");
        return z0(this.g, str, i);
    }

    public final boolean j1(long j) {
        FutureTask futureTask = new FutureTask(new e());
        kotlinx.coroutines.f.d(h1.f, w0.b(), (CoroutineStart) null, new Daemon$verifyOnline$1(j, futureTask, null), 2, (Object) null);
        try {
            Object obj = futureTask.get();
            r.c(obj, "task.get()");
            return ((Boolean) obj).booleanValue();
        } catch (Exception unused) {
            return false;
        }
    }

    public final JSONObject k0(boolean z2) {
        String strZ0 = z0("extreme-perf", "" + z2, 2000);
        if ((strZ0.length() > 0) && (!r.a(strZ0, "error"))) {
            try {
                return new JSONObject(strZ0);
            } catch (Exception unused) {
            }
        }
        return null;
    }

    public final boolean l0(String str, boolean z2) {
        r.d(str, "path");
        String strC0 = C0(str);
        if (!z2) {
            return k.t(strC0, "file", false, 2, (Object) null);
        }
        if (!k.t(strC0, "file", false, 2, (Object) null)) {
            return false;
        }
        int iG = k.G(strC0, ',', 0, false, 6, (Object) null) + 1;
        if (strC0 == null) {
            throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
        }
        String strSubstring = strC0.substring(iG);
        r.c(strSubstring, "(this as java.lang.String).substring(startIndex)");
        return Long.parseLong(strSubstring) > 0;
    }

    public final long n0(String str) {
        r.d(str, "path");
        String strC0 = C0(str);
        if (!k.y(strC0, ",", false, 2, (Object) null)) {
            return -1L;
        }
        int iH = k.H(strC0, ",", 0, false, 6, (Object) null) + 1;
        if (strC0 == null) {
            throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
        }
        String strSubstring = strC0.substring(iH);
        r.c(strSubstring, "(this as java.lang.String).substring(startIndex)");
        return Long.parseLong(strSubstring);
    }

    public final boolean o0(String str, com.omarea.common.net.b bVar) throws IOException {
        r.d(str, "shellCommand");
        r.d(bVar, "daemonConnectHandler");
        SocketChannel socketChannelOpen = SocketChannel.open();
        Socket socket = socketChannelOpen.socket();
        socket.setKeepAlive(true);
        socket.setTcpNoDelay(true);
        socket.setSendBufferSize(1024);
        socket.setReceiveBufferSize(65536);
        try {
            socketChannelOpen.connect(new InetSocketAddress("127.0.0.1", z));
            r.c(socketChannelOpen, "socketChannel");
            bVar.c(socketChannelOpen, q0(socketChannelOpen));
            X0(socketChannelOpen, e0(str));
            Y0(socketChannelOpen, bVar);
            return true;
        } catch (IOException e2) {
            if ((e2 instanceof ConnectException) && r.a(e2.getMessage(), "Permission denied") && System.currentTimeMillis() - this.o > 5000) {
                com.omarea.common.net.d dVar = C;
                if (dVar != null) {
                    dVar.d("请不要禁止Scene连接网络!\nDo not deny Scene access to the network!");
                }
                this.o = System.currentTimeMillis();
            }
            r.c(socketChannelOpen, "socketChannel");
            bVar.a(socketChannelOpen);
            return false;
        }
    }

    public final ArrayList<Integer> p0() {
        ArrayList<Integer> arrayList = new ArrayList<>();
        String strT0 = T0("cpu-cycles", "", 2000);
        if ((strT0.length() > 0) && (!r.a(strT0, "error"))) {
            try {
                JSONArray jSONArray = new JSONArray(strT0);
                int length = jSONArray.length();
                for (int i = 0; i < length; i++) {
                    arrayList.add(Integer.valueOf((int) (jSONArray.getLong(i) / ((long) 1000))));
                }
            } catch (Exception unused) {
            }
        }
        return arrayList;
    }

    public final String r0() {
        String strZ0 = z0("daemon-version", "", 1000);
        if ((strZ0.length() > 0) && (!r.a(strZ0, "error"))) {
            return strZ0;
        }
        return null;
    }

    public final JSONObject s0() {
        String strZ0 = z0("device-id", "", 1000);
        if ((strZ0.length() > 0) && (!r.a(strZ0, "error"))) {
            try {
                return new JSONObject(strZ0);
            } catch (Exception unused) {
            }
        }
        return null;
    }

    public final String u0(String str) {
        r.d(str, "prop");
        String strT0 = T0("get-kernel-prop", str, 1000);
        if (strT0 != null) {
            return k.k0(strT0).toString();
        }
        throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
    }

    public final SocketChannel v0() {
        SocketChannel socketChannel = (SocketChannel) q.u(this.p);
        if (socketChannel == null || !socketChannel.isConnected()) {
            return null;
        }
        return socketChannel;
    }

    public final String w0() {
        return this.q;
    }

    public final int x0(String str) {
        r.d(str, "sensorName");
        try {
            return Integer.parseInt(T0("temperature", str, 1000));
        } catch (Exception unused) {
            return -1;
        }
    }

    public final JSONArray y0(int i) {
        String strZ0 = z0("get-threads", String.valueOf(i), 2000);
        if ((strZ0.length() > 0) && (!r.a(strZ0, "error"))) {
            try {
                return new JSONArray(strZ0);
            } catch (Exception unused) {
            }
        }
        return null;
    }

    public final String z0(String str, String str2, int i) {
        r.d(str, "api");
        r.d(str2, "params");
        FutureTask futureTask = new FutureTask(new c(str, str2));
        kotlinx.coroutines.f.d(h1.f, w0.b(), (CoroutineStart) null, new Daemon$httpApiRequest$1(futureTask, null), 2, (Object) null);
        try {
            Object obj = futureTask.get(i, TimeUnit.MILLISECONDS);
            r.c(obj, "task.get(timeout.toLong(), TimeUnit.MILLISECONDS)");
            return (String) obj;
        } catch (Exception unused) {
            return "error";
        }
    }
}
