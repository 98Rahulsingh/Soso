package com.omarea.common.net;

import android.util.Log;
import java.nio.channels.SocketChannel;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.h;
import kotlin.jvm.b.p;
import kotlin.jvm.internal.Ref;
import kotlin.jvm.internal.r;
import kotlin.s;
import kotlinx.coroutines.TimeoutKt;
import kotlinx.coroutines.h0;
import org.json.JSONException;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
@kotlin.coroutines.jvm.internal.d(c = "com.omarea.common.net.Daemon$socketApiRequest$2", f = "Daemon.kt", l = {294, 303}, m = "invokeSuspend")
final class Daemon$socketApiRequest$2 extends SuspendLambda implements p<h0, kotlin.coroutines.c<? super s>, Object> {
    final /* synthetic */ String $api;
    final /* synthetic */ SocketChannel $connect;
    final /* synthetic */ String $content;
    final /* synthetic */ Ref.ObjectRef $result;
    final /* synthetic */ Integer $timeout;
    final /* synthetic */ String $uuid;
    Object L$0;
    Object L$1;
    int label;
    private h0 p$;
    final /* synthetic */ Daemon this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    Daemon$socketApiRequest$2(Daemon daemon, Integer num, Ref.ObjectRef objectRef, SocketChannel socketChannel, String str, String str2, String str3, kotlin.coroutines.c cVar) {
        super(2, cVar);
        this.this$0 = daemon;
        this.$timeout = num;
        this.$result = objectRef;
        this.$connect = socketChannel;
        this.$uuid = str;
        this.$api = str2;
        this.$content = str3;
    }

    public final kotlin.coroutines.c<s> create(Object obj, kotlin.coroutines.c<?> cVar) {
        r.d(cVar, "completion");
        Daemon$socketApiRequest$2 daemon$socketApiRequest$2 = new Daemon$socketApiRequest$2(this.this$0, this.$timeout, this.$result, this.$connect, this.$uuid, this.$api, this.$content, cVar);
        daemon$socketApiRequest$2.p$ = (h0) obj;
        return daemon$socketApiRequest$2;
    }

    public final Object invoke(Object obj, Object obj2) {
        return create(obj, (kotlin.coroutines.c) obj2).invokeSuspend(s.a);
    }

    /* JADX WARN: Code duplicated, block: B:23:0x0066  */
    /* JADX WARN: Instruction removed from duplicated block: B:23:0x0066, please report this as an issue */
    public final Object invokeSuspend(Object obj) throws JSONException {
        Ref.ObjectRef objectRef;
        Object objD = kotlin.coroutines.intrinsics.a.d();
        int i = this.label;
        if (i == 0) {
            h.b(obj);
            h0 h0Var = this.p$;
            synchronized (this.this$0) {
                this.this$0.l++;
                s sVar = s.a;
            }
            Integer num = this.$timeout;
            if (num == null || num.intValue() <= 0) {
                Ref.ObjectRef objectRef2 = this.$result;
                Daemon daemon = this.this$0;
                SocketChannel socketChannel = this.$connect;
                String str = this.$uuid;
                String str2 = this.$api;
                String str3 = this.$content;
                this.L$0 = h0Var;
                this.L$1 = objectRef2;
                this.label = 2;
                obj = daemon.W0(socketChannel, str, str2, str3, this);
                if (obj == objD) {
                    return objD;
                }
                objectRef = objectRef2;
                objectRef.element = (String) obj;
            } else {
                long jIntValue = this.$timeout.intValue();
                Daemon$socketApiRequest$2$r$1 daemon$socketApiRequest$2$r$1 = new Daemon$socketApiRequest$2$r$1(this, null);
                this.L$0 = h0Var;
                this.label = 1;
                obj = TimeoutKt.c(jIntValue, daemon$socketApiRequest$2$r$1, this);
                if (obj == objD) {
                    return objD;
                }
                if (((s) obj) == null) {
                    this.this$0.k.remove(this.$uuid);
                    Log.e("@Scene", "[TIMEOUT](Socket) " + this.$timeout + ", Waiting:" + this.this$0.l + ", " + this.$api + ':' + this.$content);
                    this.$result.element = this.this$0.z0(this.$api, this.$content, this.$timeout.intValue());
                }
            }
        } else if (i == 1) {
            h.b(obj);
            if (((s) obj) == null) {
                this.this$0.k.remove(this.$uuid);
                Log.e("@Scene", "[TIMEOUT](Socket) " + this.$timeout + ", Waiting:" + this.this$0.l + ", " + this.$api + ':' + this.$content);
                this.$result.element = this.this$0.z0(this.$api, this.$content, this.$timeout.intValue());
            }
        } else {
            if (i != 2) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            objectRef = (Ref.ObjectRef) this.L$1;
            h.b(obj);
            objectRef.element = (String) obj;
        }
        synchronized (this.this$0) {
            this.this$0.l--;
            s sVar2 = s.a;
        }
        return s.a;
    }
}
