package com.omarea.common.net;

import android.util.Base64;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.Proxy;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.Charset;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import javax.crypto.NoSuchPaddingException;
import kotlin.jvm.internal.o;
import kotlin.jvm.internal.r;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class g {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final byte[] f440a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final int f441b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final int f442c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private final Proxy f443d;

    public g(Proxy proxy) {
        this.f443d = proxy;
        this.f440a = new byte[]{52, 49, 66, 55, 69, 53, 57, 52, 66, 50, 65, 66, 51, 65, 65, 51, 54, 53, 50, 68, 49, 48, 51, 50, 49, 68, 70, 55, 51, 49, 55, 49};
        this.f441b = 3000;
        this.f442c = 5000;
    }

    public /* synthetic */ g(Proxy proxy, int i, o oVar) {
        this((i & 1) != 0 ? null : proxy);
    }

    private final HttpURLConnection k(String str, String str2) throws IOException {
        URLConnection uRLConnectionOpenConnection;
        if (this.f443d == null) {
            uRLConnectionOpenConnection = new URL(str).openConnection();
            if (uRLConnectionOpenConnection == null) {
                throw new NullPointerException("null cannot be cast to non-null type java.net.HttpURLConnection");
            }
        } else {
            uRLConnectionOpenConnection = new URL(str).openConnection(this.f443d);
            if (uRLConnectionOpenConnection == null) {
                throw new NullPointerException("null cannot be cast to non-null type java.net.HttpURLConnection");
            }
        }
        HttpURLConnection httpURLConnection = (HttpURLConnection) uRLConnectionOpenConnection;
        httpURLConnection.setRequestMethod("POST");
        httpURLConnection.setConnectTimeout(i());
        httpURLConnection.setReadTimeout(j());
        httpURLConnection.setDoOutput(true);
        httpURLConnection.setUseCaches(false);
        httpURLConnection.setRequestProperty("Content-Type", str2);
        return httpURLConnection;
    }

    protected final byte[] g(String str) throws IOException {
        URLConnection uRLConnectionOpenConnection;
        r.d(str, "url");
        if (this.f443d == null) {
            uRLConnectionOpenConnection = new URL(str).openConnection();
            if (uRLConnectionOpenConnection == null) {
                throw new NullPointerException("null cannot be cast to non-null type java.net.HttpURLConnection");
            }
        } else {
            uRLConnectionOpenConnection = new URL(str).openConnection(this.f443d);
            if (uRLConnectionOpenConnection == null) {
                throw new NullPointerException("null cannot be cast to non-null type java.net.HttpURLConnection");
            }
        }
        HttpURLConnection httpURLConnection = (HttpURLConnection) uRLConnectionOpenConnection;
        httpURLConnection.setRequestMethod("GET");
        httpURLConnection.setConnectTimeout(i());
        httpURLConnection.setReadTimeout(j());
        httpURLConnection.setUseCaches(false);
        InputStream inputStream = httpURLConnection.getInputStream();
        r.c(inputStream, "connection.inputStream");
        byte[] bArrC = kotlin.io.a.c(inputStream);
        httpURLConnection.disconnect();
        return bArrC;
    }

    public final HttpURLConnection h(String str, byte[] bArr) throws IOException {
        r.d(str, "url");
        r.d(bArr, "bytes");
        HttpURLConnection httpURLConnectionK = k(str, "text/plain");
        OutputStream outputStream = httpURLConnectionK.getOutputStream();
        outputStream.write(bArr);
        outputStream.flush();
        outputStream.close();
        return httpURLConnectionK;
    }

    protected int i() {
        return this.f441b;
    }

    protected int j() {
        return this.f442c;
    }

    protected final String l(String str) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, InvalidAlgorithmParameterException {
        r.d(str, "response");
        byte[] bArrA = new a().a(Base64.decode(str, 11), this.f440a);
        r.c(bArrA, "decrypted");
        return new String(bArrA, kotlin.text.d.a);
    }

    public final String m(String str, JSONObject jSONObject) throws JSONException, IOException {
        r.d(str, "url");
        r.d(jSONObject, "json");
        HttpURLConnection httpURLConnectionK = k(str, "text/plain");
        OutputStream outputStream = httpURLConnectionK.getOutputStream();
        String string = jSONObject.toString(0);
        r.c(string, "json.toString(0)");
        Charset charset = kotlin.text.d.a;
        if (string == null) {
            throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
        }
        byte[] bytes = string.getBytes(charset);
        r.c(bytes, "(this as java.lang.String).getBytes(charset)");
        outputStream.write(Base64.encode(bytes, 11));
        outputStream.flush();
        outputStream.close();
        return p(httpURLConnectionK);
    }

    public final String n(String str, String str2) {
        r.d(str, "url");
        r.d(str2, "text");
        byte[] bytes = str2.getBytes(kotlin.text.d.a);
        r.c(bytes, "(this as java.lang.String).getBytes(charset)");
        return o(str, bytes);
    }

    public final String o(String str, byte[] bArr) throws IOException {
        r.d(str, "url");
        r.d(bArr, "bytes");
        HttpURLConnection httpURLConnectionK = k(str, "text/plain");
        OutputStream outputStream = httpURLConnectionK.getOutputStream();
        outputStream.write(bArr);
        outputStream.flush();
        outputStream.close();
        return p(httpURLConnectionK);
    }

    protected final String p(HttpURLConnection httpURLConnection) {
        r.d(httpURLConnection, "connection");
        try {
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream()));
            StringBuilder sb = new StringBuilder();
            while (true) {
                String line = bufferedReader.readLine();
                if (line == null) {
                    String string = sb.toString();
                    r.c(string, "stringBuilder.toString()");
                    return string;
                }
                sb.append(line);
                sb.append("\n");
            }
        } finally {
            httpURLConnection.disconnect();
        }
    }

    public final JSONObject q(String str) {
        r.d(str, "str");
        try {
            if (str.length() > 0) {
                return new JSONObject(str);
            }
            return null;
        } catch (Exception unused) {
            return null;
        }
    }

    public final JSONArray r(String str) {
        r.d(str, "str");
        try {
            if (str.length() > 0) {
                return new JSONArray(str);
            }
            return null;
        } catch (Exception unused) {
            return null;
        }
    }
}
