package com.omarea.common.net;

import android.util.Log;
import java.util.ArrayList;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.h;
import kotlin.jvm.b.p;
import kotlin.jvm.internal.r;
import kotlin.s;
import kotlinx.coroutines.h0;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
@kotlin.coroutines.jvm.internal.d(c = "com.omarea.common.net.Daemon$socketReplyDecode$1", f = "Daemon.kt", l = {}, m = "invokeSuspend")
final class Daemon$socketReplyDecode$1 extends SuspendLambda implements p<h0, kotlin.coroutines.c<? super s>, Object> {
    final /* synthetic */ b $daemonConnectHandler;
    final /* synthetic */ ArrayList $rows;
    int label;
    private h0 p$;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    Daemon$socketReplyDecode$1(ArrayList arrayList, b bVar, kotlin.coroutines.c cVar) {
        super(2, cVar);
        this.$rows = arrayList;
        this.$daemonConnectHandler = bVar;
    }

    public final kotlin.coroutines.c<s> create(Object obj, kotlin.coroutines.c<?> cVar) {
        r.d(cVar, "completion");
        Daemon$socketReplyDecode$1 daemon$socketReplyDecode$1 = new Daemon$socketReplyDecode$1(this.$rows, this.$daemonConnectHandler, cVar);
        daemon$socketReplyDecode$1.p$ = (h0) obj;
        return daemon$socketReplyDecode$1;
    }

    public final Object invoke(Object obj, Object obj2) {
        return create(obj, (kotlin.coroutines.c) obj2).invokeSuspend(s.a);
    }

    public final Object invokeSuspend(Object obj) throws JSONException {
        kotlin.coroutines.intrinsics.a.d();
        if (this.label != 0) {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        h.b(obj);
        for (String str : this.$rows) {
            try {
                JSONObject jSONObject = new JSONObject(str);
                String string = jSONObject.getString("tag");
                String string2 = jSONObject.getString("type");
                String string3 = jSONObject.getString("body");
                if (string != null) {
                    int iHashCode = string.hashCode();
                    if (iHashCode != 69) {
                        if (iHashCode != 77) {
                            if (iHashCode == 81 && string.equals("Q")) {
                                int i = -1;
                                try {
                                    r.c(string3, "body");
                                    i = Integer.parseInt(string3);
                                } catch (Exception unused) {
                                    Log.e("Scene", "Daemon-Shell ExitCode " + string3);
                                }
                                this.$daemonConnectHandler.f(i);
                            }
                        } else if (string.equals("M")) {
                            b bVar = this.$daemonConnectHandler;
                            r.c(string2, "type");
                            r.c(string3, "body");
                            bVar.b(string2, string3);
                        }
                    } else if (string.equals("E")) {
                        b bVar2 = this.$daemonConnectHandler;
                        r.c(string2, "type");
                        r.c(string3, "body");
                        bVar2.e(string2, string3);
                    }
                }
            } catch (Exception unused2) {
                Log.e("@Scene", "[SocketReplyDecode] " + str);
            }
        }
        return s.a;
    }
}
