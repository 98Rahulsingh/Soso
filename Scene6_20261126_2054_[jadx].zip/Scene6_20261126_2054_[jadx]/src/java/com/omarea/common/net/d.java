package com.omarea.common.net;

import java.util.List;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public interface d {
    void a(String str, String str2);

    void b(String str, String str2);

    List<DaemonTask> c();

    void d(String str);
}
