package com.omarea.common.net;

import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.h;
import kotlin.jvm.b.p;
import kotlin.jvm.internal.r;
import kotlin.s;
import kotlinx.coroutines.h0;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
@kotlin.coroutines.jvm.internal.d(c = "com.omarea.common.net.Daemon$onMessageOutput$1", f = "Daemon.kt", l = {}, m = "invokeSuspend")
final class Daemon$onMessageOutput$1 extends SuspendLambda implements p<h0, kotlin.coroutines.c<? super s>, Object> {
    final /* synthetic */ byte[] $result;
    final /* synthetic */ String $taskId;
    int label;
    private h0 p$;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    Daemon$onMessageOutput$1(String str, byte[] bArr, kotlin.coroutines.c cVar) {
        super(2, cVar);
        this.$taskId = str;
        this.$result = bArr;
    }

    public final kotlin.coroutines.c<s> create(Object obj, kotlin.coroutines.c<?> cVar) {
        r.d(cVar, "completion");
        Daemon$onMessageOutput$1 daemon$onMessageOutput$1 = new Daemon$onMessageOutput$1(this.$taskId, this.$result, cVar);
        daemon$onMessageOutput$1.p$ = (h0) obj;
        return daemon$onMessageOutput$1;
    }

    public final Object invoke(Object obj, Object obj2) {
        return create(obj, (kotlin.coroutines.c) obj2).invokeSuspend(s.a);
    }

    public final Object invokeSuspend(Object obj) {
        kotlin.coroutines.intrinsics.a.d();
        if (this.label != 0) {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        h.b(obj);
        d dVar = Daemon.C;
        if (dVar != null) {
            String str = this.$taskId;
            byte[] bArr = this.$result;
            r.c(bArr, "result");
            dVar.a(str, new String(bArr, kotlin.text.d.a));
        }
        return s.a;
    }
}
