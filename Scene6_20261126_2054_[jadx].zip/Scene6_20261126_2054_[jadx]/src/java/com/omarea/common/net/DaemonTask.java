package com.omarea.common.net;

import java.io.Serializable;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public interface DaemonTask extends Serializable {
    String getTaskId();

    DaemonTask parseTaskObject(JSONObject jSONObject);

    JSONObject toTaskObject();
}
