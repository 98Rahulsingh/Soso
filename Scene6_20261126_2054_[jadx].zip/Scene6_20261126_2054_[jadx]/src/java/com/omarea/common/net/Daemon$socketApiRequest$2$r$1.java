package com.omarea.common.net;

import java.nio.channels.SocketChannel;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.h;
import kotlin.jvm.b.p;
import kotlin.jvm.internal.Ref;
import kotlin.jvm.internal.r;
import kotlin.s;
import kotlinx.coroutines.h0;
import org.json.JSONException;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
@kotlin.coroutines.jvm.internal.d(c = "com.omarea.common.net.Daemon$socketApiRequest$2$r$1", f = "Daemon.kt", l = {295}, m = "invokeSuspend")
final class Daemon$socketApiRequest$2$r$1 extends SuspendLambda implements p<h0, kotlin.coroutines.c<? super s>, Object> {
    Object L$0;
    Object L$1;
    int label;
    private h0 p$;
    final /* synthetic */ Daemon$socketApiRequest$2 this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    Daemon$socketApiRequest$2$r$1(Daemon$socketApiRequest$2 daemon$socketApiRequest$2, kotlin.coroutines.c cVar) {
        super(2, cVar);
        this.this$0 = daemon$socketApiRequest$2;
    }

    public final kotlin.coroutines.c<s> create(Object obj, kotlin.coroutines.c<?> cVar) {
        r.d(cVar, "completion");
        Daemon$socketApiRequest$2$r$1 daemon$socketApiRequest$2$r$1 = new Daemon$socketApiRequest$2$r$1(this.this$0, cVar);
        daemon$socketApiRequest$2$r$1.p$ = (h0) obj;
        return daemon$socketApiRequest$2$r$1;
    }

    public final Object invoke(Object obj, Object obj2) {
        return create(obj, (kotlin.coroutines.c) obj2).invokeSuspend(s.a);
    }

    public final Object invokeSuspend(Object obj) throws JSONException {
        Ref.ObjectRef objectRef;
        Object objD = kotlin.coroutines.intrinsics.a.d();
        int i = this.label;
        if (i == 0) {
            h.b(obj);
            h0 h0Var = this.p$;
            Daemon$socketApiRequest$2 daemon$socketApiRequest$2 = this.this$0;
            Ref.ObjectRef objectRef2 = daemon$socketApiRequest$2.$result;
            Daemon daemon = daemon$socketApiRequest$2.this$0;
            SocketChannel socketChannel = daemon$socketApiRequest$2.$connect;
            String str = daemon$socketApiRequest$2.$uuid;
            String str2 = daemon$socketApiRequest$2.$api;
            String str3 = daemon$socketApiRequest$2.$content;
            this.L$0 = h0Var;
            this.L$1 = objectRef2;
            this.label = 1;
            obj = daemon.W0(socketChannel, str, str2, str3, this);
            if (obj == objD) {
                return objD;
            }
            objectRef = objectRef2;
        } else {
            if (i != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            objectRef = (Ref.ObjectRef) this.L$1;
            h.b(obj);
        }
        objectRef.element = (String) obj;
        return s.a;
    }
}
