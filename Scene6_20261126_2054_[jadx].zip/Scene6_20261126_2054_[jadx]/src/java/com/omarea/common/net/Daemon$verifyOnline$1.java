package com.omarea.common.net;

import java.util.concurrent.FutureTask;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.h;
import kotlin.jvm.b.p;
import kotlin.jvm.internal.r;
import kotlin.s;
import kotlinx.coroutines.h0;
import kotlinx.coroutines.q0;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
@kotlin.coroutines.jvm.internal.d(c = "com.omarea.common.net.Daemon$verifyOnline$1", f = "Daemon.kt", l = {1117}, m = "invokeSuspend")
final class Daemon$verifyOnline$1 extends SuspendLambda implements p<h0, kotlin.coroutines.c<? super s>, Object> {
    final /* synthetic */ FutureTask $task;
    final /* synthetic */ long $timeout;
    Object L$0;
    int label;
    private h0 p$;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    Daemon$verifyOnline$1(long j, FutureTask futureTask, kotlin.coroutines.c cVar) {
        super(2, cVar);
        this.$timeout = j;
        this.$task = futureTask;
    }

    public final kotlin.coroutines.c<s> create(Object obj, kotlin.coroutines.c<?> cVar) {
        r.d(cVar, "completion");
        Daemon$verifyOnline$1 daemon$verifyOnline$1 = new Daemon$verifyOnline$1(this.$timeout, this.$task, cVar);
        daemon$verifyOnline$1.p$ = (h0) obj;
        return daemon$verifyOnline$1;
    }

    public final Object invoke(Object obj, Object obj2) {
        return create(obj, (kotlin.coroutines.c) obj2).invokeSuspend(s.a);
    }

    public final Object invokeSuspend(Object obj) {
        Object objD = kotlin.coroutines.intrinsics.a.d();
        int i = this.label;
        if (i == 0) {
            h.b(obj);
            h0 h0Var = this.p$;
            long j = this.$timeout;
            if (j > 0) {
                this.L$0 = h0Var;
                this.label = 1;
                if (q0.a(j, this) == objD) {
                    return objD;
                }
            }
        } else {
            if (i != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            h.b(obj);
        }
        this.$task.run();
        return s.a;
    }
}
