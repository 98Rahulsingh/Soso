package com.omarea.common.net;

import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.h;
import kotlin.jvm.b.p;
import kotlin.jvm.internal.r;
import kotlin.s;
import kotlinx.coroutines.h0;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
@kotlin.coroutines.jvm.internal.d(c = "com.omarea.common.net.Daemon$tryReconnect$1", f = "Daemon.kt", l = {}, m = "invokeSuspend")
final class Daemon$tryReconnect$1 extends SuspendLambda implements p<h0, kotlin.coroutines.c<? super s>, Object> {
    int label;
    private h0 p$;
    final /* synthetic */ Daemon this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    Daemon$tryReconnect$1(Daemon daemon, kotlin.coroutines.c cVar) {
        super(2, cVar);
        this.this$0 = daemon;
    }

    public final kotlin.coroutines.c<s> create(Object obj, kotlin.coroutines.c<?> cVar) {
        r.d(cVar, "completion");
        Daemon$tryReconnect$1 daemon$tryReconnect$1 = new Daemon$tryReconnect$1(this.this$0, cVar);
        daemon$tryReconnect$1.p$ = (h0) obj;
        return daemon$tryReconnect$1;
    }

    public final Object invoke(Object obj, Object obj2) {
        return create(obj, (kotlin.coroutines.c) obj2).invokeSuspend(s.a);
    }

    public final Object invokeSuspend(Object obj) {
        kotlin.coroutines.intrinsics.a.d();
        if (this.label != 0) {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        h.b(obj);
        for (int i = 0; i < 30 && Daemon.v == Daemon.Status.STATUS_STARTING; i++) {
            this.this$0.j1(1000L);
        }
        Daemon.v = Daemon.Status.STATUS_STOP;
        this.this$0.r = false;
        return s.a;
    }
}
