package com.omarea.common.net;

import java.nio.channels.SocketChannel;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public interface b {
    void a(SocketChannel socketChannel);

    void b(String str, String str2);

    void c(SocketChannel socketChannel, c cVar);

    void d(SocketChannel socketChannel);

    void e(String str, String str2);

    void f(int i);
}
