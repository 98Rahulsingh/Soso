package com.omarea.common.net;

import java.net.ServerSocket;
import java.net.Socket;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.h;
import kotlin.jvm.b.p;
import kotlin.jvm.internal.r;
import kotlin.s;
import kotlinx.coroutines.CoroutineStart;
import kotlinx.coroutines.h0;
import kotlinx.coroutines.i0;
import kotlinx.coroutines.w0;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
@kotlin.coroutines.jvm.internal.d(c = "com.omarea.common.net.Daemon$daemonWatch$1", f = "Daemon.kt", l = {}, m = "invokeSuspend")
final class Daemon$daemonWatch$1 extends SuspendLambda implements p<h0, kotlin.coroutines.c<? super s>, Object> {
    final /* synthetic */ ServerSocket $server;
    int label;
    private h0 p$;
    final /* synthetic */ Daemon this$0;

    /* JADX INFO: renamed from: com.omarea.common.net.Daemon$daemonWatch$1$1, reason: invalid class name */
    @kotlin.coroutines.jvm.internal.d(c = "com.omarea.common.net.Daemon$daemonWatch$1$1", f = "Daemon.kt", l = {}, m = "invokeSuspend")
    static final class AnonymousClass1 extends SuspendLambda implements p<h0, kotlin.coroutines.c<? super s>, Object> {
        int label;
        private h0 p$;

        AnonymousClass1(kotlin.coroutines.c cVar) {
            super(2, cVar);
        }

        public final kotlin.coroutines.c<s> create(Object obj, kotlin.coroutines.c<?> cVar) {
            r.d(cVar, "completion");
            AnonymousClass1 anonymousClass1 = Daemon$daemonWatch$1.this.new AnonymousClass1(cVar);
            anonymousClass1.p$ = (h0) obj;
            return anonymousClass1;
        }

        public final Object invoke(Object obj, Object obj2) {
            return create(obj, (kotlin.coroutines.c) obj2).invokeSuspend(s.a);
        }

        public final Object invokeSuspend(Object obj) {
            kotlin.coroutines.intrinsics.a.d();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            h.b(obj);
            Daemon$daemonWatch$1.this.this$0.W(Daemon.A);
            return s.a;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    Daemon$daemonWatch$1(Daemon daemon, ServerSocket serverSocket, kotlin.coroutines.c cVar) {
        super(2, cVar);
        this.this$0 = daemon;
        this.$server = serverSocket;
    }

    public final kotlin.coroutines.c<s> create(Object obj, kotlin.coroutines.c<?> cVar) {
        r.d(cVar, "completion");
        Daemon$daemonWatch$1 daemon$daemonWatch$1 = new Daemon$daemonWatch$1(this.this$0, this.$server, cVar);
        daemon$daemonWatch$1.p$ = (h0) obj;
        return daemon$daemonWatch$1;
    }

    public final Object invoke(Object obj, Object obj2) {
        return create(obj, (kotlin.coroutines.c) obj2).invokeSuspend(s.a);
    }

    public final Object invokeSuspend(Object obj) {
        kotlin.coroutines.intrinsics.a.d();
        if (this.label != 0) {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        h.b(obj);
        while (true) {
            try {
                Socket socketAccept = this.$server.accept();
                Daemon.v = Daemon.Status.STATUS_RUNNING;
                if (!Daemon.E.b()) {
                    this.this$0.j1(0L);
                }
                if (Daemon.A.length() > 0) {
                    kotlinx.coroutines.f.d(i0.a(w0.a()), (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass1(null), 3, (Object) null);
                }
                socketAccept.close();
            } catch (Exception unused) {
            }
        }
    }
}
