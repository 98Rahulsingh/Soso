package com.omarea.common.net;

import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.nio.charset.Charset;
import kotlin.Result;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.h;
import kotlin.jvm.b.p;
import kotlin.jvm.internal.r;
import kotlin.s;
import kotlinx.coroutines.h0;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
@kotlin.coroutines.jvm.internal.d(c = "com.omarea.common.net.Daemon$getDaemonConnectHandler$1$exit$1", f = "Daemon.kt", l = {}, m = "invokeSuspend")
final class Daemon$getDaemonConnectHandler$1$exit$1 extends SuspendLambda implements p<h0, kotlin.coroutines.c<? super s>, Object> {
    int label;
    private h0 p$;
    final /* synthetic */ Daemon$getDaemonConnectHandler$1 this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    Daemon$getDaemonConnectHandler$1$exit$1(Daemon$getDaemonConnectHandler$1 daemon$getDaemonConnectHandler$1, kotlin.coroutines.c cVar) {
        super(2, cVar);
        this.this$0 = daemon$getDaemonConnectHandler$1;
    }

    public final kotlin.coroutines.c<s> create(Object obj, kotlin.coroutines.c<?> cVar) {
        r.d(cVar, "completion");
        Daemon$getDaemonConnectHandler$1$exit$1 daemon$getDaemonConnectHandler$1$exit$1 = new Daemon$getDaemonConnectHandler$1$exit$1(this.this$0, cVar);
        daemon$getDaemonConnectHandler$1$exit$1.p$ = (h0) obj;
        return daemon$getDaemonConnectHandler$1$exit$1;
    }

    public final Object invoke(Object obj, Object obj2) {
        return create(obj, (kotlin.coroutines.c) obj2).invokeSuspend(s.a);
    }

    public final Object invokeSuspend(Object obj) {
        kotlin.coroutines.intrinsics.a.d();
        if (this.label != 0) {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        h.b(obj);
        try {
            Result.a aVar = Result.Companion;
            this.this$0.f428b.write(ByteBuffer.wrap(this.this$0.f427a.e0("@signal:exit")));
            SocketChannel socketChannel = this.this$0.f428b;
            Charset charsetDefaultCharset = Charset.defaultCharset();
            r.c(charsetDefaultCharset, "Charset.defaultCharset()");
            byte[] bytes = ";".getBytes(charsetDefaultCharset);
            r.c(bytes, "(this as java.lang.String).getBytes(charset)");
            Result.constructor-impl(kotlin.coroutines.jvm.internal.a.e(socketChannel.write(ByteBuffer.wrap(bytes))));
        } catch (Throwable th) {
            Result.a aVar2 = Result.Companion;
            Result.constructor-impl(h.a(th));
        }
        return s.a;
    }
}
