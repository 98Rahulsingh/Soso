package com.omarea.common.net;

import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.h;
import kotlin.jvm.b.p;
import kotlin.jvm.internal.r;
import kotlin.s;
import kotlinx.coroutines.h0;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
@kotlin.coroutines.jvm.internal.d(c = "com.omarea.common.net.Daemon$setAccessibilityDaemon$1", f = "Daemon.kt", l = {}, m = "invokeSuspend")
final class Daemon$setAccessibilityDaemon$1 extends SuspendLambda implements p<h0, kotlin.coroutines.c<? super s>, Object> {
    final /* synthetic */ Boolean $allow;
    int label;
    private h0 p$;
    final /* synthetic */ Daemon this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    Daemon$setAccessibilityDaemon$1(Daemon daemon, Boolean bool, kotlin.coroutines.c cVar) {
        super(2, cVar);
        this.this$0 = daemon;
        this.$allow = bool;
    }

    public final kotlin.coroutines.c<s> create(Object obj, kotlin.coroutines.c<?> cVar) {
        r.d(cVar, "completion");
        Daemon$setAccessibilityDaemon$1 daemon$setAccessibilityDaemon$1 = new Daemon$setAccessibilityDaemon$1(this.this$0, this.$allow, cVar);
        daemon$setAccessibilityDaemon$1.p$ = (h0) obj;
        return daemon$setAccessibilityDaemon$1;
    }

    public final Object invoke(Object obj, Object obj2) {
        return create(obj, (kotlin.coroutines.c) obj2).invokeSuspend(s.a);
    }

    public final Object invokeSuspend(Object obj) {
        String str;
        kotlin.coroutines.intrinsics.a.d();
        if (this.label != 0) {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        h.b(obj);
        Daemon daemon = this.this$0;
        if (r.a(this.$allow, kotlin.coroutines.jvm.internal.a.a(true))) {
            str = "10";
        } else {
            str = this.$allow == null ? "-1" : "0";
        }
        daemon.z0("accessibility-daemon", str, 10000);
        return s.a;
    }
}
