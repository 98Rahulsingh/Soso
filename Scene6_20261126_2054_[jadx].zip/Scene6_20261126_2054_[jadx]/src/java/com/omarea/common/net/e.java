package com.omarea.common.net;

import java.io.File;
import java.util.ArrayList;
import kotlin.jvm.internal.o;
import kotlin.jvm.internal.r;
import kotlin.text.k;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class e {
    public static final a f = new a(null);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private boolean f434a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private String f435b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private String f436c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private long f437d;
    private boolean e;

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(o oVar) {
            this();
        }

        public final e a(String str) {
            r.d(str, "path");
            e eVarD0 = Daemon.E.a().D0(str);
            if (eVarD0 != null) {
                return eVarD0;
            }
            e eVar = new e((o) null);
            File file = new File(str);
            String name = file.getName();
            r.c(name, "f.name");
            eVar.j(name);
            String absolutePath = file.getAbsolutePath();
            r.c(absolutePath, "f.absolutePath");
            eVar.h(absolutePath);
            eVar.i(false);
            return eVar;
        }
    }

    private e() {
        this.f435b = "";
        this.f436c = "";
    }

    public /* synthetic */ e(o oVar) {
        this();
    }

    public e(JSONObject jSONObject) throws JSONException {
        r.d(jSONObject, "jsonObject");
        this.f435b = "";
        this.f436c = "";
        if (jSONObject.has("isDir")) {
            this.f434a = jSONObject.getBoolean("isDir");
        }
        if (jSONObject.has("name")) {
            String string = jSONObject.getString("name");
            r.c(string, "jsonObject.getString(\"name\")");
            this.f435b = string;
        }
        if (jSONObject.has("absPath")) {
            String string2 = jSONObject.getString("absPath");
            r.c(string2, "jsonObject.getString(\"absPath\")");
            this.f436c = string2;
        }
        if (jSONObject.has("size")) {
            this.f437d = jSONObject.getLong("size");
        }
        if (jSONObject.has("exist")) {
            this.e = jSONObject.getBoolean("exist");
        }
    }

    public final String a() {
        return this.f436c;
    }

    public final boolean b() {
        return this.e;
    }

    public final String c() {
        return this.f435b;
    }

    public final String d() {
        if (!k.y(this.f436c, "/", false, 2, (Object) null)) {
            return "";
        }
        String str = this.f436c;
        int iN = k.N(str, "/", 0, false, 6, (Object) null);
        if (str == null) {
            throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
        }
        String strSubstring = str.substring(0, iN);
        r.c(strSubstring, "(this as java.lang.Strin…ing(startIndex, endIndex)");
        return strSubstring;
    }

    public final long e() {
        return this.f437d;
    }

    public final boolean f() {
        return this.f434a;
    }

    public final ArrayList<e> g() throws JSONException {
        ArrayList<e> arrayListA;
        if (!this.f434a) {
            return new ArrayList<>();
        }
        f fVarF0 = Daemon.E.a().F0(this.f436c);
        return (fVarF0 == null || (arrayListA = fVarF0.a()) == null) ? new ArrayList<>() : arrayListA;
    }

    public final void h(String str) {
        r.d(str, "<set-?>");
        this.f436c = str;
    }

    public final void i(boolean z) {
        this.e = z;
    }

    public final void j(String str) {
        r.d(str, "<set-?>");
        this.f435b = str;
    }
}
