package com.omarea.common.net;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import kotlin.collections.q;
import kotlin.jvm.b.l;
import kotlin.jvm.internal.r;
import kotlin.text.k;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class DaemonTaskDaily implements DaemonTask {
    private List<DaemonCommand> commands;
    private long countdown;
    private boolean enabled;
    private long expireDate;
    private String id;
    private String name;
    private boolean once;
    private int timeMinutes;

    public DaemonTaskDaily(String str) {
        r.d(str, "taskId");
        this.id = "";
        this.name = "";
        this.commands = new ArrayList();
        this.id = str;
    }

    public final List<DaemonCommand> getCommands() {
        return this.commands;
    }

    public final long getCountdown() {
        return this.countdown;
    }

    public final boolean getEnabled() {
        return this.enabled;
    }

    public final long getExpireDate() {
        return this.expireDate;
    }

    public final String getId() {
        return this.id;
    }

    public final String getName() {
        return this.name;
    }

    public final boolean getOnce() {
        return this.once;
    }

    @Override // com.omarea.common.net.DaemonTask
    public String getTaskId() {
        return this.id;
    }

    public final int getTimeMinutes() {
        return this.timeMinutes;
    }

    @Override // com.omarea.common.net.DaemonTask
    public DaemonTaskDaily parseTaskObject(JSONObject jSONObject) throws JSONException {
        r.d(jSONObject, "daemonBack");
        if (jSONObject.has("id")) {
            String string = jSONObject.getString("id");
            r.c(string, "daemonBack.getString(\"id\")");
            this.id = string;
        }
        if (jSONObject.has("name")) {
            String string2 = jSONObject.getString("name");
            r.c(string2, "daemonBack.getString(\"name\")");
            this.name = string2;
        }
        if (jSONObject.has("once")) {
            this.once = jSONObject.getBoolean("once");
        }
        if (jSONObject.has("countdown")) {
            this.countdown = jSONObject.getLong("countdown");
        }
        if (jSONObject.has("commands")) {
            String string3 = jSONObject.getString("commands");
            r.c(string3, "daemonBack.getString(\"commands\")");
            List<String> listW = k.W(string3, new String[]{"\n"}, false, 0, 6, (Object) null);
            ArrayList arrayList = new ArrayList(q.k(listW, 10));
            for (String str : listW) {
                DaemonCommand daemonCommand = new DaemonCommand();
                daemonCommand.setName("");
                daemonCommand.setCommand(str);
                arrayList.add(daemonCommand);
            }
            this.commands = arrayList;
        }
        return this;
    }

    public final void setCommands(List<DaemonCommand> list) {
        r.d(list, "<set-?>");
        this.commands = list;
    }

    public final void setCountdown(long j) {
        this.countdown = j;
    }

    public final void setEnabled(boolean z) {
        this.enabled = z;
    }

    public final void setExpireDate(long j) {
        this.expireDate = j;
    }

    public final void setId(String str) {
        r.d(str, "<set-?>");
        this.id = str;
    }

    public final void setName(String str) {
        r.d(str, "<set-?>");
        this.name = str;
    }

    public final void setOnce(boolean z) {
        this.once = z;
    }

    public final void setTimeMinutes(int i) {
        this.timeMinutes = i;
    }

    @Override // com.omarea.common.net.DaemonTask
    public JSONObject toTaskObject() throws JSONException {
        int i = ((this.timeMinutes + 1440) - 480) % 1440;
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("id", this.id);
        jSONObject.put("model", "DaemonTaskDaily");
        jSONObject.put("name", this.name);
        jSONObject.put("spec", (i % 60) + ' ' + (i / 60) + " * * ? ");
        jSONObject.put("once", this.once);
        List<DaemonCommand> list = this.commands;
        ArrayList arrayList = new ArrayList(q.k(list, 10));
        Iterator<T> it = list.iterator();
        while (it.hasNext()) {
            arrayList.add(((DaemonCommand) it.next()).getCommand());
        }
        jSONObject.put("commands", q.A(arrayList, "\n\n", (CharSequence) null, (CharSequence) null, 0, (CharSequence) null, (l) null, 62, (Object) null));
        return jSONObject;
    }
}
