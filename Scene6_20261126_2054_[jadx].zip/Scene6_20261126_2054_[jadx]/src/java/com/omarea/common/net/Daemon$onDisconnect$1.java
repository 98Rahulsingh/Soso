package com.omarea.common.net;

import java.util.ArrayList;
import java.util.Iterator;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.h;
import kotlin.jvm.b.l;
import kotlin.jvm.b.p;
import kotlin.jvm.internal.r;
import kotlin.s;
import kotlinx.coroutines.h0;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
@kotlin.coroutines.jvm.internal.d(c = "com.omarea.common.net.Daemon$onDisconnect$1", f = "Daemon.kt", l = {}, m = "invokeSuspend")
final class Daemon$onDisconnect$1 extends SuspendLambda implements p<h0, kotlin.coroutines.c<? super s>, Object> {
    final /* synthetic */ ArrayList $callbacks;
    int label;
    private h0 p$;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    Daemon$onDisconnect$1(ArrayList arrayList, kotlin.coroutines.c cVar) {
        super(2, cVar);
        this.$callbacks = arrayList;
    }

    public final kotlin.coroutines.c<s> create(Object obj, kotlin.coroutines.c<?> cVar) {
        r.d(cVar, "completion");
        Daemon$onDisconnect$1 daemon$onDisconnect$1 = new Daemon$onDisconnect$1(this.$callbacks, cVar);
        daemon$onDisconnect$1.p$ = (h0) obj;
        return daemon$onDisconnect$1;
    }

    public final Object invoke(Object obj, Object obj2) {
        return create(obj, (kotlin.coroutines.c) obj2).invokeSuspend(s.a);
    }

    public final Object invokeSuspend(Object obj) {
        kotlin.coroutines.intrinsics.a.d();
        if (this.label != 0) {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        h.b(obj);
        Iterator it = this.$callbacks.iterator();
        while (it.hasNext()) {
            ((l) it.next()).invoke("error");
        }
        return s.a;
    }
}
