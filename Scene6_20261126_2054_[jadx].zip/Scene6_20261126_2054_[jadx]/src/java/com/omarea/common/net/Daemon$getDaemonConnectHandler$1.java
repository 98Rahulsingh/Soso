package com.omarea.common.net;

import java.nio.channels.SocketChannel;
import kotlin.coroutines.CoroutineContext;
import kotlinx.coroutines.CoroutineStart;
import kotlinx.coroutines.i0;
import kotlinx.coroutines.w0;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class Daemon$getDaemonConnectHandler$1 implements c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    final /* synthetic */ Daemon f427a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    final /* synthetic */ SocketChannel f428b;

    Daemon$getDaemonConnectHandler$1(Daemon daemon, SocketChannel socketChannel) {
        this.f427a = daemon;
        this.f428b = socketChannel;
    }

    @Override // com.omarea.common.net.c
    public void a() {
        kotlinx.coroutines.f.d(i0.a(w0.b()), (CoroutineContext) null, (CoroutineStart) null, new Daemon$getDaemonConnectHandler$1$exit$1(this, null), 3, (Object) null);
    }
}
