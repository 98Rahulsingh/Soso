package com.omarea.common.net;

import kotlin.Result;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.h;
import kotlin.jvm.b.p;
import kotlin.jvm.internal.r;
import kotlin.s;
import kotlinx.coroutines.h0;
import kotlinx.coroutines.k;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
final class Daemon$httpApiRequestSendAsync$$inlined$suspendCancellableCoroutine$lambda$1 extends SuspendLambda implements p<h0, kotlin.coroutines.c<? super s>, Object> {
    final /* synthetic */ String $api$inlined;
    final /* synthetic */ k $it;
    final /* synthetic */ String $params$inlined;
    int label;
    private h0 p$;
    final /* synthetic */ Daemon this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    Daemon$httpApiRequestSendAsync$$inlined$suspendCancellableCoroutine$lambda$1(k kVar, kotlin.coroutines.c cVar, Daemon daemon, String str, String str2) {
        super(2, cVar);
        this.$it = kVar;
        this.this$0 = daemon;
        this.$api$inlined = str;
        this.$params$inlined = str2;
    }

    public final kotlin.coroutines.c<s> create(Object obj, kotlin.coroutines.c<?> cVar) {
        r.d(cVar, "completion");
        Daemon$httpApiRequestSendAsync$$inlined$suspendCancellableCoroutine$lambda$1 daemon$httpApiRequestSendAsync$$inlined$suspendCancellableCoroutine$lambda$1 = new Daemon$httpApiRequestSendAsync$$inlined$suspendCancellableCoroutine$lambda$1(this.$it, cVar, this.this$0, this.$api$inlined, this.$params$inlined);
        daemon$httpApiRequestSendAsync$$inlined$suspendCancellableCoroutine$lambda$1.p$ = (h0) obj;
        return daemon$httpApiRequestSendAsync$$inlined$suspendCancellableCoroutine$lambda$1;
    }

    public final Object invoke(Object obj, Object obj2) {
        return create(obj, (kotlin.coroutines.c) obj2).invokeSuspend(s.a);
    }

    public final Object invokeSuspend(Object obj) throws Throwable {
        kotlin.coroutines.intrinsics.a.d();
        if (this.label != 0) {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        h.b(obj);
        k kVar = this.$it;
        String strB0 = this.this$0.B0(this.$api$inlined, this.$params$inlined);
        Result.a aVar = Result.Companion;
        kVar.resumeWith(Result.constructor-impl(strB0));
        return s.a;
    }
}
