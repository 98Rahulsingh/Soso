package com.omarea.common.net;

import java.util.Iterator;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.h;
import kotlin.jvm.b.p;
import kotlin.jvm.internal.r;
import kotlin.s;
import kotlinx.coroutines.h0;
import kotlinx.coroutines.q0;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
final class Daemon$onConnected$$inlined$run$lambda$1 extends SuspendLambda implements p<h0, kotlin.coroutines.c<? super s>, Object> {
    final /* synthetic */ d $this_run;
    Object L$0;
    int label;
    private h0 p$;
    final /* synthetic */ Daemon this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    Daemon$onConnected$$inlined$run$lambda$1(d dVar, kotlin.coroutines.c cVar, Daemon daemon) {
        super(2, cVar);
        this.$this_run = dVar;
        this.this$0 = daemon;
    }

    public final kotlin.coroutines.c<s> create(Object obj, kotlin.coroutines.c<?> cVar) {
        r.d(cVar, "completion");
        Daemon$onConnected$$inlined$run$lambda$1 daemon$onConnected$$inlined$run$lambda$1 = new Daemon$onConnected$$inlined$run$lambda$1(this.$this_run, cVar, this.this$0);
        daemon$onConnected$$inlined$run$lambda$1.p$ = (h0) obj;
        return daemon$onConnected$$inlined$run$lambda$1;
    }

    public final Object invoke(Object obj, Object obj2) {
        return create(obj, (kotlin.coroutines.c) obj2).invokeSuspend(s.a);
    }

    public final Object invokeSuspend(Object obj) {
        Object objD = kotlin.coroutines.intrinsics.a.d();
        int i = this.label;
        if (i == 0) {
            h.b(obj);
            this.L$0 = this.p$;
            this.label = 1;
            if (q0.a(100L, this) == objD) {
                return objD;
            }
        } else {
            if (i != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            h.b(obj);
        }
        if (r.a(Daemon.E.c(), "root")) {
            Iterator<T> it = this.$this_run.c().iterator();
            while (it.hasNext()) {
                this.this$0.b1((DaemonTask) it.next());
            }
        }
        return s.a;
    }
}
