package com.omarea.common.net;

import java.io.Serializable;
import kotlin.jvm.internal.r;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class DaemonCommand implements Serializable {
    private String name = "";
    private String command = "";

    public final String getCommand() {
        return this.command;
    }

    public final String getName() {
        return this.name;
    }

    public final void setCommand(String str) {
        r.d(str, "<set-?>");
        this.command = str;
    }

    public final void setName(String str) {
        r.d(str, "<set-?>");
        this.name = str;
    }
}
