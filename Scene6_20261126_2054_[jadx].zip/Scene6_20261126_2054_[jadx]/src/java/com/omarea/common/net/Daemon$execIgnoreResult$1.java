package com.omarea.common.net;

import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.h;
import kotlin.jvm.b.p;
import kotlin.jvm.internal.r;
import kotlin.s;
import kotlinx.coroutines.h0;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
@kotlin.coroutines.jvm.internal.d(c = "com.omarea.common.net.Daemon$execIgnoreResult$1", f = "Daemon.kt", l = {}, m = "invokeSuspend")
final class Daemon$execIgnoreResult$1 extends SuspendLambda implements p<h0, kotlin.coroutines.c<? super s>, Object> {
    final /* synthetic */ String $shell;
    int label;
    private h0 p$;
    final /* synthetic */ Daemon this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    Daemon$execIgnoreResult$1(Daemon daemon, String str, kotlin.coroutines.c cVar) {
        super(2, cVar);
        this.this$0 = daemon;
        this.$shell = str;
    }

    public final kotlin.coroutines.c<s> create(Object obj, kotlin.coroutines.c<?> cVar) {
        r.d(cVar, "completion");
        Daemon$execIgnoreResult$1 daemon$execIgnoreResult$1 = new Daemon$execIgnoreResult$1(this.this$0, this.$shell, cVar);
        daemon$execIgnoreResult$1.p$ = (h0) obj;
        return daemon$execIgnoreResult$1;
    }

    public final Object invoke(Object obj, Object obj2) {
        return create(obj, (kotlin.coroutines.c) obj2).invokeSuspend(s.a);
    }

    public final Object invokeSuspend(Object obj) {
        kotlin.coroutines.intrinsics.a.d();
        if (this.label != 0) {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        h.b(obj);
        try {
            super/*com.omarea.common.net.g*/.o(this.this$0.t0(this.this$0.g), this.this$0.e0(this.$shell));
        } catch (Exception unused) {
        }
        return s.a;
    }
}
