package com.omarea.common.net;

import java.util.ArrayList;
import kotlin.jvm.internal.r;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private boolean f438a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private ArrayList<e> f439b;

    public f(JSONObject jSONObject) throws JSONException {
        r.d(jSONObject, "jsonObject");
        this.f439b = new ArrayList<>();
        if (jSONObject.has("success")) {
            this.f438a = jSONObject.getBoolean("success");
        }
        if (jSONObject.has("error")) {
            r.c(jSONObject.getString("error"), "jsonObject.getString(\"error\")");
        }
        if (jSONObject.has("absPath")) {
            r.c(jSONObject.getString("absPath"), "jsonObject.getString(\"absPath\")");
        }
        if (this.f438a && jSONObject.has("files")) {
            JSONArray jSONArray = jSONObject.getJSONArray("files");
            int length = jSONArray.length();
            for (int i = 0; i < length; i++) {
                ArrayList<e> arrayList = this.f439b;
                JSONObject jSONObject2 = jSONArray.getJSONObject(i);
                r.c(jSONObject2, "arr.getJSONObject(i)");
                arrayList.add(new e(jSONObject2));
            }
        }
    }

    public final ArrayList<e> a() {
        return this.f439b;
    }
}
