package com.omarea.common.ui;

import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.EditText;
import android.widget.Filterable;
import android.widget.ListAdapter;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;
import kotlin.jvm.internal.o;
import kotlin.jvm.internal.r;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class h {
    public static final b k = new b(null);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final int f501a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private View f502b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private com.omarea.common.ui.e.c f503c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private String f504d;
    private String e;
    private a f;
    private final Context g;
    private ArrayList<com.omarea.a.f.a> h;
    private ArrayList<com.omarea.a.f.a> i;
    private final boolean j;

    public interface a {
        void a(List<com.omarea.a.f.a> list, boolean[] zArr);
    }

    public static final class b {
        private b() {
        }

        public /* synthetic */ b(o oVar) {
            this();
        }

        public final h a(Context context, String[] strArr, int i) {
            ArrayList arrayList;
            r.d(context, "context");
            r.d(strArr, "items");
            ArrayList arrayList2 = new ArrayList(strArr.length);
            for (String str : strArr) {
                com.omarea.a.f.a aVar = new com.omarea.a.f.a();
                aVar.e(str);
                aVar.f(aVar.b());
                arrayList2.add(aVar);
            }
            ArrayList arrayList3 = new ArrayList(arrayList2);
            if (i > -1) {
                arrayList = new ArrayList();
                arrayList.add(arrayList3.get(i));
            } else {
                arrayList = new ArrayList();
            }
            return new h(context, arrayList3, arrayList, false);
        }
    }

    public static final class c implements TextWatcher {
        final /* synthetic */ View f;
        final /* synthetic */ AbsListView g;

        c(View view, AbsListView absListView) {
            this.f = view;
            this.g = absListView;
        }

        @Override // android.text.TextWatcher
        public void afterTextChanged(Editable editable) {
            if (editable != null) {
                View view = this.f;
                r.c(view, "clearBtn");
                view.setVisibility(editable.length() > 0 ? 0 : 8);
            }
        }

        @Override // android.text.TextWatcher
        public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }

        @Override // android.text.TextWatcher
        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            AbsListView absListView = this.g;
            r.c(absListView, "absListView");
            ListAdapter listAdapter = (ListAdapter) absListView.getAdapter();
            if (listAdapter == null) {
                throw new NullPointerException("null cannot be cast to non-null type android.widget.Filterable");
            }
            ((Filterable) listAdapter).getFilter().filter(charSequence == null ? "" : charSequence.toString());
        }
    }

    static final class d implements View.OnClickListener {
        d() {
        }

        @Override // android.view.View.OnClickListener
        public final void onClick(View view) {
            h.this.d();
        }
    }

    static final class e implements View.OnClickListener {
        final /* synthetic */ AbsListView g;

        e(AbsListView absListView) {
            this.g = absListView;
        }

        @Override // android.view.View.OnClickListener
        public final void onClick(View view) {
            h hVar = h.this;
            AbsListView absListView = this.g;
            r.c(absListView, "absListView");
            hVar.e(absListView);
        }
    }

    static final class f implements View.OnClickListener {
        final /* synthetic */ EditText f;

        f(EditText editText) {
            this.f = editText;
        }

        @Override // android.view.View.OnClickListener
        public final void onClick(View view) {
            EditText editText = this.f;
            r.c(editText, "searchBox");
            editText.setText((CharSequence) null);
        }
    }

    public h(Context context, ArrayList<com.omarea.a.f.a> arrayList, ArrayList<com.omarea.a.f.a> arrayList2, boolean z) {
        r.d(context, "context");
        r.d(arrayList, "items");
        r.d(arrayList2, "selectedItems");
        this.g = context;
        this.h = arrayList;
        this.i = arrayList2;
        this.j = z;
        this.f501a = com.omarea.a.b.dialog_item_chooser_small;
        this.f504d = "";
        this.e = "";
    }

    public /* synthetic */ h(Context context, ArrayList arrayList, ArrayList arrayList2, boolean z, int i, o oVar) {
        this(context, arrayList, arrayList2, (i & 8) != 0 ? false : z);
    }

    private final View c() {
        View view = this.f502b;
        if (view != null) {
            r.b(view);
            return view;
        }
        View viewInflate = LayoutInflater.from(this.g).inflate(this.f501a, (ViewGroup) null);
        this.f502b = viewInflate;
        r.c(viewInflate, "view");
        return viewInflate;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void d() {
        com.omarea.common.ui.e.c cVar = this.f503c;
        if (cVar != null) {
            cVar.a();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void e(AbsListView absListView) {
        ListAdapter listAdapter = (ListAdapter) absListView.getAdapter();
        if (listAdapter == null) {
            throw new NullPointerException("null cannot be cast to non-null type com.omarea.common.ui.AdapterItemChooser2");
        }
        com.omarea.common.ui.b bVar = (com.omarea.common.ui.b) listAdapter;
        List<com.omarea.a.f.a> listG = bVar.g();
        boolean[] zArrF = bVar.f();
        a aVar = this.f;
        if (aVar != null) {
            aVar.a(listG, zArrF);
        }
        d();
    }

    private final void f(View view) {
        AbsListView absListView = (AbsListView) view.findViewById(com.omarea.a.a.item_list);
        r.c(absListView, "absListView");
        k(absListView);
        view.findViewById(com.omarea.a.a.btn_cancel).setOnClickListener(new d());
        view.findViewById(com.omarea.a.a.btn_confirm).setOnClickListener(new e(absListView));
        if (this.h.size() > 5) {
            View viewFindViewById = view.findViewById(com.omarea.a.a.search_box_clear);
            EditText editText = (EditText) view.findViewById(com.omarea.a.a.search_box);
            editText.addTextChangedListener(new c(viewFindViewById, absListView));
            r.c(viewFindViewById, "clearBtn");
            r.c(editText, "searchBox");
            Editable text = editText.getText();
            viewFindViewById.setVisibility(text == null || text.length() == 0 ? 8 : 0);
            viewFindViewById.setOnClickListener(new f(editText));
        }
        n();
        m();
    }

    private final void k(AbsListView absListView) {
        Context context = absListView.getContext();
        r.c(context, "gridView.context");
        absListView.setAdapter((ListAdapter) new com.omarea.common.ui.b(context, this.h, this.i, this.j));
    }

    private final void m() {
        View view = this.f502b;
        if (view != null) {
            TextView textView = (TextView) view.findViewById(com.omarea.a.a.dialog_desc);
            textView.setText(this.e);
            textView.setVisibility(this.e.length() > 0 ? 0 : 8);
        }
    }

    private final void n() {
        View view = this.f502b;
        if (view != null) {
            TextView textView = (TextView) view.findViewById(com.omarea.a.a.dialog_title);
            textView.setText(this.f504d);
            textView.setVisibility(this.f504d.length() > 0 ? 0 : 8);
        }
    }

    public final h g(a aVar) {
        this.f = aVar;
        return this;
    }

    public final h h(String str) {
        r.d(str, "message");
        this.e = str;
        m();
        return this;
    }

    public final h i(int i) {
        String string = this.g.getString(i);
        r.c(string, "context.getString(resId)");
        j(string);
        return this;
    }

    public final h j(String str) {
        r.d(str, "title");
        this.f504d = str;
        n();
        return this;
    }

    public final com.omarea.common.ui.e.c l() {
        com.omarea.common.ui.e.c cVar = this.f503c;
        if (cVar == null || !cVar.f()) {
            f(c());
            com.omarea.common.ui.e.a aVar = com.omarea.common.ui.e.f492b;
            Context context = this.g;
            View view = this.f502b;
            r.b(view);
            this.f503c = com.omarea.common.ui.e.a.q(aVar, context, view, false, 4, null);
        }
        com.omarea.common.ui.e.c cVar2 = this.f503c;
        r.b(cVar2);
        return cVar2;
    }
}
