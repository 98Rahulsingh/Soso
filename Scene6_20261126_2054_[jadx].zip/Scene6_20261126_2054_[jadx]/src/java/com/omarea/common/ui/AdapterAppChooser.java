package com.omarea.common.ui;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.util.LruCache;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CompoundButton;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import kotlin.collections.q;
import kotlin.jvm.internal.r;
import kotlin.s;
import kotlin.text.Regex;
import kotlinx.coroutines.CoroutineStart;
import kotlinx.coroutines.h1;
import kotlinx.coroutines.o0;
import kotlinx.coroutines.w0;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class AdapterAppChooser extends BaseAdapter implements Filterable {
    private d f;
    private Filter g;
    private ArrayList<b> h;
    private final Object i;
    private final LruCache<String, Drawable> j;
    private final Context k;
    private ArrayList<b> l;
    private final boolean m;

    public static final class a<T> implements Comparator<T> {
        /* JADX WARN: Multi-variable type inference failed */
        @Override // java.util.Comparator
        public final int compare(T t, T t2) {
            return kotlin.v.a.a(Boolean.valueOf(!((b) t).getSelected()), Boolean.valueOf(!((b) t2).getSelected()));
        }
    }

    public static class b {
        private boolean notFound;
        private boolean selected;
        private String appName = "";
        private String packageName = "";

        public final String getAppName() {
            return this.appName;
        }

        public final boolean getNotFound() {
            return this.notFound;
        }

        public final String getPackageName() {
            return this.packageName;
        }

        public final boolean getSelected() {
            return this.selected;
        }

        public final void setAppName(String str) {
            r.d(str, "<set-?>");
            this.appName = str;
        }

        public final void setNotFound(boolean z) {
            this.notFound = z;
        }

        public final void setPackageName(String str) {
            r.d(str, "<set-?>");
            this.packageName = str;
        }

        public final void setSelected(boolean z) {
            this.selected = z;
        }
    }

    private static final class c extends Filter {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private AdapterAppChooser f476a;

        public c(AdapterAppChooser adapterAppChooser) {
            r.d(adapterAppChooser, "adapter");
            this.f476a = adapterAppChooser;
        }

        private final boolean a(String str, String str2) {
            List listE;
            if (kotlin.text.k.y(str, str2, false, 2, (Object) null)) {
                return true;
            }
            List listSplit = new Regex(" ").split(str, 0);
            if (listSplit.isEmpty()) {
                listE = q.e();
                break;
            }
            ListIterator listIterator = listSplit.listIterator(listSplit.size());
            while (true) {
                if (!listIterator.hasPrevious()) {
                    listE = q.e();
                    break;
                }
                if (!(((String) listIterator.previous()).length() == 0)) {
                    listE = q.Q(listSplit, listIterator.nextIndex() + 1);
                    break;
                }
            }
            Object[] array = listE.toArray(new String[0]);
            if (array == null) {
                throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T>");
            }
            for (String str3 : (String[]) array) {
                if (kotlin.text.k.y(str3, str2, false, 2, (Object) null)) {
                    return true;
                }
            }
            return false;
        }

        /* JADX WARN: Code duplicated, block: B:29:0x007e  */
        @Override // android.widget.Filter
        protected Filter.FilterResults performFiltering(CharSequence charSequence) {
            ArrayList arrayList;
            int size;
            ArrayList arrayList2;
            Filter.FilterResults filterResults = new Filter.FilterResults();
            String string = charSequence == null ? "" : charSequence.toString();
            if (string.length() == 0) {
                synchronized (this.f476a.i) {
                    arrayList2 = new ArrayList(this.f476a.l);
                    s sVar = s.a;
                }
                filterResults.values = arrayList2;
                size = arrayList2.size();
            } else {
                if (string == null) {
                    throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                }
                String lowerCase = string.toLowerCase();
                r.c(lowerCase, "(this as java.lang.String).toLowerCase()");
                synchronized (this.f476a.i) {
                    arrayList = new ArrayList(this.f476a.l);
                    s sVar2 = s.a;
                }
                List<b> listI = this.f476a.i();
                int size2 = arrayList.size();
                ArrayList arrayList3 = new ArrayList();
                for (int i = 0; i < size2; i++) {
                    Object obj = arrayList.get(i);
                    r.c(obj, "values[i]");
                    b bVar = (b) obj;
                    if (listI.contains(bVar)) {
                        arrayList3.add(bVar);
                    } else {
                        String appName = bVar.getAppName();
                        if (appName == null) {
                            throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                        }
                        String lowerCase2 = appName.toLowerCase();
                        r.c(lowerCase2, "(this as java.lang.String).toLowerCase()");
                        String packageName = bVar.getPackageName();
                        if (packageName == null) {
                            throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                        }
                        String lowerCase3 = packageName.toLowerCase();
                        r.c(lowerCase3, "(this as java.lang.String).toLowerCase()");
                        if (a(lowerCase2, lowerCase) || a(lowerCase3, lowerCase)) {
                            arrayList3.add(bVar);
                        }
                    }
                }
                filterResults.values = arrayList3;
                size = arrayList3.size();
            }
            filterResults.count = size;
            return filterResults;
        }

        @Override // android.widget.Filter
        protected void publishResults(CharSequence charSequence, Filter.FilterResults filterResults) {
            AdapterAppChooser adapterAppChooser = this.f476a;
            r.b(filterResults);
            Object obj = filterResults.values;
            if (obj == null) {
                throw new NullPointerException("null cannot be cast to non-null type java.util.ArrayList<com.omarea.common.ui.AdapterAppChooser.AppInfo>");
            }
            adapterAppChooser.k((ArrayList) obj);
            if (filterResults.count > 0) {
                this.f476a.notifyDataSetChanged();
            } else {
                this.f476a.notifyDataSetInvalidated();
            }
        }
    }

    public interface d {
        void a(List<? extends b> list);
    }

    public final class e {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private TextView f477a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private TextView f478b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private ImageView f479c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        private CompoundButton f480d;

        public e(AdapterAppChooser adapterAppChooser) {
        }

        public final CompoundButton a() {
            return this.f480d;
        }

        public final ImageView b() {
            return this.f479c;
        }

        public final TextView c() {
            return this.f478b;
        }

        public final TextView d() {
            return this.f477a;
        }

        public final void e(CompoundButton compoundButton) {
            this.f480d = compoundButton;
        }

        public final void f(ImageView imageView) {
            this.f479c = imageView;
        }

        public final void g(TextView textView) {
            this.f478b = textView;
        }

        public final void h(TextView textView) {
            this.f477a = textView;
        }

        public final void i(String str) {
        }
    }

    static final class f implements View.OnClickListener {
        final /* synthetic */ b g;
        final /* synthetic */ e h;

        f(b bVar, e eVar) {
            this.g = bVar;
            this.h = eVar;
        }

        @Override // android.view.View.OnClickListener
        public final void onClick(View view) {
            Object next;
            if (!AdapterAppChooser.this.m && !this.g.getSelected()) {
                Iterator it = AdapterAppChooser.this.l.iterator();
                do {
                    if (!it.hasNext()) {
                        next = null;
                        break;
                    }
                    next = it.next();
                } while (!((b) next).getSelected());
                b bVar = (b) next;
                if (bVar != null) {
                    bVar.setSelected(false);
                }
                this.g.setSelected(true);
                AdapterAppChooser.this.notifyDataSetChanged();
            } else if (AdapterAppChooser.this.m) {
                b bVar2 = this.g;
                bVar2.setSelected(true ^ bVar2.getSelected());
                CompoundButton compoundButtonA = this.h.a();
                if (compoundButtonA != null) {
                    compoundButtonA.setChecked(this.g.getSelected());
                }
            }
            d dVar = AdapterAppChooser.this.f;
            if (dVar != null) {
                dVar.a(AdapterAppChooser.this.i());
            }
        }
    }

    public AdapterAppChooser(Context context, ArrayList<b> arrayList, boolean z) {
        r.d(context, "context");
        r.d(arrayList, "apps");
        this.k = context;
        this.l = arrayList;
        this.m = z;
        this.h = arrayList;
        this.i = new Object();
        this.j = new LruCache<>(100);
        ArrayList<b> arrayList2 = this.h;
        if (arrayList2.size() > 1) {
            q.l(arrayList2, new a());
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final o0<Drawable> j(b bVar) {
        return kotlinx.coroutines.f.b(h1.f, w0.b(), (CoroutineStart) null, new AdapterAppChooser$loadIcon$1(this, bVar, null), 2, (Object) null);
    }

    @Override // android.widget.Adapter
    public int getCount() {
        return this.h.size();
    }

    @Override // android.widget.Filterable
    public Filter getFilter() {
        if (this.g == null) {
            this.g = new c(this);
        }
        Filter filter = this.g;
        r.b(filter);
        return filter;
    }

    @Override // android.widget.Adapter
    public long getItemId(int i) {
        return i;
    }

    @Override // android.widget.Adapter
    public View getView(int i, View view, ViewGroup viewGroup) {
        r.d(viewGroup, "parent");
        if (view == null) {
            view = View.inflate(this.k, this.m ? com.omarea.a.b.app_multiple_chooser_item : com.omarea.a.b.app_single_chooser_item, null);
        }
        r.b(view);
        n(i, view);
        return view;
    }

    @Override // android.widget.Adapter
    /* JADX INFO: renamed from: h, reason: merged with bridge method [inline-methods] */
    public b getItem(int i) {
        b bVar = this.h.get(i);
        r.c(bVar, "filterApps[position]");
        return bVar;
    }

    public final List<b> i() {
        ArrayList<b> arrayList = this.l;
        ArrayList arrayList2 = new ArrayList();
        for (Object obj : arrayList) {
            if (((b) obj).getSelected()) {
                arrayList2.add(obj);
            }
        }
        return arrayList2;
    }

    public final void k(ArrayList<b> arrayList) {
        r.d(arrayList, "<set-?>");
        this.h = arrayList;
    }

    public final void l(boolean z) {
        Iterator<T> it = this.l.iterator();
        while (it.hasNext()) {
            ((b) it.next()).setSelected(z);
        }
        notifyDataSetChanged();
    }

    public final void m(d dVar) {
        this.f = dVar;
    }

    public final void n(int i, View view) {
        e eVar;
        r.d(view, "convertView");
        b item = getItem(i);
        if (view.getTag() != null) {
            Object tag = view.getTag();
            if (tag == null) {
                throw new NullPointerException("null cannot be cast to non-null type com.omarea.common.ui.AdapterAppChooser.ViewHolder");
            }
            eVar = (e) tag;
        } else {
            eVar = new e(this);
            eVar.h((TextView) view.findViewById(com.omarea.a.a.ItemTitle));
            eVar.g((TextView) view.findViewById(com.omarea.a.a.ItemDesc));
            eVar.f((ImageView) view.findViewById(com.omarea.a.a.ItemIcon));
            eVar.e((CompoundButton) view.findViewById(com.omarea.a.a.ItemChecBox));
        }
        String packageName = item.getPackageName();
        eVar.i(packageName);
        view.setOnClickListener(new f(item, eVar));
        TextView textViewD = eVar.d();
        if (textViewD != null) {
            textViewD.setText(item.getAppName());
        }
        TextView textViewC = eVar.c();
        if (textViewC != null) {
            textViewC.setText(item.getPackageName());
        }
        CompoundButton compoundButtonA = eVar.a();
        if (compoundButtonA != null) {
            compoundButtonA.setChecked(item.getSelected());
        }
        ImageView imageViewB = eVar.b();
        r.b(imageViewB);
        imageViewB.setTag(packageName);
        kotlinx.coroutines.f.d(h1.f, w0.c(), (CoroutineStart) null, new AdapterAppChooser$updateRow$$inlined$run$lambda$1(imageViewB, null, this, item, packageName), 2, (Object) null);
    }
}
