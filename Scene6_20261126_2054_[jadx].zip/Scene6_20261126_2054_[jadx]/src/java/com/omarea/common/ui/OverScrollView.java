package com.omarea.common.ui;

import android.content.Context;
import android.util.AttributeSet;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class OverScrollView extends d.b.a.c {
    public OverScrollView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }
}
