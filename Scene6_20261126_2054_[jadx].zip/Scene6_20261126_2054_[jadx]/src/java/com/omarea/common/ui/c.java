package com.omarea.common.ui;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.AbsListView;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Filterable;
import android.widget.ListAdapter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import kotlin.jvm.internal.r;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class c extends com.omarea.common.ui.d {
    private boolean r0;
    private String[] s0;
    private ArrayList<AdapterAppChooser.b> t0;
    private final boolean u0;
    private a v0;
    private HashMap w0;

    public interface a {
        void a(List<? extends AdapterAppChooser.b> list);
    }

    public static final class b implements TextWatcher {
        final /* synthetic */ View f;
        final /* synthetic */ AbsListView g;

        b(View view, AbsListView absListView) {
            this.f = view;
            this.g = absListView;
        }

        @Override // android.text.TextWatcher
        public void afterTextChanged(Editable editable) {
            if (editable != null) {
                View view = this.f;
                r.c(view, "clearBtn");
                view.setVisibility(editable.length() > 0 ? 0 : 8);
            }
        }

        @Override // android.text.TextWatcher
        public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }

        @Override // android.text.TextWatcher
        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            AbsListView absListView = this.g;
            r.c(absListView, "absListView");
            ListAdapter listAdapter = (ListAdapter) absListView.getAdapter();
            if (listAdapter == null) {
                throw new NullPointerException("null cannot be cast to non-null type android.widget.Filterable");
            }
            ((Filterable) listAdapter).getFilter().filter(charSequence == null ? "" : charSequence.toString());
        }
    }

    /* JADX INFO: renamed from: com.omarea.common.ui.c$c, reason: collision with other inner class name */
    public static final class C0048c implements AdapterAppChooser.d {

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final /* synthetic */ CompoundButton f490b;

        C0048c(CompoundButton compoundButton) {
            this.f490b = compoundButton;
        }

        @Override // com.omarea.common.ui.AdapterAppChooser.d
        public void a(List<? extends AdapterAppChooser.b> list) {
            r.d(list, "selected");
            this.f490b.setChecked(list.size() == c.this.t0.size());
        }
    }

    static final class d implements View.OnClickListener {
        d() {
        }

        @Override // android.view.View.OnClickListener
        public final void onClick(View view) {
            c.this.y1();
        }
    }

    static final class e implements View.OnClickListener {
        final /* synthetic */ AbsListView g;

        e(AbsListView absListView) {
            this.g = absListView;
        }

        @Override // android.view.View.OnClickListener
        public final void onClick(View view) {
            c cVar = c.this;
            AbsListView absListView = this.g;
            r.c(absListView, "absListView");
            cVar.I1(absListView);
        }
    }

    static final class f implements View.OnClickListener {
        final /* synthetic */ AdapterAppChooser f;

        f(AdapterAppChooser adapterAppChooser) {
            this.f = adapterAppChooser;
        }

        @Override // android.view.View.OnClickListener
        public final void onClick(View view) {
            AdapterAppChooser adapterAppChooser = this.f;
            if (adapterAppChooser != null) {
                if (view == null) {
                    throw new NullPointerException("null cannot be cast to non-null type android.widget.CompoundButton");
                }
                adapterAppChooser.l(((CompoundButton) view).isChecked());
            }
        }
    }

    static final class g implements View.OnClickListener {
        final /* synthetic */ EditText f;

        g(EditText editText) {
            this.f = editText;
        }

        @Override // android.view.View.OnClickListener
        public final void onClick(View view) {
            EditText editText = this.f;
            r.c(editText, "searchBox");
            editText.setText((CharSequence) null);
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public c(boolean z, ArrayList<AdapterAppChooser.b> arrayList, boolean z2, a aVar) {
        super(com.omarea.a.b.dialog_app_chooser, z);
        r.d(arrayList, "packages");
        this.t0 = arrayList;
        this.u0 = z2;
        this.v0 = aVar;
        this.r0 = true;
        this.s0 = new String[0];
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void I1(AbsListView absListView) {
        ListAdapter listAdapter = (ListAdapter) absListView.getAdapter();
        if (listAdapter == null) {
            throw new NullPointerException("null cannot be cast to non-null type com.omarea.common.ui.AdapterAppChooser");
        }
        List<AdapterAppChooser.b> listI = ((AdapterAppChooser) listAdapter).i();
        a aVar = this.v0;
        if (aVar != null) {
            aVar.a(listI);
        }
        y1();
    }

    private final void L1(AbsListView absListView) {
        ArrayList<AdapterAppChooser.b> arrayList = this.t0;
        ArrayList arrayList2 = new ArrayList();
        for (Object obj : arrayList) {
            if (!kotlin.collections.h.j(this.s0, ((AdapterAppChooser.b) obj).getPackageName())) {
                arrayList2.add(obj);
            }
        }
        ArrayList arrayList3 = new ArrayList(arrayList2);
        Context context = absListView.getContext();
        r.c(context, "gridView.context");
        absListView.setAdapter((ListAdapter) new AdapterAppChooser(context, arrayList3, this.u0));
    }

    /* JADX WARN: Code duplicated, block: B:21:0x009b  */
    @Override // com.omarea.common.ui.d
    public void E0(View view, Bundle bundle) {
        r.d(view, "view");
        super.E0(view, bundle);
        AbsListView absListView = (AbsListView) view.findViewById(com.omarea.a.a.app_list);
        r.c(absListView, "absListView");
        L1(absListView);
        view.findViewById(com.omarea.a.a.btn_cancel).setOnClickListener(new d());
        view.findViewById(com.omarea.a.a.btn_confirm).setOnClickListener(new e(absListView));
        CompoundButton compoundButton = (CompoundButton) view.findViewById(com.omarea.a.a.select_all);
        boolean z = true;
        if (compoundButton != null) {
            if (this.u0) {
                AdapterAppChooser adapterAppChooser = (AdapterAppChooser) ((ListAdapter) absListView.getAdapter());
                compoundButton.setVisibility(0);
                ArrayList<AdapterAppChooser.b> arrayList = this.t0;
                ArrayList arrayList2 = new ArrayList();
                for (Object obj : arrayList) {
                    if (((AdapterAppChooser.b) obj).getSelected()) {
                        arrayList2.add(obj);
                    }
                }
                compoundButton.setChecked(arrayList2.size() == this.t0.size());
                compoundButton.setOnClickListener(new f(adapterAppChooser));
                if (adapterAppChooser != null) {
                    adapterAppChooser.m(new C0048c(compoundButton));
                }
                if (!this.r0) {
                    compoundButton.setVisibility(8);
                }
            } else {
                compoundButton.setVisibility(8);
            }
        }
        View viewFindViewById = view.findViewById(com.omarea.a.a.search_box_clear);
        EditText editText = (EditText) view.findViewById(com.omarea.a.a.search_box);
        editText.addTextChangedListener(new b(viewFindViewById, absListView));
        r.c(viewFindViewById, "clearBtn");
        r.c(editText, "searchBox");
        Editable text = editText.getText();
        if (text != null && text.length() != 0) {
            z = false;
        }
        viewFindViewById.setVisibility(z ? 8 : 0);
        viewFindViewById.setOnClickListener(new g(editText));
    }

    @Override // com.omarea.common.ui.d
    public void F1() {
        HashMap map = this.w0;
        if (map != null) {
            map.clear();
        }
    }

    public final c J1(boolean z) {
        CompoundButton compoundButton;
        this.r0 = z;
        View viewN = N();
        if (viewN != null && (compoundButton = (CompoundButton) viewN.findViewById(com.omarea.a.a.select_all)) != null) {
            compoundButton.setVisibility(z ? 0 : 8);
        }
        return this;
    }

    public final c K1(String[] strArr) {
        r.d(strArr, "apps");
        this.s0 = strArr;
        if (N() != null) {
            Log.e("@DialogAppChooser", "Unable to set the exclusion list, The list has been loaded");
        }
        return this;
    }

    @Override // com.omarea.common.ui.d
    public void Z(Bundle bundle) {
        super.Z(bundle);
    }

    @Override // com.omarea.common.ui.d
    public /* synthetic */ void m0() {
        super.m0();
        F1();
    }

    public void onDismiss(DialogInterface dialogInterface) {
        r.d(dialogInterface, "dialog");
        super.onDismiss(dialogInterface);
    }
}
