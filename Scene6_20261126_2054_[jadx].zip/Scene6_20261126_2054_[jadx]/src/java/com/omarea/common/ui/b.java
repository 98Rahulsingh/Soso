package com.omarea.common.ui;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CompoundButton;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import kotlin.collections.q;
import kotlin.jvm.internal.r;
import kotlin.s;
import kotlin.text.Regex;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class b extends BaseAdapter implements Filterable {
    private Filter f;
    private ArrayList<com.omarea.a.f.a> g;
    private final Object h;
    private final ArrayList<com.omarea.a.f.a> i;
    private final Context j;
    private ArrayList<com.omarea.a.f.a> k;
    private ArrayList<com.omarea.a.f.a> l;
    private final boolean m;

    private static final class a extends Filter {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private b f485a;

        public a(b bVar) {
            r.d(bVar, "adapter");
            this.f485a = bVar;
        }

        @Override // android.widget.Filter
        protected Filter.FilterResults performFiltering(CharSequence charSequence) {
            ArrayList arrayList;
            int size;
            String lowerCase;
            List listE;
            ArrayList arrayList2;
            Filter.FilterResults filterResults = new Filter.FilterResults();
            String string = charSequence == null ? "" : charSequence.toString();
            int i = 1;
            if (string.length() == 0) {
                synchronized (this.f485a.h) {
                    arrayList2 = new ArrayList(this.f485a.k);
                    s sVar = s.a;
                }
                filterResults.values = arrayList2;
                size = arrayList2.size();
            } else {
                if (string == null) {
                    throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                }
                String lowerCase2 = string.toLowerCase();
                r.c(lowerCase2, "(this as java.lang.String).toLowerCase()");
                synchronized (this.f485a.h) {
                    arrayList = new ArrayList(this.f485a.k);
                    s sVar2 = s.a;
                }
                ArrayList arrayList3 = this.f485a.i;
                int size2 = arrayList.size();
                ArrayList arrayList4 = new ArrayList();
                int i2 = 0;
                while (i2 < size2) {
                    Object obj = arrayList.get(i2);
                    r.c(obj, "values[i]");
                    com.omarea.a.f.a aVar = (com.omarea.a.f.a) obj;
                    if (aVar.b() == null) {
                        lowerCase = "";
                    } else {
                        String strB = aVar.b();
                        r.b(strB);
                        if (strB == null) {
                            throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                        }
                        lowerCase = strB.toLowerCase();
                        r.c(lowerCase, "(this as java.lang.String).toLowerCase()");
                    }
                    if (arrayList3.contains(aVar) || kotlin.text.k.y(lowerCase, lowerCase2, false, 2, (Object) null)) {
                        arrayList4.add(aVar);
                        break;
                        break;
                    }
                    List listSplit = new Regex(" ").split(lowerCase, 0);
                    if (listSplit.isEmpty()) {
                        listE = q.e();
                        break;
                    }
                    ListIterator listIterator = listSplit.listIterator(listSplit.size());
                    while (true) {
                        if (!listIterator.hasPrevious()) {
                            listE = q.e();
                            break;
                        }
                        if ((((String) listIterator.previous()).length() == 0 ? i : 0) == 0) {
                            listE = q.Q(listSplit, listIterator.nextIndex() + i);
                            break;
                        }
                    }
                    Object[] array = listE.toArray(new String[0]);
                    if (array == null) {
                        throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T>");
                    }
                    for (String str : (String[]) array) {
                        if (kotlin.text.k.y(str, lowerCase2, false, 2, (Object) null)) {
                            arrayList4.add(aVar);
                            break;
                        }
                    }
                    i2++;
                    i = 1;
                }
                filterResults.values = arrayList4;
                size = arrayList4.size();
            }
            filterResults.count = size;
            return filterResults;
        }

        @Override // android.widget.Filter
        protected void publishResults(CharSequence charSequence, Filter.FilterResults filterResults) {
            b bVar = this.f485a;
            r.b(filterResults);
            Object obj = filterResults.values;
            if (obj == null) {
                throw new NullPointerException("null cannot be cast to non-null type java.util.ArrayList<com.omarea.common.model.SelectItem>");
            }
            bVar.h((ArrayList) obj);
            if (filterResults.count > 0) {
                this.f485a.notifyDataSetChanged();
            } else {
                this.f485a.notifyDataSetInvalidated();
            }
        }
    }

    /* JADX INFO: renamed from: com.omarea.common.ui.b$b, reason: collision with other inner class name */
    public final class C0047b {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private TextView f486a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private TextView f487b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private CompoundButton f488c;

        public C0047b(b bVar) {
        }

        public final CompoundButton a() {
            return this.f488c;
        }

        public final TextView b() {
            return this.f487b;
        }

        public final TextView c() {
            return this.f486a;
        }

        public final void d(CompoundButton compoundButton) {
            this.f488c = compoundButton;
        }

        public final void e(ImageView imageView) {
        }

        public final void f(TextView textView) {
            this.f487b = textView;
        }

        public final void g(TextView textView) {
            this.f486a = textView;
        }
    }

    static final class c implements View.OnClickListener {
        final /* synthetic */ com.omarea.a.f.a g;
        final /* synthetic */ C0047b h;

        c(com.omarea.a.f.a aVar, C0047b c0047b) {
            this.g = aVar;
            this.h = c0047b;
        }

        @Override // android.view.View.OnClickListener
        public final void onClick(View view) {
            CompoundButton compoundButtonA;
            boolean z;
            if (b.this.i.contains(this.g)) {
                if (!b.this.m) {
                    return;
                }
                b.this.i.remove(this.g);
                compoundButtonA = this.h.a();
                if (compoundButtonA == null) {
                    return;
                } else {
                    z = false;
                }
            } else if (!b.this.m) {
                b.this.i.clear();
                b.this.i.add(this.g);
                b.this.notifyDataSetChanged();
                return;
            } else {
                b.this.i.add(this.g);
                compoundButtonA = this.h.a();
                if (compoundButtonA == null) {
                    return;
                } else {
                    z = true;
                }
            }
            compoundButtonA.setChecked(z);
        }
    }

    public b(Context context, ArrayList<com.omarea.a.f.a> arrayList, ArrayList<com.omarea.a.f.a> arrayList2, boolean z) {
        r.d(context, "context");
        r.d(arrayList, "items");
        r.d(arrayList2, "selectedItems");
        this.j = context;
        this.k = arrayList;
        this.l = arrayList2;
        this.m = z;
        this.g = arrayList;
        this.h = new Object();
        ArrayList<com.omarea.a.f.a> arrayList3 = new ArrayList<>();
        Iterator<T> it = this.l.iterator();
        while (it.hasNext()) {
            arrayList3.add((com.omarea.a.f.a) it.next());
        }
        s sVar = s.a;
        this.i = arrayList3;
    }

    @Override // android.widget.Adapter
    /* JADX INFO: renamed from: e, reason: merged with bridge method [inline-methods] */
    public com.omarea.a.f.a getItem(int i) {
        com.omarea.a.f.a aVar = this.g.get(i);
        r.c(aVar, "filterItems[position]");
        return aVar;
    }

    public final boolean[] f() {
        ArrayList<com.omarea.a.f.a> arrayList = this.k;
        ArrayList arrayList2 = new ArrayList(q.k(arrayList, 10));
        Iterator<T> it = arrayList.iterator();
        while (it.hasNext()) {
            arrayList2.add(Boolean.valueOf(this.i.contains((com.omarea.a.f.a) it.next())));
        }
        return q.R(arrayList2);
    }

    public final List<com.omarea.a.f.a> g() {
        return this.i;
    }

    @Override // android.widget.Adapter
    public int getCount() {
        return this.g.size();
    }

    @Override // android.widget.Filterable
    public Filter getFilter() {
        if (this.f == null) {
            this.f = new a(this);
        }
        Filter filter = this.f;
        r.b(filter);
        return filter;
    }

    @Override // android.widget.Adapter
    public long getItemId(int i) {
        return i;
    }

    @Override // android.widget.Adapter
    public View getView(int i, View view, ViewGroup viewGroup) {
        r.d(viewGroup, "parent");
        if (view == null) {
            view = View.inflate(this.j, this.m ? com.omarea.a.b.item_multiple_chooser_item : com.omarea.a.b.item_single_chooser_item, null);
        }
        r.b(view);
        i(i, view);
        return view;
    }

    public final void h(ArrayList<com.omarea.a.f.a> arrayList) {
        r.d(arrayList, "<set-?>");
        this.g = arrayList;
    }

    public final void i(int i, View view) {
        r.d(view, "convertView");
        com.omarea.a.f.a item = getItem(i);
        C0047b c0047b = new C0047b(this);
        c0047b.g((TextView) view.findViewById(com.omarea.a.a.ItemTitle));
        c0047b.f((TextView) view.findViewById(com.omarea.a.a.ItemDesc));
        c0047b.e((ImageView) view.findViewById(com.omarea.a.a.ItemIcon));
        c0047b.d((CompoundButton) view.findViewById(com.omarea.a.a.ItemChecBox));
        view.setOnClickListener(new c(item, c0047b));
        TextView textViewC = c0047b.c();
        if (textViewC != null) {
            textViewC.setText(item.b());
        }
        TextView textViewB = c0047b.b();
        if (textViewB != null) {
            String strB = item.b();
            if (strB == null || strB.length() == 0) {
                textViewB.setText(item.b());
            } else {
                textViewB.setVisibility(8);
            }
        }
        CompoundButton compoundButtonA = c0047b.a();
        if (compoundButtonA != null) {
            compoundButtonA.setChecked(this.i.contains(item));
        }
    }
}
