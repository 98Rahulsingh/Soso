package com.omarea.common.ui;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;
import kotlin.jvm.internal.r;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class ProgressCircle extends View {
    private int f;
    private int g;
    private float h;
    private float i;
    private int j;
    private Paint k;
    private Paint l;
    private Paint m;
    private final int n;
    private int o;
    private int p;
    private float q;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public ProgressCircle(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        r.d(context, "context");
        r.d(attributeSet, "attrs");
        this.h = 300.0f;
        this.i = 10.0f;
        this.j = 20;
        this.n = -7829368;
        this.q = 35.0f;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, com.omarea.a.e.ProgressState);
        this.f = (int) ((((double) typedArrayObtainStyledAttributes.getInteger(com.omarea.a.e.ProgressState_current, 1)) * 100.0d) / ((double) typedArrayObtainStyledAttributes.getInteger(com.omarea.a.e.ProgressState_total, 1)));
        typedArrayObtainStyledAttributes.recycle();
    }

    private final int a(Context context, float f) {
        Resources resources = context.getResources();
        r.c(resources, "context.resources");
        return (int) ((f * resources.getDisplayMetrics().density) + 0.5f);
    }

    /* JADX WARN: Code duplicated, block: B:21:0x0074  */
    /* JADX WARN: Code duplicated, block: B:22:0x008b  */
    private final void b(Canvas canvas) {
        Paint paint;
        int iRgb;
        Paint paint2 = this.k;
        r.b(paint2);
        paint2.setColor(579373192);
        float f = this.h;
        RectF rectF = new RectF(0.0f, 0.0f, f, f);
        Paint paint3 = this.k;
        r.b(paint3);
        canvas.drawArc(rectF, 0.0f, 360.0f, false, paint3);
        float f2 = this.q;
        if (f2 < 48 && this.g >= 11) {
            if (f2 > 44 || this.f < 16) {
                paint = this.k;
                r.b(paint);
                iRgb = -65536;
            }
            Paint paint4 = this.k;
            r.b(paint4);
            paint4.setStrokeCap(Paint.Cap.ROUND);
            if (this.f < 1 || this.g > 2) {
                if (this.g >= 98) {
                    float f3 = this.h;
                    RectF rectF2 = new RectF(0.0f, 0.0f, f3, f3);
                    Paint paint5 = this.k;
                    r.b(paint5);
                    canvas.drawArc(rectF2, -90.0f, 360.0f, false, paint5);
                    return;
                }
                float f4 = this.h;
                RectF rectF3 = new RectF(0.0f, 0.0f, f4, f4);
                float f5 = this.g * 3.6f;
                Paint paint6 = this.k;
                r.b(paint6);
                canvas.drawArc(rectF3, -90.0f, f5, false, paint6);
            }
            return;
        }
        paint = this.k;
        r.b(paint);
        iRgb = Color.rgb(255, 15, 0);
        paint.setColor(iRgb);
        Paint paint7 = this.k;
        r.b(paint7);
        paint7.setStrokeCap(Paint.Cap.ROUND);
        if (this.f < 1) {
        }
        if (this.g >= 98) {
            float f6 = this.h;
            RectF rectF4 = new RectF(0.0f, 0.0f, f6, f6);
            Paint paint8 = this.k;
            r.b(paint8);
            canvas.drawArc(rectF4, -90.0f, 360.0f, false, paint8);
            return;
        }
        float f7 = this.h;
        RectF rectF5 = new RectF(0.0f, 0.0f, f7, f7);
        float f8 = this.g * 3.6f;
        Paint paint9 = this.k;
        r.b(paint9);
        canvas.drawArc(rectF5, -90.0f, f8, false, paint9);
    }

    private final void c() {
        Paint paint = new Paint();
        this.k = paint;
        r.b(paint);
        paint.setAntiAlias(true);
        Paint paint2 = this.k;
        r.b(paint2);
        paint2.setStyle(Paint.Style.STROKE);
        Paint paint3 = this.k;
        r.b(paint3);
        paint3.setStrokeWidth(this.i);
        Paint paint4 = new Paint();
        this.l = paint4;
        r.b(paint4);
        paint4.setAntiAlias(true);
        Paint paint5 = this.l;
        r.b(paint5);
        paint5.setColor(this.n);
        Paint paint6 = this.l;
        r.b(paint6);
        paint6.setStyle(Paint.Style.STROKE);
        Paint paint7 = this.l;
        r.b(paint7);
        paint7.setStrokeWidth(1.0f);
        Paint paint8 = this.l;
        r.b(paint8);
        paint8.setTextSize(this.j);
        Paint paint9 = new Paint();
        this.m = paint9;
        r.b(paint9);
        paint9.setAntiAlias(true);
        Paint paint10 = this.m;
        r.b(paint10);
        paint10.setStyle(Paint.Style.FILL);
        Paint paint11 = this.m;
        r.b(paint11);
        paint11.setStrokeWidth(20.0f);
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        r.d(canvas, "canvas");
        super.onDraw(canvas);
        float f = this.p / 2;
        float f2 = this.h;
        float f3 = 2;
        canvas.translate(f - (f2 / f3), (this.o / 2) - (f2 / f3));
        c();
        b(canvas);
    }

    @Override // android.view.View
    protected void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        this.p = i;
        this.o = i2;
        Context context = getContext();
        r.c(context, "context");
        int iA = a(context, 10.0f);
        this.i = iA;
        Context context2 = getContext();
        r.c(context2, "context");
        this.j = a(context2, 18.0f);
        this.h = (int) (((i > i2 ? i2 : i) * 0.9d) - ((double) iA));
    }
}
