package com.omarea.common.ui;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import java.io.IOException;
import java.util.LinkedHashMap;
import kotlin.jvm.internal.o;
import kotlin.jvm.internal.r;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class j {
    private static final LinkedHashMap<String, e.c> e = new LinkedHashMap<>();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private e.c f505a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private TextView f506b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private Activity f507c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private String f508d;

    public static final class a extends Handler {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private e.c f509a;

        /* JADX WARN: Illegal instructions before constructor call */
        public a(e.c cVar) {
            Looper looperMyLooper = Looper.myLooper();
            r.b(looperMyLooper);
            super(looperMyLooper);
            this.f509a = cVar;
        }

        @Override // android.os.Handler
        public void handleMessage(Message message) {
            Context contextB;
            int i;
            Toast toastMakeText;
            r.d(message, "msg");
            super.handleMessage(message);
            try {
                if (this.f509a == null) {
                    return;
                }
                if (message.what == 10) {
                    e.c cVar = this.f509a;
                    r.b(cVar);
                    cVar.a();
                    e.c cVar2 = this.f509a;
                    r.b(cVar2);
                    cVar2.d();
                    if (r.a(message.obj, Boolean.TRUE)) {
                        e.c cVar3 = this.f509a;
                        r.b(cVar3);
                        toastMakeText = Toast.makeText(cVar3.b(), com.omarea.a.c.execute_success, 0);
                    } else {
                        e.c cVar4 = this.f509a;
                        r.b(cVar4);
                        contextB = cVar4.b();
                        i = com.omarea.a.c.execute_fail;
                    }
                    toastMakeText.show();
                }
                if (message.what == -1) {
                    e.c cVar5 = this.f509a;
                    r.b(cVar5);
                    contextB = cVar5.b();
                    i = com.omarea.a.c.execute_fail;
                } else {
                    if (message.what != 0 || !r.a(message.obj, Boolean.FALSE)) {
                        return;
                    }
                    e.c cVar6 = this.f509a;
                    r.b(cVar6);
                    cVar6.a();
                    e.c cVar7 = this.f509a;
                    r.b(cVar7);
                    cVar7.d();
                    e.c cVar8 = this.f509a;
                    r.b(cVar8);
                    contextB = cVar8.b();
                    i = com.omarea.a.c.execute_fail;
                }
                toastMakeText = Toast.makeText(contextB, i, 1);
                toastMakeText.show();
            } catch (Exception unused) {
            }
        }
    }

    public j(Activity activity, String str) {
        r.d(activity, "context");
        this.f507c = activity;
        this.f508d = str;
        c();
    }

    public /* synthetic */ j(Activity activity, String str, int i, o oVar) {
        this(activity, (i & 2) != 0 ? null : str);
    }

    public static /* synthetic */ void b(j jVar, String str, Handler handler, int i, Object obj) throws IOException {
        if (obj != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: execShell");
        }
        if ((i & 2) != 0) {
            handler = null;
        }
        jVar.a(str, handler);
    }

    public static /* synthetic */ j e(j jVar, String str, int i, Object obj) {
        if (obj != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: showDialog");
        }
        if ((i & 1) != 0) {
            str = jVar.f507c.getString(com.omarea.a.c.execute_wait);
            r.c(str, "context.getString(R.string.execute_wait)");
        }
        jVar.d(str);
        return jVar;
    }

    @SuppressLint({"InflateParams"})
    public final void a(String str, Handler handler) throws IOException {
        r.d(str, "cmd");
        c();
        View viewInflate = LayoutInflater.from(this.f507c).inflate(com.omarea.a.b.dialog_loading, (ViewGroup) null);
        View viewFindViewById = viewInflate.findViewById(com.omarea.a.a.dialog_text);
        if (viewFindViewById == null) {
            throw new NullPointerException("null cannot be cast to non-null type android.widget.TextView");
        }
        ((TextView) viewFindViewById).setText(this.f507c.getString(com.omarea.a.c.execute_wait));
        e.a aVar = e.f492b;
        Activity activity = this.f507c;
        r.c(viewInflate, "dialog");
        this.f505a = aVar.p(activity, viewInflate, false);
        if (handler == null) {
            com.omarea.common.shell.a aVar2 = new com.omarea.common.shell.a(new a(this.f505a));
            aVar2.b(str);
            aVar2.f();
        } else {
            com.omarea.common.shell.a aVar3 = new com.omarea.common.shell.a(handler);
            aVar3.b(str);
            aVar3.f();
        }
    }

    public final void c() {
        try {
            if (this.f505a != null) {
                e.c cVar = this.f505a;
                r.b(cVar);
                cVar.a();
                e.c cVar2 = this.f505a;
                r.b(cVar2);
                cVar2.d();
                this.f505a = null;
            }
        } catch (Exception unused) {
        }
        String str = this.f508d;
        if (str == null || !e.containsKey(str)) {
            return;
        }
        e.remove(str);
    }

    @SuppressLint({"InflateParams"})
    public final j d(String str) {
        r.d(str, "text");
        TextView textView = this.f506b;
        if (textView == null || this.f505a == null) {
            c();
            View viewInflate = LayoutInflater.from(this.f507c).inflate(com.omarea.a.b.dialog_loading, (ViewGroup) null);
            View viewFindViewById = viewInflate.findViewById(com.omarea.a.a.dialog_text);
            if (viewFindViewById == null) {
                throw new NullPointerException("null cannot be cast to non-null type android.widget.TextView");
            }
            TextView textView2 = (TextView) viewFindViewById;
            this.f506b = textView2;
            r.b(textView2);
            textView2.setText(str);
            e.a aVar = e.f492b;
            Activity activity = this.f507c;
            r.c(viewInflate, "dialog");
            this.f505a = aVar.p(activity, viewInflate, false);
        } else {
            r.b(textView);
            textView.setText(str);
        }
        String str2 = this.f508d;
        if (str2 != null) {
            if (e.containsKey(str2)) {
                e.remove(str2);
            }
            e.c cVar = this.f505a;
            if (cVar != null) {
                LinkedHashMap<String, e.c> linkedHashMap = e;
                r.b(cVar);
                linkedHashMap.put(str2, cVar);
            }
        }
        return this;
    }
}
