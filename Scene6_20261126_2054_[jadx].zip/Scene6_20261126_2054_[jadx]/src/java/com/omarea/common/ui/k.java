package com.omarea.common.ui;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class k {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private boolean f510a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private boolean f511b;

    public final boolean a() {
        return this.f510a;
    }

    public final boolean b() {
        return this.f511b;
    }

    public final void c(boolean z) {
        this.f510a = z;
    }

    public final void d(boolean z) {
        this.f511b = z;
    }
}
