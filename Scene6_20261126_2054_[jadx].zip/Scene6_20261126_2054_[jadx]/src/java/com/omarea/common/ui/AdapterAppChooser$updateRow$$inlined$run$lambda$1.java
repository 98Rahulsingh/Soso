package com.omarea.common.ui;

import android.graphics.drawable.Drawable;
import android.widget.ImageView;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.b.p;
import kotlin.jvm.internal.r;
import kotlin.s;
import kotlinx.coroutines.h0;
import kotlinx.coroutines.o0;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
final class AdapterAppChooser$updateRow$$inlined$run$lambda$1 extends SuspendLambda implements p<h0, kotlin.coroutines.c<? super s>, Object> {
    final /* synthetic */ ImageView $imgView;
    final /* synthetic */ AdapterAppChooser.b $item$inlined;
    final /* synthetic */ String $packageName$inlined;
    Object L$0;
    int label;
    private h0 p$;
    final /* synthetic */ AdapterAppChooser this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    AdapterAppChooser$updateRow$$inlined$run$lambda$1(ImageView imageView, kotlin.coroutines.c cVar, AdapterAppChooser adapterAppChooser, AdapterAppChooser.b bVar, String str) {
        super(2, cVar);
        this.$imgView = imageView;
        this.this$0 = adapterAppChooser;
        this.$item$inlined = bVar;
        this.$packageName$inlined = str;
    }

    public final kotlin.coroutines.c<s> create(Object obj, kotlin.coroutines.c<?> cVar) {
        r.d(cVar, "completion");
        AdapterAppChooser$updateRow$$inlined$run$lambda$1 adapterAppChooser$updateRow$$inlined$run$lambda$1 = new AdapterAppChooser$updateRow$$inlined$run$lambda$1(this.$imgView, cVar, this.this$0, this.$item$inlined, this.$packageName$inlined);
        adapterAppChooser$updateRow$$inlined$run$lambda$1.p$ = (h0) obj;
        return adapterAppChooser$updateRow$$inlined$run$lambda$1;
    }

    public final Object invoke(Object obj, Object obj2) {
        return create(obj, (kotlin.coroutines.c) obj2).invokeSuspend(s.a);
    }

    public final Object invokeSuspend(Object obj) {
        Object objD = kotlin.coroutines.intrinsics.a.d();
        int i = this.label;
        if (i == 0) {
            kotlin.h.b(obj);
            h0 h0Var = this.p$;
            o0 o0VarJ = this.this$0.j(this.$item$inlined);
            this.L$0 = h0Var;
            this.label = 1;
            obj = o0VarJ.u(this);
            if (obj == objD) {
                return objD;
            }
        } else {
            if (i != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            kotlin.h.b(obj);
        }
        Drawable drawable = (Drawable) obj;
        if (drawable != null && r.a(this.$imgView.getTag(), this.$packageName$inlined)) {
            this.$imgView.setImageDrawable(drawable);
        }
        return s.a;
    }
}
