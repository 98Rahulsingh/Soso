package com.omarea.common.ui;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.GridView;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class OverScrollGridView extends GridView {
    private int f;

    public OverScrollGridView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f = 400;
    }

    @Override // android.view.View
    protected boolean overScrollBy(int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8, boolean z) {
        return super.overScrollBy(i, i2, i3, i4, i5, i6, i7, this.f, z);
    }

    public void setMaxOverScrollY(int i) {
        this.f = i;
    }
}
