package com.omarea.common.ui;

import android.graphics.drawable.Drawable;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.b.p;
import kotlin.jvm.internal.r;
import kotlin.s;
import kotlinx.coroutines.h0;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
@kotlin.coroutines.jvm.internal.d(c = "com.omarea.common.ui.AdapterAppChooser$loadIcon$1", f = "AdapterAppChooser.kt", l = {}, m = "invokeSuspend")
final class AdapterAppChooser$loadIcon$1 extends SuspendLambda implements p<h0, kotlin.coroutines.c<? super Drawable>, Object> {
    final /* synthetic */ AdapterAppChooser.b $app;
    int label;
    private h0 p$;
    final /* synthetic */ AdapterAppChooser this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    AdapterAppChooser$loadIcon$1(AdapterAppChooser adapterAppChooser, AdapterAppChooser.b bVar, kotlin.coroutines.c cVar) {
        super(2, cVar);
        this.this$0 = adapterAppChooser;
        this.$app = bVar;
    }

    public final kotlin.coroutines.c<s> create(Object obj, kotlin.coroutines.c<?> cVar) {
        r.d(cVar, "completion");
        AdapterAppChooser$loadIcon$1 adapterAppChooser$loadIcon$1 = new AdapterAppChooser$loadIcon$1(this.this$0, this.$app, cVar);
        adapterAppChooser$loadIcon$1.p$ = (h0) obj;
        return adapterAppChooser$loadIcon$1;
    }

    public final Object invoke(Object obj, Object obj2) {
        return create(obj, (kotlin.coroutines.c) obj2).invokeSuspend(s.a);
    }

    public final Object invokeSuspend(Object obj) {
        kotlin.coroutines.intrinsics.a.d();
        if (this.label != 0) {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        kotlin.h.b(obj);
        String packageName = this.$app.getPackageName();
        Drawable drawable = (Drawable) this.this$0.j.get(packageName);
        if (drawable != null || this.$app.getNotFound()) {
            return drawable;
        }
        try {
            this.this$0.j.put(packageName, this.this$0.k.getPackageManager().getPackageInfo(packageName, 0).applicationInfo.loadIcon(this.this$0.k.getPackageManager()));
        } catch (Exception unused) {
            this.$app.setNotFound(true);
        }
        return this.this$0.j.get(packageName);
    }
}
