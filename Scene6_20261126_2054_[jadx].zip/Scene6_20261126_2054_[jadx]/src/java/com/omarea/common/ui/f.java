package com.omarea.common.ui;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AbsListView;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Filterable;
import android.widget.ListAdapter;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import kotlin.jvm.internal.o;
import kotlin.jvm.internal.r;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class f extends com.omarea.common.ui.d {
    private String r0;
    private String s0;
    private ArrayList<com.omarea.a.f.a> t0;
    private final boolean u0;
    private a v0;
    private HashMap w0;

    public interface a {
        void a(List<com.omarea.a.f.a> list, boolean[] zArr);
    }

    public static final class b implements TextWatcher {
        final /* synthetic */ View f;
        final /* synthetic */ AbsListView g;

        b(View view, AbsListView absListView) {
            this.f = view;
            this.g = absListView;
        }

        @Override // android.text.TextWatcher
        public void afterTextChanged(Editable editable) {
            if (editable != null) {
                View view = this.f;
                r.c(view, "clearBtn");
                view.setVisibility(editable.length() > 0 ? 0 : 8);
            }
        }

        @Override // android.text.TextWatcher
        public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }

        @Override // android.text.TextWatcher
        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            AbsListView absListView = this.g;
            r.c(absListView, "absListView");
            ListAdapter listAdapter = (ListAdapter) absListView.getAdapter();
            if (listAdapter == null) {
                throw new NullPointerException("null cannot be cast to non-null type android.widget.Filterable");
            }
            ((Filterable) listAdapter).getFilter().filter(charSequence == null ? "" : charSequence.toString());
        }
    }

    public static final class c implements com.omarea.common.ui.a.b {

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final /* synthetic */ CompoundButton f500b;

        c(CompoundButton compoundButton) {
            this.f500b = compoundButton;
        }

        @Override // com.omarea.common.ui.a.b
        public void a(List<com.omarea.a.f.a> list) {
            r.d(list, "selected");
            this.f500b.setChecked(list.size() == f.this.t0.size());
        }
    }

    static final class d implements View.OnClickListener {
        d() {
        }

        @Override // android.view.View.OnClickListener
        public final void onClick(View view) {
            f.this.y1();
        }
    }

    static final class e implements View.OnClickListener {
        final /* synthetic */ AbsListView g;

        e(AbsListView absListView) {
            this.g = absListView;
        }

        @Override // android.view.View.OnClickListener
        public final void onClick(View view) {
            f fVar = f.this;
            AbsListView absListView = this.g;
            r.c(absListView, "absListView");
            fVar.I1(absListView);
        }
    }

    /* JADX INFO: renamed from: com.omarea.common.ui.f$f, reason: collision with other inner class name */
    static final class ViewOnClickListenerC0051f implements View.OnClickListener {
        final /* synthetic */ com.omarea.common.ui.a f;

        ViewOnClickListenerC0051f(com.omarea.common.ui.a aVar) {
            this.f = aVar;
        }

        @Override // android.view.View.OnClickListener
        public final void onClick(View view) {
            com.omarea.common.ui.a aVar = this.f;
            if (aVar != null) {
                if (view == null) {
                    throw new NullPointerException("null cannot be cast to non-null type android.widget.CompoundButton");
                }
                aVar.i(((CompoundButton) view).isChecked());
            }
        }
    }

    static final class g implements View.OnClickListener {
        final /* synthetic */ EditText f;

        g(EditText editText) {
            this.f = editText;
        }

        @Override // android.view.View.OnClickListener
        public final void onClick(View view) {
            EditText editText = this.f;
            r.c(editText, "searchBox");
            editText.setText((CharSequence) null);
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public f(boolean z, ArrayList<com.omarea.a.f.a> arrayList, boolean z2, a aVar, Boolean bool) {
        super((arrayList.size() <= 7 || !(r.a(bool, Boolean.TRUE) ^ true)) ? com.omarea.a.b.dialog_item_chooser_small : com.omarea.a.b.dialog_item_chooser, z);
        r.d(arrayList, "items");
        this.t0 = arrayList;
        this.u0 = z2;
        this.v0 = aVar;
        this.r0 = "";
        this.s0 = "";
    }

    public /* synthetic */ f(boolean z, ArrayList arrayList, boolean z2, a aVar, Boolean bool, int i, o oVar) {
        this(z, arrayList, (i & 4) != 0 ? false : z2, (i & 8) != 0 ? null : aVar, (i & 16) != 0 ? null : bool);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void I1(AbsListView absListView) {
        ListAdapter listAdapter = (ListAdapter) absListView.getAdapter();
        if (listAdapter == null) {
            throw new NullPointerException("null cannot be cast to non-null type com.omarea.common.ui.AdapterItemChooser");
        }
        com.omarea.common.ui.a aVar = (com.omarea.common.ui.a) listAdapter;
        List<com.omarea.a.f.a> listG = aVar.g();
        boolean[] zArrF = aVar.f();
        a aVar2 = this.v0;
        if (aVar2 != null) {
            aVar2.a(listG, zArrF);
        }
        y1();
    }

    private final void L1(AbsListView absListView) {
        Context context = absListView.getContext();
        r.c(context, "gridView.context");
        absListView.setAdapter((ListAdapter) new com.omarea.common.ui.a(context, this.t0, this.u0));
    }

    private final void M1() {
        TextView textView;
        View viewN = N();
        if (viewN == null || (textView = (TextView) viewN.findViewById(com.omarea.a.a.dialog_desc)) == null) {
            return;
        }
        textView.setText(this.s0);
        textView.setVisibility(this.s0.length() > 0 ? 0 : 8);
    }

    private final void N1() {
        TextView textView;
        View viewN = N();
        if (viewN == null || (textView = (TextView) viewN.findViewById(com.omarea.a.a.dialog_title)) == null) {
            return;
        }
        textView.setText(this.r0);
        textView.setVisibility(this.r0.length() > 0 ? 0 : 8);
    }

    @Override // com.omarea.common.ui.d
    public void E0(View view, Bundle bundle) {
        r.d(view, "view");
        super.E0(view, bundle);
        AbsListView absListView = (AbsListView) view.findViewById(com.omarea.a.a.item_list);
        r.c(absListView, "absListView");
        L1(absListView);
        view.findViewById(com.omarea.a.a.btn_cancel).setOnClickListener(new d());
        view.findViewById(com.omarea.a.a.btn_confirm).setOnClickListener(new e(absListView));
        CompoundButton compoundButton = (CompoundButton) view.findViewById(com.omarea.a.a.select_all);
        boolean z = true;
        if (compoundButton != null) {
            if (this.u0) {
                com.omarea.common.ui.a aVar = (com.omarea.common.ui.a) ((ListAdapter) absListView.getAdapter());
                compoundButton.setVisibility(0);
                ArrayList<com.omarea.a.f.a> arrayList = this.t0;
                ArrayList arrayList2 = new ArrayList();
                for (Object obj : arrayList) {
                    if (((com.omarea.a.f.a) obj).a()) {
                        arrayList2.add(obj);
                    }
                }
                compoundButton.setChecked(arrayList2.size() == this.t0.size());
                compoundButton.setOnClickListener(new ViewOnClickListenerC0051f(aVar));
                if (aVar != null) {
                    aVar.j(new c(compoundButton));
                }
            } else {
                compoundButton.setVisibility(8);
            }
        }
        if (this.t0.size() > 5) {
            View viewFindViewById = view.findViewById(com.omarea.a.a.search_box_clear);
            EditText editText = (EditText) view.findViewById(com.omarea.a.a.search_box);
            editText.addTextChangedListener(new b(viewFindViewById, absListView));
            r.c(viewFindViewById, "clearBtn");
            r.c(editText, "searchBox");
            Editable text = editText.getText();
            if (text != null && text.length() != 0) {
                z = false;
            }
            viewFindViewById.setVisibility(z ? 8 : 0);
            viewFindViewById.setOnClickListener(new g(editText));
        }
        N1();
        M1();
    }

    @Override // com.omarea.common.ui.d
    public void F1() {
        HashMap map = this.w0;
        if (map != null) {
            map.clear();
        }
    }

    public final f J1(String str) {
        r.d(str, "message");
        this.s0 = str;
        M1();
        return this;
    }

    public final f K1(String str) {
        r.d(str, "title");
        this.r0 = str;
        N1();
        return this;
    }

    @Override // com.omarea.common.ui.d
    public void Z(Bundle bundle) {
        super.Z(bundle);
    }

    @Override // com.omarea.common.ui.d
    public /* synthetic */ void m0() {
        super.m0();
        F1();
    }

    public void onDismiss(DialogInterface dialogInterface) {
        r.d(dialogInterface, "dialog");
        super.onDismiss(dialogInterface);
    }
}
