package com.omarea.common.ui;

import android.R;
import android.app.Activity;
import android.app.Dialog;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import kotlin.jvm.internal.r;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class d extends androidx.fragment.app.c {
    private int n0;
    private View o0;
    private final int p0;
    private final boolean q0;

    public d(int i, boolean z) {
        this.p0 = i;
        this.q0 = z;
        this.n0 = z ? com.omarea.a.d.dialog_full_screen_dark : com.omarea.a.d.dialog_full_screen_light;
    }

    public Dialog B1(Bundle bundle) {
        if (Build.VERSION.SDK_INT < 23) {
            androidx.fragment.app.d dVarJ = j();
            r.b(dVarJ);
            return new Dialog(dVarJ, -1);
        }
        androidx.fragment.app.d dVarJ2 = j();
        r.b(dVarJ2);
        int i = this.n0;
        if (i == 0) {
            i = com.omarea.a.d.dialog_full_screen_light;
        }
        return new Dialog(dVarJ2, i);
    }

    public void E0(View view, Bundle bundle) {
        Dialog dialogA1;
        Window window;
        r.d(view, "view");
        super/*androidx.fragment.app.Fragment*/.E0(view, bundle);
        Activity activityJ = j();
        if (activityJ == null || (dialogA1 = A1()) == null || (window = dialogA1.getWindow()) == null) {
            return;
        }
        if (Build.VERSION.SDK_INT < 23) {
            window.setWindowAnimations(R.style.Animation.Translucent);
        }
        e.f492b.E(window, activityJ);
    }

    public abstract void F1();

    public void Z(Bundle bundle) {
        super.Z(bundle);
    }

    public View j0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        r.d(layoutInflater, "inflater");
        View viewInflate = layoutInflater.inflate(this.p0, viewGroup);
        r.c(viewInflate, "inflater.inflate(layout, container)");
        this.o0 = viewInflate;
        if (viewInflate != null) {
            return viewInflate;
        }
        r.q("currentView");
        throw null;
    }

    public /* synthetic */ void m0() {
        super.m0();
        F1();
    }
}
