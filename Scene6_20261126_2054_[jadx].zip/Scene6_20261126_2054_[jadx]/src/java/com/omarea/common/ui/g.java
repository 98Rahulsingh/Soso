package com.omarea.common.ui;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AbsListView;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Filterable;
import android.widget.ListAdapter;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import kotlin.jvm.internal.r;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class g extends com.omarea.common.ui.d {
    private String r0;
    private String s0;
    private ArrayList<com.omarea.a.f.a> t0;
    private ArrayList<com.omarea.a.f.a> u0;
    private final boolean v0;
    private a w0;
    private HashMap x0;

    public interface a {
        void a(List<com.omarea.a.f.a> list, boolean[] zArr);
    }

    public static final class b implements TextWatcher {
        final /* synthetic */ View f;
        final /* synthetic */ AbsListView g;

        b(View view, AbsListView absListView) {
            this.f = view;
            this.g = absListView;
        }

        @Override // android.text.TextWatcher
        public void afterTextChanged(Editable editable) {
            if (editable != null) {
                View view = this.f;
                r.c(view, "clearBtn");
                view.setVisibility(editable.length() > 0 ? 0 : 8);
            }
        }

        @Override // android.text.TextWatcher
        public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }

        @Override // android.text.TextWatcher
        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            AbsListView absListView = this.g;
            r.c(absListView, "absListView");
            ListAdapter listAdapter = (ListAdapter) absListView.getAdapter();
            if (listAdapter == null) {
                throw new NullPointerException("null cannot be cast to non-null type android.widget.Filterable");
            }
            ((Filterable) listAdapter).getFilter().filter(charSequence == null ? "" : charSequence.toString());
        }
    }

    static final class c implements View.OnClickListener {
        c() {
        }

        @Override // android.view.View.OnClickListener
        public final void onClick(View view) {
            g.this.y1();
        }
    }

    static final class d implements View.OnClickListener {
        final /* synthetic */ AbsListView g;

        d(AbsListView absListView) {
            this.g = absListView;
        }

        @Override // android.view.View.OnClickListener
        public final void onClick(View view) {
            g gVar = g.this;
            AbsListView absListView = this.g;
            r.c(absListView, "absListView");
            gVar.H1(absListView);
        }
    }

    static final class e implements View.OnClickListener {
        final /* synthetic */ EditText f;

        e(EditText editText) {
            this.f = editText;
        }

        @Override // android.view.View.OnClickListener
        public final void onClick(View view) {
            EditText editText = this.f;
            r.c(editText, "searchBox");
            editText.setText((CharSequence) null);
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public g(boolean z, ArrayList<com.omarea.a.f.a> arrayList, ArrayList<com.omarea.a.f.a> arrayList2, boolean z2, a aVar) {
        super(arrayList.size() > 7 ? com.omarea.a.b.dialog_item_chooser : com.omarea.a.b.dialog_item_chooser_small, z);
        r.d(arrayList, "items");
        r.d(arrayList2, "selectedItems");
        this.t0 = arrayList;
        this.u0 = arrayList2;
        this.v0 = z2;
        this.w0 = aVar;
        this.r0 = "";
        this.s0 = "";
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void H1(AbsListView absListView) {
        ListAdapter listAdapter = (ListAdapter) absListView.getAdapter();
        if (listAdapter == null) {
            throw new NullPointerException("null cannot be cast to non-null type com.omarea.common.ui.AdapterItemChooser2");
        }
        com.omarea.common.ui.b bVar = (com.omarea.common.ui.b) listAdapter;
        List<com.omarea.a.f.a> listG = bVar.g();
        boolean[] zArrF = bVar.f();
        a aVar = this.w0;
        if (aVar != null) {
            aVar.a(listG, zArrF);
        }
        y1();
    }

    private final void J1(AbsListView absListView) {
        Context context = absListView.getContext();
        r.c(context, "gridView.context");
        absListView.setAdapter((ListAdapter) new com.omarea.common.ui.b(context, this.t0, this.u0, this.v0));
    }

    private final void K1() {
        TextView textView;
        View viewN = N();
        if (viewN == null || (textView = (TextView) viewN.findViewById(com.omarea.a.a.dialog_desc)) == null) {
            return;
        }
        textView.setText(this.s0);
        textView.setVisibility(this.s0.length() > 0 ? 0 : 8);
    }

    private final void L1() {
        TextView textView;
        View viewN = N();
        if (viewN == null || (textView = (TextView) viewN.findViewById(com.omarea.a.a.dialog_title)) == null) {
            return;
        }
        textView.setText(this.r0);
        textView.setVisibility(this.r0.length() > 0 ? 0 : 8);
    }

    @Override // com.omarea.common.ui.d
    public void E0(View view, Bundle bundle) {
        r.d(view, "view");
        super.E0(view, bundle);
        AbsListView absListView = (AbsListView) view.findViewById(com.omarea.a.a.item_list);
        r.c(absListView, "absListView");
        J1(absListView);
        view.findViewById(com.omarea.a.a.btn_cancel).setOnClickListener(new c());
        view.findViewById(com.omarea.a.a.btn_confirm).setOnClickListener(new d(absListView));
        CompoundButton compoundButton = (CompoundButton) view.findViewById(com.omarea.a.a.select_all);
        if (compoundButton != null) {
            compoundButton.setVisibility(8);
        }
        if (this.t0.size() > 5) {
            View viewFindViewById = view.findViewById(com.omarea.a.a.search_box_clear);
            EditText editText = (EditText) view.findViewById(com.omarea.a.a.search_box);
            editText.addTextChangedListener(new b(viewFindViewById, absListView));
            r.c(viewFindViewById, "clearBtn");
            r.c(editText, "searchBox");
            Editable text = editText.getText();
            viewFindViewById.setVisibility(text == null || text.length() == 0 ? 8 : 0);
            viewFindViewById.setOnClickListener(new e(editText));
        }
        L1();
        K1();
    }

    @Override // com.omarea.common.ui.d
    public void F1() {
        HashMap map = this.x0;
        if (map != null) {
            map.clear();
        }
    }

    public final g I1(String str) {
        r.d(str, "title");
        this.r0 = str;
        L1();
        return this;
    }

    @Override // com.omarea.common.ui.d
    public void Z(Bundle bundle) {
        super.Z(bundle);
    }

    @Override // com.omarea.common.ui.d
    public /* synthetic */ void m0() {
        super.m0();
        F1();
    }

    public void onDismiss(DialogInterface dialogInterface) {
        r.d(dialogInterface, "dialog");
        super.onDismiss(dialogInterface);
    }
}
