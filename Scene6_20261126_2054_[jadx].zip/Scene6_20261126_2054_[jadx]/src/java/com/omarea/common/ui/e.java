package com.omarea.common.ui;

import android.R;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.UiModeManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.TextView;
import kotlin.jvm.internal.o;
import kotlin.jvm.internal.r;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private static boolean f491a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final a f492b = new a(null);

    public static final class a {

        /* JADX INFO: renamed from: com.omarea.common.ui.e$a$a, reason: collision with other inner class name */
        static final class ViewOnClickListenerC0049a implements View.OnClickListener {
            final /* synthetic */ c f;
            final /* synthetic */ Runnable g;

            ViewOnClickListenerC0049a(c cVar, Runnable runnable) {
                this.f = cVar;
                this.g = runnable;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f.a();
                Runnable runnable = this.g;
                if (runnable != null) {
                    runnable.run();
                }
            }
        }

        static final class b implements View.OnClickListener {
            final /* synthetic */ c f;
            final /* synthetic */ Runnable g;

            b(c cVar, Runnable runnable) {
                this.f = cVar;
                this.g = runnable;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f.a();
                Runnable runnable = this.g;
                if (runnable != null) {
                    runnable.run();
                }
            }
        }

        static final class c implements View.OnClickListener {
            final /* synthetic */ b f;
            final /* synthetic */ c g;

            c(b bVar, c cVar) {
                this.f = bVar;
                this.g = cVar;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                b bVar = this.f;
                if (bVar == null) {
                    this.g.a();
                    return;
                }
                if (bVar.a()) {
                    this.g.a();
                }
                Runnable runnableB = this.f.b();
                if (runnableB != null) {
                    runnableB.run();
                }
            }
        }

        static final class d implements View.OnClickListener {
            final /* synthetic */ b f;
            final /* synthetic */ c g;

            d(b bVar, c cVar) {
                this.f = bVar;
                this.g = cVar;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                b bVar = this.f;
                if (bVar == null) {
                    this.g.a();
                    return;
                }
                if (bVar.a()) {
                    this.g.a();
                }
                Runnable runnableB = this.f.b();
                if (runnableB != null) {
                    runnableB.run();
                }
            }
        }

        /* JADX INFO: renamed from: com.omarea.common.ui.e$a$e, reason: collision with other inner class name */
        static final class DialogInterfaceOnDismissListenerC0050e implements DialogInterface.OnDismissListener {
            final /* synthetic */ Runnable f;

            DialogInterfaceOnDismissListenerC0050e(Runnable runnable, c cVar) {
                this.f = runnable;
            }

            @Override // android.content.DialogInterface.OnDismissListener
            public final void onDismiss(DialogInterface dialogInterface) {
                this.f.run();
            }
        }

        static final class f implements View.OnClickListener {
            final /* synthetic */ c f;

            f(Runnable runnable, c cVar) {
                this.f = cVar;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f.a();
            }
        }

        static final class g implements View.OnClickListener {
            final /* synthetic */ c f;
            final /* synthetic */ Runnable g;

            g(c cVar, Runnable runnable) {
                this.f = cVar;
                this.g = runnable;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f.a();
                Runnable runnable = this.g;
                if (runnable != null) {
                    runnable.run();
                }
            }
        }

        static final class h implements View.OnClickListener {
            final /* synthetic */ c f;
            final /* synthetic */ Runnable g;

            h(c cVar, Runnable runnable) {
                this.f = cVar;
                this.g = runnable;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f.a();
                Runnable runnable = this.g;
                if (runnable != null) {
                    runnable.run();
                }
            }
        }

        static final class i implements View.OnClickListener {
            final /* synthetic */ c f;
            final /* synthetic */ Runnable g;

            i(c cVar, Runnable runnable) {
                this.f = cVar;
                this.g = runnable;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f.a();
                Runnable runnable = this.g;
                if (runnable != null) {
                    runnable.run();
                }
            }
        }

        public static final class j implements View.OnTouchListener {
            final /* synthetic */ View f;
            final /* synthetic */ c g;

            j(View view, c cVar) {
                this.f = view;
                this.g = cVar;
            }

            @Override // android.view.View.OnTouchListener
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (motionEvent == null || motionEvent.getAction() != 1) {
                    return false;
                }
                int x = (int) motionEvent.getX();
                int y = (int) motionEvent.getY();
                Rect rect = new Rect();
                this.f.getGlobalVisibleRect(rect);
                if (!rect.contains(x, y) && this.g.e()) {
                    this.g.a();
                }
                return true;
            }
        }

        private a() {
        }

        public /* synthetic */ a(o oVar) {
            this();
        }

        public static /* synthetic */ c A(a aVar, Context context, String str, String str2, Runnable runnable, int i2, Object obj) {
            if ((i2 & 8) != 0) {
                runnable = null;
            }
            return aVar.x(context, str, str2, runnable);
        }

        private final boolean B(Context context) {
            int iL = androidx.appcompat.app.f.l();
            if (iL == 2) {
                return true;
            }
            if (iL != -1 && iL != -100) {
                return false;
            }
            Object systemService = context.getSystemService("uimode");
            if (systemService != null) {
                return ((UiModeManager) systemService).getNightMode() == 2;
            }
            throw new NullPointerException("null cannot be cast to non-null type android.app.UiModeManager");
        }

        private final c C(Context context, int i2, String str, String str2, Runnable runnable, Runnable runnable2) {
            View viewR = r(context, i2, str, str2, null);
            c cVarQ = q(this, context, viewR, false, 4, null);
            View viewFindViewById = viewR.findViewById(com.omarea.a.a.btn_cancel);
            if (viewFindViewById != null) {
                viewFindViewById.setOnClickListener(new h(cVarQ, runnable2));
            }
            View viewFindViewById2 = viewR.findViewById(com.omarea.a.a.btn_confirm);
            if (viewFindViewById2 != null) {
                viewFindViewById2.setOnClickListener(new i(cVarQ, runnable));
            }
            return cVarQ;
        }

        private final c D(View view, c cVar) {
            Window window = cVar.c().getWindow();
            View decorView = window != null ? window.getDecorView() : null;
            if (decorView != null) {
                decorView.setOnTouchListener(new j(view, cVar));
            }
            return cVar;
        }

        public static /* synthetic */ c b(a aVar, Context context, String str, String str2, Runnable runnable, int i2, Object obj) {
            if ((i2 & 2) != 0) {
                str = "";
            }
            if ((i2 & 4) != 0) {
                str2 = "";
            }
            if ((i2 & 8) != 0) {
                runnable = null;
            }
            return aVar.a(context, str, str2, runnable);
        }

        public static /* synthetic */ c j(a aVar, Context context, View view, b bVar, b bVar2, int i2, Object obj) {
            if ((i2 & 2) != 0) {
                view = null;
            }
            if ((i2 & 4) != 0) {
                bVar = null;
            }
            if ((i2 & 8) != 0) {
                bVar2 = null;
            }
            return aVar.e(context, view, bVar, bVar2);
        }

        public static /* synthetic */ c q(a aVar, Context context, View view, boolean z, int i2, Object obj) {
            if ((i2 & 4) != 0) {
                z = true;
            }
            return aVar.p(context, view, z);
        }

        private final View r(Context context, int i2, String str, String str2, View view) {
            FrameLayout frameLayout;
            View viewInflate = LayoutInflater.from(context).inflate(i2, (ViewGroup) null);
            TextView textView = (TextView) viewInflate.findViewById(com.omarea.a.a.confirm_title);
            if (textView != null) {
                if (str.length() == 0) {
                    textView.setVisibility(8);
                } else {
                    textView.setText(str);
                }
            }
            TextView textView2 = (TextView) viewInflate.findViewById(com.omarea.a.a.confirm_message);
            if (textView2 != null) {
                if (str2.length() == 0) {
                    textView2.setVisibility(8);
                } else {
                    textView2.setText(str2);
                }
            }
            if (view != null && (frameLayout = (FrameLayout) viewInflate.findViewById(com.omarea.a.a.confirm_custom_view)) != null) {
                frameLayout.addView(view);
            }
            r.c(viewInflate, "view");
            return viewInflate;
        }

        private final int t(Context context, int i2) {
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(new int[]{R.attr.background});
            int color = typedArrayObtainStyledAttributes.getColor(0, i2);
            typedArrayObtainStyledAttributes.recycle();
            return color;
        }

        static /* synthetic */ int u(a aVar, Context context, int i2, int i3, Object obj) {
            if ((i3 & 2) != 0) {
                i2 = 0;
            }
            return aVar.t(context, i2);
        }

        public static /* synthetic */ c y(a aVar, Context context, String str, Runnable runnable, int i2, Object obj) {
            if ((i2 & 4) != 0) {
                runnable = null;
            }
            return aVar.v(context, str, runnable);
        }

        public static /* synthetic */ c z(a aVar, Context context, String str, String str2, View view, Runnable runnable, int i2, Object obj) {
            String str3 = (i2 & 2) != 0 ? "" : str;
            String str4 = (i2 & 4) != 0 ? "" : str2;
            if ((i2 & 16) != 0) {
                runnable = null;
            }
            return aVar.w(context, str3, str4, view, runnable);
        }

        public final void E(Window window, Activity activity) {
            ColorDrawable colorDrawable;
            r.d(window, "window");
            r.d(activity, "activity");
            Window window2 = activity.getWindow();
            r.c(window2, "activity.window");
            boolean z = (window2.getAttributes().flags & 1048576) != 0;
            Bitmap bitmapC = (e.f492b.s() || z) ? null : com.omarea.common.ui.i.c(activity);
            if (bitmapC != null) {
                window.setBackgroundDrawable(new BitmapDrawable(activity.getResources(), bitmapC));
                return;
            }
            try {
                int iU = u(e.f492b, activity, 0, 2, null);
                if (iU != 0) {
                    window.setBackgroundDrawable(new ColorDrawable(iU));
                    return;
                }
                if (window.isFloating()) {
                    window.setBackgroundDrawable(new ColorDrawable(iU));
                    window.setDimAmount(0.9f);
                    return;
                }
                if (!z) {
                    a aVar = e.f492b;
                    Context context = window.getContext();
                    r.c(context, "context");
                    colorDrawable = aVar.B(context) ? new ColorDrawable(Color.argb(255, 18, 18, 18)) : new ColorDrawable(Color.argb(255, 245, 245, 245));
                }
                window.setBackgroundDrawable(colorDrawable);
            } catch (Exception unused) {
                window.setBackgroundDrawable(new ColorDrawable(Color.argb(255, 245, 245, 245)));
            }
        }

        public final c F(Context context, String str, String str2, Runnable runnable, Runnable runnable2) {
            r.d(context, "context");
            r.d(str, "title");
            r.d(str2, "message");
            return C(context, com.omarea.a.b.dialog_warning, str, str2, runnable, runnable2);
        }

        public final c a(Context context, String str, String str2, Runnable runnable) {
            r.d(context, "context");
            r.d(str, "title");
            r.d(str2, "message");
            return C(context, com.omarea.a.b.dialog_alert, str, str2, runnable, null);
        }

        public final c c(AlertDialog.Builder builder) {
            r.d(builder, "builder");
            AlertDialog alertDialogCreate = builder.create();
            d(alertDialogCreate);
            r.c(alertDialogCreate, "dialog");
            return new c(alertDialogCreate);
        }

        public final c d(AlertDialog alertDialog) {
            if (alertDialog != null && !alertDialog.isShowing()) {
                Window window = alertDialog.getWindow();
                if (window != null) {
                    window.setWindowAnimations(com.omarea.a.d.windowAnim);
                }
                alertDialog.show();
            }
            if (alertDialog != null) {
                return new c(alertDialog);
            }
            return null;
        }

        public final c e(Context context, View view, b bVar, b bVar2) {
            r.d(context, "context");
            return f(context, "", "", view, bVar, bVar2);
        }

        public final c f(Context context, String str, String str2, View view, b bVar, b bVar2) {
            r.d(context, "context");
            r.d(str, "title");
            r.d(str2, "message");
            View viewR = r(context, com.omarea.a.b.dialog_confirm, str, str2, view);
            c cVarQ = q(this, context, viewR, false, 4, null);
            TextView textView = (TextView) viewR.findViewById(com.omarea.a.a.btn_confirm);
            if (bVar != null && textView != null) {
                textView.setText(bVar.c());
            }
            if (textView != null) {
                textView.setOnClickListener(new c(bVar, cVarQ));
            }
            TextView textView2 = (TextView) viewR.findViewById(com.omarea.a.a.btn_cancel);
            if (bVar2 != null && textView2 != null) {
                textView2.setText(bVar2.c());
            }
            textView2.setOnClickListener(new d(bVar2, cVarQ));
            return cVarQ;
        }

        public final c g(Context context, String str, String str2, View view, Runnable runnable, Runnable runnable2) {
            r.d(context, "context");
            r.d(str, "title");
            r.d(str2, "message");
            View viewR = r(context, com.omarea.a.b.dialog_confirm, str, str2, view);
            c cVarQ = q(this, context, viewR, false, 4, null);
            viewR.findViewById(com.omarea.a.a.btn_cancel).setOnClickListener(new ViewOnClickListenerC0049a(cVarQ, runnable2));
            viewR.findViewById(com.omarea.a.a.btn_confirm).setOnClickListener(new b(cVarQ, runnable));
            return cVarQ;
        }

        public final c h(Context context, String str, String str2, b bVar, b bVar2) {
            r.d(context, "context");
            r.d(str, "title");
            r.d(str2, "message");
            return f(context, str, str2, null, bVar, bVar2);
        }

        public final c i(Context context, String str, String str2, Runnable runnable, Runnable runnable2) {
            r.d(context, "context");
            r.d(str, "title");
            r.d(str2, "message");
            return C(context, com.omarea.a.b.dialog_confirm, str, str2, runnable, runnable2);
        }

        public final c n(Activity activity, String str, String str2, Runnable runnable, Runnable runnable2) {
            r.d(activity, "context");
            r.d(str, "title");
            r.d(str2, "message");
            return C(activity, com.omarea.a.b.dialog_confirm, str, str2, runnable, runnable2);
        }

        /* JADX WARN: Code duplicated, block: B:7:0x0027  */
        public final c p(Context context, View view, boolean z) {
            boolean z2;
            r.d(context, "context");
            r.d(view, "view");
            boolean z3 = context instanceof Activity;
            if (z3) {
                Window window = ((Activity) context).getWindow();
                r.c(window, "context.window");
                if ((window.getAttributes().flags & 1048576) == 0) {
                    z2 = true;
                } else {
                    z2 = false;
                }
            } else {
                z2 = false;
            }
            AlertDialog alertDialogCreate = (z2 ? new AlertDialog.Builder(context, com.omarea.a.d.custom_alert_dialog) : new AlertDialog.Builder(context)).setView(view).setCancelable(z).create();
            if (z3) {
                alertDialogCreate.show();
                r.c(alertDialogCreate, "dialog");
                Window window2 = alertDialogCreate.getWindow();
                if (window2 != null) {
                    Activity activity = (Activity) context;
                    e.f492b.E(window2, activity);
                    View decorView = window2.getDecorView();
                    Window window3 = activity.getWindow();
                    r.c(window3, "context.window");
                    View decorView2 = window3.getDecorView();
                    r.c(decorView2, "context.window.decorView");
                    decorView.setSystemUiVisibility(decorView2.getSystemUiVisibility());
                }
            } else {
                r.c(alertDialogCreate, "dialog");
                Window window4 = alertDialogCreate.getWindow();
                if (window4 != null) {
                    window4.setWindowAnimations(com.omarea.a.d.windowAnim2);
                }
                alertDialogCreate.show();
                Window window5 = alertDialogCreate.getWindow();
                if (window5 != null) {
                    window5.setBackgroundDrawableResource(R.color.transparent);
                }
            }
            c cVar = new c(alertDialogCreate);
            cVar.g(z);
            D(view, cVar);
            return cVar;
        }

        public final boolean s() {
            return e.f491a;
        }

        public final c v(Context context, String str, Runnable runnable) {
            r.d(context, "context");
            r.d(str, "message");
            String string = context.getString(com.omarea.a.c.help_title);
            r.c(string, "context.getString(R.string.help_title)");
            return x(context, string, str, runnable);
        }

        public final c w(Context context, String str, String str2, View view, Runnable runnable) {
            r.d(context, "context");
            r.d(str, "title");
            r.d(str2, "message");
            r.d(view, "contentView");
            View viewR = r(context, com.omarea.a.b.dialog_help_info, str, str2, view);
            c cVarQ = q(this, context, viewR, false, 4, null);
            viewR.findViewById(com.omarea.a.a.btn_confirm).setOnClickListener(new g(cVarQ, runnable));
            return cVarQ;
        }

        public final c x(Context context, String str, String str2, Runnable runnable) {
            r.d(context, "context");
            r.d(str, "title");
            r.d(str2, "message");
            View viewInflate = LayoutInflater.from(context).inflate(com.omarea.a.b.dialog_help_info, (ViewGroup) null);
            View viewFindViewById = viewInflate.findViewById(com.omarea.a.a.confirm_title);
            if (viewFindViewById == null) {
                throw new NullPointerException("null cannot be cast to non-null type android.widget.TextView");
            }
            TextView textView = (TextView) viewFindViewById;
            if (str.length() > 0) {
                textView.setText(str);
                textView.setVisibility(0);
            } else {
                textView.setVisibility(8);
            }
            View viewFindViewById2 = viewInflate.findViewById(com.omarea.a.a.confirm_message);
            if (viewFindViewById2 == null) {
                throw new NullPointerException("null cannot be cast to non-null type android.widget.TextView");
            }
            TextView textView2 = (TextView) viewFindViewById2;
            if (str2.length() > 0) {
                textView2.setText(str2);
                textView2.setVisibility(0);
            } else {
                textView2.setVisibility(8);
            }
            r.c(viewInflate, "dialog");
            c cVarP = p(context, viewInflate, runnable == null);
            View viewFindViewById3 = viewInflate.findViewById(com.omarea.a.a.btn_confirm);
            if (viewFindViewById3 == null) {
                throw new NullPointerException("null cannot be cast to non-null type android.view.View");
            }
            if (runnable != null) {
                cVarP.h(new DialogInterfaceOnDismissListenerC0050e(runnable, cVarP));
            }
            viewFindViewById3.setOnClickListener(new f(runnable, cVarP));
            return cVarP;
        }
    }

    public static final class b {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final String f493a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private final Runnable f494b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private final boolean f495c;

        public b(String str, Runnable runnable, boolean z) {
            r.d(str, "text");
            this.f493a = str;
            this.f494b = runnable;
            this.f495c = z;
        }

        public /* synthetic */ b(String str, Runnable runnable, boolean z, int i, o oVar) {
            this(str, (i & 2) != 0 ? null : runnable, (i & 4) != 0 ? true : z);
        }

        public final boolean a() {
            return this.f495c;
        }

        public final Runnable b() {
            return this.f494b;
        }

        public final String c() {
            return this.f493a;
        }
    }

    public static final class c {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final Context f496a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private boolean f497b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private final AlertDialog f498c;

        public c(AlertDialog alertDialog) {
            r.d(alertDialog, "d");
            this.f498c = alertDialog;
            this.f496a = c().getContext();
            this.f497b = true;
        }

        public final void a() {
            try {
                this.f498c.dismiss();
            } catch (Exception unused) {
            }
        }

        public final Context b() {
            return this.f496a;
        }

        public final AlertDialog c() {
            return this.f498c;
        }

        public final void d() {
            try {
                this.f498c.hide();
            } catch (Exception unused) {
            }
        }

        public final boolean e() {
            return this.f497b;
        }

        public final boolean f() {
            return this.f498c.isShowing();
        }

        public final c g(boolean z) {
            this.f497b = z;
            this.f498c.setCancelable(z);
            return this;
        }

        public final c h(DialogInterface.OnDismissListener onDismissListener) {
            r.d(onDismissListener, "onDismissListener");
            this.f498c.setOnDismissListener(onDismissListener);
            return this;
        }
    }
}
