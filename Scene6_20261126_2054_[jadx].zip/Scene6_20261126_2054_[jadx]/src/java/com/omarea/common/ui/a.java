package com.omarea.common.ui;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CompoundButton;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import kotlin.collections.q;
import kotlin.jvm.internal.r;
import kotlin.s;
import kotlin.text.Regex;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class a extends BaseAdapter implements Filterable {
    private b f;
    private Filter g;
    private ArrayList<com.omarea.a.f.a> h;
    private final Object i;
    private final Context j;
    private ArrayList<com.omarea.a.f.a> k;
    private final boolean l;

    /* JADX INFO: renamed from: com.omarea.common.ui.a$a, reason: collision with other inner class name */
    private static final class C0046a extends Filter {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private a f481a;

        public C0046a(a aVar) {
            r.d(aVar, "adapter");
            this.f481a = aVar;
        }

        /* JADX WARN: Code duplicated, block: B:31:0x0084  */
        @Override // android.widget.Filter
        protected Filter.FilterResults performFiltering(CharSequence charSequence) {
            String string;
            ArrayList arrayList;
            int size;
            String lowerCase;
            List listE;
            ArrayList arrayList2;
            Filter.FilterResults filterResults = new Filter.FilterResults();
            if (charSequence == null || (string = charSequence.toString()) == null) {
                string = "";
            }
            int i = 1;
            if (string.length() == 0) {
                synchronized (this.f481a.i) {
                    arrayList2 = new ArrayList(this.f481a.k);
                    s sVar = s.a;
                }
                filterResults.values = arrayList2;
                size = arrayList2.size();
            } else {
                if (string == null) {
                    throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                }
                String lowerCase2 = string.toLowerCase();
                r.c(lowerCase2, "(this as java.lang.String).toLowerCase()");
                synchronized (this.f481a.i) {
                    arrayList = new ArrayList(this.f481a.k);
                    s sVar2 = s.a;
                }
                List<com.omarea.a.f.a> listG = this.f481a.g();
                int size2 = arrayList.size();
                ArrayList arrayList3 = new ArrayList();
                int i2 = 0;
                while (i2 < size2) {
                    Object obj = arrayList.get(i2);
                    r.c(obj, "values[i]");
                    com.omarea.a.f.a aVar = (com.omarea.a.f.a) obj;
                    if (listG.contains(aVar)) {
                        arrayList3.add(aVar);
                        break;
                        break;
                    }
                    if (aVar.b() == null) {
                        lowerCase = "";
                    } else {
                        String strB = aVar.b();
                        r.b(strB);
                        if (strB == null) {
                            throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                        }
                        lowerCase = strB.toLowerCase();
                        r.c(lowerCase, "(this as java.lang.String).toLowerCase()");
                    }
                    if (kotlin.text.k.y(lowerCase, lowerCase2, false, 2, (Object) null)) {
                        arrayList3.add(aVar);
                        break;
                    }
                    List listSplit = new Regex(" ").split(lowerCase, 0);
                    if (listSplit.isEmpty()) {
                        listE = q.e();
                        break;
                    }
                    ListIterator listIterator = listSplit.listIterator(listSplit.size());
                    while (true) {
                        if (!listIterator.hasPrevious()) {
                            listE = q.e();
                            break;
                        }
                        if ((((String) listIterator.previous()).length() == 0 ? i : 0) == 0) {
                            listE = q.Q(listSplit, listIterator.nextIndex() + i);
                            break;
                        }
                    }
                    Object[] array = listE.toArray(new String[0]);
                    if (array == null) {
                        throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T>");
                    }
                    for (String str : (String[]) array) {
                        if (kotlin.text.k.y(str, lowerCase2, false, 2, (Object) null)) {
                            arrayList3.add(aVar);
                            break;
                            break;
                        }
                    }
                    i2++;
                    i = 1;
                }
                filterResults.values = arrayList3;
                size = arrayList3.size();
            }
            filterResults.count = size;
            return filterResults;
        }

        @Override // android.widget.Filter
        protected void publishResults(CharSequence charSequence, Filter.FilterResults filterResults) {
            a aVar = this.f481a;
            r.b(filterResults);
            Object obj = filterResults.values;
            if (obj == null) {
                throw new NullPointerException("null cannot be cast to non-null type java.util.ArrayList<com.omarea.common.model.SelectItem>");
            }
            aVar.h((ArrayList) obj);
            if (filterResults.count > 0) {
                this.f481a.notifyDataSetChanged();
            } else {
                this.f481a.notifyDataSetInvalidated();
            }
        }
    }

    public interface b {
        void a(List<com.omarea.a.f.a> list);
    }

    public final class c {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private TextView f482a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private TextView f483b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private CompoundButton f484c;

        public c(a aVar) {
        }

        public final CompoundButton a() {
            return this.f484c;
        }

        public final TextView b() {
            return this.f483b;
        }

        public final TextView c() {
            return this.f482a;
        }

        public final void d(CompoundButton compoundButton) {
            this.f484c = compoundButton;
        }

        public final void e(ImageView imageView) {
        }

        public final void f(TextView textView) {
            this.f483b = textView;
        }

        public final void g(TextView textView) {
            this.f482a = textView;
        }
    }

    static final class d implements View.OnClickListener {
        final /* synthetic */ com.omarea.a.f.a g;
        final /* synthetic */ c h;

        d(com.omarea.a.f.a aVar, c cVar) {
            this.g = aVar;
            this.h = cVar;
        }

        @Override // android.view.View.OnClickListener
        public final void onClick(View view) {
            Object next;
            if (a.this.l) {
                com.omarea.a.f.a aVar = this.g;
                aVar.d(true ^ aVar.a());
                CompoundButton compoundButtonA = this.h.a();
                if (compoundButtonA != null) {
                    compoundButtonA.setChecked(this.g.a());
                }
            } else {
                if (this.g.a()) {
                    return;
                }
                Iterator it = a.this.k.iterator();
                do {
                    if (!it.hasNext()) {
                        next = null;
                        break;
                    }
                    next = it.next();
                } while (!((com.omarea.a.f.a) next).a());
                com.omarea.a.f.a aVar2 = (com.omarea.a.f.a) next;
                if (aVar2 != null) {
                    aVar2.d(false);
                }
                this.g.d(true);
                a.this.notifyDataSetChanged();
            }
            b bVar = a.this.f;
            if (bVar != null) {
                bVar.a(a.this.g());
            }
        }
    }

    public a(Context context, ArrayList<com.omarea.a.f.a> arrayList, boolean z) {
        r.d(context, "context");
        r.d(arrayList, "items");
        this.j = context;
        this.k = arrayList;
        this.l = z;
        this.h = arrayList;
        this.i = new Object();
    }

    @Override // android.widget.Adapter
    /* JADX INFO: renamed from: e, reason: merged with bridge method [inline-methods] */
    public com.omarea.a.f.a getItem(int i) {
        com.omarea.a.f.a aVar = this.h.get(i);
        r.c(aVar, "filterItems[position]");
        return aVar;
    }

    public final boolean[] f() {
        ArrayList<com.omarea.a.f.a> arrayList = this.k;
        ArrayList arrayList2 = new ArrayList(q.k(arrayList, 10));
        Iterator<T> it = arrayList.iterator();
        while (it.hasNext()) {
            arrayList2.add(Boolean.valueOf(((com.omarea.a.f.a) it.next()).a()));
        }
        return q.R(arrayList2);
    }

    public final List<com.omarea.a.f.a> g() {
        ArrayList<com.omarea.a.f.a> arrayList = this.k;
        ArrayList arrayList2 = new ArrayList();
        for (Object obj : arrayList) {
            if (((com.omarea.a.f.a) obj).a()) {
                arrayList2.add(obj);
            }
        }
        return arrayList2;
    }

    @Override // android.widget.Adapter
    public int getCount() {
        return this.h.size();
    }

    @Override // android.widget.Filterable
    public Filter getFilter() {
        if (this.g == null) {
            this.g = new C0046a(this);
        }
        Filter filter = this.g;
        r.b(filter);
        return filter;
    }

    @Override // android.widget.Adapter
    public long getItemId(int i) {
        return i;
    }

    @Override // android.widget.Adapter
    public View getView(int i, View view, ViewGroup viewGroup) {
        r.d(viewGroup, "parent");
        if (view == null) {
            view = View.inflate(this.j, this.l ? com.omarea.a.b.item_multiple_chooser_item : com.omarea.a.b.item_single_chooser_item, null);
        }
        r.b(view);
        k(i, view);
        return view;
    }

    public final void h(ArrayList<com.omarea.a.f.a> arrayList) {
        r.d(arrayList, "<set-?>");
        this.h = arrayList;
    }

    public final void i(boolean z) {
        Iterator<T> it = this.k.iterator();
        while (it.hasNext()) {
            ((com.omarea.a.f.a) it.next()).d(z);
        }
        notifyDataSetChanged();
    }

    public final void j(b bVar) {
        this.f = bVar;
    }

    public final void k(int i, View view) {
        r.d(view, "convertView");
        com.omarea.a.f.a item = getItem(i);
        c cVar = new c(this);
        cVar.g((TextView) view.findViewById(com.omarea.a.a.ItemTitle));
        cVar.f((TextView) view.findViewById(com.omarea.a.a.ItemDesc));
        cVar.e((ImageView) view.findViewById(com.omarea.a.a.ItemIcon));
        cVar.d((CompoundButton) view.findViewById(com.omarea.a.a.ItemChecBox));
        view.setOnClickListener(new d(item, cVar));
        TextView textViewC = cVar.c();
        if (textViewC != null) {
            textViewC.setText(item.b());
        }
        TextView textViewB = cVar.b();
        if (textViewB != null) {
            String strB = item.b();
            if (strB == null || strB.length() == 0) {
                textViewB.setText(item.b());
            } else {
                textViewB.setVisibility(8);
            }
        }
        CompoundButton compoundButtonA = cVar.a();
        if (compoundButtonA != null) {
            compoundButtonA.setChecked(item.a());
        }
    }
}
