package com.omarea.data.customer;

import com.omarea.data.EventType;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final /* synthetic */ class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final /* synthetic */ int[] f532a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final /* synthetic */ int[] f533b;

    static {
        int[] iArr = new int[EventType.values().length];
        f532a = iArr;
        iArr[EventType.BOOT_COMPLETED.ordinal()] = 1;
        f532a[EventType.BATTERY_LOW.ordinal()] = 2;
        f532a[EventType.BATTERY_FULL.ordinal()] = 3;
        f532a[EventType.BATTERY_CAPACITY_CHANGED.ordinal()] = 4;
        f532a[EventType.POWER_CONNECTED.ordinal()] = 5;
        f532a[EventType.POWER_DISCONNECTED.ordinal()] = 6;
        f532a[EventType.SCREEN_OFF.ordinal()] = 7;
        f532a[EventType.SCREEN_ON.ordinal()] = 8;
        int[] iArr2 = new int[EventType.values().length];
        f533b = iArr2;
        iArr2[EventType.BOOT_COMPLETED.ordinal()] = 1;
        f533b[EventType.BATTERY_LOW.ordinal()] = 2;
        f533b[EventType.BATTERY_FULL.ordinal()] = 3;
        f533b[EventType.BATTERY_CAPACITY_CHANGED.ordinal()] = 4;
        f533b[EventType.POWER_CONNECTED.ordinal()] = 5;
        f533b[EventType.POWER_DISCONNECTED.ordinal()] = 6;
        f533b[EventType.SCREEN_OFF.ordinal()] = 7;
        f533b[EventType.SCREEN_ON.ordinal()] = 8;
        f533b[EventType.APP_SWITCH.ordinal()] = 9;
    }
}
