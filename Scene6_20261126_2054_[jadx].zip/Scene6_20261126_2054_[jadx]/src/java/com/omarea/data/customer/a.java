package com.omarea.data.customer;

import com.omarea.data.EventType;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final /* synthetic */ class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final /* synthetic */ int[] f529a;

    static {
        int[] iArr = new int[EventType.values().length];
        f529a = iArr;
        iArr[EventType.BATTERY_CAPACITY_CHANGED.ordinal()] = 1;
        f529a[EventType.BATTERY_CHANGED.ordinal()] = 2;
        f529a[EventType.BATTERY_LOW.ordinal()] = 3;
        f529a[EventType.POWER_CONNECTED.ordinal()] = 4;
        f529a[EventType.POWER_DISCONNECTED.ordinal()] = 5;
        f529a[EventType.CHARGE_CONFIG_CHANGED.ordinal()] = 6;
    }
}
