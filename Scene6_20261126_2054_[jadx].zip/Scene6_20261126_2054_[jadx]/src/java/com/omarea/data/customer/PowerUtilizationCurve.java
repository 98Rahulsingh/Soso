package com.omarea.data.customer;

import android.content.Context;
import com.omarea.data.EventType;
import com.omarea.library.basic.o;
import com.omarea.model.BatteryStatus;
import com.omarea.scene_mode.ModeSwitcher;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.h;
import kotlin.jvm.b.p;
import kotlin.jvm.internal.r;
import kotlin.s;
import kotlinx.coroutines.CoroutineStart;
import kotlinx.coroutines.h0;
import kotlinx.coroutines.i0;
import kotlinx.coroutines.w0;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class PowerUtilizationCurve implements com.omarea.data.c {
    private static long i;
    private static Timer j;
    private final com.omarea.store.c f;
    private final o g;
    private int h;

    public PowerUtilizationCurve(Context context) {
        r.d(context, "context");
        this.f = new com.omarea.store.c(context);
        this.g = new o(context);
        this.h = -1;
    }

    private final void b() {
        Timer timer = j;
        if (timer != null) {
            timer.cancel();
            j = null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void c() {
        long jCurrentTimeMillis = System.currentTimeMillis();
        if (jCurrentTimeMillis - i < 2900) {
            return;
        }
        i = jCurrentTimeMillis;
        if (com.omarea.data.b.n.a() < 1 || com.omarea.data.b.n.d() == 1) {
            com.omarea.data.b.n.s();
        } else {
            com.omarea.data.b.n.u();
        }
        boolean zC = this.g.c();
        BatteryStatus batteryStatus = new BatteryStatus();
        batteryStatus.time = System.currentTimeMillis();
        batteryStatus.temperature = com.omarea.data.b.n.k();
        batteryStatus.status = com.omarea.data.b.n.d();
        batteryStatus.current = (int) com.omarea.data.b.n.b();
        double dL = com.omarea.data.b.n.l();
        if (dL > 0) {
            batteryStatus.voltage = dL;
        }
        batteryStatus.screenOn = zC;
        batteryStatus.capacity = com.omarea.data.b.n.a();
        batteryStatus.packageName = ModeSwitcher.x.e();
        batteryStatus.mode = ModeSwitcher.x.d();
        this.f.j(batteryStatus);
        if (zC) {
            return;
        }
        b();
    }

    private final void d() {
        if (j == null && this.g.c()) {
            Timer timer = new Timer("Analyser-Power");
            timer.schedule(new TimerTask() { // from class: com.omarea.data.customer.PowerUtilizationCurve$startUpdate$$inlined$apply$lambda$1

                /* JADX INFO: renamed from: com.omarea.data.customer.PowerUtilizationCurve$startUpdate$$inlined$apply$lambda$1$1, reason: invalid class name */
                static final class AnonymousClass1 extends SuspendLambda implements p<h0, kotlin.coroutines.c<? super s>, Object> {
                    int label;
                    private h0 p$;

                    AnonymousClass1(kotlin.coroutines.c cVar) {
                        super(2, cVar);
                    }

                    public final kotlin.coroutines.c<s> create(Object obj, kotlin.coroutines.c<?> cVar) {
                        r.d(cVar, "completion");
                        AnonymousClass1 anonymousClass1 = PowerUtilizationCurve$startUpdate$$inlined$apply$lambda$1.this.new AnonymousClass1(cVar);
                        anonymousClass1.p$ = (h0) obj;
                        return anonymousClass1;
                    }

                    public final Object invoke(Object obj, Object obj2) {
                        return create(obj, (kotlin.coroutines.c) obj2).invokeSuspend(s.a);
                    }

                    public final Object invokeSuspend(Object obj) {
                        kotlin.coroutines.intrinsics.a.d();
                        if (this.label != 0) {
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        h.b(obj);
                        PowerUtilizationCurve$startUpdate$$inlined$apply$lambda$1.this.f.c();
                        return s.a;
                    }
                }

                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    kotlinx.coroutines.f.d(i0.a(w0.b()), (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass1(null), 3, (Object) null);
                }
            }, 0L, 3000L);
            j = timer;
        }
    }

    @Override // com.omarea.data.c
    public boolean eventFilter(EventType eventType) {
        r.d(eventType, "eventType");
        switch (e.f534a[eventType.ordinal()]) {
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
                return true;
            default:
                return false;
        }
    }

    @Override // com.omarea.data.c
    public boolean isAsync() {
        return true;
    }

    @Override // com.omarea.data.c
    public void onReceive(EventType eventType, HashMap<String, Object> map) {
        r.d(eventType, "eventType");
        switch (e.f535b[eventType.ordinal()]) {
            case 1:
                break;
            case 2:
                b();
                c();
                return;
            case 3:
                this.h = com.omarea.data.b.n.a();
                return;
            case 4:
                this.f.a();
                return;
            case 5:
                if ((com.omarea.data.b.n.a() > 80 && com.omarea.data.b.n.a() - this.h > 1) || com.omarea.data.b.n.a() - this.h > 30) {
                    this.f.a();
                }
                break;
            case 6:
                if (com.omarea.data.b.n.d() != 2) {
                    this.h = com.omarea.data.b.n.a();
                }
                break;
            default:
                return;
        }
        d();
    }

    @Override // com.omarea.data.c
    public void onSubscribe() {
        d();
    }

    @Override // com.omarea.data.c
    public void onUnsubscribe() {
        b();
    }
}
