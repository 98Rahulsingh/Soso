package com.omarea.data.customer;

import com.omarea.common.net.Daemon;
import com.omarea.common.net.DaemonEvent;
import com.omarea.data.EventType;
import java.util.HashMap;
import kotlin.jvm.internal.r;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class d implements com.omarea.data.c {
    private final boolean f;

    public d(boolean z) {
        this.f = z;
    }

    @Override // com.omarea.data.c
    public boolean eventFilter(EventType eventType) {
        r.d(eventType, "eventType");
        switch (c.f532a[eventType.ordinal()]) {
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
            case 7:
            case 8:
                return true;
            default:
                return false;
        }
    }

    @Override // com.omarea.data.c
    public boolean isAsync() {
        return this.f;
    }

    @Override // com.omarea.data.c
    public void onReceive(EventType eventType, HashMap<String, Object> map) {
        DaemonEvent daemonEvent;
        r.d(eventType, "eventType");
        if (Daemon.E.b()) {
            switch (c.f533b[eventType.ordinal()]) {
                case 1:
                    daemonEvent = DaemonEvent.BOOT_COMPLETED;
                    break;
                case 2:
                    daemonEvent = DaemonEvent.BATTERY_LOW;
                    break;
                case 3:
                    daemonEvent = DaemonEvent.BATTERY_FULL;
                    break;
                case 4:
                    daemonEvent = DaemonEvent.BATTERY_CAPACITY_CHANGED;
                    break;
                case 5:
                    daemonEvent = DaemonEvent.POWER_CONNECTED;
                    break;
                case 6:
                    daemonEvent = DaemonEvent.POWER_DISCONNECTED;
                    break;
                case 7:
                    daemonEvent = DaemonEvent.SCREEN_OFF;
                    break;
                case 8:
                    daemonEvent = DaemonEvent.SCREEN_ON;
                    break;
                case 9:
                    daemonEvent = DaemonEvent.APP_SWITCH;
                    break;
                default:
                    return;
            }
            Daemon.E.a().G0(daemonEvent, "");
        }
    }

    @Override // com.omarea.data.c
    public void onSubscribe() {
    }

    @Override // com.omarea.data.c
    public void onUnsubscribe() {
    }
}
