package com.omarea.data.customer;

import android.content.Context;
import com.omarea.Scene;
import com.omarea.data.EventType;
import com.omarea.store.j;
import com.omarea.vtools.popup.FloatMonitorFPS;
import com.omarea.vtools.popup.FloatMonitorThreads;
import java.util.HashMap;
import kotlin.jvm.internal.r;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class f implements com.omarea.data.c {
    private final boolean[] f;
    private final Context g;

    static final class a implements Runnable {
        final /* synthetic */ EventType g;

        a(EventType eventType) {
            this.g = eventType;
        }

        @Override // java.lang.Runnable
        public final void run() {
            EventType eventType = this.g;
            if (eventType == EventType.SCREEN_OFF) {
                f.this.f[0] = r.a(com.omarea.vtools.popup.c.s.a(), Boolean.TRUE);
                f.this.f[1] = com.omarea.vtools.popup.e.j.b();
                f.this.f[2] = FloatMonitorThreads.p.b();
                f.this.f[3] = r.a(FloatMonitorFPS.x.a(), Boolean.TRUE);
                f.this.f[4] = r.a(com.omarea.vtools.popup.b.G.a(), Boolean.TRUE);
                f.this.f[5] = r.a(com.omarea.vtools.popup.f.k.a(), Boolean.TRUE);
                new com.omarea.vtools.popup.c(f.this.g).g();
                new com.omarea.vtools.popup.e(f.this.g).m();
                new FloatMonitorThreads(f.this.g).j();
                new FloatMonitorFPS(f.this.g).u();
                new com.omarea.vtools.popup.b(f.this.g).u();
                new com.omarea.vtools.popup.f(f.this.g).h();
                return;
            }
            if (eventType == EventType.SCREEN_ON) {
                if (f.this.f[0]) {
                    new com.omarea.vtools.popup.c(f.this.g).i();
                    f.this.f[0] = false;
                }
                if (f.this.f[1]) {
                    new com.omarea.vtools.popup.e(f.this.g).p();
                    f.this.f[1] = false;
                }
                if (f.this.f[2]) {
                    new FloatMonitorThreads(f.this.g).k();
                    f.this.f[2] = false;
                }
                if (f.this.f[3]) {
                    new FloatMonitorFPS(f.this.g).x();
                    f.this.f[3] = false;
                }
                if (f.this.f[4]) {
                    new com.omarea.vtools.popup.b(f.this.g).w();
                    f.this.f[4] = false;
                }
                if (f.this.f[5]) {
                    new com.omarea.vtools.popup.f(f.this.g).j();
                    f.this.f[5] = false;
                }
            }
        }
    }

    public f(Context context) {
        r.d(context, "context");
        this.g = context;
        this.f = new boolean[]{false, false, false, false, false, false};
    }

    @Override // com.omarea.data.c
    public boolean eventFilter(EventType eventType) {
        r.d(eventType, "eventType");
        return eventType == EventType.SCREEN_OFF || eventType == EventType.SCREEN_ON;
    }

    @Override // com.omarea.data.c
    public boolean isAsync() {
        return false;
    }

    @Override // com.omarea.data.c
    public void onReceive(EventType eventType, HashMap<String, Object> map) {
        r.d(eventType, "eventType");
        Scene.a aVar = Scene.l;
        String str = j.M;
        r.c(str, "SpfConfig.GLOBAL_SPF_LAYER_ALWAYS_ON");
        if (aVar.a(str, false)) {
            return;
        }
        Scene.l.g(new a(eventType));
    }

    @Override // com.omarea.data.c
    public void onSubscribe() {
    }

    @Override // com.omarea.data.c
    public void onUnsubscribe() {
    }
}
