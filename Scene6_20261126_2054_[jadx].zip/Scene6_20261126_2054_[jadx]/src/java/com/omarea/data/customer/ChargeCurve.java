package com.omarea.data.customer;

import android.content.Context;
import com.omarea.data.EventType;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.h;
import kotlin.jvm.b.p;
import kotlin.jvm.internal.r;
import kotlin.s;
import kotlinx.coroutines.CoroutineStart;
import kotlinx.coroutines.h0;
import kotlinx.coroutines.i0;
import kotlinx.coroutines.w0;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class ChargeCurve implements com.omarea.data.c {
    private final com.omarea.store.d f;
    private Timer g;

    public ChargeCurve(Context context) {
        r.d(context, "context");
        this.f = new com.omarea.store.d(context);
    }

    private final void b() {
        Timer timer = this.g;
        if (timer != null) {
            timer.cancel();
            this.g = null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void c() {
        if (com.omarea.data.b.n.d() != 2) {
            b();
            return;
        }
        com.omarea.data.b.n.s();
        if (Math.abs(com.omarea.data.b.n.b()) > 100) {
            this.f.a(com.omarea.data.b.n.b(), com.omarea.data.b.n.h(), com.omarea.data.b.n.a(), com.omarea.data.b.n.k());
        }
    }

    private final void d() {
        if (this.g == null) {
            Timer timer = new Timer("Analyser-Charge");
            timer.schedule(new TimerTask() { // from class: com.omarea.data.customer.ChargeCurve$startUpdate$$inlined$apply$lambda$1

                /* JADX INFO: renamed from: com.omarea.data.customer.ChargeCurve$startUpdate$$inlined$apply$lambda$1$1, reason: invalid class name */
                static final class AnonymousClass1 extends SuspendLambda implements p<h0, kotlin.coroutines.c<? super s>, Object> {
                    int label;
                    private h0 p$;

                    AnonymousClass1(kotlin.coroutines.c cVar) {
                        super(2, cVar);
                    }

                    public final kotlin.coroutines.c<s> create(Object obj, kotlin.coroutines.c<?> cVar) {
                        r.d(cVar, "completion");
                        AnonymousClass1 anonymousClass1 = ChargeCurve$startUpdate$$inlined$apply$lambda$1.this.new AnonymousClass1(cVar);
                        anonymousClass1.p$ = (h0) obj;
                        return anonymousClass1;
                    }

                    public final Object invoke(Object obj, Object obj2) {
                        return create(obj, (kotlin.coroutines.c) obj2).invokeSuspend(s.a);
                    }

                    public final Object invokeSuspend(Object obj) {
                        kotlin.coroutines.intrinsics.a.d();
                        if (this.label != 0) {
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        h.b(obj);
                        ChargeCurve$startUpdate$$inlined$apply$lambda$1.this.f.c();
                        return s.a;
                    }
                }

                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    kotlinx.coroutines.f.d(i0.a(w0.b()), (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass1(null), 3, (Object) null);
                }
            }, 15000L, 1000L);
            s sVar = s.a;
            this.g = timer;
        }
    }

    @Override // com.omarea.data.c
    public boolean eventFilter(EventType eventType) {
        r.d(eventType, "eventType");
        int i = b.f530a[eventType.ordinal()];
        return i == 1 || i == 2 || i == 3;
    }

    @Override // com.omarea.data.c
    public boolean isAsync() {
        return true;
    }

    @Override // com.omarea.data.c
    public void onReceive(EventType eventType, HashMap<String, Object> map) {
        r.d(eventType, "eventType");
        int i = b.f531b[eventType.ordinal()];
        if (i == 1) {
            int iF = this.f.f();
            if (com.omarea.data.b.n.a() == -1 || com.omarea.data.b.n.a() == iF) {
                return;
            }
            this.f.c();
            return;
        }
        if (i == 2) {
            b();
        } else if (i == 3 && this.g == null && com.omarea.data.b.n.d() == 2) {
            d();
        }
    }

    @Override // com.omarea.data.c
    public void onSubscribe() {
    }

    @Override // com.omarea.data.c
    public void onUnsubscribe() {
    }
}
