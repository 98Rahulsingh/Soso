package com.omarea.data.customer;

import com.omarea.data.EventType;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final /* synthetic */ class e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final /* synthetic */ int[] f534a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final /* synthetic */ int[] f535b;

    static {
        int[] iArr = new int[EventType.values().length];
        f534a = iArr;
        iArr[EventType.SCREEN_ON.ordinal()] = 1;
        f534a[EventType.SCREEN_OFF.ordinal()] = 2;
        f534a[EventType.POWER_CONNECTED.ordinal()] = 3;
        f534a[EventType.POWER_DISCONNECTED.ordinal()] = 4;
        f534a[EventType.BATTERY_CHANGED.ordinal()] = 5;
        f534a[EventType.BATTERY_FULL.ordinal()] = 6;
        int[] iArr2 = new int[EventType.values().length];
        f535b = iArr2;
        iArr2[EventType.SCREEN_ON.ordinal()] = 1;
        f535b[EventType.SCREEN_OFF.ordinal()] = 2;
        f535b[EventType.POWER_CONNECTED.ordinal()] = 3;
        f535b[EventType.BATTERY_FULL.ordinal()] = 4;
        f535b[EventType.POWER_DISCONNECTED.ordinal()] = 5;
        f535b[EventType.BATTERY_CHANGED.ordinal()] = 6;
    }
}
