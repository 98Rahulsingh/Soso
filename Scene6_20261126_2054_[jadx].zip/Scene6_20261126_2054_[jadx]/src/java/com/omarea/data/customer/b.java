package com.omarea.data.customer;

import com.omarea.data.EventType;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final /* synthetic */ class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final /* synthetic */ int[] f530a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final /* synthetic */ int[] f531b;

    static {
        int[] iArr = new int[EventType.values().length];
        f530a = iArr;
        iArr[EventType.POWER_CONNECTED.ordinal()] = 1;
        f530a[EventType.POWER_DISCONNECTED.ordinal()] = 2;
        f530a[EventType.BATTERY_CHANGED.ordinal()] = 3;
        int[] iArr2 = new int[EventType.values().length];
        f531b = iArr2;
        iArr2[EventType.POWER_CONNECTED.ordinal()] = 1;
        f531b[EventType.POWER_DISCONNECTED.ordinal()] = 2;
        f531b[EventType.BATTERY_CHANGED.ordinal()] = 3;
    }
}
