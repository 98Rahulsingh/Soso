package com.omarea.data.customer;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import com.omarea.data.EventType;
import com.omarea.library.shell.BatteryUtils;
import com.omarea.library.shell.t;
import com.omarea.store.j;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import kotlin.jvm.internal.o;
import kotlin.jvm.internal.r;
import kotlin.s;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class BatteryReceiver implements com.omarea.data.c {
    private final double batteryCapacity;
    private BatteryUtils batteryUtils;
    private SharedPreferences chargeConfig;
    private boolean chargeDisabled;
    private Timer governorTimer;
    private final boolean isAsync;
    private com.omarea.common.shell.c keepShellAsync;
    private int lastLimitValue;
    private long lastSetChargeLimit;
    private int lowSpeedExtreme;
    private int lowSpeedHigh;
    private int lowSpeedMedium;

    public static final class a extends TimerTask {
        a() {
        }

        @Override // java.util.TimerTask, java.lang.Runnable
        public void run() {
            BatteryReceiver.this.governorRun();
        }
    }

    public BatteryReceiver(Context context, boolean z) {
        r.d(context, "service");
        this.isAsync = z;
        this.chargeDisabled = t.f771a.a("vtools.bp").equals("1");
        this.batteryCapacity = new com.omarea.d.b.a().a(context);
        this.batteryUtils = new BatteryUtils();
        this.lowSpeedMedium = 1000;
        this.lowSpeedHigh = 500;
        this.lowSpeedExtreme = 100;
        this.lastLimitValue = -1;
        if (this.keepShellAsync == null) {
            this.keepShellAsync = new com.omarea.common.shell.c(context, false, 2, null);
        }
        SharedPreferences sharedPreferences = context.getSharedPreferences(j.f921d, 0);
        r.c(sharedPreferences, "service.getSharedPrefere…PF, Context.MODE_PRIVATE)");
        this.chargeConfig = sharedPreferences;
    }

    public /* synthetic */ BatteryReceiver(Context context, boolean z, int i, o oVar) {
        this(context, (i & 2) != 0 ? true : z);
    }

    private final void autoChangeLimitValue(EventType eventType) {
        int i;
        if (!this.chargeConfig.getBoolean(j.p, false) || com.omarea.data.b.n.a() <= 80) {
            if (this.chargeConfig.getBoolean(j.g, false)) {
                setChargerLimitToValue(getQcLimit(), eventType, false);
            }
        } else {
            if (com.omarea.data.b.n.a() > 90) {
                i = this.lowSpeedExtreme;
            } else {
                i = com.omarea.data.b.n.a() > 85 ? this.lowSpeedHigh : this.lowSpeedMedium;
            }
            setChargerLimitToValue(i, eventType, true);
        }
    }

    private final void disableCharge() {
        this.chargeDisabled = new BatteryUtils().l();
    }

    private final boolean getBpAllowed() {
        return this.chargeConfig.getBoolean(j.j, false);
    }

    private final int getBpLevel() {
        return this.chargeConfig.getInt(j.k, j.o);
    }

    private final int getCurrentTime() {
        Calendar calendar = Calendar.getInstance();
        return (calendar.get(11) * 60) + calendar.get(12);
    }

    private final int getGetUpTime() {
        return this.chargeConfig.getInt(j.q, j.r);
    }

    private final int getGoToBedTime() {
        return this.chargeConfig.getInt(j.s, j.t);
    }

    private final boolean getOnCharge() {
        return com.omarea.data.b.n.d() == 2;
    }

    private final int getQcLimit() {
        return this.chargeConfig.getInt(j.h, j.i);
    }

    private final boolean getShouldBP() {
        return getBpAllowed() && (com.omarea.data.b.n.a() >= getBpLevel() || (this.chargeDisabled && com.omarea.data.b.n.a() > getBpLevel() + (-20)));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void governorRun() {
        if (this.chargeConfig.getInt(j.u, j.y) != j.x || inSleepTime() || this.chargeDisabled) {
            stopGovernorTimer();
        } else {
            autoChangeLimitValue(EventType.TIMER);
        }
    }

    private final boolean inSleepTime() {
        if (!this.chargeConfig.getBoolean(j.p, false)) {
            return false;
        }
        int currentTime = getCurrentTime();
        int getUpTime = getGetUpTime();
        int goToBedTime = getGoToBedTime();
        if (getUpTime <= goToBedTime || goToBedTime > currentTime || getUpTime < currentTime) {
            if (getUpTime >= goToBedTime) {
                return false;
            }
            if (currentTime < goToBedTime && currentTime > getUpTime) {
                return false;
            }
        }
        return true;
    }

    private final void resumeCharge() {
        this.chargeDisabled = !new BatteryUtils().q();
    }

    private final void setChargerLimitToValue(int i, EventType eventType, boolean z) {
        int i2 = this.chargeConfig.getInt(j.u, j.y);
        try {
            boolean z2 = false;
            boolean z3 = true;
            if (eventType == EventType.CHARGE_CONFIG_CHANGED) {
                boolean z4 = z3;
                z3 = false;
                z2 = z4;
            } else if (i2 == j.w) {
                if (eventType != EventType.BATTERY_CHANGED) {
                    Log.d("@Scene", "CHARGE_SPF_EXEC_MODE_SPEED_DOWN > " + eventType.name());
                }
                if (eventType == EventType.BATTERY_CAPACITY_CHANGED || eventType == EventType.POWER_CONNECTED || eventType == EventType.POWER_DISCONNECTED) {
                    z2 = true;
                }
            } else {
                if (i2 == j.x) {
                    if (z) {
                        stopGovernorTimer();
                        if (z && System.currentTimeMillis() - this.lastSetChargeLimit < 5000) {
                            z3 = false;
                        }
                    } else if (eventType != EventType.TIMER) {
                        startGovernorTimer();
                    }
                } else if (i2 != j.v || (z && System.currentTimeMillis() - this.lastSetChargeLimit < 5000)) {
                    z3 = false;
                }
                boolean z5 = z3;
                z3 = false;
                z2 = z5;
            }
            if (z2) {
                this.lastSetChargeLimit = System.currentTimeMillis();
                this.lastLimitValue = i;
                this.batteryUtils.t(i, z3);
            }
        } catch (Exception unused) {
        }
    }

    private final boolean sleepChargeMode(int i, int i2, int i3, EventType eventType) {
        if (i < 20 || !inSleepTime()) {
            return false;
        }
        int getUpTime = getGetUpTime();
        if (i >= i2) {
            int i4 = this.lastLimitValue;
            int i5 = this.lowSpeedExtreme;
            if (i4 != i5) {
                this.lastLimitValue = i5;
                this.batteryUtils.t(i5, eventType == EventType.BATTERY_CAPACITY_CHANGED);
            }
        } else {
            int iB = (int) ((((double) ((i2 - i) / 100.0f)) * this.batteryCapacity) / ((double) (new com.omarea.d.a.b(getUpTime).b() / 60.0f)));
            int i6 = this.lowSpeedExtreme;
            if (iB < i6) {
                i3 = i6;
            } else if (iB <= i3) {
                i3 = iB;
            }
            if (this.lastLimitValue != i3) {
                this.lastLimitValue = i3;
                this.batteryUtils.t(i3, eventType == EventType.BATTERY_CAPACITY_CHANGED);
            }
        }
        return true;
    }

    private final void startGovernorTimer() {
        if (this.governorTimer == null) {
            Timer timer = new Timer("ChargeControl");
            timer.schedule(new a(), 0L, 1000L);
            s sVar = s.a;
            this.governorTimer = timer;
        }
    }

    private final void stopGovernorTimer() {
        Timer timer = this.governorTimer;
        if (timer != null) {
            if (timer != null) {
                timer.cancel();
            }
            Timer timer2 = this.governorTimer;
            if (timer2 != null) {
                timer2.purge();
            }
            this.governorTimer = null;
        }
    }

    @Override // com.omarea.data.c
    public boolean eventFilter(EventType eventType) {
        r.d(eventType, "eventType");
        switch (com.omarea.data.customer.a.f529a[eventType.ordinal()]) {
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
                return true;
            default:
                return false;
        }
    }

    @Override // com.omarea.data.c
    public boolean isAsync() {
        return this.isAsync;
    }

    public final void onDestroy$app_release_mini() {
        resumeCharge();
        com.omarea.common.shell.c cVar = this.keepShellAsync;
        if (cVar != null) {
            cVar.a();
        }
        this.keepShellAsync = null;
    }

    @Override // com.omarea.data.c
    public void onReceive(EventType eventType, HashMap<String, Object> map) {
        r.d(eventType, "eventType");
        if (com.omarea.data.b.n.a() < 0) {
            return;
        }
        try {
            if (getShouldBP() != this.chargeDisabled) {
                if (!this.chargeDisabled) {
                    disableCharge();
                    return;
                }
                resumeCharge();
            }
            if (getOnCharge()) {
                if (sleepChargeMode(com.omarea.data.b.n.a(), getBpAllowed() ? getBpLevel() : 100, getQcLimit(), eventType) || !this.chargeConfig.getBoolean(j.g, false)) {
                    return;
                }
                autoChangeLimitValue(eventType);
            }
        } catch (Exception unused) {
        }
    }

    @Override // com.omarea.data.c
    public void onSubscribe() {
    }

    @Override // com.omarea.data.c
    public void onUnsubscribe() {
    }
}
