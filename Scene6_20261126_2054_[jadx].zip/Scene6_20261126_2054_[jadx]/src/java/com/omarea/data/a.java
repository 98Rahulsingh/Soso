package com.omarea.data;

import android.util.Log;
import java.util.ArrayList;
import java.util.HashMap;
import kotlin.jvm.internal.r;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class a {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final a f524b = new a();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private static final ArrayList<c> f523a = new ArrayList<>();

    /* JADX INFO: renamed from: com.omarea.data.a$a, reason: collision with other inner class name */
    public static final class C0055a extends Thread {
        private final c f;
        private final EventType g;
        private final HashMap<String, Object> h;

        public C0055a(c cVar, EventType eventType, HashMap<String, Object> map) {
            r.d(cVar, "eventReceiver");
            this.f = cVar;
            this.g = eventType;
            this.h = map;
        }

        @Override // java.lang.Thread, java.lang.Runnable
        public void run() {
            c cVar = this.f;
            EventType eventType = this.g;
            r.b(eventType);
            cVar.onReceive(eventType, this.h);
        }
    }

    private a() {
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static /* synthetic */ void b(a aVar, EventType eventType, HashMap map, int i, Object obj) {
        if ((i & 2) != 0) {
            map = null;
        }
        aVar.a(eventType, map);
    }

    public final void a(EventType eventType, HashMap<String, Object> map) {
        if (f523a.size() > 0) {
            for (c cVar : new ArrayList(f523a)) {
                try {
                    r.b(eventType);
                    if (cVar.eventFilter(eventType)) {
                        if (cVar.isAsync()) {
                            r.c(cVar, "eventReceiver");
                            new C0055a(cVar, eventType, map).start();
                        } else {
                            cVar.onReceive(eventType, map);
                        }
                    }
                } catch (Exception e) {
                    Log.e("SceneEventBus", "" + e.getMessage());
                }
            }
        }
    }

    public final void c(c cVar) {
        r.d(cVar, "eventReceiver");
        if (f523a.contains(cVar)) {
            return;
        }
        f523a.add(cVar);
        cVar.onSubscribe();
    }

    public final void d(c cVar) {
        r.d(cVar, "eventReceiver");
        if (f523a.contains(cVar)) {
            f523a.remove(cVar);
            cVar.onUnsubscribe();
        }
    }
}
