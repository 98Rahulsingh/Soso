package com.omarea.data;

import java.util.HashMap;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public interface c {
    boolean eventFilter(EventType eventType);

    boolean isAsync();

    void onReceive(EventType eventType, HashMap<String, Object> map);

    void onSubscribe();

    void onUnsubscribe();
}
