package com.omarea.data.publisher;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import com.omarea.data.EventType;
import com.omarea.data.b;
import com.omarea.data.customer.BatteryReceiver;
import kotlin.jvm.internal.r;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class a extends BroadcastReceiver {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private int f538a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private int f539b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private BatteryManager f540c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private final Context f541d;

    public a(Context context) {
        r.d(context, "applicationContext");
        this.f541d = context;
        this.f539b = 1;
    }

    public final void a() {
        Context context = this.f541d;
        context.registerReceiver(this, new IntentFilter("android.intent.action.BOOT_COMPLETED"));
        context.registerReceiver(this, new IntentFilter("android.intent.action.ACTION_POWER_CONNECTED"));
        context.registerReceiver(this, new IntentFilter("android.intent.action.ACTION_POWER_DISCONNECTED"));
        context.registerReceiver(this, new IntentFilter("android.intent.action.BATTERY_CHANGED"));
        context.registerReceiver(this, new IntentFilter("android.intent.action.BATTERY_LOW"));
        com.omarea.data.a.f524b.c(new BatteryReceiver(this.f541d, false, 2, null));
    }

    /* JADX WARN: Code duplicated, block: B:17:0x005a A[Catch: all -> 0x010e, Exception -> 0x0113, TryCatch #2 {Exception -> 0x0113, all -> 0x010e, blocks: (B:6:0x0015, B:8:0x003d, B:9:0x0043, B:12:0x004c, B:17:0x005a, B:19:0x005e, B:21:0x006a, B:22:0x006f, B:23:0x0076, B:24:0x0077, B:25:0x0081, B:27:0x0099, B:29:0x009d, B:31:0x00ad, B:32:0x00b1, B:33:0x00b5, B:35:0x00c4, B:36:0x00c9, B:38:0x00d1, B:39:0x00d5, B:49:0x0100, B:51:0x0104, B:40:0x00d9, B:42:0x00e1, B:43:0x00e6, B:45:0x00ee, B:46:0x00f3, B:48:0x00fb, B:13:0x004e), top: B:59:0x0015 }] */
    /* JADX WARN: Code duplicated, block: B:19:0x005e A[Catch: all -> 0x010e, Exception -> 0x0113, TryCatch #2 {Exception -> 0x0113, all -> 0x010e, blocks: (B:6:0x0015, B:8:0x003d, B:9:0x0043, B:12:0x004c, B:17:0x005a, B:19:0x005e, B:21:0x006a, B:22:0x006f, B:23:0x0076, B:24:0x0077, B:25:0x0081, B:27:0x0099, B:29:0x009d, B:31:0x00ad, B:32:0x00b1, B:33:0x00b5, B:35:0x00c4, B:36:0x00c9, B:38:0x00d1, B:39:0x00d5, B:49:0x0100, B:51:0x0104, B:40:0x00d9, B:42:0x00e1, B:43:0x00e6, B:45:0x00ee, B:46:0x00f3, B:48:0x00fb, B:13:0x004e), top: B:59:0x0015 }] */
    /* JADX WARN: Code duplicated, block: B:21:0x006a A[Catch: all -> 0x010e, Exception -> 0x0113, TryCatch #2 {Exception -> 0x0113, all -> 0x010e, blocks: (B:6:0x0015, B:8:0x003d, B:9:0x0043, B:12:0x004c, B:17:0x005a, B:19:0x005e, B:21:0x006a, B:22:0x006f, B:23:0x0076, B:24:0x0077, B:25:0x0081, B:27:0x0099, B:29:0x009d, B:31:0x00ad, B:32:0x00b1, B:33:0x00b5, B:35:0x00c4, B:36:0x00c9, B:38:0x00d1, B:39:0x00d5, B:49:0x0100, B:51:0x0104, B:40:0x00d9, B:42:0x00e1, B:43:0x00e6, B:45:0x00ee, B:46:0x00f3, B:48:0x00fb, B:13:0x004e), top: B:59:0x0015 }] */
    /* JADX WARN: Code duplicated, block: B:22:0x006f A[Catch: all -> 0x010e, Exception -> 0x0113, TryCatch #2 {Exception -> 0x0113, all -> 0x010e, blocks: (B:6:0x0015, B:8:0x003d, B:9:0x0043, B:12:0x004c, B:17:0x005a, B:19:0x005e, B:21:0x006a, B:22:0x006f, B:23:0x0076, B:24:0x0077, B:25:0x0081, B:27:0x0099, B:29:0x009d, B:31:0x00ad, B:32:0x00b1, B:33:0x00b5, B:35:0x00c4, B:36:0x00c9, B:38:0x00d1, B:39:0x00d5, B:49:0x0100, B:51:0x0104, B:40:0x00d9, B:42:0x00e1, B:43:0x00e6, B:45:0x00ee, B:46:0x00f3, B:48:0x00fb, B:13:0x004e), top: B:59:0x0015 }] */
    /* JADX WARN: Code duplicated, block: B:31:0x00ad A[Catch: all -> 0x010e, Exception -> 0x0113, TryCatch #2 {Exception -> 0x0113, all -> 0x010e, blocks: (B:6:0x0015, B:8:0x003d, B:9:0x0043, B:12:0x004c, B:17:0x005a, B:19:0x005e, B:21:0x006a, B:22:0x006f, B:23:0x0076, B:24:0x0077, B:25:0x0081, B:27:0x0099, B:29:0x009d, B:31:0x00ad, B:32:0x00b1, B:33:0x00b5, B:35:0x00c4, B:36:0x00c9, B:38:0x00d1, B:39:0x00d5, B:49:0x0100, B:51:0x0104, B:40:0x00d9, B:42:0x00e1, B:43:0x00e6, B:45:0x00ee, B:46:0x00f3, B:48:0x00fb, B:13:0x004e), top: B:59:0x0015 }] */
    /* JADX WARN: Code duplicated, block: B:33:0x00b5 A[Catch: all -> 0x010e, Exception -> 0x0113, TryCatch #2 {Exception -> 0x0113, all -> 0x010e, blocks: (B:6:0x0015, B:8:0x003d, B:9:0x0043, B:12:0x004c, B:17:0x005a, B:19:0x005e, B:21:0x006a, B:22:0x006f, B:23:0x0076, B:24:0x0077, B:25:0x0081, B:27:0x0099, B:29:0x009d, B:31:0x00ad, B:32:0x00b1, B:33:0x00b5, B:35:0x00c4, B:36:0x00c9, B:38:0x00d1, B:39:0x00d5, B:49:0x0100, B:51:0x0104, B:40:0x00d9, B:42:0x00e1, B:43:0x00e6, B:45:0x00ee, B:46:0x00f3, B:48:0x00fb, B:13:0x004e), top: B:59:0x0015 }] */
    /* JADX WARN: Code duplicated, block: B:35:0x00c4 A[Catch: all -> 0x010e, Exception -> 0x0113, TryCatch #2 {Exception -> 0x0113, all -> 0x010e, blocks: (B:6:0x0015, B:8:0x003d, B:9:0x0043, B:12:0x004c, B:17:0x005a, B:19:0x005e, B:21:0x006a, B:22:0x006f, B:23:0x0076, B:24:0x0077, B:25:0x0081, B:27:0x0099, B:29:0x009d, B:31:0x00ad, B:32:0x00b1, B:33:0x00b5, B:35:0x00c4, B:36:0x00c9, B:38:0x00d1, B:39:0x00d5, B:49:0x0100, B:51:0x0104, B:40:0x00d9, B:42:0x00e1, B:43:0x00e6, B:45:0x00ee, B:46:0x00f3, B:48:0x00fb, B:13:0x004e), top: B:59:0x0015 }] */
    /* JADX WARN: Code duplicated, block: B:38:0x00d1 A[Catch: all -> 0x010e, Exception -> 0x0113, TryCatch #2 {Exception -> 0x0113, all -> 0x010e, blocks: (B:6:0x0015, B:8:0x003d, B:9:0x0043, B:12:0x004c, B:17:0x005a, B:19:0x005e, B:21:0x006a, B:22:0x006f, B:23:0x0076, B:24:0x0077, B:25:0x0081, B:27:0x0099, B:29:0x009d, B:31:0x00ad, B:32:0x00b1, B:33:0x00b5, B:35:0x00c4, B:36:0x00c9, B:38:0x00d1, B:39:0x00d5, B:49:0x0100, B:51:0x0104, B:40:0x00d9, B:42:0x00e1, B:43:0x00e6, B:45:0x00ee, B:46:0x00f3, B:48:0x00fb, B:13:0x004e), top: B:59:0x0015 }] */
    /* JADX WARN: Code duplicated, block: B:40:0x00d9 A[Catch: all -> 0x010e, Exception -> 0x0113, TryCatch #2 {Exception -> 0x0113, all -> 0x010e, blocks: (B:6:0x0015, B:8:0x003d, B:9:0x0043, B:12:0x004c, B:17:0x005a, B:19:0x005e, B:21:0x006a, B:22:0x006f, B:23:0x0076, B:24:0x0077, B:25:0x0081, B:27:0x0099, B:29:0x009d, B:31:0x00ad, B:32:0x00b1, B:33:0x00b5, B:35:0x00c4, B:36:0x00c9, B:38:0x00d1, B:39:0x00d5, B:49:0x0100, B:51:0x0104, B:40:0x00d9, B:42:0x00e1, B:43:0x00e6, B:45:0x00ee, B:46:0x00f3, B:48:0x00fb, B:13:0x004e), top: B:59:0x0015 }] */
    /* JADX WARN: Code duplicated, block: B:42:0x00e1 A[Catch: all -> 0x010e, Exception -> 0x0113, TryCatch #2 {Exception -> 0x0113, all -> 0x010e, blocks: (B:6:0x0015, B:8:0x003d, B:9:0x0043, B:12:0x004c, B:17:0x005a, B:19:0x005e, B:21:0x006a, B:22:0x006f, B:23:0x0076, B:24:0x0077, B:25:0x0081, B:27:0x0099, B:29:0x009d, B:31:0x00ad, B:32:0x00b1, B:33:0x00b5, B:35:0x00c4, B:36:0x00c9, B:38:0x00d1, B:39:0x00d5, B:49:0x0100, B:51:0x0104, B:40:0x00d9, B:42:0x00e1, B:43:0x00e6, B:45:0x00ee, B:46:0x00f3, B:48:0x00fb, B:13:0x004e), top: B:59:0x0015 }] */
    /* JADX WARN: Code duplicated, block: B:43:0x00e6 A[Catch: all -> 0x010e, Exception -> 0x0113, TryCatch #2 {Exception -> 0x0113, all -> 0x010e, blocks: (B:6:0x0015, B:8:0x003d, B:9:0x0043, B:12:0x004c, B:17:0x005a, B:19:0x005e, B:21:0x006a, B:22:0x006f, B:23:0x0076, B:24:0x0077, B:25:0x0081, B:27:0x0099, B:29:0x009d, B:31:0x00ad, B:32:0x00b1, B:33:0x00b5, B:35:0x00c4, B:36:0x00c9, B:38:0x00d1, B:39:0x00d5, B:49:0x0100, B:51:0x0104, B:40:0x00d9, B:42:0x00e1, B:43:0x00e6, B:45:0x00ee, B:46:0x00f3, B:48:0x00fb, B:13:0x004e), top: B:59:0x0015 }] */
    /* JADX WARN: Code duplicated, block: B:45:0x00ee A[Catch: all -> 0x010e, Exception -> 0x0113, TryCatch #2 {Exception -> 0x0113, all -> 0x010e, blocks: (B:6:0x0015, B:8:0x003d, B:9:0x0043, B:12:0x004c, B:17:0x005a, B:19:0x005e, B:21:0x006a, B:22:0x006f, B:23:0x0076, B:24:0x0077, B:25:0x0081, B:27:0x0099, B:29:0x009d, B:31:0x00ad, B:32:0x00b1, B:33:0x00b5, B:35:0x00c4, B:36:0x00c9, B:38:0x00d1, B:39:0x00d5, B:49:0x0100, B:51:0x0104, B:40:0x00d9, B:42:0x00e1, B:43:0x00e6, B:45:0x00ee, B:46:0x00f3, B:48:0x00fb, B:13:0x004e), top: B:59:0x0015 }] */
    /* JADX WARN: Code duplicated, block: B:46:0x00f3 A[Catch: all -> 0x010e, Exception -> 0x0113, TryCatch #2 {Exception -> 0x0113, all -> 0x010e, blocks: (B:6:0x0015, B:8:0x003d, B:9:0x0043, B:12:0x004c, B:17:0x005a, B:19:0x005e, B:21:0x006a, B:22:0x006f, B:23:0x0076, B:24:0x0077, B:25:0x0081, B:27:0x0099, B:29:0x009d, B:31:0x00ad, B:32:0x00b1, B:33:0x00b5, B:35:0x00c4, B:36:0x00c9, B:38:0x00d1, B:39:0x00d5, B:49:0x0100, B:51:0x0104, B:40:0x00d9, B:42:0x00e1, B:43:0x00e6, B:45:0x00ee, B:46:0x00f3, B:48:0x00fb, B:13:0x004e), top: B:59:0x0015 }] */
    /* JADX WARN: Code duplicated, block: B:48:0x00fb A[Catch: all -> 0x010e, Exception -> 0x0113, TryCatch #2 {Exception -> 0x0113, all -> 0x010e, blocks: (B:6:0x0015, B:8:0x003d, B:9:0x0043, B:12:0x004c, B:17:0x005a, B:19:0x005e, B:21:0x006a, B:22:0x006f, B:23:0x0076, B:24:0x0077, B:25:0x0081, B:27:0x0099, B:29:0x009d, B:31:0x00ad, B:32:0x00b1, B:33:0x00b5, B:35:0x00c4, B:36:0x00c9, B:38:0x00d1, B:39:0x00d5, B:49:0x0100, B:51:0x0104, B:40:0x00d9, B:42:0x00e1, B:43:0x00e6, B:45:0x00ee, B:46:0x00f3, B:48:0x00fb, B:13:0x004e), top: B:59:0x0015 }] */
    /* JADX WARN: Code duplicated, block: B:49:0x0100 A[Catch: all -> 0x010e, Exception -> 0x0113, TryCatch #2 {Exception -> 0x0113, all -> 0x010e, blocks: (B:6:0x0015, B:8:0x003d, B:9:0x0043, B:12:0x004c, B:17:0x005a, B:19:0x005e, B:21:0x006a, B:22:0x006f, B:23:0x0076, B:24:0x0077, B:25:0x0081, B:27:0x0099, B:29:0x009d, B:31:0x00ad, B:32:0x00b1, B:33:0x00b5, B:35:0x00c4, B:36:0x00c9, B:38:0x00d1, B:39:0x00d5, B:49:0x0100, B:51:0x0104, B:40:0x00d9, B:42:0x00e1, B:43:0x00e6, B:45:0x00ee, B:46:0x00f3, B:48:0x00fb, B:13:0x004e), top: B:59:0x0015 }] */
    /* JADX WARN: Code duplicated, block: B:51:0x0104 A[Catch: all -> 0x010e, Exception -> 0x0113, TRY_LEAVE, TryCatch #2 {Exception -> 0x0113, all -> 0x010e, blocks: (B:6:0x0015, B:8:0x003d, B:9:0x0043, B:12:0x004c, B:17:0x005a, B:19:0x005e, B:21:0x006a, B:22:0x006f, B:23:0x0076, B:24:0x0077, B:25:0x0081, B:27:0x0099, B:29:0x009d, B:31:0x00ad, B:32:0x00b1, B:33:0x00b5, B:35:0x00c4, B:36:0x00c9, B:38:0x00d1, B:39:0x00d5, B:49:0x0100, B:51:0x0104, B:40:0x00d9, B:42:0x00e1, B:43:0x00e6, B:45:0x00ee, B:46:0x00f3, B:48:0x00fb, B:13:0x004e), top: B:59:0x0015 }] */
    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        double d2;
        com.omarea.data.a aVar;
        EventType eventType;
        com.omarea.data.a aVar2;
        EventType eventType2;
        Object systemService;
        r.d(context, "context");
        r.d(intent, "intent");
        String action = intent.getAction();
        if (action == null) {
            return;
        }
        BroadcastReceiver.PendingResult pendingResultGoAsync = goAsync();
        try {
            int intExtra = intent.getIntExtra("status", 1);
            int intExtra2 = intent.getIntExtra("level", -1);
            double intExtra3 = ((double) intent.getIntExtra("temperature", -1)) / ((double) 10.0f);
            double intExtra4 = intent.getIntExtra("voltage", 0);
            if (intExtra4 > 1000) {
                intExtra4 /= 1000.0d;
            }
            if (intExtra4 <= 100) {
                if (intExtra4 > 10) {
                    d2 = 10.0d;
                } else {
                    if (intExtra2 == -1) {
                        if (this.f540c == null) {
                            systemService = context.getApplicationContext().getSystemService("batterymanager");
                            if (systemService != null) {
                                throw new NullPointerException("null cannot be cast to non-null type android.os.BatteryManager");
                            }
                            this.f540c = (BatteryManager) systemService;
                        }
                        BatteryManager batteryManager = this.f540c;
                        r.b(batteryManager);
                        intExtra2 = batteryManager.getIntProperty(4);
                    }
                    b.n.n(intExtra);
                    b.n.m(intExtra2);
                    b.n.o(intExtra4);
                    b.n.r(intExtra3);
                    if (intExtra != 1 && intExtra != this.f539b) {
                        this.f539b = intExtra;
                        if (!Integer.valueOf(intExtra).equals(2)) {
                            aVar2 = com.omarea.data.a.f524b;
                            eventType2 = EventType.POWER_CONNECTED;
                        } else if (Integer.valueOf(intExtra).equals(5)) {
                            aVar2 = com.omarea.data.a.f524b;
                            eventType2 = EventType.BATTERY_FULL;
                        }
                        com.omarea.data.a.b(aVar2, eventType2, null, 2, null);
                    }
                    if (r.a(action, "android.intent.action.BATTERY_LOW")) {
                        aVar = com.omarea.data.a.f524b;
                        eventType = EventType.BATTERY_LOW;
                    } else if (r.a(action, "android.intent.action.BATTERY_CHANGED")) {
                        aVar = com.omarea.data.a.f524b;
                        eventType = EventType.BATTERY_CHANGED;
                    } else if (!r.a(action, "android.intent.action.ACTION_POWER_DISCONNECTED")) {
                        aVar = com.omarea.data.a.f524b;
                        eventType = EventType.POWER_DISCONNECTED;
                    } else if (r.a(action, "android.intent.action.ACTION_POWER_CONNECTED")) {
                        aVar = com.omarea.data.a.f524b;
                        eventType = EventType.POWER_CONNECTED;
                    } else if (this.f538a != intExtra2) {
                        this.f538a = intExtra2;
                        com.omarea.data.a.b(com.omarea.data.a.f524b, EventType.BATTERY_CAPACITY_CHANGED, null, 2, null);
                    }
                    com.omarea.data.a.b(aVar, eventType, null, 2, null);
                    if (this.f538a != intExtra2) {
                        this.f538a = intExtra2;
                        com.omarea.data.a.b(com.omarea.data.a.f524b, EventType.BATTERY_CAPACITY_CHANGED, null, 2, null);
                    }
                }
                pendingResultGoAsync.finish();
            }
            d2 = 100.0d;
            intExtra4 /= d2;
            if (intExtra2 == -1) {
                if (this.f540c == null) {
                    systemService = context.getApplicationContext().getSystemService("batterymanager");
                    if (systemService != null) {
                        throw new NullPointerException("null cannot be cast to non-null type android.os.BatteryManager");
                    }
                    this.f540c = (BatteryManager) systemService;
                }
                BatteryManager batteryManager2 = this.f540c;
                r.b(batteryManager2);
                intExtra2 = batteryManager2.getIntProperty(4);
            }
            b.n.n(intExtra);
            b.n.m(intExtra2);
            b.n.o(intExtra4);
            b.n.r(intExtra3);
            if (intExtra != 1) {
                this.f539b = intExtra;
                if (!Integer.valueOf(intExtra).equals(2)) {
                    if (Integer.valueOf(intExtra).equals(5)) {
                        aVar2 = com.omarea.data.a.f524b;
                        eventType2 = EventType.BATTERY_FULL;
                    }
                    pendingResultGoAsync.finish();
                }
                aVar2 = com.omarea.data.a.f524b;
                eventType2 = EventType.POWER_CONNECTED;
                com.omarea.data.a.b(aVar2, eventType2, null, 2, null);
            }
            if (r.a(action, "android.intent.action.BATTERY_LOW")) {
                aVar = com.omarea.data.a.f524b;
                eventType = EventType.BATTERY_LOW;
            } else if (r.a(action, "android.intent.action.BATTERY_CHANGED")) {
                aVar = com.omarea.data.a.f524b;
                eventType = EventType.BATTERY_CHANGED;
            } else {
                if (!r.a(action, "android.intent.action.ACTION_POWER_DISCONNECTED")) {
                    if (r.a(action, "android.intent.action.ACTION_POWER_CONNECTED")) {
                        aVar = com.omarea.data.a.f524b;
                        eventType = EventType.POWER_CONNECTED;
                    } else if (this.f538a != intExtra2) {
                        this.f538a = intExtra2;
                        com.omarea.data.a.b(com.omarea.data.a.f524b, EventType.BATTERY_CAPACITY_CHANGED, null, 2, null);
                    }
                    pendingResultGoAsync.finish();
                }
                aVar = com.omarea.data.a.f524b;
                eventType = EventType.POWER_DISCONNECTED;
            }
            com.omarea.data.a.b(aVar, eventType, null, 2, null);
            if (this.f538a != intExtra2) {
                this.f538a = intExtra2;
                com.omarea.data.a.b(com.omarea.data.a.f524b, EventType.BATTERY_CAPACITY_CHANGED, null, 2, null);
            }
        } catch (Exception unused) {
        } catch (Throwable th) {
            pendingResultGoAsync.finish();
            throw th;
        }
        pendingResultGoAsync.finish();
    }
}
