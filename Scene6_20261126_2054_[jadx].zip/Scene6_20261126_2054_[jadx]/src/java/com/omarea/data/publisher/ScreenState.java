package com.omarea.data.publisher;

import android.app.KeyguardManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import com.omarea.data.EventType;
import com.omarea.data.b;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.c;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.coroutines.jvm.internal.d;
import kotlin.h;
import kotlin.jvm.b.p;
import kotlin.jvm.internal.r;
import kotlin.s;
import kotlinx.coroutines.CoroutineStart;
import kotlinx.coroutines.f;
import kotlinx.coroutines.h0;
import kotlinx.coroutines.i0;
import kotlinx.coroutines.q0;
import kotlinx.coroutines.w0;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class ScreenState extends BroadcastReceiver {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private long f536a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private Context f537b;

    /* JADX INFO: renamed from: com.omarea.data.publisher.ScreenState$onReceive$1, reason: invalid class name */
    @d(c = "com.omarea.data.publisher.ScreenState$onReceive$1", f = "ScreenState.kt", l = {50}, m = "invokeSuspend")
    static final class AnonymousClass1 extends SuspendLambda implements p<h0, c<? super s>, Object> {
        final /* synthetic */ long $ms;
        int I$0;
        int I$1;
        Object L$0;
        int label;
        private h0 p$;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass1(long j, c cVar) {
            super(2, cVar);
            this.$ms = j;
        }

        public final c<s> create(Object obj, c<?> cVar) {
            r.d(cVar, "completion");
            AnonymousClass1 anonymousClass1 = ScreenState.this.new AnonymousClass1(this.$ms, cVar);
            anonymousClass1.p$ = (h0) obj;
            return anonymousClass1;
        }

        public final Object invoke(Object obj, Object obj2) {
            return create(obj, (c) obj2).invokeSuspend(s.a);
        }

        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:16:0x0051 -> B:18:0x0054). Please report as a decompilation issue!!! */
        public final Object invokeSuspend(Object obj) {
            h0 h0Var;
            AnonymousClass1 anonymousClass1;
            int i;
            int i2;
            Object objD = kotlin.coroutines.intrinsics.a.d();
            int i3 = this.label;
            if (i3 == 0) {
                h.b(obj);
                h0Var = this.p$;
                anonymousClass1 = this;
                i = 0;
                i2 = 5;
                if (i < i2 || anonymousClass1.$ms != ScreenState.this.f536a || ScreenState.this.d()) {
                    return s.a;
                }
                anonymousClass1.L$0 = h0Var;
                anonymousClass1.I$0 = i;
                anonymousClass1.I$1 = i2;
                anonymousClass1.label = 1;
                if (q0.a(1000L, anonymousClass1) == objD) {
                    return objD;
                }
            } else {
                if (i3 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                i2 = this.I$1;
                i = this.I$0;
                h0Var = (h0) this.L$0;
                h.b(obj);
                anonymousClass1 = this;
            }
            i++;
            if (i < i2) {
            }
            return s.a;
        }
    }

    public ScreenState(Context context) {
        r.d(context, "context");
        this.f537b = context;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final boolean d() {
        Object systemService = this.f537b.getSystemService("keyguard");
        if (systemService == null) {
            throw new NullPointerException("null cannot be cast to non-null type android.app.KeyguardManager");
        }
        KeyguardManager keyguardManager = (KeyguardManager) systemService;
        try {
            if (!keyguardManager.isKeyguardLocked() && !keyguardManager.inKeyguardRestrictedInputMode()) {
                com.omarea.data.a.b(com.omarea.data.a.f524b, EventType.SCREEN_ON, null, 2, null);
                b.n.q(true);
            }
            return true;
        } catch (Exception unused) {
            return false;
        }
    }

    public final ScreenState c() {
        Context applicationContext = this.f537b.getApplicationContext() != null ? this.f537b.getApplicationContext() : this.f537b;
        applicationContext.registerReceiver(this, new IntentFilter("android.intent.action.SCREEN_OFF"));
        if (Build.VERSION.SDK_INT >= 24) {
            applicationContext.registerReceiver(this, new IntentFilter("android.intent.action.USER_UNLOCKED"));
        }
        applicationContext.registerReceiver(this, new IntentFilter("android.intent.action.SCREEN_ON"));
        applicationContext.registerReceiver(this, new IntentFilter("android.intent.action.USER_PRESENT"));
        f.d(i0.a(w0.b()), (CoroutineContext) null, (CoroutineStart) null, new ScreenState$autoRegister$1(this, null), 3, (Object) null);
        return this;
    }

    /* JADX WARN: Code duplicated, block: B:18:0x0042  */
    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        b bVar;
        boolean z;
        if (intent == null) {
            return;
        }
        BroadcastReceiver.PendingResult pendingResultGoAsync = goAsync();
        String action = intent.getAction();
        if (action != null) {
            switch (action.hashCode()) {
                case -2128145023:
                    if (action.equals("android.intent.action.SCREEN_OFF")) {
                        this.f536a = System.currentTimeMillis();
                        com.omarea.data.a.b(com.omarea.data.a.f524b, EventType.SCREEN_OFF, null, 2, null);
                        bVar = b.n;
                        z = false;
                        bVar.q(z);
                    }
                    break;
                case -1454123155:
                    if (action.equals("android.intent.action.SCREEN_ON")) {
                        long jCurrentTimeMillis = System.currentTimeMillis();
                        this.f536a = System.currentTimeMillis();
                        f.d(i0.a(w0.b()), (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass1(jCurrentTimeMillis, null), 3, (Object) null);
                    }
                    break;
                case 823795052:
                    if (action.equals("android.intent.action.USER_PRESENT")) {
                        this.f536a = System.currentTimeMillis();
                        com.omarea.data.a.b(com.omarea.data.a.f524b, EventType.SCREEN_ON, null, 2, null);
                        bVar = b.n;
                        z = true;
                        bVar.q(z);
                    }
                    break;
                case 833559602:
                    if (action.equals("android.intent.action.USER_UNLOCKED")) {
                        long jCurrentTimeMillis2 = System.currentTimeMillis();
                        this.f536a = System.currentTimeMillis();
                        f.d(i0.a(w0.b()), (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass1(jCurrentTimeMillis2, null), 3, (Object) null);
                    }
                    break;
            }
        }
        pendingResultGoAsync.finish();
    }
}
