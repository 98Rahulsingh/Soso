package com.omarea.data;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public enum EventType {
    POWER_CONNECTED,
    POWER_DISCONNECTED,
    BATTERY_LOW,
    BATTERY_CAPACITY_CHANGED,
    BATTERY_CHANGED,
    BATTERY_FULL,
    CHARGE_CONFIG_CHANGED,
    SCREEN_ON,
    SCREEN_OFF,
    APP_SWITCH,
    BOOT_COMPLETED,
    TIMER,
    SERVICE_DEBUG,
    SERVICE_UPDATE,
    STATE_RESUME,
    SCENE_MODE_ACTION,
    SCENE_CONFIG,
    SCENE_APP_CONFIG
}
