package com.omarea.data;

import android.os.BatteryManager;
import android.os.Build;
import com.omarea.Scene;
import com.omarea.common.net.Daemon;
import com.omarea.library.shell.BatteryUtils;
import com.omarea.library.shell.z;
import com.omarea.store.j;
import java.util.Arrays;
import kotlin.jvm.internal.r;
import kotlin.jvm.internal.w;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private static double f525a = -1.0d;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private static long f526b = 0;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private static BatteryManager f527c = null;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private static Boolean f528d = null;
    private static int e = -1;
    private static double f = -1.0d;
    private static long g = -1;
    private static int h = 1;
    private static String i = "";
    private static boolean j;
    private static double k;
    private static double m;
    public static final b n = new b();
    private static long l = System.currentTimeMillis() - ((long) 5000);

    private b() {
    }

    private final BatteryManager c() {
        if (f527c == null) {
            Object systemService = Scene.l.b().getSystemService("batterymanager");
            if (systemService == null) {
                throw new NullPointerException("null cannot be cast to non-null type android.os.BatteryManager");
            }
            f527c = (BatteryManager) systemService;
        }
        BatteryManager batteryManager = f527c;
        r.b(batteryManager);
        return batteryManager;
    }

    private final int g() {
        double dH = ((g * h()) + (j ? 1.2d : 0.0d)) / 0.92d;
        if (dH < 0) {
            return 0;
        }
        return (int) dH;
    }

    private final double t() {
        double dA;
        String strC = Daemon.E.c();
        if (!r.a(strC, "basic")) {
            if (r.a(strC, "root") && (!r.a(f528d, Boolean.FALSE))) {
                if (r.a(f528d, Boolean.TRUE)) {
                    dA = z.f784a.a("battery");
                } else {
                    dA = z.f784a.a("battery");
                    Boolean boolValueOf = Boolean.valueOf((dA == -1.0d || dA == 0.0d) ? false : true);
                    f528d = boolValueOf;
                    if (r.a(boolValueOf, Boolean.TRUE)) {
                    }
                }
                f525a = dA;
            } else {
                dA = BatteryUtils.e.a().temperature;
                if (dA > 10 && dA < 100) {
                    f525a = dA;
                }
            }
        }
        return f525a;
    }

    public final int a() {
        return e;
    }

    public final long b() {
        return g;
    }

    public final int d() {
        return h;
    }

    public final double e() {
        return f;
    }

    public final String f() {
        int iG = g();
        w wVar = w.a;
        String str = String.format("%.1fW?", Arrays.copyOf(new Object[]{Double.valueOf(((double) iG) / ((double) 1000))}, 1));
        r.c(str, "java.lang.String.format(format, *args)");
        return str;
    }

    public final double h() {
        return l() > ((double) 5) ? 8.98d : 4.49d;
    }

    public final String i() {
        return i;
    }

    public final String j() {
        int iL = (int) (g * l());
        w wVar = w.a;
        String str = String.format("%.2fW", Arrays.copyOf(new Object[]{Double.valueOf(((double) iL) / ((double) 1000))}, 1));
        r.c(str, "java.lang.String.format(format, *args)");
        return str;
    }

    public final double k() {
        return f525a;
    }

    public final double l() {
        double d2;
        double d3 = 0;
        if (f <= d3) {
            return 4.0d;
        }
        if (m > 0.0d && System.currentTimeMillis() - l < 3000) {
            return m;
        }
        double dB = BatteryUtils.e.b();
        if (dB <= d3) {
            return f;
        }
        l = System.currentTimeMillis();
        if (k == 0.0d) {
            int i2 = (int) (dB > 3.1d ? dB / 3.1d : dB / 3.0d);
            double d4 = f;
            int i3 = (int) (d4 > 3.1d ? d4 / 3.1d : d4 / 3.0d);
            if (i2 == i3) {
                d2 = 1.0d;
            } else {
                d2 = i2 > i3 ? 2.0d : 0.5d;
            }
            k = d2;
        }
        double d5 = dB / k;
        m = d5;
        f = d5;
        return d5;
    }

    public final void m(int i2) {
        e = i2;
    }

    public final void n(int i2) {
        h = i2;
    }

    public final void o(double d2) {
        f = d2;
    }

    public final void p(String str) {
        r.d(str, "<set-?>");
        i = str;
    }

    public final void q(boolean z) {
        j = z;
    }

    public final void r(double d2) {
        f525a = d2;
    }

    public final void s() {
        int intProperty;
        if (System.currentTimeMillis() - ((long) 5000) >= f526b) {
            u();
            e = c().getIntProperty(4);
            if (Build.VERSION.SDK_INT >= 26 && (intProperty = c().getIntProperty(6)) != 1) {
                h = intProperty;
            }
            t();
            f526b = System.currentTimeMillis();
        }
    }

    public final void u() {
        Scene.a aVar = Scene.l;
        String str = j.g0;
        r.c(str, "SpfConfig.GLOBAL_SPF_ELECTRIC_DOUBLE");
        g = (c().getLongProperty(2) / ((long) Scene.l.c().getInt(j.f0, j.h0))) * ((long) (aVar.a(str, false) ? 2 : 1));
    }
}
