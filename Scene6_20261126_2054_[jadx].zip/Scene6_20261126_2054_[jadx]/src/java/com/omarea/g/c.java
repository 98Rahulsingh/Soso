package com.omarea.g;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class c {
    /* JADX WARN: Code restructure failed: missing block: B:23:0x006f, code lost:
    
        if (r1 > 0) goto L24;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x0084, code lost:
    
        if (r1 > 0) goto L25;
     */
    /* JADX WARN: Code restructure failed: missing block: B:40:?, code lost:
    
        return 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:41:?, code lost:
    
        return -1;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final int a(android.content.Context r14) {
        /*
            r13 = this;
            java.lang.String r0 = "context"
            kotlin.jvm.internal.r.d(r14, r0)
            java.lang.String r0 = "batterymanager"
            java.lang.Object r14 = r14.getSystemService(r0)
            if (r14 == 0) goto L90
            android.os.BatteryManager r14 = (android.os.BatteryManager) r14
            r0 = 2
            long r1 = r14.getLongProperty(r0)
            java.lang.String r14 = android.os.Build.MANUFACTURER
            java.lang.String r3 = "Build.MANUFACTURER"
            kotlin.jvm.internal.r.c(r14, r3)
            java.util.Locale r3 = java.util.Locale.getDefault()
            java.lang.String r4 = "Locale.getDefault()"
            kotlin.jvm.internal.r.c(r3, r4)
            if (r14 == 0) goto L88
            java.lang.String r14 = r14.toUpperCase(r3)
            java.lang.String r3 = "(this as java.lang.String).toUpperCase(locale)"
            kotlin.jvm.internal.r.c(r14, r3)
            java.lang.String r3 = "XIAOMI"
            boolean r14 = kotlin.jvm.internal.r.a(r14, r3)
            r3 = 1000(0x3e8, float:1.401E-42)
            r4 = -1000(0xfffffffffffffc18, float:NaN)
            if (r14 == 0) goto L3e
        L3b:
            int r3 = com.omarea.store.j.h0
            goto L87
        L3e:
            com.omarea.data.b r14 = com.omarea.data.b.n
            int r14 = r14.d()
            r5 = 3
            r6 = -1
            r7 = 1
            r8 = 0
            r10 = -20000(0xffffffffffffb1e0, float:NaN)
            r11 = 20000(0x4e20, float:2.8026E-41)
            if (r14 == r5) goto L75
            com.omarea.data.b r14 = com.omarea.data.b.n
            int r14 = r14.d()
            r5 = 4
            if (r14 != r5) goto L59
            goto L75
        L59:
            com.omarea.data.b r14 = com.omarea.data.b.n
            int r14 = r14.d()
            if (r14 != r0) goto L3b
            long r11 = (long) r11
            int r14 = (r1 > r11 ? 1 : (r1 == r11 ? 0 : -1))
            if (r14 <= 0) goto L67
            goto L87
        L67:
            long r10 = (long) r10
            int r14 = (r1 > r10 ? 1 : (r1 == r10 ? 0 : -1))
            if (r14 >= 0) goto L6d
            goto L7a
        L6d:
            int r14 = (r1 > r8 ? 1 : (r1 == r8 ? 0 : -1))
            if (r14 <= 0) goto L73
        L71:
            r3 = r7
            goto L87
        L73:
            r3 = r6
            goto L87
        L75:
            long r11 = (long) r11
            int r14 = (r1 > r11 ? 1 : (r1 == r11 ? 0 : -1))
            if (r14 <= 0) goto L7c
        L7a:
            r3 = r4
            goto L87
        L7c:
            long r4 = (long) r10
            int r14 = (r1 > r4 ? 1 : (r1 == r4 ? 0 : -1))
            if (r14 >= 0) goto L82
            goto L87
        L82:
            int r14 = (r1 > r8 ? 1 : (r1 == r8 ? 0 : -1))
            if (r14 <= 0) goto L71
            goto L73
        L87:
            return r3
        L88:
            java.lang.NullPointerException r14 = new java.lang.NullPointerException
            java.lang.String r0 = "null cannot be cast to non-null type java.lang.String"
            r14.<init>(r0)
            throw r14
        L90:
            java.lang.NullPointerException r14 = new java.lang.NullPointerException
            java.lang.String r0 = "null cannot be cast to non-null type android.os.BatteryManager"
            r14.<init>(r0)
            throw r14
        */
        throw new UnsupportedOperationException("Method not decompiled: com.omarea.g.c.a(android.content.Context):int");
    }
}
