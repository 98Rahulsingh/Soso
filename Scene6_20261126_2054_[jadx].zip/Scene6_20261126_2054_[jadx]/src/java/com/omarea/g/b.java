package com.omarea.g;

import android.os.Environment;
import java.io.File;
import kotlin.jvm.internal.r;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private static final String f559a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private static final String f560b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final b f561c = new b();

    static {
        File externalStorageDirectory = Environment.getExternalStorageDirectory();
        r.c(externalStorageDirectory, "Environment.getExternalStorageDirectory()");
        String absolutePath = externalStorageDirectory.getAbsolutePath();
        r.c(absolutePath, "Environment.getExternalS…eDirectory().absolutePath");
        f559a = absolutePath;
        f560b = f559a + "/backups/apps/";
    }

    private b() {
    }

    public final String a() {
        return f560b;
    }

    public final String b() {
        return f559a;
    }
}
