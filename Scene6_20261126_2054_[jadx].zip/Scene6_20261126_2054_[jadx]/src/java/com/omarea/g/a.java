package com.omarea.g;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import com.omarea.net.SceneCloud;
import java.net.URLEncoder;
import java.util.concurrent.TimeUnit;
import kotlin.jvm.internal.r;
import kotlin.text.k;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private Context f558a;

    public a(Context context) {
        r.d(context, "context");
        this.f558a = context;
    }

    private final void b(String str) {
        c(this.f558a, str);
    }

    private final boolean c(Context context, String str) {
        try {
            if (k.t(str, "alipayqr://", false, 2, (Object) null) || k.t(str, "alipays://", false, 2, (Object) null)) {
                d(context, str);
                return true;
            }
            try {
                String strEncode = URLEncoder.encode(str, "utf-8");
                r.c(strEncode, "URLEncoder.encode(qrcode, \"utf-8\")");
                str = strEncode;
            } catch (Exception unused) {
            }
            d(context, ("alipayqr://platformapi/startapp?saId=10000007&qrcode=" + str) + "%3F_s%3Dweb-other&_t=" + System.currentTimeMillis());
            return true;
        } catch (Exception unused2) {
            return false;
        }
    }

    private final void d(Context context, String str) {
        context.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(str)));
    }

    public final void a() {
        try {
            String str = new SceneCloud(this.f558a).E().get(5L, TimeUnit.SECONDS);
            if (str == null || str.length() == 0) {
                return;
            }
            b(str);
        } catch (Exception unused) {
        }
    }
}
