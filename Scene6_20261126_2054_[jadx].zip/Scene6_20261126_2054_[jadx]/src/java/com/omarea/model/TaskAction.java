package com.omarea.model;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public enum TaskAction {
    FSTRIM,
    STANDBY_MODE_ON,
    STANDBY_MODE_OFF,
    ZEN_MODE_ON,
    ZEN_MODE_OFF,
    POWER_OFF
}
