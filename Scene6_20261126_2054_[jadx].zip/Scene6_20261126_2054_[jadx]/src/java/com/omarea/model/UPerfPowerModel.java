package com.omarea.model;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class UPerfPowerModel {
    public int efficiency;
    public Double freeFreq;
    public int nr;
    public Double plainFreq;
    public Double sweetFreq;
    public Double typicalFreq;
    public Double typicalPower;
}
