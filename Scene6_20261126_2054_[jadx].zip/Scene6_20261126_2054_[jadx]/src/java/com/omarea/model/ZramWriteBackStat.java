package com.omarea.model;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class ZramWriteBackStat {
    private int backReads;
    private int backWrites;
    private int backed;
    private String backingDev;

    public final int getBackReads() {
        return this.backReads;
    }

    public final int getBackWrites() {
        return this.backWrites;
    }

    public final int getBacked() {
        return this.backed;
    }

    public final String getBackingDev() {
        return this.backingDev;
    }

    public final void setBackReads(int i) {
        this.backReads = i;
    }

    public final void setBackWrites(int i) {
        this.backWrites = i;
    }

    public final void setBacked(int i) {
        this.backed = i;
    }

    public final void setBackingDev(String str) {
        this.backingDev = str;
    }
}
