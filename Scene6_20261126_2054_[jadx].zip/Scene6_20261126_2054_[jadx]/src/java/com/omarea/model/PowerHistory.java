package com.omarea.model;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class PowerHistory {
    public int capacity;
    public boolean charging;
    public long endTime;
    public long io;
    public boolean screenOn;
    public long startTime;

    public String toString() {
        return "PowerHistory{io=" + this.io + ", capacity=" + this.capacity + ", startTime=" + this.startTime + ", endTime=" + this.endTime + ", screenOn=" + this.screenOn + ", charging=" + this.charging + '}';
    }
}
