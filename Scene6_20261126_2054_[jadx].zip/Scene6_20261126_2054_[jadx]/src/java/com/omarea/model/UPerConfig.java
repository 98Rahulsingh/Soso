package com.omarea.model;

import java.util.ArrayList;
import java.util.List;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class UPerConfig {
    public boolean running;
    public String globalDefault = "";
    public String lockMode = "";
    public List<AppRue> apps = new ArrayList();

    public static class AppRue {
        public String mode;
        public String packageName;
    }
}
