package com.omarea.model;

import android.graphics.drawable.Drawable;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class FpsWatchSession {
    public Drawable appIcon;
    public String appName;
    public double avgFPS;
    public double avgPower;
    public Long beginTime;
    public int duration;
    public String mode;
    public String packageName;
    public String sessionDesc;
    public Long sessionId;
}
