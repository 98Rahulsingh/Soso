package com.omarea.model;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class ProcessInfo {
    public String cGroup;
    public float cpu;
    public String cpuSet;
    public String cpusAllowed;
    public String ctxtSwitches;
    public long mem;
    public String name;
    public String oomAdj;
    public String oomScore;
    public String oomScoreAdj;
    public int pid;
    public long res;
    public long rss;
    public long swap;
    public String user;
    public String state = "";
    public String command = "";
    public String cmdline = "";
    public String friendlyName = "";

    public float getCpu() {
        return this.cpu;
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code duplicated, block: B:58:0x00ad  */
    /* JADX WARN: Failed to clean up code after switch over string restore
    jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r1v0 int, still in use, count: 9, list:
      (r1v0 int) from 0x0008: IF  (r1v0 int) != (68 int)  -> B:4:0x000a A[HIDDEN]
      (r1v0 int) from 0x000c: IF  (r1v0 int) != (73 int)  -> B:6:0x000e A[HIDDEN]
      (r1v0 int) from 0x0010: IF  (r1v0 int) != (75 int)  -> B:8:0x0012 A[HIDDEN]
      (r1v0 int) from 0x0014: IF  (r1v0 int) != (80 int)  -> B:10:0x0016 A[HIDDEN]
      (r1v0 int) from 0x0018: IF  (r1v0 int) != (90 int)  -> B:12:0x001a A[HIDDEN]
      (r1v0 int) from 0x001c: IF  (r1v0 int) != (116 int)  -> B:14:0x001e A[HIDDEN]
      (r1v0 int) from 0x0020: IF  (r1v0 int) != (120 int)  -> B:16:0x0022 A[HIDDEN]
      (r1v0 int) from 0x0024: IF  (r1v0 int) != (87 int)  -> B:18:0x0026 A[HIDDEN]
      (r1v0 int) from 0x0028: IF  (r1v0 int) != (88 int)  -> B:20:0x002a A[HIDDEN]
    	at jadx.core.utils.InsnRemover.removeSsaVar(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:179)
    	at jadx.core.utils.InsnRemover.unbindResult(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:22)
    	at jadx.core.utils.InsnRemover.unbindInsn(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:4)
    	at jadx.core.utils.InsnRemover.remove(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:47)
    	at jadx.core.utils.InsnRemover.remove(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:22)
    	at jadx.core.dex.visitors.regions.SwitchOverStringVisitor.replaceWithMergedSwitch(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:279)
    	at jadx.core.dex.visitors.regions.SwitchOverStringVisitor.restoreSwitchOverString(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:137)
    	at jadx.core.dex.visitors.regions.SwitchOverStringVisitor.visitRegion(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:12)
    	at jadx.core.dex.visitors.regions.DepthRegionTraversal.traverseIterativeStepInternal(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:19)
    	at jadx.core.dex.visitors.regions.DepthRegionTraversal.traverseIterative(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:16)
    	at jadx.core.dex.visitors.regions.SwitchOverStringVisitor.visit(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:10)
     */
    public String getState() {
        byte b2;
        String str = this.state;
        if (iHashCode != 68) {
            if (iHashCode != 73) {
                if (iHashCode != 75) {
                    if (iHashCode != 80) {
                        if (iHashCode != 90) {
                            if (iHashCode != 116) {
                                if (iHashCode != 120) {
                                    if (iHashCode != 87) {
                                        if (iHashCode != 88) {
                                            switch (str) {
                                                case "R":
                                                    b2 = 0;
                                                    break;
                                                case "S":
                                                    b2 = 1;
                                                    break;
                                                case "T":
                                                    b2 = 3;
                                                    break;
                                                default:
                                                    b2 = -1;
                                                    break;
                                            }
                                        } else if (str.equals("X")) {
                                            b2 = 5;
                                        } else {
                                            b2 = -1;
                                        }
                                    } else if (str.equals("W")) {
                                        b2 = 11;
                                    } else {
                                        b2 = -1;
                                    }
                                } else if (str.equals("x")) {
                                    b2 = 9;
                                } else {
                                    b2 = -1;
                                }
                            } else if (str.equals("t")) {
                                b2 = 4;
                            } else {
                                b2 = -1;
                            }
                        } else if (str.equals("Z")) {
                            b2 = 6;
                        } else {
                            b2 = -1;
                        }
                    } else if (str.equals("P")) {
                        b2 = 7;
                    } else {
                        b2 = -1;
                    }
                } else if (str.equals("K")) {
                    b2 = 10;
                } else {
                    b2 = -1;
                }
            } else if (str.equals("I")) {
                b2 = 8;
            } else {
                b2 = -1;
            }
        } else if (str.equals("D")) {
            b2 = 2;
        } else {
            b2 = -1;
        }
        switch (b2) {
            case 0:
                return "R (running)";
            case 1:
                return "S (sleeping)";
            case 2:
                return "D (device I/O)";
            case 3:
                return "T (stopped)";
            case 4:
                return "t (trace stop)";
            case 5:
                return "X (dead)";
            case 6:
                return "Z (zombie)";
            case 7:
                return "P (parked)";
            case 8:
                return "I (idle)";
            case 9:
                return "x (dead)";
            case 10:
                return "K (wakekill)";
            case 11:
                return "W (waking)";
            default:
                return "Unknown";
        }
    }
}
