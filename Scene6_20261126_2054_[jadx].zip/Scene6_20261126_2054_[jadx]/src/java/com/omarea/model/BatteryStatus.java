package com.omarea.model;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class BatteryStatus {
    public int capacity;
    public int chargerPower;
    public String mode;
    public String packageName;
    public boolean screenOn;
    public String statusText;
    public long time;
    public double temperature = -1.0d;
    public int status = 0;
    public int current = -1;
    public double voltage = 3.85d;
}
