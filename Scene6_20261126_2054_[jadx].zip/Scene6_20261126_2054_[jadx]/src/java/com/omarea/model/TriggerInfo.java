package com.omarea.model;

import com.omarea.common.net.DaemonCommand;
import com.omarea.data.EventType;
import java.io.Serializable;
import java.util.ArrayList;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class TriggerInfo implements Serializable {
    public ArrayList<DaemonCommand> customTaskActions;
    public boolean enabled;
    public ArrayList<EventType> events;
    public String id;
    public ArrayList<TaskAction> taskActions;
    public boolean timeLimited = false;
    public int timeStart = 0;
    public int timeEnd = 1439;

    public TriggerInfo(String str) {
        this.id = str;
    }
}
