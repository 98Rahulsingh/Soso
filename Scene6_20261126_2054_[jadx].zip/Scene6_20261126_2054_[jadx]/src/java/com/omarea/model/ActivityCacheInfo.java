package com.omarea.model;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class ActivityCacheInfo {
    public String name;
    public String packageName;
    public boolean enabled = true;
    public boolean exported = false;
    public String label = "";
    public String authority = null;
}
