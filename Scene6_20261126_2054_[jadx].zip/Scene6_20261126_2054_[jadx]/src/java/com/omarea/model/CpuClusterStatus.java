package com.omarea.model;

import java.io.Serializable;
import java.util.HashMap;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class CpuClusterStatus implements Serializable {
    public String min_freq = "";
    public String max_freq = "";
    public String governor = "";
    public HashMap<String, String> governor_params = null;
}
