package com.omarea.model;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class CpuCoreInfo {
    public int coreIndex;
    public String currentFreq;
    public double loadRatio;
    public String maxFreq;
    public String minFreq;

    public CpuCoreInfo(int i) {
        this.coreIndex = i;
    }
}
