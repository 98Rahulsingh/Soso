package com.omarea.model;

import java.io.Serializable;
import java.util.ArrayList;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class CpuStatus implements Serializable {
    public ArrayList<CpuClusterStatus> cpuClusterStatuses = new ArrayList<>();
    public String coreControl = "";
    public String vdd = "";
    public String msmThermal = "";
    public ArrayList<Boolean> coreOnline = null;
    public int exynosHmpUP = 0;
    public int exynosHmpDown = 0;
    public boolean exynosHmpBooster = false;
    public boolean exynosHotplug = false;
    public String adrenoMinFreq = "";
    public String adrenoMaxFreq = "";
    public String adrenoMinPL = "";
    public String adrenoMaxPL = "";
    public String adrenoDefaultPL = "";
    public String adrenoGovernor = "";
    public String cpusetBackground = "";
    public String cpusetSysBackground = "";
    public String cpusetForeground = "";
    public String cpusetTopApp = "";
    public String cpusetRestricted = "";
}
