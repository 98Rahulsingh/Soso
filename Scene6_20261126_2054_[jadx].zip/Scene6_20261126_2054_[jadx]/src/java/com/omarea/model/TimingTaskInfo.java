package com.omarea.model;

import com.omarea.common.net.DaemonCommand;
import java.io.Serializable;
import java.util.ArrayList;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class TimingTaskInfo implements Serializable {
    public boolean afterScreenOff;
    public int batteryCapacityRequire;
    public boolean beforeExecuteConfirm;
    public boolean chargeOnly;
    public ArrayList<DaemonCommand> customTaskActions;
    public boolean enabled;
    public long expireDate;
    public ArrayList<TaskAction> taskActions;
    public String taskId;
    public String taskName;
    public int triggerTimeMinutes = 420;

    public TimingTaskInfo() {
    }

    public TimingTaskInfo(String str) {
        this.taskId = str;
    }
}
