package com.omarea.model;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class ThreadInfo {
    public int cpuAffinity;
    public double cpuLoad;
    public String name;
    public int tid;
}
