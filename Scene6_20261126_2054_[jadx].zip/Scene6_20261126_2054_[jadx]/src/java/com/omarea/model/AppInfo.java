package com.omarea.model;

import com.omarea.common.ui.AdapterAppChooser;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class AppInfo extends AdapterAppChooser.b {
    public AppType appType;
    public CharSequence desc;
    public Boolean enabled;
    public int minSdkVersion;
    public SceneConfigInfo sceneConfigInfo;
    public Boolean suspended;
    public int targetSdkVersion;
    public Boolean updated;
    public int versionCode;
    public String versionName;
    public CharSequence stateTags = "";
    public CharSequence path = "";
    public CharSequence dir = "";

    public enum AppType {
        UNKNOW,
        USER,
        SYSTEM,
        BACKUPFILE
    }

    public AppInfo() {
        Boolean bool = Boolean.FALSE;
        this.enabled = bool;
        this.suspended = bool;
        this.updated = bool;
        this.versionName = "";
        this.versionCode = 0;
        this.appType = AppType.UNKNOW;
    }

    public static AppInfo getItem() {
        return new AppInfo();
    }
}
