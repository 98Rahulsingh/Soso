package com.omarea.model;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class SceneConfigInfo {
    public String packageName;
    public boolean aloneLight = false;
    public int aloneLightValue = -1;
    public boolean disNotice = false;
    public boolean disButton = false;
    public boolean gpsOn = false;
    public boolean freeze = false;
    public int screenOrientation = -1;
    public String fgCGroupMem = "";
    public String bgCGroupMem = "";
    public boolean dynamicBoostMem = false;
    public boolean showMonitor = false;
}
