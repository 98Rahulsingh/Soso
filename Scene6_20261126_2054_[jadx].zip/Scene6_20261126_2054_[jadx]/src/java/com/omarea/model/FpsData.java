package com.omarea.model;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class FpsData {
    public int BigJank;
    public double FrameNumber;
    public int[] FrameTimeMS;
    public int Jank;
    public int MaxFrameTime;
    public String window;
}
