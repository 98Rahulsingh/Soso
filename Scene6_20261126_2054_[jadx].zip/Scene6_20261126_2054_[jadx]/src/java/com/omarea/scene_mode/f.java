package com.omarea.scene_mode;

import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private boolean f859a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private boolean f860b;
    private List<String> g;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private long f861c = -1;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private String f862d = "";
    private String e = "";
    private String f = "";
    private String h = "";
    private String i = "";

    private final String h(JSONObject jSONObject, String str, String str2) throws JSONException {
        if (!jSONObject.has(str) || !(!kotlin.jvm.internal.r.a(jSONObject.get(str), JSONObject.NULL))) {
            return str2;
        }
        String string = jSONObject.getString(str);
        kotlin.jvm.internal.r.c(string, "resultObj.getString(prop)");
        return string;
    }

    static /* synthetic */ String i(f fVar, JSONObject jSONObject, String str, String str2, int i, Object obj) {
        if ((i & 4) != 0) {
            str2 = "";
        }
        return fVar.h(jSONObject, str, str2);
    }

    public final String a() {
        return this.f;
    }

    public final List<String> b() {
        return this.g;
    }

    public final String c() {
        return this.h;
    }

    public final String d() {
        return this.e;
    }

    public final boolean e() {
        return this.f860b;
    }

    public final String f() {
        return this.i;
    }

    public final boolean g() {
        return this.f859a;
    }

    public final String j() {
        return this.f862d;
    }

    public final long k() {
        return this.f861c;
    }

    public final void l(JSONObject jSONObject) throws JSONException {
        JSONArray jSONArray;
        int length;
        kotlin.jvm.internal.r.d(jSONObject, "resultObj");
        if (jSONObject.has("versionCode") && (!kotlin.jvm.internal.r.a(jSONObject.get("versionCode"), JSONObject.NULL))) {
            this.f861c = jSONObject.getLong("versionCode");
        }
        this.f862d = i(this, jSONObject, "version", null, 4, null);
        this.e = i(this, jSONObject, "name", null, 4, null);
        this.f = i(this, jSONObject, "author", null, 4, null);
        this.h = i(this, jSONObject, "module", null, 4, null);
        this.i = i(this, jSONObject, "state", null, 4, null);
        if (jSONObject.has("files") && (!kotlin.jvm.internal.r.a(jSONObject.get("files"), JSONObject.NULL)) && (length = (jSONArray = jSONObject.getJSONArray("files")).length()) > 0) {
            ArrayList arrayList = new ArrayList();
            for (int i = 0; i < length; i++) {
                arrayList.add(jSONArray.getString(i));
            }
            this.g = arrayList;
        }
        if (jSONObject.has("features") && (!kotlin.jvm.internal.r.a(jSONObject.get("features"), JSONObject.NULL))) {
            JSONObject jSONObject2 = jSONObject.getJSONObject("features");
            if (jSONObject2.has("strict") && (!kotlin.jvm.internal.r.a(jSONObject2.get("strict"), JSONObject.NULL))) {
                this.f859a = jSONObject2.getBoolean("strict");
            } else {
                this.f859a = false;
            }
            if (jSONObject2.has("pedestal") && (!kotlin.jvm.internal.r.a(jSONObject2.get("pedestal"), JSONObject.NULL))) {
                this.f860b = jSONObject2.getBoolean("pedestal");
            } else {
                this.f860b = false;
            }
        }
    }

    public final void m(long j) {
        this.f861c = j;
    }
}
