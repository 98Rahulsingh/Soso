package com.omarea.scene_mode;

import android.app.ActivityManager;
import android.content.ContentResolver;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.provider.Settings;
import android.util.Log;
import com.omarea.Scene;
import com.omarea.common.net.Daemon;
import com.omarea.library.shell.w;
import com.omarea.model.SceneConfigInfo;
import com.omarea.vtools.AccessibilitySceneMode;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class k {
    private static String q = "";
    private static volatile k r;
    public static final a s = new a(null);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private String f875a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private ContentResolver f876b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private ArrayList<b> f877c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private final SharedPreferences f878d;
    private final com.omarea.vtools.popup.d e;
    private int f;
    private int g;
    private SceneConfigInfo h;
    private String i;
    private boolean j;
    private int k;
    private ActivityManager l;
    private Timer m;
    private w n;
    private final AccessibilitySceneMode o;
    private com.omarea.store.i p;

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(kotlin.jvm.internal.o oVar) {
            this();
        }

        public final void a(String str) {
            kotlin.jvm.internal.r.d(str, "app");
            if (kotlin.jvm.internal.r.a(str, "com.android.vending")) {
                new com.omarea.library.shell.m().a();
                return;
            }
            com.omarea.common.shell.e.f469b.c("pm disable " + str);
        }

        public final k b() {
            return k.r;
        }

        public final k c(AccessibilitySceneMode accessibilitySceneMode, com.omarea.store.i iVar) {
            k kVar;
            kotlin.jvm.internal.r.d(accessibilitySceneMode, "context");
            kotlin.jvm.internal.r.d(iVar, "store");
            if (k.r != null && (kVar = k.r) != null) {
                kVar.o();
            }
            k.r = new k(accessibilitySceneMode, iVar, null);
            k kVar2 = k.r;
            kotlin.jvm.internal.r.b(kVar2);
            return kVar2;
        }

        public final void d(String str) {
            kotlin.jvm.internal.r.d(str, "app");
            if (kotlin.jvm.internal.r.a(str, "com.android.vending")) {
                new com.omarea.library.shell.m().a();
                return;
            }
            com.omarea.common.shell.e.f469b.c("pm suspend " + str + "\nam force-stop " + str + " || am kill current " + str);
        }

        public final void e(String str) {
            kotlin.jvm.internal.r.d(str, "app");
            k kVarB = b();
            if (kVarB != null) {
                kVarB.G(str);
            }
            if (kotlin.jvm.internal.r.a(str, "com.android.vending")) {
                new com.omarea.library.shell.m().b();
                return;
            }
            com.omarea.common.shell.e.f469b.c("pm unsuspend " + str + "\npm enable " + str);
        }
    }

    public static final class b {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private long f879a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private String f880b = "";

        public final long a() {
            return this.f879a;
        }

        public final String b() {
            return this.f880b;
        }

        public final void c(long j) {
            this.f879a = j;
        }

        public final void d(String str) {
            kotlin.jvm.internal.r.d(str, "<set-?>");
            this.f880b = str;
        }

        public final void e(long j) {
        }
    }

    public static final class c extends Thread {
        private final Context f;
        private final boolean g;
        private final int h;

        public c(Context context, boolean z, int i) {
            kotlin.jvm.internal.r.d(context, "context");
            this.f = context;
            this.g = z;
            this.h = i;
        }

        @Override // java.lang.Thread, java.lang.Runnable
        public void run() {
            k kVarB;
            SharedPreferences sharedPreferences = this.f.getSharedPreferences(com.omarea.store.j.B, 0);
            List<String> listT = (this.g || (kVarB = k.s.b()) == null) ? null : kVarB.t();
            boolean z = sharedPreferences.getBoolean(com.omarea.store.j.j0, Build.VERSION.SDK_INT >= 28);
            ArrayList arrayList = new ArrayList();
            for (String str : new com.omarea.store.i(this.f).c()) {
                if (listT == null || !listT.contains(str)) {
                    arrayList.add(str);
                }
            }
            if (arrayList.size() > 0) {
                StringBuilder sb = new StringBuilder("freeze_apps=\"");
                Iterator it = arrayList.iterator();
                while (it.hasNext()) {
                    sb.append(((String) it.next()) + '\n');
                }
                sb.append("\"\n");
                com.omarea.common.shared.d dVar = com.omarea.common.shared.d.f450b;
                String string = sb.toString();
                kotlin.jvm.internal.r.c(string, "cmds.toString()");
                Charset charsetDefaultCharset = Charset.defaultCharset();
                kotlin.jvm.internal.r.c(charsetDefaultCharset, "Charset.defaultCharset()");
                if (string == null) {
                    throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                }
                byte[] bytes = string.getBytes(charsetDefaultCharset);
                kotlin.jvm.internal.r.c(bytes, "(this as java.lang.String).getBytes(charset)");
                boolean zH = dVar.h(bytes, "freeze_apps.sh", this.f);
                String str2 = z ? "suspend" : "disable";
                String strB = zH ? com.omarea.common.shared.d.f450b.b(this.f, "freeze_apps.sh") : null;
                String strI = com.omarea.common.shared.d.f450b.i("addin/freeze_executor.sh", "freeze_executor.sh", this.f);
                if (strI == null || strB == null) {
                    return;
                }
                int i = this.h;
                if (i <= 0) {
                    i = 1;
                }
                if (k.q.length() > 0) {
                    Daemon.E.a().S0(k.q);
                }
                k.q = Daemon.E.a().R0("sh " + strI + ' ' + str2 + ' ' + strB, i * 1000);
            }
        }
    }

    static final class d implements Runnable {
        d(String str) {
        }

        @Override // java.lang.Runnable
        public final void run() {
            k.this.j = new com.omarea.vtools.popup.c(k.this.o).i();
        }
    }

    static final class e implements Runnable {
        e(String str) {
        }

        @Override // java.lang.Runnable
        public final void run() {
            new com.omarea.vtools.popup.c(k.this.o).g();
        }
    }

    static final class f implements Runnable {
        final /* synthetic */ String g;
        final /* synthetic */ com.omarea.library.shell.c h;
        final /* synthetic */ String i;

        f(String str, com.omarea.library.shell.c cVar, String str2) {
            this.g = str;
            this.h = cVar;
            this.i = str2;
        }

        @Override // java.lang.Runnable
        public final void run() {
            SceneConfigInfo sceneConfigInfoR = k.this.r();
            if (!kotlin.jvm.internal.r.a(sceneConfigInfoR != null ? sceneConfigInfoR.packageName : null, this.g)) {
                this.h.c(this.g, this.i);
            }
        }
    }

    static final class g implements Runnable {
        final /* synthetic */ String g;
        final /* synthetic */ com.omarea.library.shell.c h;
        final /* synthetic */ String i;

        g(String str, com.omarea.library.shell.c cVar, String str2) {
            this.g = str;
            this.h = cVar;
            this.i = str2;
        }

        @Override // java.lang.Runnable
        public final void run() {
            SceneConfigInfo sceneConfigInfoR = k.this.r();
            if (!kotlin.jvm.internal.r.a(sceneConfigInfoR != null ? sceneConfigInfoR.packageName : null, this.g)) {
                this.h.c(this.g, this.i);
            }
        }
    }

    public static final class h extends TimerTask {
        final /* synthetic */ ActivityManager.MemoryInfo g;

        h(ActivityManager.MemoryInfo memoryInfo) {
            this.g = memoryInfo;
        }

        @Override // java.util.TimerTask, java.lang.Runnable
        public void run() {
            w wVar;
            ActivityManager activityManager = k.this.l;
            if (activityManager != null) {
                activityManager.getMemoryInfo(this.g);
            }
            ActivityManager.MemoryInfo memoryInfo = this.g;
            double d2 = memoryInfo.availMem / memoryInfo.totalMem;
            if (d2 >= 0.16d || d2 <= 0.0d || (wVar = k.this.n) == null) {
                return;
            }
            wVar.a(0);
        }
    }

    private k(AccessibilitySceneMode accessibilitySceneMode, com.omarea.store.i iVar) {
        this.o = accessibilitySceneMode;
        this.p = iVar;
        this.f875a = "com.android.systemui";
        ContentResolver contentResolver = accessibilitySceneMode.getContentResolver();
        kotlin.jvm.internal.r.c(contentResolver, "context.contentResolver");
        this.f876b = contentResolver;
        this.f877c = new ArrayList<>();
        this.f878d = this.o.getSharedPreferences(com.omarea.store.j.B, 0);
        this.e = new com.omarea.vtools.popup.d(this.o);
        this.f = -1;
        this.g = -1;
        this.i = "none";
        this.k = -1;
    }

    public /* synthetic */ k(AccessibilitySceneMode accessibilitySceneMode, com.omarea.store.i iVar, kotlin.jvm.internal.o oVar) {
        this(accessibilitySceneMode, iVar);
    }

    private final void D() {
        try {
            if (this.k > -1) {
                Settings.Global.putInt(this.f876b, "heads_up_notifications_enabled", this.k);
                this.f876b.notifyChange(Settings.System.getUriFor("heads_up_notifications_enabled"), null);
                this.k = -1;
            }
        } catch (Exception unused) {
        }
    }

    private final void E() {
        if (!kotlin.jvm.internal.r.a(this.i, "none")) {
            if (!kotlin.text.k.y(this.i, "gps", false, 2, (Object) null)) {
                if (kotlin.text.k.y(this.i, "network", false, 2, (Object) null)) {
                    new com.omarea.library.shell.p().a();
                } else {
                    new com.omarea.library.shell.p().b();
                }
            }
            this.i = "none";
        }
    }

    private final void F() {
        try {
            int i = this.f;
            if (i > -1) {
                Settings.System.putInt(this.f876b, "screen_brightness_mode", i);
                this.f876b.notifyChange(Settings.System.getUriFor("screen_brightness_mode"), null);
            }
            this.f = -1;
            if (this.g > -1 && i == 0) {
                Settings.System.putInt(this.f876b, "screen_brightness", this.g);
                this.f876b.notifyChange(Settings.System.getUriFor("screen_brightness"), null);
            }
            this.g = -1;
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private final void I(com.omarea.library.shell.c cVar, String str, String str2) {
        Scene.a aVar;
        Runnable fVar;
        long j;
        int iHashCode = str2.hashCode();
        if (iHashCode == -775488296) {
            if (str2.equals("scene_bg")) {
                aVar = Scene.l;
                fVar = new f(str, cVar, str2);
                j = 3000;
                aVar.h(fVar, j);
                return;
            }
            cVar.c(str, str2);
        }
        if (iHashCode == 58102287 && str2.equals("scene_cache")) {
            aVar = Scene.l;
            fVar = new g(str, cVar, str2);
            j = 8000;
            aVar.h(fVar, j);
            return;
        }
        cVar.c(str, str2);
    }

    private final void J() {
        if (this.l == null) {
            this.l = (ActivityManager) this.o.getSystemService("activity");
        }
        ActivityManager.MemoryInfo memoryInfo = new ActivityManager.MemoryInfo();
        Timer timer = new Timer("BoosterMemoryWatch");
        if (this.n == null) {
            this.n = new w(this.o);
        }
        timer.schedule(new h(memoryInfo), 3000L, 10000L);
        kotlin.s sVar = kotlin.s.a;
        this.m = timer;
    }

    private final void K() {
        Timer timer = this.m;
        if (timer != null) {
            if (timer != null) {
                timer.cancel();
            }
            this.m = null;
        }
    }

    private final void M() {
        SceneConfigInfo sceneConfigInfo = this.h;
        if (sceneConfigInfo != null) {
            this.e.g(sceneConfigInfo);
        }
    }

    private final boolean i(int i) {
        try {
            if (Settings.System.putInt(this.f876b, "screen_brightness_mode", 0)) {
                this.f876b.notifyChange(Settings.System.getUriFor("screen_brightness_mode"), null);
                if (i > -1 && Settings.System.putInt(this.f876b, "screen_brightness", i)) {
                    this.f876b.notifyChange(Settings.System.getUriFor("screen_brightness"), null);
                    return true;
                }
            }
        } catch (Exception unused) {
        }
        return false;
    }

    private final int j() {
        if (this.f == -1) {
            try {
                this.f = Settings.System.getInt(this.f876b, "screen_brightness_mode");
                this.g = Settings.System.getInt(this.f876b, "screen_brightness");
            } catch (Settings.SettingNotFoundException e2) {
                e2.printStackTrace();
            }
        }
        return this.f;
    }

    private final void k() {
        if (this.k < 0) {
            try {
                this.k = Settings.Global.getInt(this.f876b, "heads_up_notifications_enabled");
            } catch (Exception unused) {
            }
        }
    }

    private final void l() {
        String string;
        if (kotlin.jvm.internal.r.a(this.i, "none")) {
            if (Build.VERSION.SDK_INT >= 30) {
                string = kotlin.jvm.internal.r.a(Settings.Secure.getString(this.f876b, "location_mode"), "3") ? "gps" : "";
            } else {
                string = Settings.Secure.getString(this.f876b, "location_providers_allowed");
                kotlin.jvm.internal.r.c(string, "Settings.Secure.getStrin…CATION_PROVIDERS_ALLOWED)");
            }
            this.i = string;
        }
    }

    private final boolean p() {
        if (Build.VERSION.SDK_INT >= 30) {
            return kotlin.jvm.internal.r.a(Settings.Secure.getString(this.f876b, "location_mode"), "3");
        }
        String string = Settings.Secure.getString(this.f876b, "location_providers_allowed");
        kotlin.jvm.internal.r.c(string, "Settings.Secure.getStrin…CATION_PROVIDERS_ALLOWED)");
        return kotlin.text.k.y(string, "gps", false, 2, (Object) null);
    }

    private final void q(b bVar) {
        if (this.p.b(bVar.b()).freeze) {
            if (u()) {
                s.d(bVar.b());
            } else {
                s.a(bVar.b());
            }
        }
        this.f877c.remove(bVar);
    }

    private final int s() {
        return this.f878d.getInt(com.omarea.store.j.k0, 2) * 60 * 1000;
    }

    private final boolean u() {
        return this.f878d.getBoolean(com.omarea.store.j.j0, Build.VERSION.SDK_INT >= 28);
    }

    public static /* synthetic */ void w(k kVar, String str, boolean z, int i, Object obj) {
        if ((i & 2) != 0) {
            z = false;
        }
        kVar.v(str, z);
    }

    private final void x(SceneConfigInfo sceneConfigInfo) {
        if (sceneConfigInfo.freeze) {
            String str = sceneConfigInfo.packageName;
            kotlin.jvm.internal.r.c(str, "sceneConfigInfo.packageName");
            G(str);
        }
        if (sceneConfigInfo.aloneLight) {
            try {
                int i = Settings.System.getInt(this.f876b, "screen_brightness");
                if (i != sceneConfigInfo.aloneLightValue) {
                    sceneConfigInfo.aloneLightValue = i;
                    this.p.f(sceneConfigInfo);
                }
            } catch (Exception unused) {
            }
        }
        if (!kotlin.jvm.internal.r.a(sceneConfigInfo.fgCGroupMem, sceneConfigInfo.bgCGroupMem)) {
            com.omarea.library.shell.c cVar = new com.omarea.library.shell.c(Scene.l.b());
            if (!cVar.b()) {
                Scene.l.k("你的内核不支持cgroup设置！\n(Scene试验性功能)");
                return;
            }
            String str2 = sceneConfigInfo.bgCGroupMem;
            if (str2 != null) {
                if (str2.length() > 0) {
                    String str3 = sceneConfigInfo.packageName;
                    kotlin.jvm.internal.r.b(str3);
                    String str4 = sceneConfigInfo.bgCGroupMem;
                    kotlin.jvm.internal.r.c(str4, "sceneConfigInfo.bgCGroupMem");
                    I(cVar, str3, str4);
                    return;
                }
            }
            String str5 = sceneConfigInfo.packageName;
            kotlin.jvm.internal.r.b(str5);
            cVar.c(str5, "");
        }
    }

    public final void A() {
    }

    public final void B() {
        M();
    }

    public final b C(String str) {
        kotlin.jvm.internal.r.d(str, "packageName");
        for (b bVar : this.f877c) {
            if (kotlin.jvm.internal.r.a(bVar.b(), str)) {
                this.f877c.remove(bVar);
                return bVar;
            }
        }
        return null;
    }

    public final void G(String str) {
        kotlin.jvm.internal.r.d(str, "packageName");
        b bVarC = C(str);
        if (bVarC == null) {
            bVarC = new b();
        }
        bVarC.c(System.currentTimeMillis());
        bVarC.d(str);
        this.f877c.add(bVarC);
    }

    public final void H(String str) {
        kotlin.jvm.internal.r.d(str, "packageName");
        C(str);
        b bVar = new b();
        bVar.e(System.currentTimeMillis());
        bVar.c(-1L);
        bVar.d(str);
        this.f877c.add(bVar);
    }

    public final void L() {
        if (this.f875a.length() == 0) {
            return;
        }
        v(this.f875a, true);
    }

    public final void m() {
        if (q.length() > 0) {
            Daemon.E.a().S0(q);
        }
    }

    public final void n() {
        int iS = s();
        if (iS > 0) {
            long jCurrentTimeMillis = System.currentTimeMillis();
            ArrayList<b> arrayList = this.f877c;
            ArrayList<b> arrayList2 = new ArrayList();
            Iterator<T> it = arrayList.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                b bVar = (b) next;
                if (bVar.a() > ((long) (-1)) && jCurrentTimeMillis - bVar.a() > ((long) iS) && (kotlin.jvm.internal.r.a(bVar.b(), this.f875a) ^ true)) {
                    arrayList2.add(next);
                }
            }
            if (!arrayList2.isEmpty()) {
                String[] strArrP = this.o.p();
                for (b bVar2 : arrayList2) {
                    if (!kotlin.collections.h.j(strArrP, bVar2.b())) {
                        q(bVar2);
                    }
                }
            }
        }
    }

    public final void o() {
        this.f875a = "com.android.systemui";
        E();
        F();
        this.h = null;
        this.e.f();
        r = null;
    }

    public final SceneConfigInfo r() {
        return this.h;
    }

    public final List<String> t() {
        ArrayList arrayList = new ArrayList();
        ArrayList<b> arrayList2 = this.f877c;
        ArrayList arrayList3 = new ArrayList(kotlin.collections.q.k(arrayList2, 10));
        Iterator<T> it = arrayList2.iterator();
        while (it.hasNext()) {
            arrayList3.add(((b) it.next()).b());
        }
        arrayList.addAll(arrayList3);
        ArrayList<String> arrayListC = new com.omarea.store.i(this.o).c();
        for (String str : this.o.p()) {
            if (arrayListC.contains(str) && !arrayList.contains(str)) {
                arrayList.add(str);
                H(str);
            }
        }
        return arrayList;
    }

    /* JADX WARN: Code duplicated, block: B:55:0x00f8 A[Catch: all -> 0x0154, Exception -> 0x0156, TryCatch #2 {Exception -> 0x0156, blocks: (B:7:0x0011, B:9:0x0019, B:11:0x001d, B:13:0x0021, B:15:0x0028, B:16:0x0030, B:18:0x003a, B:73:0x014b, B:74:0x014e, B:19:0x0045, B:21:0x004c, B:23:0x005d, B:25:0x0067, B:27:0x0076, B:31:0x0091, B:33:0x009a, B:35:0x00a3, B:37:0x00af, B:43:0x00d8, B:44:0x00db, B:46:0x00e4, B:47:0x00e7, B:49:0x00eb, B:51:0x00ef, B:64:0x010d, B:66:0x011e, B:68:0x013f, B:70:0x0143, B:72:0x0147, B:67:0x0138, B:55:0x00f8, B:57:0x00fc, B:59:0x0100, B:61:0x0104, B:62:0x0106, B:36:0x00ac, B:28:0x0081, B:30:0x0085, B:22:0x005a), top: B:85:0x0011, outer: #0 }] */
    /* JADX WARN: Code duplicated, block: B:57:0x00fc A[Catch: all -> 0x0154, Exception -> 0x0156, TryCatch #2 {Exception -> 0x0156, blocks: (B:7:0x0011, B:9:0x0019, B:11:0x001d, B:13:0x0021, B:15:0x0028, B:16:0x0030, B:18:0x003a, B:73:0x014b, B:74:0x014e, B:19:0x0045, B:21:0x004c, B:23:0x005d, B:25:0x0067, B:27:0x0076, B:31:0x0091, B:33:0x009a, B:35:0x00a3, B:37:0x00af, B:43:0x00d8, B:44:0x00db, B:46:0x00e4, B:47:0x00e7, B:49:0x00eb, B:51:0x00ef, B:64:0x010d, B:66:0x011e, B:68:0x013f, B:70:0x0143, B:72:0x0147, B:67:0x0138, B:55:0x00f8, B:57:0x00fc, B:59:0x0100, B:61:0x0104, B:62:0x0106, B:36:0x00ac, B:28:0x0081, B:30:0x0085, B:22:0x005a), top: B:85:0x0011, outer: #0 }] */
    /* JADX WARN: Code duplicated, block: B:58:0x00ff  */
    /* JADX WARN: Code duplicated, block: B:61:0x0104 A[Catch: all -> 0x0154, Exception -> 0x0156, TryCatch #2 {Exception -> 0x0156, blocks: (B:7:0x0011, B:9:0x0019, B:11:0x001d, B:13:0x0021, B:15:0x0028, B:16:0x0030, B:18:0x003a, B:73:0x014b, B:74:0x014e, B:19:0x0045, B:21:0x004c, B:23:0x005d, B:25:0x0067, B:27:0x0076, B:31:0x0091, B:33:0x009a, B:35:0x00a3, B:37:0x00af, B:43:0x00d8, B:44:0x00db, B:46:0x00e4, B:47:0x00e7, B:49:0x00eb, B:51:0x00ef, B:64:0x010d, B:66:0x011e, B:68:0x013f, B:70:0x0143, B:72:0x0147, B:67:0x0138, B:55:0x00f8, B:57:0x00fc, B:59:0x0100, B:61:0x0104, B:62:0x0106, B:36:0x00ac, B:28:0x0081, B:30:0x0085, B:22:0x005a), top: B:85:0x0011, outer: #0 }] */
    /* JADX WARN: Code duplicated, block: B:64:0x010d A[Catch: all -> 0x0154, Exception -> 0x0156, TryCatch #2 {Exception -> 0x0156, blocks: (B:7:0x0011, B:9:0x0019, B:11:0x001d, B:13:0x0021, B:15:0x0028, B:16:0x0030, B:18:0x003a, B:73:0x014b, B:74:0x014e, B:19:0x0045, B:21:0x004c, B:23:0x005d, B:25:0x0067, B:27:0x0076, B:31:0x0091, B:33:0x009a, B:35:0x00a3, B:37:0x00af, B:43:0x00d8, B:44:0x00db, B:46:0x00e4, B:47:0x00e7, B:49:0x00eb, B:51:0x00ef, B:64:0x010d, B:66:0x011e, B:68:0x013f, B:70:0x0143, B:72:0x0147, B:67:0x0138, B:55:0x00f8, B:57:0x00fc, B:59:0x0100, B:61:0x0104, B:62:0x0106, B:36:0x00ac, B:28:0x0081, B:30:0x0085, B:22:0x005a), top: B:85:0x0011, outer: #0 }] */
    /* JADX WARN: Code duplicated, block: B:66:0x011e A[Catch: all -> 0x0154, Exception -> 0x0156, TryCatch #2 {Exception -> 0x0156, blocks: (B:7:0x0011, B:9:0x0019, B:11:0x001d, B:13:0x0021, B:15:0x0028, B:16:0x0030, B:18:0x003a, B:73:0x014b, B:74:0x014e, B:19:0x0045, B:21:0x004c, B:23:0x005d, B:25:0x0067, B:27:0x0076, B:31:0x0091, B:33:0x009a, B:35:0x00a3, B:37:0x00af, B:43:0x00d8, B:44:0x00db, B:46:0x00e4, B:47:0x00e7, B:49:0x00eb, B:51:0x00ef, B:64:0x010d, B:66:0x011e, B:68:0x013f, B:70:0x0143, B:72:0x0147, B:67:0x0138, B:55:0x00f8, B:57:0x00fc, B:59:0x0100, B:61:0x0104, B:62:0x0106, B:36:0x00ac, B:28:0x0081, B:30:0x0085, B:22:0x005a), top: B:85:0x0011, outer: #0 }] */
    /* JADX WARN: Code duplicated, block: B:67:0x0138 A[Catch: all -> 0x0154, Exception -> 0x0156, TryCatch #2 {Exception -> 0x0156, blocks: (B:7:0x0011, B:9:0x0019, B:11:0x001d, B:13:0x0021, B:15:0x0028, B:16:0x0030, B:18:0x003a, B:73:0x014b, B:74:0x014e, B:19:0x0045, B:21:0x004c, B:23:0x005d, B:25:0x0067, B:27:0x0076, B:31:0x0091, B:33:0x009a, B:35:0x00a3, B:37:0x00af, B:43:0x00d8, B:44:0x00db, B:46:0x00e4, B:47:0x00e7, B:49:0x00eb, B:51:0x00ef, B:64:0x010d, B:66:0x011e, B:68:0x013f, B:70:0x0143, B:72:0x0147, B:67:0x0138, B:55:0x00f8, B:57:0x00fc, B:59:0x0100, B:61:0x0104, B:62:0x0106, B:36:0x00ac, B:28:0x0081, B:30:0x0085, B:22:0x005a), top: B:85:0x0011, outer: #0 }] */
    public final void v(String str, boolean z) {
        SceneConfigInfo sceneConfigInfo;
        String str2;
        SceneConfigInfo sceneConfigInfo2;
        com.omarea.library.shell.c cVar;
        String str3;
        kotlin.jvm.internal.r.d(str, "packageName");
        if (!kotlin.jvm.internal.r.a(this.f875a, str) || z) {
            synchronized (this) {
                try {
                    this.f875a = str;
                    if (this.h != null) {
                        SceneConfigInfo sceneConfigInfo3 = this.h;
                        if (!kotlin.jvm.internal.r.a(sceneConfigInfo3 != null ? sceneConfigInfo3.packageName : null, str)) {
                            SceneConfigInfo sceneConfigInfo4 = this.h;
                            kotlin.jvm.internal.r.b(sceneConfigInfo4);
                            x(sceneConfigInfo4);
                        }
                    }
                    SceneConfigInfo sceneConfigInfoB = this.p.b(str);
                    this.h = sceneConfigInfoB;
                    if (sceneConfigInfoB == null) {
                        E();
                        F();
                        D();
                    } else {
                        kotlin.jvm.internal.r.b(sceneConfigInfoB);
                        if (sceneConfigInfoB.aloneLight) {
                            j();
                            SceneConfigInfo sceneConfigInfo5 = this.h;
                            kotlin.jvm.internal.r.b(sceneConfigInfo5);
                            i(sceneConfigInfo5.aloneLightValue);
                        } else {
                            F();
                        }
                        SceneConfigInfo sceneConfigInfo6 = this.h;
                        kotlin.jvm.internal.r.b(sceneConfigInfo6);
                        if (sceneConfigInfo6.showMonitor) {
                            if (!kotlin.jvm.internal.r.a(com.omarea.vtools.popup.c.s.a(), Boolean.TRUE)) {
                                Scene.l.g(new d(str));
                            }
                        } else if (this.j) {
                            Scene.l.g(new e(str));
                            this.j = false;
                        }
                        SceneConfigInfo sceneConfigInfo7 = this.h;
                        kotlin.jvm.internal.r.b(sceneConfigInfo7);
                        if (sceneConfigInfo7.gpsOn) {
                            l();
                            if (!p()) {
                                new com.omarea.library.shell.p().c();
                            }
                        } else {
                            E();
                        }
                        SceneConfigInfo sceneConfigInfo8 = this.h;
                        kotlin.jvm.internal.r.b(sceneConfigInfo8);
                        if (sceneConfigInfo8.disNotice) {
                            try {
                                int i = Settings.Global.getInt(this.f876b, "heads_up_notifications_enabled");
                                k();
                                if (i != 0) {
                                    Settings.Global.putInt(this.f876b, "heads_up_notifications_enabled", 0);
                                    this.f876b.notifyChange(Settings.System.getUriFor("heads_up_notifications_enabled"), null);
                                }
                            } catch (Exception unused) {
                            }
                        } else {
                            D();
                        }
                        SceneConfigInfo sceneConfigInfo9 = this.h;
                        kotlin.jvm.internal.r.b(sceneConfigInfo9);
                        if (sceneConfigInfo9.freeze) {
                            H(str);
                        }
                        SceneConfigInfo sceneConfigInfo10 = this.h;
                        if (sceneConfigInfo10 == null || (str3 = sceneConfigInfo10.fgCGroupMem) == null) {
                            sceneConfigInfo = this.h;
                            if (sceneConfigInfo != null) {
                                str2 = sceneConfigInfo.bgCGroupMem;
                            } else {
                                str2 = null;
                            }
                            sceneConfigInfo2 = this.h;
                            if (!kotlin.jvm.internal.r.a(str2, sceneConfigInfo2 != null ? sceneConfigInfo2.fgCGroupMem : null)) {
                                cVar = new com.omarea.library.shell.c(Scene.l.b());
                                if (cVar.b()) {
                                    SceneConfigInfo sceneConfigInfo11 = this.h;
                                    kotlin.jvm.internal.r.b(sceneConfigInfo11);
                                    String str4 = sceneConfigInfo11.packageName;
                                    kotlin.jvm.internal.r.b(str4);
                                    SceneConfigInfo sceneConfigInfo12 = this.h;
                                    kotlin.jvm.internal.r.b(sceneConfigInfo12);
                                    String str5 = sceneConfigInfo12.fgCGroupMem;
                                    kotlin.jvm.internal.r.c(str5, "currentSceneConfig!!.fgCGroupMem");
                                    cVar.c(str4, str5);
                                } else {
                                    Scene.l.k("你的内核不支持cgroup设置！\n(Scene试验性功能)");
                                }
                            }
                        } else {
                            if (!(str3.length() > 0)) {
                                sceneConfigInfo = this.h;
                                if (sceneConfigInfo != null) {
                                    str2 = sceneConfigInfo.bgCGroupMem;
                                } else {
                                    str2 = null;
                                }
                                sceneConfigInfo2 = this.h;
                                if (!kotlin.jvm.internal.r.a(str2, sceneConfigInfo2 != null ? sceneConfigInfo2.fgCGroupMem : null)) {
                                    cVar = new com.omarea.library.shell.c(Scene.l.b());
                                    if (cVar.b()) {
                                        SceneConfigInfo sceneConfigInfo13 = this.h;
                                        kotlin.jvm.internal.r.b(sceneConfigInfo13);
                                        String str6 = sceneConfigInfo13.packageName;
                                        kotlin.jvm.internal.r.b(str6);
                                        SceneConfigInfo sceneConfigInfo14 = this.h;
                                        kotlin.jvm.internal.r.b(sceneConfigInfo14);
                                        String str7 = sceneConfigInfo14.fgCGroupMem;
                                        kotlin.jvm.internal.r.c(str7, "currentSceneConfig!!.fgCGroupMem");
                                        cVar.c(str6, str7);
                                    } else {
                                        Scene.l.k("你的内核不支持cgroup设置！\n(Scene试验性功能)");
                                    }
                                }
                            } else {
                                cVar = new com.omarea.library.shell.c(Scene.l.b());
                                if (cVar.b()) {
                                    SceneConfigInfo sceneConfigInfo15 = this.h;
                                    kotlin.jvm.internal.r.b(sceneConfigInfo15);
                                    String str8 = sceneConfigInfo15.packageName;
                                    kotlin.jvm.internal.r.b(str8);
                                    SceneConfigInfo sceneConfigInfo16 = this.h;
                                    kotlin.jvm.internal.r.b(sceneConfigInfo16);
                                    String str9 = sceneConfigInfo16.fgCGroupMem;
                                    kotlin.jvm.internal.r.c(str9, "currentSceneConfig!!.fgCGroupMem");
                                    cVar.c(str8, str9);
                                } else {
                                    Scene.l.k("你的内核不支持cgroup设置！\n(Scene试验性功能)");
                                }
                            }
                        }
                        SceneConfigInfo sceneConfigInfo17 = this.h;
                        if (sceneConfigInfo17 != null && sceneConfigInfo17.dynamicBoostMem) {
                            J();
                        }
                        M();
                        kotlin.s sVar = kotlin.s.a;
                    }
                    K();
                    M();
                    kotlin.s sVar2 = kotlin.s.a;
                } catch (Exception e2) {
                    Log.e(">>>>", "" + e2.getMessage());
                }
            }
        }
    }

    public final boolean y() {
        SceneConfigInfo sceneConfigInfo = this.h;
        if (sceneConfigInfo == null) {
            return false;
        }
        kotlin.jvm.internal.r.b(sceneConfigInfo);
        return sceneConfigInfo.disNotice;
    }

    public final void z() {
        this.e.f();
    }
}
