package com.omarea.scene_mode;

import android.content.Context;
import android.os.SystemClock;
import android.util.Log;
import com.omarea.Scene;
import com.omarea.common.net.Daemon;
import com.omarea.library.shell.t;
import java.io.File;
import java.util.ArrayList;
import kotlin.coroutines.CoroutineContext;
import kotlinx.coroutines.CoroutineStart;
import kotlinx.coroutines.i0;
import kotlinx.coroutines.w0;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class ModeSwitcher {
    private static boolean f = false;
    private static String g = "PROVIDER_NONE";
    private static String h = "";
    private static f i;
    private static String j;
    private static String u;
    public static final a x = new a(null);
    private static final com.omarea.library.basic.h k = new com.omarea.library.basic.h(Scene.l.b());
    private static String l = "powersave";
    private static String m = "performance";
    private static String n = "fast";
    private static String o = "balance";
    private static String p = "pedestal";
    private static String q = "auto";
    private static String r = "igoned";
    private static String s = "balance";
    private static String t = "init";
    private static String v = "";
    private static final ArrayList<b> w = new ArrayList<>();

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(kotlin.jvm.internal.o oVar) {
            this();
        }

        public final void a() {
            ModeSwitcher.j = null;
            ModeSwitcher.i = null;
        }

        public final String b() {
            return ModeSwitcher.q;
        }

        public final String c() {
            return ModeSwitcher.o;
        }

        public final String d() {
            String strA;
            if (ModeSwitcher.u == null) {
                f fVarU = new ModeSwitcher().u(Scene.l.b());
                String strF = fVarU != null ? fVarU.f() : null;
                if (strF == null || strF.length() == 0) {
                    strA = t.f771a.a("vtools.powercfg");
                    if (strA.length() == 0) {
                        strA = "";
                    }
                } else {
                    strA = kotlin.text.k.t(strF, "/", false, 2, (Object) null) ? com.omarea.common.shell.f.f471b.a(strF) : t.f771a.a(strF);
                }
                ModeSwitcher.u = strA;
            }
            String str = ModeSwitcher.u;
            kotlin.jvm.internal.r.b(str);
            return str;
        }

        public final String e() {
            if (ModeSwitcher.v.length() == 0) {
                String strA = t.f771a.a("vtools.powercfg_app");
                if (strA.length() == 0) {
                    strA = "android";
                }
                ModeSwitcher.v = strA;
            }
            return ModeSwitcher.v;
        }

        public final String f() {
            if (new g().d()) {
                return "SOURCE_OUTSIDE";
            }
            Scene.a aVar = Scene.l;
            String str = com.omarea.store.j.a0;
            kotlin.jvm.internal.r.c(str, "SpfConfig.GLOBAL_SPF_PROFILE_SOURCE");
            String strD = aVar.d(str, "UNKNOWN");
            if (!kotlin.jvm.internal.r.a(strD, "SOURCE_SCENE_CUSTOM") && !new g().b()) {
                return "SOURCE_NONE";
            }
            kotlin.jvm.internal.r.b(strD);
            return strD;
        }

        public final String g() {
            String strF = f();
            if (kotlin.jvm.internal.r.a(strF, "SOURCE_OUTSIDE")) {
                f fVarU = new ModeSwitcher().u(Scene.l.b());
                String strD = fVarU != null ? fVarU.d() : null;
                if (!(strD == null || strD.length() == 0)) {
                    return strD;
                }
                String strA = fVarU != null ? fVarU.a() : null;
                if (!(strA == null || strA.length() == 0)) {
                    return strA;
                }
            }
            return q(strF);
        }

        public final String h() {
            return ModeSwitcher.s;
        }

        public final String i() {
            return ModeSwitcher.n;
        }

        public final String j() {
            return ModeSwitcher.r;
        }

        public final String k(String str) {
            String string;
            String str2;
            kotlin.jvm.internal.r.d(str, "mode");
            if (kotlin.jvm.internal.r.a(str, p())) {
                string = Scene.l.b().getString(2131887141);
                str2 = "Scene.context.getString(R.string.powersave)";
            } else if (kotlin.jvm.internal.r.a(str, o())) {
                string = Scene.l.b().getString(2131887097);
                str2 = "Scene.context.getString(R.string.performance)";
            } else if (kotlin.jvm.internal.r.a(str, i())) {
                string = Scene.l.b().getString(2131886698);
                str2 = "Scene.context.getString(R.string.fast)";
            } else if (kotlin.jvm.internal.r.a(str, c())) {
                string = Scene.l.b().getString(2131886461);
                str2 = "Scene.context.getString(R.string.balance)";
            } else if (kotlin.jvm.internal.r.a(str, n())) {
                string = Scene.l.b().getString(2131887068);
                str2 = "Scene.context.getString(R.string.pedestal)";
            } else if (kotlin.jvm.internal.r.a(str, j())) {
                string = Scene.l.b().getString(2131886818);
                str2 = "Scene.context.getString(R.string.kepp_state)";
            } else if (kotlin.jvm.internal.r.a(str, b())) {
                string = Scene.l.b().getString(2131887499);
                str2 = "Scene.context.getString(R.string.uperf_auto)";
            } else if (kotlin.jvm.internal.r.a(str, "")) {
                string = Scene.l.b().getString(2131886769);
                str2 = "Scene.context.getString(R.string.global_default)";
            } else {
                string = Scene.l.b().getString(2131887498);
                str2 = "Scene.context.getString(R.string.unknown_mode)";
            }
            kotlin.jvm.internal.r.c(string, str2);
            return string;
        }

        public final String l() {
            b bVar = (b) kotlin.collections.q.u(ModeSwitcher.w);
            if (bVar != null) {
                return bVar.c();
            }
            return null;
        }

        public final String m() {
            b bVar = (b) kotlin.collections.q.u(ModeSwitcher.w);
            if (bVar != null) {
                return bVar.a();
            }
            return null;
        }

        public final String n() {
            return ModeSwitcher.p;
        }

        public final String o() {
            return ModeSwitcher.m;
        }

        public final String p() {
            return ModeSwitcher.l;
        }

        /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
        /* JADX WARN: Code duplicated, block: B:25:0x0099  */
        /* JADX WARN: Code duplicated, block: B:26:0x00a9  */
        public final String q(String str) {
            String string;
            String str2;
            kotlin.jvm.internal.r.d(str, "source");
            switch (str) {
                case "SOURCE_SCENE_CONSERVATIVE":
                case "SOURCE_SCENE_ACTIVE":
                    string = Scene.l.b().getString(2131887358);
                    str2 = "Scene.context.getString(R.string.source_classics)";
                    break;
                case "SOURCE_SCENE_CUSTOM":
                    string = Scene.l.b().getString(2131887359);
                    str2 = "Scene.context.getString(R.string.source_custom)";
                    break;
                case "SOURCE_SCENE_IMPORT":
                    string = Scene.l.b().getString(2131887360);
                    str2 = "Scene.context.getString(R.string.source_import)";
                    break;
                case "SOURCE_SCENE_ONLINE":
                    string = Scene.l.b().getString(2131887361);
                    str2 = "Scene.context.getString(R.string.source_online)";
                    break;
                case "SOURCE_OUTSIDE":
                    string = Scene.l.b().getString(2131887362);
                    str2 = "Scene.context.getString(R.string.source_outside)";
                    break;
                case "SOURCE_NONE":
                    string = Scene.l.b().getString(2131887363);
                    str2 = "Scene.context.getString(R.string.source_undefined)";
                    break;
                default:
                    string = Scene.l.b().getString(2131887364);
                    str2 = "Scene.context.getString(R.string.source_unknown)";
                    break;
            }
            kotlin.jvm.internal.r.c(string, str2);
            return string;
        }

        public final boolean r() {
            String strF = f();
            if (kotlin.collections.h.j(new String[]{"SOURCE_SCENE_CONSERVATIVE", "SOURCE_SCENE_ACTIVE", "SOURCE_SCENE_ONLINE"}, strF)) {
                return true;
            }
            return kotlin.jvm.internal.r.a(strF, "SOURCE_OUTSIDE") && com.omarea.common.shell.g.f472a.d("/data/powercfg.json");
        }
    }

    public static final class b {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private String f846a = "";

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private String f847b = "";

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private long f848c;

        public final String a() {
            return this.f846a;
        }

        public final long b() {
            return this.f848c;
        }

        public final String c() {
            return this.f847b;
        }

        public final void d(String str) {
            kotlin.jvm.internal.r.d(str, "<set-?>");
            this.f846a = str;
        }

        public final void e(long j) {
            this.f848c = j;
        }

        public final void f(String str) {
            kotlin.jvm.internal.r.d(str, "<set-?>");
            this.f847b = str;
        }
    }

    public static final /* synthetic */ ModeSwitcher a(ModeSwitcher modeSwitcher, String str, String str2) throws JSONException {
        modeSwitcher.t(str, str2);
        return modeSwitcher;
    }

    private final void s() {
        kotlinx.coroutines.f.d(i0.a(w0.b()), (CoroutineContext) null, (CoroutineStart) null, new ModeSwitcher$execNext$1(this, null), 3, (Object) null);
    }

    /* JADX WARN: Code duplicated, block: B:48:0x0199  */
    /* JADX WARN: Code duplicated, block: B:49:0x019c  */
    /* JADX WARN: Code duplicated, block: B:51:0x01a0  */
    /* JADX WARN: Code duplicated, block: B:53:0x01bb  */
    /* JADX WARN: Code duplicated, block: B:54:0x01be  */
    /* JADX WARN: Code duplicated, block: B:57:0x01c8  */
    /* JADX WARN: Code duplicated, block: B:58:0x01dc  */
    /* JADX WARN: Code duplicated, block: B:62:0x0233  */
    /* JADX WARN: Code duplicated, block: B:65:0x0274  */
    /* JADX WARN: Instruction removed from duplicated block: B:62:0x0233, please report this as an issue */
    /* JADX WARN: Instruction removed from duplicated block: B:65:0x0274, please report this as an issue */
    private final ModeSwitcher t(String str, String str2) throws JSONException {
        String str3;
        String str4;
        String str5;
        String str6;
        boolean z;
        boolean z2;
        boolean zA;
        String str7;
        String str8;
        int i2;
        StringBuilder sb;
        if (!kotlin.jvm.internal.r.a(str, r)) {
            String strF = x.f();
            int iHashCode = strF.hashCode();
            if (iHashCode == -610722744) {
                str3 = "Scene";
                str4 = "Profile lost!";
                str5 = "";
                if (strF.equals("SOURCE_SCENE_CUSTOM")) {
                    com.omarea.store.e eVar = new com.omarea.store.e(Scene.l.b());
                    if (eVar.a(str)) {
                        eVar.f(Scene.l.b(), str);
                        A(str);
                    } else {
                        Log.e(str3, str5 + str + str4);
                    }
                    this = this;
                }
            } else if (iHashCode == 1873639777 && strF.equals("SOURCE_OUTSIDE")) {
                if (!f || (!kotlin.jvm.internal.r.a(g, "PROVIDER_OUTSIDE"))) {
                    v();
                }
                if (h.length() > 0) {
                    Scene.a aVar = Scene.l;
                    String str9 = com.omarea.store.j.V;
                    kotlin.jvm.internal.r.c(str9, "SpfConfig.GLOBAL_SPF_DYNAMIC_CONTROL");
                    boolean zA2 = aVar.a(str9, com.omarea.store.j.X);
                    String str10 = kotlin.jvm.internal.r.a(k.b(str2), Boolean.TRUE) ? "game" : "app";
                    if (zA2 && C()) {
                        sb = new StringBuilder();
                        sb.append("export top_app='");
                        sb.append(str2);
                        sb.append("'\n");
                        sb.append("export mode='");
                        sb.append(str);
                        sb.append("'\n");
                        sb.append("export category='");
                        sb.append(str10);
                        sb.append("'\n");
                        sb.append("export scene='");
                        sb.append(str2);
                        sb.append("'\n");
                    } else {
                        sb = new StringBuilder();
                        sb.append("export top_app=''\n");
                        sb.append("export mode='");
                        sb.append(str);
                        sb.append("'\n");
                        sb.append("export category='");
                        sb.append(str10);
                        sb.append("'\n");
                        sb.append("export scene=''\n");
                    }
                    sb.append("sh ");
                    sb.append(h);
                    sb.append(" '");
                    sb.append(str);
                    sb.append("' > /dev/null 2>&1");
                    w(sb.toString(), 5000);
                    A(str);
                } else {
                    Log.e("Scene", "" + str + "Profile lost!");
                }
                this = this;
            } else {
                str3 = "Scene";
                str4 = "Profile lost!";
                str5 = "";
            }
            if (f) {
                str6 = str3;
                z = true;
                if (!kotlin.jvm.internal.r.a(g, "PROVIDER_INSIDE")) {
                }
                if (h.length() > 0) {
                    z2 = z;
                } else {
                    z2 = false;
                }
                if (z2) {
                    Scene.a aVar2 = Scene.l;
                    String str11 = com.omarea.store.j.V;
                    kotlin.jvm.internal.r.c(str11, "SpfConfig.GLOBAL_SPF_DYNAMIC_CONTROL");
                    zA = aVar2.a(str11, com.omarea.store.j.X);
                    if (kotlin.jvm.internal.r.a(k.b(str2), Boolean.TRUE)) {
                        str7 = "game";
                    } else {
                        str7 = "app";
                    }
                    if (kotlin.jvm.internal.r.a(strF, "SOURCE_SCENE_ONLINE")) {
                        Daemon.E.a().J0(str7, str2, str, false, false);
                        this = this;
                    } else {
                        if (zA || !C()) {
                            str8 = "export top_app=''\nexport mode='" + str + "'\nexport category='" + str7 + "'\nexport scene=''\nsh " + h + " '" + str + "' > /dev/null 2>&1";
                            i2 = 5000;
                        } else {
                            str8 = "export top_app='" + str2 + "'\nexport mode='" + str + "'\nexport category='" + str7 + "'\nexport scene='" + str2 + "'\nsh " + h + " '" + str + "' 'task" + SystemClock.elapsedRealtime() + "' > /dev/null 2>&1";
                            i2 = 5000;
                        }
                        w(str8, i2);
                    }
                    A(str);
                } else {
                    this = this;
                    Log.e(str6, str5 + str + str4);
                }
            } else {
                str6 = str3;
                z = true;
            }
            v();
            if (h.length() > 0) {
                z2 = z;
            } else {
                z2 = false;
            }
            if (z2) {
                Scene.a aVar3 = Scene.l;
                String str12 = com.omarea.store.j.V;
                kotlin.jvm.internal.r.c(str12, "SpfConfig.GLOBAL_SPF_DYNAMIC_CONTROL");
                zA = aVar3.a(str12, com.omarea.store.j.X);
                if (kotlin.jvm.internal.r.a(k.b(str2), Boolean.TRUE)) {
                    str7 = "game";
                } else {
                    str7 = "app";
                }
                if (kotlin.jvm.internal.r.a(strF, "SOURCE_SCENE_ONLINE")) {
                    Daemon.E.a().J0(str7, str2, str, false, false);
                    this = this;
                } else {
                    if (zA) {
                        str8 = "export top_app=''\nexport mode='" + str + "'\nexport category='" + str7 + "'\nexport scene=''\nsh " + h + " '" + str + "' > /dev/null 2>&1";
                        i2 = 5000;
                    } else {
                        str8 = "export top_app=''\nexport mode='" + str + "'\nexport category='" + str7 + "'\nexport scene=''\nsh " + h + " '" + str + "' > /dev/null 2>&1";
                        i2 = 5000;
                    }
                    w(str8, i2);
                }
                A(str);
            } else {
                this = this;
                Log.e(str6, str5 + str + str4);
            }
        } else {
            this = this;
        }
        this.B(str2);
        return this;
    }

    private final void w(String str, int i2) {
        Daemon.E.a().h0(str, i2);
    }

    static /* synthetic */ void x(ModeSwitcher modeSwitcher, String str, int i2, int i3, Object obj) {
        if (obj != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: keepShellExec");
        }
        if ((i3 & 2) != 0) {
            i2 = 10000;
        }
        modeSwitcher.w(str, i2);
    }

    public final ModeSwitcher A(String str) {
        kotlin.jvm.internal.r.d(str, "powerCfg");
        u = str;
        t.f771a.b("vtools.powercfg", str);
        return this;
    }

    public final ModeSwitcher B(String str) {
        kotlin.jvm.internal.r.d(str, "app");
        v = str;
        t.f771a.b("vtools.powercfg_app", str);
        return this;
    }

    public final boolean C() {
        f fVarU = u(Scene.l.b());
        if (fVarU != null) {
            return fVarU.g();
        }
        Scene.a aVar = Scene.l;
        String str = com.omarea.store.j.Y;
        kotlin.jvm.internal.r.c(str, "SpfConfig.GLOBAL_SPF_DYNAMIC_CONTROL_STRICT");
        return aVar.a(str, false);
    }

    /* JADX WARN: Code duplicated, block: B:18:0x007a  */
    public final ModeSwitcher D(String str, String str2) {
        kotlin.jvm.internal.r.d(str, "mode");
        kotlin.jvm.internal.r.d(str2, "app");
        if (!kotlin.jvm.internal.r.a(Daemon.E.c(), "root")) {
            return this;
        }
        while (w.size() > 1) {
            kotlin.collections.q.p(w);
        }
        b bVar = new b();
        bVar.f(str);
        bVar.d(str2);
        if ((!kotlin.jvm.internal.r.a(x.f(), "SOURCE_SCENE_ONLINE")) && (!kotlin.jvm.internal.r.a(v, "standby")) && (!kotlin.jvm.internal.r.a(u, q)) && kotlin.text.k.W(str2, new String[]{"."}, false, 0, 6, (Object) null).size() < 4) {
            if (kotlin.jvm.internal.r.a(str, l)) {
                bVar.e(1000L);
            } else {
                String[] strArr = {l, o, s, m, n, p, q};
                if (kotlin.collections.h.n(strArr, str) <= kotlin.collections.h.n(strArr, x.d())) {
                    bVar.e(1000L);
                }
            }
        }
        w.add(bVar);
        if (w.size() < 2) {
            s();
        }
        return this;
    }

    public final boolean q() {
        com.omarea.store.e eVar = new com.omarea.store.e(Scene.l.b());
        return eVar.a(l) && eVar.a(o) && eVar.a(m) && eVar.a(n);
    }

    public final void r() {
        f = false;
    }

    public final f u(Context context) {
        f fVar;
        kotlin.jvm.internal.r.d(context, "context");
        String strF = x.f();
        if (kotlin.jvm.internal.r.a(j, strF) && (fVar = i) != null) {
            return fVar;
        }
        if (kotlin.collections.h.j(new String[]{"SOURCE_SCENE_CONSERVATIVE", "SOURCE_SCENE_ACTIVE", "SOURCE_SCENE_ONLINE"}, strF)) {
            try {
                String str = new String(kotlin.io.e.a(new File(com.omarea.common.shared.d.f450b.b(context, "manifest.json"))), kotlin.text.d.a);
                f fVar2 = new f();
                fVar2.l(new JSONObject(str));
                return fVar2;
            } catch (Exception unused) {
                return null;
            }
        }
        if (!kotlin.jvm.internal.r.a(strF, "SOURCE_OUTSIDE") || !com.omarea.common.shell.g.f472a.d("/data/powercfg.json")) {
            return null;
        }
        try {
            JSONObject jSONObject = new JSONObject(com.omarea.common.shell.f.f471b.a("/data/powercfg.json"));
            f fVar3 = new f();
            fVar3.l(jSONObject);
            return fVar3;
        } catch (Exception unused2) {
            return null;
        }
    }

    public final ModeSwitcher v() {
        g gVar = new g();
        if (gVar.d()) {
            h = "/data/powercfg.sh";
            gVar.a();
            g = "PROVIDER_OUTSIDE";
        } else {
            g = "PROVIDER_INSIDE";
            h = com.omarea.common.shared.d.f450b.b(Scene.l.b(), "powercfg.sh");
        }
        if (h.length() > 0) {
            x(this, "sh " + h + ' ' + t + " > /dev/null 2>&1", 0, 2, null);
            A("");
            f = true;
        }
        return this;
    }

    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    public final boolean y() {
        if (new g().d()) {
            return true;
        }
        String strF = x.f();
        switch (strF.hashCode()) {
            case -852205116:
                if (!strF.equals("SOURCE_SCENE_CONSERVATIVE")) {
                    return false;
                }
                break;
            case -684584995:
                if (!strF.equals("SOURCE_SCENE_ACTIVE")) {
                    return false;
                }
                break;
            case -610722744:
                if (strF.equals("SOURCE_SCENE_CUSTOM")) {
                    return q();
                }
                return false;
            case -446430084:
                if (!strF.equals("SOURCE_SCENE_IMPORT")) {
                    return false;
                }
                break;
            case -273856726:
                if (!strF.equals("SOURCE_SCENE_ONLINE")) {
                    return false;
                }
                break;
            default:
                return false;
        }
        return new g().b();
    }

    public final boolean z() {
        f fVarU = u(Scene.l.b());
        if (fVarU != null) {
            return fVarU.e();
        }
        return false;
    }
}
