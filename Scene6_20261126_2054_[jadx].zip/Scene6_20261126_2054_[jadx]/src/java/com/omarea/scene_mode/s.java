package com.omarea.scene_mode;

import android.content.Context;
import android.content.SharedPreferences;
import com.omarea.data.EventType;
import com.omarea.model.TriggerInfo;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class s {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final SharedPreferences f895a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private Context f896b;

    public s(Context context) {
        kotlin.jvm.internal.r.d(context, "context");
        this.f896b = context;
        this.f895a = context.getSharedPreferences("scene_trigger_list", 0);
    }

    public final List<TriggerInfo> a() {
        com.omarea.store.m mVar = new com.omarea.store.m(this.f896b);
        SharedPreferences sharedPreferences = this.f895a;
        kotlin.jvm.internal.r.c(sharedPreferences, "triggerListConfig");
        Set<String> setKeySet = sharedPreferences.getAll().keySet();
        ArrayList arrayList = new ArrayList(kotlin.collections.q.k(setKeySet, 10));
        for (String str : setKeySet) {
            kotlin.jvm.internal.r.c(str, "it");
            arrayList.add(mVar.c(str));
        }
        ArrayList arrayList2 = new ArrayList();
        for (Object obj : arrayList) {
            if (((TriggerInfo) obj) != null) {
                arrayList2.add(obj);
            }
        }
        return kotlin.collections.q.U(arrayList2);
    }

    public final void b(TriggerInfo triggerInfo) {
        kotlin.jvm.internal.r.d(triggerInfo, "triggerInfo");
        this.f895a.edit().remove(triggerInfo.id).apply();
        com.omarea.store.m mVar = new com.omarea.store.m(this.f896b);
        String str = triggerInfo.id;
        kotlin.jvm.internal.r.c(str, "triggerInfo.id");
        mVar.d(str);
    }

    public final void c(TriggerInfo triggerInfo) {
        kotlin.jvm.internal.r.d(triggerInfo, "triggerInfo");
        StringBuilder sb = new StringBuilder();
        ArrayList<EventType> arrayList = triggerInfo.events;
        if (arrayList != null) {
            Iterator<T> it = arrayList.iterator();
            while (it.hasNext()) {
                sb.append(((EventType) it.next()).name());
                sb.append(",");
            }
        }
        this.f895a.edit().putString(triggerInfo.id, sb.toString()).apply();
        new com.omarea.store.m(this.f896b).g(triggerInfo);
    }
}
