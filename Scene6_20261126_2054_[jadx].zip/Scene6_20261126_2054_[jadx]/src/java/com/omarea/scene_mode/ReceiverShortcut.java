package com.omarea.scene_mode;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class ReceiverShortcut extends BroadcastReceiver {
    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        if (intent == null || !intent.hasExtra("packageName")) {
            return;
        }
        String stringExtra = intent.getStringExtra("packageName");
        if (stringExtra.equals(context.getPackageName())) {
            return;
        }
        if (context.getSharedPreferences(com.omarea.store.j.B, 0).getBoolean(com.omarea.store.j.j0, Build.VERSION.SDK_INT >= 28)) {
            k.s.d(stringExtra);
        } else {
            k.s.a(stringExtra);
        }
    }
}
