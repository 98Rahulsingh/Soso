package com.omarea.scene_mode;

import com.omarea.data.EventType;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final /* synthetic */ class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final /* synthetic */ int[] f849a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final /* synthetic */ int[] f850b;

    static {
        int[] iArr = new int[EventType.values().length];
        f849a = iArr;
        iArr[EventType.APP_SWITCH.ordinal()] = 1;
        f849a[EventType.SCREEN_ON.ordinal()] = 2;
        f849a[EventType.SCREEN_OFF.ordinal()] = 3;
        f849a[EventType.POWER_CONNECTED.ordinal()] = 4;
        f849a[EventType.POWER_DISCONNECTED.ordinal()] = 5;
        f849a[EventType.SCENE_CONFIG.ordinal()] = 6;
        f849a[EventType.SCENE_APP_CONFIG.ordinal()] = 7;
        int[] iArr2 = new int[EventType.values().length];
        f850b = iArr2;
        iArr2[EventType.APP_SWITCH.ordinal()] = 1;
        f850b[EventType.SCREEN_OFF.ordinal()] = 2;
        f850b[EventType.SCREEN_ON.ordinal()] = 3;
        f850b[EventType.SCENE_CONFIG.ordinal()] = 4;
        f850b[EventType.SCENE_APP_CONFIG.ordinal()] = 5;
        f850b[EventType.POWER_CONNECTED.ordinal()] = 6;
        f850b[EventType.POWER_DISCONNECTED.ordinal()] = 7;
    }
}
