package com.omarea.scene_mode;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.Rect;
import android.os.Build;
import android.view.accessibility.AccessibilityNodeInfo;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class c {

    public static final class a extends AccessibilityService.GestureResultCallback {
        a() {
        }

        @Override // android.accessibilityservice.AccessibilityService.GestureResultCallback
        public void onCancelled(GestureDescription gestureDescription) {
            kotlin.jvm.internal.r.d(gestureDescription, "gestureDescription");
            super.onCancelled(gestureDescription);
        }

        @Override // android.accessibilityservice.AccessibilityService.GestureResultCallback
        public void onCompleted(GestureDescription gestureDescription) {
            kotlin.jvm.internal.r.d(gestureDescription, "gestureDescription");
            super.onCompleted(gestureDescription);
        }
    }

    private final GestureDescription a(Rect rect) {
        Point point = new Point(rect.left + ((rect.right - rect.left) / 2), rect.top + ((rect.bottom - rect.top) / 2));
        GestureDescription.Builder builder = new GestureDescription.Builder();
        Path path = new Path();
        path.moveTo(point.x, point.y);
        builder.addStroke(new GestureDescription.StrokeDescription(path, 0L, 20L));
        GestureDescription gestureDescriptionBuild = builder.build();
        kotlin.jvm.internal.r.c(gestureDescriptionBuild, "gesture");
        return gestureDescriptionBuild;
    }

    public final boolean b(AccessibilityNodeInfo accessibilityNodeInfo) {
        kotlin.jvm.internal.r.d(accessibilityNodeInfo, "node");
        if (!d(accessibilityNodeInfo)) {
            return false;
        }
        accessibilityNodeInfo.performAction(16);
        return true;
    }

    protected final AccessibilityNodeInfo c(AccessibilityNodeInfo accessibilityNodeInfo) {
        kotlin.jvm.internal.r.d(accessibilityNodeInfo, "nodeInfo");
        if (accessibilityNodeInfo.isClickable()) {
            return accessibilityNodeInfo;
        }
        AccessibilityNodeInfo parent = accessibilityNodeInfo.getParent();
        if (parent != null) {
            return c(parent);
        }
        return null;
    }

    public final boolean d(AccessibilityNodeInfo accessibilityNodeInfo) {
        kotlin.jvm.internal.r.d(accessibilityNodeInfo, "node");
        return accessibilityNodeInfo.getActionList().contains(AccessibilityNodeInfo.AccessibilityAction.ACTION_CLICK);
    }

    public final boolean e(AccessibilityNodeInfo accessibilityNodeInfo, AccessibilityService accessibilityService) {
        kotlin.jvm.internal.r.d(accessibilityNodeInfo, "node");
        kotlin.jvm.internal.r.d(accessibilityService, "service");
        if (Build.VERSION.SDK_INT < 24) {
            return false;
        }
        Rect rect = new Rect();
        accessibilityNodeInfo.getBoundsInScreen(rect);
        return accessibilityService.dispatchGesture(a(rect), new a(), null);
    }
}
