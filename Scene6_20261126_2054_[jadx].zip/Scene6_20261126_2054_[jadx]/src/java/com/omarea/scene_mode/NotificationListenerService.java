package com.omarea.scene_mode;

import android.service.notification.StatusBarNotification;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class NotificationListenerService extends android.service.notification.NotificationListenerService {
    @Override // android.service.notification.NotificationListenerService
    public void onNotificationPosted(StatusBarNotification statusBarNotification) {
        k kVarB;
        super.onNotificationPosted(statusBarNotification);
        if (statusBarNotification != null && statusBarNotification.isClearable() && (kVarB = k.s.b()) != null && kVarB.y()) {
            try {
                int i = statusBarNotification.getNotification().flags;
                cancelNotification(statusBarNotification.getKey());
            } catch (Exception unused) {
            }
        }
    }
}
