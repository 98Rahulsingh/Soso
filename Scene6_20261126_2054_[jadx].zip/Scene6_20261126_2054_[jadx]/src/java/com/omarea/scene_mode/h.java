package com.omarea.scene_mode;

import android.content.ContentResolver;
import android.provider.Settings;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class h {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final String f863a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final String f864b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final String f865c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private String f866d;
    private String e;
    private String f;
    private ContentResolver g;

    public h(ContentResolver contentResolver) {
        kotlin.jvm.internal.r.d(contentResolver, "contentResolver");
        this.g = contentResolver;
        this.f863a = "immersive.navigation";
        this.f864b = "immersive.status";
        this.f865c = "immersive.full";
        this.f866d = "";
        this.e = "";
        this.f = "";
        String string = Settings.Global.getString(contentResolver, "policy_control");
        if (string != null) {
            for (String str : kotlin.text.k.W(string, new String[]{":"}, false, 0, 6, (Object) null)) {
                if (kotlin.text.k.t(str, "immersive.full", false, 2, (Object) null)) {
                    this.f = str;
                } else if (kotlin.text.k.t(str, "immersive.navigation", false, 2, (Object) null)) {
                    this.f866d = str;
                } else if (kotlin.text.k.t(str, "immersive.status", false, 2, (Object) null)) {
                    this.e = str;
                }
            }
        }
    }

    private final boolean e(String str, String str2) {
        if (kotlin.text.k.y(str, '-' + str2, false, 2, (Object) null)) {
            return false;
        }
        if (kotlin.text.k.y(str, str2, false, 2, (Object) null)) {
            return true;
        }
        if (kotlin.text.k.y(str, this.f864b + "=*", false, 2, (Object) null)) {
            return true;
        }
        StringBuilder sb = new StringBuilder();
        sb.append(this.f864b);
        sb.append("=apps");
        return kotlin.text.k.y(str, sb.toString(), false, 2, (Object) null);
    }

    public final boolean a(String str) {
        StringBuilder sb;
        char c2;
        kotlin.jvm.internal.r.d(str, "packageName");
        if (d(str)) {
            return true;
        }
        k(str);
        j(str);
        if (this.f.length() == 0) {
            sb = new StringBuilder();
            sb.append(this.f865c);
            c2 = '=';
        } else {
            sb = new StringBuilder();
            sb.append(this.f);
            c2 = ',';
        }
        sb.append(c2);
        sb.append(str);
        this.f = sb.toString();
        return h();
    }

    public final boolean b(String str) {
        StringBuilder sb;
        char c2;
        kotlin.jvm.internal.r.d(str, "packageName");
        if (f(str) || d(str)) {
            return true;
        }
        if (this.f866d.length() == 0) {
            sb = new StringBuilder();
            sb.append(this.f863a);
            c2 = '=';
        } else {
            sb = new StringBuilder();
            sb.append(this.f866d);
            c2 = ',';
        }
        sb.append(c2);
        sb.append(str);
        this.f866d = sb.toString();
        return h();
    }

    public final boolean c(String str) {
        StringBuilder sb;
        char c2;
        kotlin.jvm.internal.r.d(str, "packageName");
        if (g(str) || d(str)) {
            return true;
        }
        if (this.e.length() == 0) {
            sb = new StringBuilder();
            sb.append(this.f864b);
            c2 = '=';
        } else {
            sb = new StringBuilder();
            sb.append(this.e);
            c2 = ',';
        }
        sb.append(c2);
        sb.append(str);
        this.e = sb.toString();
        return h();
    }

    public final boolean d(String str) {
        kotlin.jvm.internal.r.d(str, "packageName");
        return e(this.f, str);
    }

    public final boolean f(String str) {
        kotlin.jvm.internal.r.d(str, "packageName");
        return e(this.f866d, str);
    }

    public final boolean g(String str) {
        kotlin.jvm.internal.r.d(str, "packageName");
        return e(this.e, str);
    }

    public final boolean h() {
        StringBuilder sb = new StringBuilder();
        if (!(this.e.length() == 0)) {
            sb.append(this.e);
        }
        if (!(this.f866d.length() == 0)) {
            if (!(sb.length() == 0)) {
                sb.append(":");
            }
            sb.append(this.f866d);
        }
        if (!(this.f.length() == 0)) {
            if (!(sb.length() == 0)) {
                sb.append(":");
            }
            sb.append(this.f);
        }
        return Settings.Global.putString(this.g, "policy_control", sb.toString());
    }

    /* JADX WARN: Code duplicated, block: B:14:0x0076  */
    /* JADX WARN: Instruction removed from duplicated block: B:14:0x0076, please report this as an issue */
    public final boolean i(String str) {
        String strR;
        kotlin.jvm.internal.r.d(str, "packageName");
        if (!d(str)) {
            return true;
        }
        if (kotlin.text.k.y(this.f, this.f865c + "=*", false, 2, (Object) null)) {
            strR = this.f + ",-" + str;
            this.f = strR;
        } else {
            if (kotlin.text.k.y(this.e, this.f865c + "=apps", false, 2, (Object) null)) {
                strR = this.f + ",-" + str;
            } else if (kotlin.text.k.y(this.f, str, false, 2, (Object) null)) {
                strR = kotlin.text.k.r(kotlin.text.k.r(this.f, ',' + str, "", false, 4, (Object) null), str, "", false, 4, (Object) null);
            }
            this.f = strR;
        }
        return h();
    }

    /* JADX WARN: Code duplicated, block: B:19:0x0088  */
    /* JADX WARN: Instruction removed from duplicated block: B:19:0x0088, please report this as an issue */
    public final boolean j(String str) {
        String strR;
        kotlin.jvm.internal.r.d(str, "packageName");
        if (!f(str) && !d(str)) {
            return true;
        }
        if (d(str)) {
            i(str);
            c(str);
        }
        if (kotlin.text.k.y(this.f866d, this.f863a + "=*", false, 2, (Object) null)) {
            strR = this.f866d + ",-" + str;
            this.f866d = strR;
        } else {
            if (kotlin.text.k.y(this.f866d, this.f863a + "=apps", false, 2, (Object) null)) {
                strR = this.f866d + ",-" + str;
            } else if (kotlin.text.k.y(this.f866d, str, false, 2, (Object) null)) {
                strR = kotlin.text.k.r(kotlin.text.k.r(this.f866d, ',' + str, "", false, 4, (Object) null), str, "", false, 4, (Object) null);
            }
            this.f866d = strR;
        }
        return h();
    }

    /* JADX WARN: Code duplicated, block: B:19:0x0088  */
    /* JADX WARN: Instruction removed from duplicated block: B:19:0x0088, please report this as an issue */
    public final boolean k(String str) {
        String strR;
        kotlin.jvm.internal.r.d(str, "packageName");
        if (!g(str) && !d(str)) {
            return true;
        }
        if (d(str)) {
            i(str);
            b(str);
        }
        if (kotlin.text.k.y(this.e, this.f864b + "=*", false, 2, (Object) null)) {
            strR = this.e + ",-" + str;
            this.e = strR;
        } else {
            if (kotlin.text.k.y(this.e, this.f864b + "=apps", false, 2, (Object) null)) {
                strR = this.e + ",-" + str;
            } else if (kotlin.text.k.y(this.e, str, false, 2, (Object) null)) {
                strR = kotlin.text.k.r(kotlin.text.k.r(this.e, ',' + str, "", false, 4, (Object) null), str, "", false, 4, (Object) null);
            }
            this.e = strR;
        }
        return h();
    }
}
