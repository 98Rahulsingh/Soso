package com.omarea.scene_mode;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class i {
    public final int a(String str) {
        kotlin.jvm.internal.r.d(str, "mode");
        if (kotlin.jvm.internal.r.a(str, ModeSwitcher.x.p())) {
            return 2131099717;
        }
        if (kotlin.jvm.internal.r.a(str, ModeSwitcher.x.c())) {
            return 2131099703;
        }
        if (kotlin.jvm.internal.r.a(str, ModeSwitcher.x.o())) {
            return 2131099715;
        }
        if (kotlin.jvm.internal.r.a(str, ModeSwitcher.x.i())) {
            return 2131099705;
        }
        return kotlin.jvm.internal.r.a(str, ModeSwitcher.x.n()) ? 2131099713 : 2131099703;
    }

    public final int b(String str) {
        kotlin.jvm.internal.r.d(str, "mode");
        if (kotlin.jvm.internal.r.a(str, ModeSwitcher.x.p())) {
            return 2131231084;
        }
        if (kotlin.jvm.internal.r.a(str, ModeSwitcher.x.c())) {
            return 2131231085;
        }
        if (kotlin.jvm.internal.r.a(str, ModeSwitcher.x.o())) {
            return 2131231086;
        }
        return (kotlin.jvm.internal.r.a(str, ModeSwitcher.x.i()) || kotlin.jvm.internal.r.a(str, ModeSwitcher.x.n())) ? 2131231087 : 2131231086;
    }

    public final int c(String str) {
        kotlin.jvm.internal.r.d(str, "mode");
        if (kotlin.jvm.internal.r.a(str, ModeSwitcher.x.p())) {
            return 2131231119;
        }
        if (kotlin.jvm.internal.r.a(str, ModeSwitcher.x.c())) {
            return 2131231120;
        }
        if (kotlin.jvm.internal.r.a(str, ModeSwitcher.x.o())) {
            return 2131231121;
        }
        if (kotlin.jvm.internal.r.a(str, ModeSwitcher.x.i())) {
            return 2131231122;
        }
        return kotlin.jvm.internal.r.a(str, ModeSwitcher.x.n()) ? 2131231123 : 2131231121;
    }
}
