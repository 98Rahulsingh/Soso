package com.omarea.scene_mode;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.AdaptiveIconDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.os.Build;
import com.omarea.library.basic.AppInfoLoader;
import kotlin.coroutines.CoroutineContext;
import kotlinx.coroutines.CoroutineStart;
import kotlinx.coroutines.i0;
import kotlinx.coroutines.w0;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class LogoCacheManager {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private Context f845a;

    public LogoCacheManager(Context context) {
        kotlin.jvm.internal.r.d(context, "context");
        this.f845a = context;
    }

    private final Bitmap b(Drawable drawable) {
        if (drawable instanceof BitmapDrawable) {
            return ((BitmapDrawable) drawable).getBitmap();
        }
        if (Build.VERSION.SDK_INT < 26 || !(drawable instanceof AdaptiveIconDrawable)) {
            return null;
        }
        AdaptiveIconDrawable adaptiveIconDrawable = (AdaptiveIconDrawable) drawable;
        LayerDrawable layerDrawable = new LayerDrawable(new Drawable[]{adaptiveIconDrawable.getBackground(), adaptiveIconDrawable.getForeground()});
        Bitmap bitmapCreateBitmap = Bitmap.createBitmap(layerDrawable.getIntrinsicWidth(), layerDrawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmapCreateBitmap);
        layerDrawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        layerDrawable.draw(canvas);
        return bitmapCreateBitmap;
    }

    private final String d(String str) {
        return com.omarea.common.shared.d.f450b.b(this.f845a, "logo_cache/" + str + ".png");
    }

    public final AppInfoLoader.a c(String str) {
        kotlin.jvm.internal.r.d(str, "packageName");
        String string = this.f845a.getSharedPreferences("IconCacheManager", 0).getString(str, null);
        Drawable drawableE = e(str);
        if (string != null) {
            str = string;
        }
        return new AppInfoLoader.a(str, drawableE);
    }

    public final Drawable e(String str) {
        kotlin.jvm.internal.r.d(str, "packageName");
        Bitmap bitmapA = new com.omarea.common.shared.b().a(d(str));
        if (bitmapA != null) {
            return new BitmapDrawable(bitmapA);
        }
        return null;
    }

    public final void f(String str) {
        kotlin.jvm.internal.r.d(str, "packageName");
        kotlinx.coroutines.f.d(i0.a(w0.b()), (CoroutineContext) null, (CoroutineStart) null, new LogoCacheManager$saveAppInfo$1(this, str, null), 3, (Object) null);
    }

    public final void g(Drawable drawable, String str) {
        kotlin.jvm.internal.r.d(drawable, "drawable");
        kotlin.jvm.internal.r.d(str, "packageName");
        new com.omarea.common.shared.b().b(b(drawable), d(str));
    }
}
