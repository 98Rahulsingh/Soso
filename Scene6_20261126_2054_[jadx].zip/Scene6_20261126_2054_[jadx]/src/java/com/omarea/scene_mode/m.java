package com.omarea.scene_mode;

import com.omarea.model.TaskAction;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final /* synthetic */ class m {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final /* synthetic */ int[] f885a;

    static {
        int[] iArr = new int[TaskAction.values().length];
        f885a = iArr;
        iArr[TaskAction.FSTRIM.ordinal()] = 1;
        f885a[TaskAction.STANDBY_MODE_OFF.ordinal()] = 2;
        f885a[TaskAction.STANDBY_MODE_ON.ordinal()] = 3;
        f885a[TaskAction.ZEN_MODE_ON.ordinal()] = 4;
        f885a[TaskAction.ZEN_MODE_OFF.ordinal()] = 5;
    }
}
