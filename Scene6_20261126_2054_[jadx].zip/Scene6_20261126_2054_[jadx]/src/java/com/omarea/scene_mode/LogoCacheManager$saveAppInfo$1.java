package com.omarea.scene_mode;

import android.graphics.drawable.Drawable;
import com.omarea.library.basic.AppInfoLoader;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlinx.coroutines.h0;
import kotlinx.coroutines.o0;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
@kotlin.coroutines.jvm.internal.d(c = "com.omarea.scene_mode.LogoCacheManager$saveAppInfo$1", f = "LogoCacheManager.kt", l = {58}, m = "invokeSuspend")
final class LogoCacheManager$saveAppInfo$1 extends SuspendLambda implements kotlin.jvm.b.p<h0, kotlin.coroutines.c<? super kotlin.s>, Object> {
    final /* synthetic */ String $packageName;
    Object L$0;
    int label;
    private h0 p$;
    final /* synthetic */ LogoCacheManager this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    LogoCacheManager$saveAppInfo$1(LogoCacheManager logoCacheManager, String str, kotlin.coroutines.c cVar) {
        super(2, cVar);
        this.this$0 = logoCacheManager;
        this.$packageName = str;
    }

    public final kotlin.coroutines.c<kotlin.s> create(Object obj, kotlin.coroutines.c<?> cVar) {
        kotlin.jvm.internal.r.d(cVar, "completion");
        LogoCacheManager$saveAppInfo$1 logoCacheManager$saveAppInfo$1 = new LogoCacheManager$saveAppInfo$1(this.this$0, this.$packageName, cVar);
        logoCacheManager$saveAppInfo$1.p$ = (h0) obj;
        return logoCacheManager$saveAppInfo$1;
    }

    public final Object invoke(Object obj, Object obj2) {
        return create(obj, (kotlin.coroutines.c) obj2).invokeSuspend(kotlin.s.a);
    }

    public final Object invokeSuspend(Object obj) {
        Object objD = kotlin.coroutines.intrinsics.a.d();
        int i = this.label;
        if (i == 0) {
            kotlin.h.b(obj);
            h0 h0Var = this.p$;
            o0<AppInfoLoader.a> o0VarD = new AppInfoLoader(this.this$0.f845a, 0, 2, null).d(this.$packageName);
            this.L$0 = h0Var;
            this.label = 1;
            obj = o0VarD.u(this);
            if (obj == objD) {
                return objD;
            }
        } else {
            if (i != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            kotlin.h.b(obj);
        }
        AppInfoLoader.a aVar = (AppInfoLoader.a) obj;
        if (aVar.b() != null) {
            LogoCacheManager logoCacheManager = new LogoCacheManager(this.this$0.f845a);
            Drawable drawableB = aVar.b();
            kotlin.jvm.internal.r.b(drawableB);
            logoCacheManager.g(drawableB, this.$packageName);
            this.this$0.f845a.getSharedPreferences("IconCacheManager", 0).edit().putString(this.$packageName, aVar.a()).apply();
        }
        return kotlin.s.a;
    }
}
