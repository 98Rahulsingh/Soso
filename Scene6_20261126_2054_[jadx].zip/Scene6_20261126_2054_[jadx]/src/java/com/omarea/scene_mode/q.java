package com.omarea.scene_mode;

import com.omarea.data.EventType;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final /* synthetic */ class q {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final /* synthetic */ int[] f894a;

    static {
        int[] iArr = new int[EventType.values().length];
        f894a = iArr;
        iArr[EventType.SCREEN_ON.ordinal()] = 1;
        f894a[EventType.SCREEN_OFF.ordinal()] = 2;
        f894a[EventType.BOOT_COMPLETED.ordinal()] = 3;
        f894a[EventType.BATTERY_LOW.ordinal()] = 4;
        f894a[EventType.POWER_CONNECTED.ordinal()] = 5;
        f894a[EventType.POWER_DISCONNECTED.ordinal()] = 6;
    }
}
