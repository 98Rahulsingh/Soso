package b.a.a.a;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcel;
import android.os.Parcelable;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
@SuppressLint({"BanParcelableUsage"})
public class b implements Parcelable {
    public static final Parcelable.Creator<b> CREATOR = new a();
    final Handler f = null;
    b.a.a.a.a g;

    class a implements Parcelable.Creator<b> {
        a() {
        }

        @Override // android.os.Parcelable.Creator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public b createFromParcel(Parcel parcel) {
            return new b(parcel);
        }

        @Override // android.os.Parcelable.Creator
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public b[] newArray(int i) {
            return new b[i];
        }
    }

    /* JADX INFO: renamed from: b.a.a.a.b$b, reason: collision with other inner class name */
    class BinderC0002b extends b.a.a.a.a.AbstractBinderC0000a {
        BinderC0002b() {
        }

        @Override // b.a.a.a.a
        public void r(int i, Bundle bundle) {
            b bVar = b.this;
            Handler handler = bVar.f;
            if (handler != null) {
                handler.post(bVar.new c(i, bundle));
            } else {
                bVar.f(i, bundle);
            }
        }
    }

    class c implements Runnable {
        final int f;
        final Bundle g;

        c(int i, Bundle bundle) {
            this.f = i;
            this.g = bundle;
        }

        @Override // java.lang.Runnable
        public void run() {
            b.this.f(this.f, this.g);
        }
    }

    b(Parcel parcel) {
        this.g = b.a.a.a.a.AbstractBinderC0000a.t(parcel.readStrongBinder());
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    protected void f(int i, Bundle bundle) {
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        synchronized (this) {
            if (this.g == null) {
                this.g = new BinderC0002b();
            }
            parcel.writeStrongBinder(this.g.asBinder());
        }
    }
}
