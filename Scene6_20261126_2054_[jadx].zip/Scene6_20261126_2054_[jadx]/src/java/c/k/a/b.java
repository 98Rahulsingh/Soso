package c.k.a;

import android.os.Bundle;
import android.util.Log;
import androidx.lifecycle.f;
import androidx.lifecycle.k;
import androidx.lifecycle.l;
import androidx.lifecycle.o;
import androidx.lifecycle.p;
import androidx.lifecycle.q;
import c.d.h;
import java.io.FileDescriptor;
import java.io.PrintWriter;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
class b extends c.k.a.a {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    static boolean f247c;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final f f248a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final c f249b;

    public static class a<D> extends k<D> implements androidx.loader.content.a.a<D> {
        private final int j;
        private final Bundle k;
        private final androidx.loader.content.a<D> l;
        private f m;
        private C0025b<D> n;
        private androidx.loader.content.a<D> o;

        protected void g() {
            if (b.f247c) {
                Log.v("LoaderManager", "  Starting: " + this);
            }
            this.l.f();
            throw null;
        }

        protected void h() {
            if (b.f247c) {
                Log.v("LoaderManager", "  Stopping: " + this);
            }
            this.l.g();
        }

        public void i(l<? super D> lVar) {
            super/*androidx.lifecycle.LiveData*/.i(lVar);
            this.m = null;
            this.n = null;
        }

        public void j(D d2) {
            super.j(d2);
            androidx.loader.content.a<D> aVar = this.o;
            if (aVar != null) {
                aVar.e();
                this.o = null;
            }
        }

        androidx.loader.content.a<D> k(boolean z) {
            if (b.f247c) {
                Log.v("LoaderManager", "  Destroying: " + this);
            }
            this.l.b();
            this.l.a();
            C0025b<D> c0025b = this.n;
            if (c0025b != null) {
                i(c0025b);
                if (z) {
                    c0025b.d();
                }
            }
            this.l.h(this);
            if ((c0025b == null || c0025b.c()) && !z) {
                return this.l;
            }
            this.l.e();
            return this.o;
        }

        public void l(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
            printWriter.print(str);
            printWriter.print("mId=");
            printWriter.print(this.j);
            printWriter.print(" mArgs=");
            printWriter.println(this.k);
            printWriter.print(str);
            printWriter.print("mLoader=");
            printWriter.println(this.l);
            this.l.d(str + "  ", fileDescriptor, printWriter, strArr);
            if (this.n != null) {
                printWriter.print(str);
                printWriter.print("mCallbacks=");
                printWriter.println(this.n);
                this.n.b(str + "  ", printWriter);
            }
            printWriter.print(str);
            printWriter.print("mData=");
            printWriter.println(m().c(d()));
            printWriter.print(str);
            printWriter.print("mStarted=");
            printWriter.println(e());
        }

        androidx.loader.content.a<D> m() {
            return this.l;
        }

        void n() {
            f fVar = this.m;
            C0025b<D> c0025b = this.n;
            if (fVar == null || c0025b == null) {
                return;
            }
            super/*androidx.lifecycle.LiveData*/.i(c0025b);
            f(fVar, c0025b);
        }

        public String toString() {
            StringBuilder sb = new StringBuilder(64);
            sb.append("LoaderInfo{");
            sb.append(Integer.toHexString(System.identityHashCode(this)));
            sb.append(" #");
            sb.append(this.j);
            sb.append(" : ");
            c.f.i.a.a(this.l, sb);
            sb.append("}}");
            return sb.toString();
        }
    }

    /* JADX INFO: renamed from: c.k.a.b$b, reason: collision with other inner class name */
    static class C0025b<D> implements l<D> {
        public abstract void b(String str, PrintWriter printWriter);

        abstract boolean c();

        abstract void d();
    }

    static class c extends o {

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private static final p.a f250c = new a();

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private h<a> f251b = new h<>();

        static class a implements p.a {
            a() {
            }

            public <T extends o> T a(Class<T> cls) {
                return new c();
            }
        }

        c() {
        }

        static c e(q qVar) {
            return (c) new p(qVar, f250c).a(c.class);
        }

        protected void c() {
            super.c();
            int iL = this.f251b.l();
            for (int i = 0; i < iL; i++) {
                this.f251b.m(i).k(true);
            }
            this.f251b.b();
        }

        public void d(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
            if (this.f251b.l() > 0) {
                printWriter.print(str);
                printWriter.println("Loaders:");
                String str2 = str + "    ";
                for (int i = 0; i < this.f251b.l(); i++) {
                    a aVarM = this.f251b.m(i);
                    printWriter.print(str);
                    printWriter.print("  #");
                    printWriter.print(this.f251b.i(i));
                    printWriter.print(": ");
                    printWriter.println(aVarM.toString());
                    aVarM.l(str2, fileDescriptor, printWriter, strArr);
                }
            }
        }

        void f() {
            int iL = this.f251b.l();
            for (int i = 0; i < iL; i++) {
                this.f251b.m(i).n();
            }
        }
    }

    b(f fVar, q qVar) {
        this.f248a = fVar;
        this.f249b = c.e(qVar);
    }

    @Override // c.k.a.a
    @Deprecated
    public void a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        this.f249b.d(str, fileDescriptor, printWriter, strArr);
    }

    @Override // c.k.a.a
    public void c() {
        this.f249b.f();
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("LoaderManager{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append(" in ");
        c.f.i.a.a(this.f248a, sb);
        sb.append("}}");
        return sb.toString();
    }
}
