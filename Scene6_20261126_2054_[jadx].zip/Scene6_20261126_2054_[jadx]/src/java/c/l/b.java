package c.l;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class b {
    public static final int compat_button_inset_horizontal_material = 2131165273;
    public static final int compat_button_inset_vertical_material = 2131165274;
    public static final int compat_button_padding_horizontal_material = 2131165275;
    public static final int compat_button_padding_vertical_material = 2131165276;
    public static final int compat_control_corner_material = 2131165277;
    public static final int compat_notification_large_icon_max_height = 2131165278;
    public static final int compat_notification_large_icon_max_width = 2131165279;
    public static final int fastscroll_default_thickness = 2131165330;
    public static final int fastscroll_margin = 2131165331;
    public static final int fastscroll_minimum_range = 2131165332;
    public static final int item_touch_helper_max_drag_scroll_per_frame = 2131165340;
    public static final int item_touch_helper_swipe_escape_max_velocity = 2131165341;
    public static final int item_touch_helper_swipe_escape_velocity = 2131165342;
    public static final int notification_action_icon_size = 2131165513;
    public static final int notification_action_text_size = 2131165514;
    public static final int notification_big_circle_margin = 2131165515;
    public static final int notification_content_margin_start = 2131165516;
    public static final int notification_large_icon_height = 2131165517;
    public static final int notification_large_icon_width = 2131165518;
    public static final int notification_main_column_padding_top = 2131165519;
    public static final int notification_media_narrow_margin = 2131165520;
    public static final int notification_right_icon_size = 2131165521;
    public static final int notification_right_side_padding_top = 2131165522;
    public static final int notification_small_icon_background_padding = 2131165523;
    public static final int notification_small_icon_size_as_large = 2131165524;
    public static final int notification_subtext_size = 2131165525;
    public static final int notification_top_pad = 2131165526;
    public static final int notification_top_pad_large_text = 2131165527;
}
