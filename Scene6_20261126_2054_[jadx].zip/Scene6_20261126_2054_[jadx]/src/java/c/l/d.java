package c.l;

import android.R;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class d {
    public static final int ColorStateListItem_alpha = 2;
    public static final int ColorStateListItem_android_alpha = 1;
    public static final int ColorStateListItem_android_color = 0;
    public static final int FontFamilyFont_android_font = 0;
    public static final int FontFamilyFont_android_fontStyle = 2;
    public static final int FontFamilyFont_android_fontVariationSettings = 4;
    public static final int FontFamilyFont_android_fontWeight = 1;
    public static final int FontFamilyFont_android_ttcIndex = 3;
    public static final int FontFamilyFont_font = 5;
    public static final int FontFamilyFont_fontStyle = 6;
    public static final int FontFamilyFont_fontVariationSettings = 7;
    public static final int FontFamilyFont_fontWeight = 8;
    public static final int FontFamilyFont_ttcIndex = 9;
    public static final int FontFamily_fontProviderAuthority = 0;
    public static final int FontFamily_fontProviderCerts = 1;
    public static final int FontFamily_fontProviderFetchStrategy = 2;
    public static final int FontFamily_fontProviderFetchTimeout = 3;
    public static final int FontFamily_fontProviderPackage = 4;
    public static final int FontFamily_fontProviderQuery = 5;
    public static final int GradientColorItem_android_color = 0;
    public static final int GradientColorItem_android_offset = 1;
    public static final int GradientColor_android_centerColor = 7;
    public static final int GradientColor_android_centerX = 3;
    public static final int GradientColor_android_centerY = 4;
    public static final int GradientColor_android_endColor = 1;
    public static final int GradientColor_android_endX = 10;
    public static final int GradientColor_android_endY = 11;
    public static final int GradientColor_android_gradientRadius = 5;
    public static final int GradientColor_android_startColor = 0;
    public static final int GradientColor_android_startX = 8;
    public static final int GradientColor_android_startY = 9;
    public static final int GradientColor_android_tileMode = 6;
    public static final int GradientColor_android_type = 2;
    public static final int RecyclerView_android_clipToPadding = 1;
    public static final int RecyclerView_android_descendantFocusability = 2;
    public static final int RecyclerView_android_orientation = 0;
    public static final int RecyclerView_fastScrollEnabled = 3;
    public static final int RecyclerView_fastScrollHorizontalThumbDrawable = 4;
    public static final int RecyclerView_fastScrollHorizontalTrackDrawable = 5;
    public static final int RecyclerView_fastScrollVerticalThumbDrawable = 6;
    public static final int RecyclerView_fastScrollVerticalTrackDrawable = 7;
    public static final int RecyclerView_layoutManager = 8;
    public static final int RecyclerView_reverseLayout = 9;
    public static final int RecyclerView_spanCount = 10;
    public static final int RecyclerView_stackFromEnd = 11;
    public static final int[] ColorStateListItem = {R.attr.color, R.attr.alpha, 2130968616};
    public static final int[] FontFamily = {2130968926, 2130968927, 2130968928, 2130968929, 2130968930, 2130968931};
    public static final int[] FontFamilyFont = {R.attr.font, R.attr.fontWeight, R.attr.fontStyle, R.attr.ttcIndex, R.attr.fontVariationSettings, 2130968924, 2130968932, 2130968933, 2130968934, 2130969399};
    public static final int[] GradientColor = {R.attr.startColor, R.attr.endColor, R.attr.type, R.attr.centerX, R.attr.centerY, R.attr.gradientRadius, R.attr.tileMode, R.attr.centerColor, R.attr.startX, R.attr.startY, R.attr.endX, R.attr.endY};
    public static final int[] GradientColorItem = {R.attr.color, R.attr.offset};
    public static final int[] RecyclerView = {R.attr.orientation, R.attr.clipToPadding, R.attr.descendantFocusability, 2130968898, 2130968899, 2130968900, 2130968901, 2130968902, 2130969008, 2130969210, 2130969246, 2130969252};
}
