package c.l;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class a {
    public static final int alpha = 2130968616;
    public static final int fastScrollEnabled = 2130968898;
    public static final int fastScrollHorizontalThumbDrawable = 2130968899;
    public static final int fastScrollHorizontalTrackDrawable = 2130968900;
    public static final int fastScrollVerticalThumbDrawable = 2130968901;
    public static final int fastScrollVerticalTrackDrawable = 2130968902;
    public static final int font = 2130968924;
    public static final int fontProviderAuthority = 2130968926;
    public static final int fontProviderCerts = 2130968927;
    public static final int fontProviderFetchStrategy = 2130968928;
    public static final int fontProviderFetchTimeout = 2130968929;
    public static final int fontProviderPackage = 2130968930;
    public static final int fontProviderQuery = 2130968931;
    public static final int fontStyle = 2130968932;
    public static final int fontVariationSettings = 2130968933;
    public static final int fontWeight = 2130968934;
    public static final int layoutManager = 2130969008;
    public static final int recyclerViewStyle = 2130969205;
    public static final int reverseLayout = 2130969210;
    public static final int spanCount = 2130969246;
    public static final int stackFromEnd = 2130969252;
    public static final int ttcIndex = 2130969399;
}
