package c.d;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class d<E> implements Cloneable {
    private static final Object j = new Object();
    private boolean f;
    private long[] g;
    private Object[] h;
    private int i;

    public d() {
        this(10);
    }

    public d(int i) {
        this.f = false;
        if (i == 0) {
            this.g = c.f60b;
            this.h = c.f61c;
        } else {
            int iF = c.f(i);
            this.g = new long[iF];
            this.h = new Object[iF];
        }
    }

    private void d() {
        int i = this.i;
        long[] jArr = this.g;
        Object[] objArr = this.h;
        int i2 = 0;
        for (int i3 = 0; i3 < i; i3++) {
            Object obj = objArr[i3];
            if (obj != j) {
                if (i3 != i2) {
                    jArr[i2] = jArr[i3];
                    objArr[i2] = obj;
                    objArr[i3] = null;
                }
                i2++;
            }
        }
        this.f = false;
        this.i = i2;
    }

    public void a(long j2, E e) {
        int i = this.i;
        if (i != 0 && j2 <= this.g[i - 1]) {
            i(j2, e);
            return;
        }
        if (this.f && this.i >= this.g.length) {
            d();
        }
        int i2 = this.i;
        if (i2 >= this.g.length) {
            int iF = c.f(i2 + 1);
            long[] jArr = new long[iF];
            Object[] objArr = new Object[iF];
            long[] jArr2 = this.g;
            System.arraycopy(jArr2, 0, jArr, 0, jArr2.length);
            Object[] objArr2 = this.h;
            System.arraycopy(objArr2, 0, objArr, 0, objArr2.length);
            this.g = jArr;
            this.h = objArr;
        }
        this.g[i2] = j2;
        this.h[i2] = e;
        this.i = i2 + 1;
    }

    public void b() {
        int i = this.i;
        Object[] objArr = this.h;
        for (int i2 = 0; i2 < i; i2++) {
            objArr[i2] = null;
        }
        this.i = 0;
        this.f = false;
    }

    /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
    public d<E> clone() {
        try {
            d<E> dVar = (d) super.clone();
            dVar.g = (long[]) this.g.clone();
            dVar.h = (Object[]) this.h.clone();
            return dVar;
        } catch (CloneNotSupportedException e) {
            throw new AssertionError(e);
        }
    }

    public E e(long j2) {
        return f(j2, null);
    }

    public E f(long j2, E e) {
        int iB = c.b(this.g, this.i, j2);
        if (iB >= 0) {
            Object[] objArr = this.h;
            if (objArr[iB] != j) {
                return (E) objArr[iB];
            }
        }
        return e;
    }

    public int g(long j2) {
        if (this.f) {
            d();
        }
        return c.b(this.g, this.i, j2);
    }

    public long h(int i) {
        if (this.f) {
            d();
        }
        return this.g[i];
    }

    public void i(long j2, E e) {
        int iB = c.b(this.g, this.i, j2);
        if (iB >= 0) {
            this.h[iB] = e;
            return;
        }
        int i = ~iB;
        if (i < this.i) {
            Object[] objArr = this.h;
            if (objArr[i] == j) {
                this.g[i] = j2;
                objArr[i] = e;
                return;
            }
        }
        if (this.f && this.i >= this.g.length) {
            d();
            i = ~c.b(this.g, this.i, j2);
        }
        int i2 = this.i;
        if (i2 >= this.g.length) {
            int iF = c.f(i2 + 1);
            long[] jArr = new long[iF];
            Object[] objArr2 = new Object[iF];
            long[] jArr2 = this.g;
            System.arraycopy(jArr2, 0, jArr, 0, jArr2.length);
            Object[] objArr3 = this.h;
            System.arraycopy(objArr3, 0, objArr2, 0, objArr3.length);
            this.g = jArr;
            this.h = objArr2;
        }
        int i3 = this.i;
        if (i3 - i != 0) {
            long[] jArr3 = this.g;
            int i4 = i + 1;
            System.arraycopy(jArr3, i, jArr3, i4, i3 - i);
            Object[] objArr4 = this.h;
            System.arraycopy(objArr4, i, objArr4, i4, this.i - i);
        }
        this.g[i] = j2;
        this.h[i] = e;
        this.i++;
    }

    public void j(long j2) {
        int iB = c.b(this.g, this.i, j2);
        if (iB >= 0) {
            Object[] objArr = this.h;
            Object obj = objArr[iB];
            Object obj2 = j;
            if (obj != obj2) {
                objArr[iB] = obj2;
                this.f = true;
            }
        }
    }

    public void k(int i) {
        Object[] objArr = this.h;
        Object obj = objArr[i];
        Object obj2 = j;
        if (obj != obj2) {
            objArr[i] = obj2;
            this.f = true;
        }
    }

    public int l() {
        if (this.f) {
            d();
        }
        return this.i;
    }

    public E m(int i) {
        if (this.f) {
            d();
        }
        return (E) this.h[i];
    }

    public String toString() {
        if (l() <= 0) {
            return "{}";
        }
        StringBuilder sb = new StringBuilder(this.i * 28);
        sb.append('{');
        for (int i = 0; i < this.i; i++) {
            if (i > 0) {
                sb.append(", ");
            }
            sb.append(h(i));
            sb.append('=');
            E eM = m(i);
            if (eM != this) {
                sb.append(eM);
            } else {
                sb.append("(this Map)");
            }
        }
        sb.append('}');
        return sb.toString();
    }
}
