package c.d;

import java.util.Collection;
import java.util.Map;
import java.util.Set;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class a<K, V> extends g<K, V> implements Map<K, V> {
    f<K, V> m;

    /* JADX INFO: renamed from: c.d.a$a, reason: collision with other inner class name */
    class C0007a extends f<K, V> {
        C0007a() {
        }

        @Override // c.d.f
        protected void a() {
            a.this.clear();
        }

        @Override // c.d.f
        protected Object b(int i, int i2) {
            return a.this.g[(i << 1) + i2];
        }

        @Override // c.d.f
        protected Map<K, V> c() {
            return a.this;
        }

        @Override // c.d.f
        protected int d() {
            return a.this.h;
        }

        @Override // c.d.f
        protected int e(Object obj) {
            return a.this.g(obj);
        }

        @Override // c.d.f
        protected int f(Object obj) {
            return a.this.i(obj);
        }

        @Override // c.d.f
        protected void g(K k, V v) {
            a.this.put(k, v);
        }

        @Override // c.d.f
        protected void h(int i) {
            a.this.l(i);
        }

        @Override // c.d.f
        protected V i(int i, V v) {
            return a.this.m(i, v);
        }
    }

    public a() {
    }

    public a(int i) {
        super(i);
    }

    public a(g gVar) {
        super(gVar);
    }

    private f<K, V> o() {
        if (this.m == null) {
            this.m = new C0007a();
        }
        return this.m;
    }

    @Override // java.util.Map
    public Set<Map.Entry<K, V>> entrySet() {
        return o().l();
    }

    @Override // java.util.Map
    public Set<K> keySet() {
        return o().m();
    }

    public boolean p(Collection<?> collection) {
        return f.p(this, collection);
    }

    @Override // java.util.Map
    public void putAll(Map<? extends K, ? extends V> map) {
        d(this.h + map.size());
        for (Map.Entry<? extends K, ? extends V> entry : map.entrySet()) {
            put(entry.getKey(), entry.getValue());
        }
    }

    @Override // java.util.Map
    public Collection<V> values() {
        return o().n();
    }
}
