package c.d;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class e<K, V> {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final LinkedHashMap<K, V> f62a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private int f63b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private int f64c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private int f65d;
    private int e;
    private int f;
    private int g;
    private int h;

    public e(int i) {
        if (i <= 0) {
            throw new IllegalArgumentException("maxSize <= 0");
        }
        this.f64c = i;
        this.f62a = new LinkedHashMap<>(0, 0.75f, true);
    }

    private int e(K k, V v) {
        int iF = f(k, v);
        if (iF >= 0) {
            return iF;
        }
        throw new IllegalStateException("Negative size: " + k + "=" + v);
    }

    protected V a(K k) {
        return null;
    }

    protected void b(boolean z, K k, V v, V v2) {
    }

    public final V c(K k) {
        V vPut;
        if (k == null) {
            throw new NullPointerException("key == null");
        }
        synchronized (this) {
            V v = this.f62a.get(k);
            if (v != null) {
                this.g++;
                return v;
            }
            this.h++;
            V vA = a(k);
            if (vA == null) {
                return null;
            }
            synchronized (this) {
                this.e++;
                vPut = this.f62a.put(k, vA);
                if (vPut != null) {
                    this.f62a.put(k, vPut);
                } else {
                    this.f63b += e(k, vA);
                }
            }
            if (vPut != null) {
                b(false, k, vA, vPut);
                return vPut;
            }
            g(this.f64c);
            return vA;
        }
    }

    public final V d(K k, V v) {
        V vPut;
        if (k == null || v == null) {
            throw new NullPointerException("key == null || value == null");
        }
        synchronized (this) {
            this.f65d++;
            this.f63b += e(k, v);
            vPut = this.f62a.put(k, v);
            if (vPut != null) {
                this.f63b -= e(k, vPut);
            }
        }
        if (vPut != null) {
            b(false, k, vPut, v);
        }
        g(this.f64c);
        return vPut;
    }

    protected int f(K k, V v) {
        return 1;
    }

    public void g(int i) {
        K key;
        V value;
        while (true) {
            synchronized (this) {
                if (this.f63b < 0 || (this.f62a.isEmpty() && this.f63b != 0)) {
                    break;
                }
                if (this.f63b > i && !this.f62a.isEmpty()) {
                    Map.Entry<K, V> next = this.f62a.entrySet().iterator().next();
                    key = next.getKey();
                    value = next.getValue();
                    this.f62a.remove(key);
                    this.f63b -= e(key, value);
                    this.f++;
                }
                return;
            }
            b(true, key, value, null);
        }
        throw new IllegalStateException(getClass().getName() + ".sizeOf() is reporting inconsistent results!");
    }

    public final synchronized String toString() {
        int i;
        i = this.g + this.h;
        return String.format(Locale.US, "LruCache[maxSize=%d,hits=%d,misses=%d,hitRate=%d%%]", Integer.valueOf(this.f64c), Integer.valueOf(this.g), Integer.valueOf(this.h), Integer.valueOf(i != 0 ? (this.g * 100) / i : 0));
    }
}
