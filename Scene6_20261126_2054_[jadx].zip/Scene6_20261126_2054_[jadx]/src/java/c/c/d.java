package c.c;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class d {
    public static final int Base_CardView = 2131951642;
    public static final int CardView = 2131951853;
    public static final int CardView_Dark = 2131951854;
    public static final int CardView_Light = 2131951855;
}
