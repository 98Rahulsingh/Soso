package c.c;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class b {
    public static final int cardview_dark_background = 2131099695;
    public static final int cardview_light_background = 2131099696;
    public static final int cardview_shadow_end_color = 2131099697;
    public static final int cardview_shadow_start_color = 2131099698;
}
