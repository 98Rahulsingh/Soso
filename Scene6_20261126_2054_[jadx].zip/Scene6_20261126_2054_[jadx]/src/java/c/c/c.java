package c.c;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class c {
    public static final int cardview_compat_inset_shadow = 2131165270;
    public static final int cardview_default_elevation = 2131165271;
    public static final int cardview_default_radius = 2131165272;
}
