package c.c;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class a {
    public static final int cardBackgroundColor = 2130968694;
    public static final int cardCornerRadius = 2130968696;
    public static final int cardElevation = 2130968697;
    public static final int cardMaxElevation = 2130968699;
    public static final int cardPreventCornerOverlap = 2130968700;
    public static final int cardUseCompatPadding = 2130968701;
    public static final int cardViewStyle = 2130968702;
    public static final int contentPadding = 2130968783;
    public static final int contentPaddingBottom = 2130968784;
    public static final int contentPaddingLeft = 2130968785;
    public static final int contentPaddingRight = 2130968786;
    public static final int contentPaddingTop = 2130968787;
}
