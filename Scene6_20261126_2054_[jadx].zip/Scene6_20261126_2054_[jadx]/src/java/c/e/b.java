package c.e;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class b {
    public static final int TextAppearance_Compat_Notification = 2131952002;
    public static final int TextAppearance_Compat_Notification_Info = 2131952003;
    public static final int TextAppearance_Compat_Notification_Line2 = 2131952005;
    public static final int TextAppearance_Compat_Notification_Time = 2131952008;
    public static final int TextAppearance_Compat_Notification_Title = 2131952010;
    public static final int Widget_Compat_NotificationActionContainer = 2131952240;
    public static final int Widget_Compat_NotificationActionText = 2131952241;
    public static final int Widget_Support_CoordinatorLayout = 2131952349;
}
