package c.e;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class a {
    public static final int alpha = 2130968616;
    public static final int coordinatorLayoutStyle = 2130968791;
    public static final int font = 2130968924;
    public static final int fontProviderAuthority = 2130968926;
    public static final int fontProviderCerts = 2130968927;
    public static final int fontProviderFetchStrategy = 2130968928;
    public static final int fontProviderFetchTimeout = 2130968929;
    public static final int fontProviderPackage = 2130968930;
    public static final int fontProviderQuery = 2130968931;
    public static final int fontStyle = 2130968932;
    public static final int fontVariationSettings = 2130968933;
    public static final int fontWeight = 2130968934;
    public static final int keylines = 2130969000;
    public static final int layout_anchor = 2130969009;
    public static final int layout_anchorGravity = 2130969010;
    public static final int layout_behavior = 2130969011;
    public static final int layout_dodgeInsetEdges = 2130969056;
    public static final int layout_insetEdge = 2130969065;
    public static final int layout_keyline = 2130969066;
    public static final int statusBarBackground = 2130969265;
    public static final int ttcIndex = 2130969399;
}
