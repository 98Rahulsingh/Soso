package c.i.a;

import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.provider.DocumentsContract;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public abstract class a {
    a(a aVar) {
    }

    public static a e(Context context, Uri uri) {
        if (Build.VERSION.SDK_INT >= 19) {
            return new c(null, context, uri);
        }
        return null;
    }

    public static a f(Context context, Uri uri) {
        if (Build.VERSION.SDK_INT >= 21) {
            return new d(null, context, DocumentsContract.buildDocumentUriUsingTree(uri, DocumentsContract.getTreeDocumentId(uri)));
        }
        return null;
    }

    public abstract boolean a();

    public abstract a b(String str);

    public abstract a c(String str, String str2);

    public a d(String str) {
        for (a aVar : h()) {
            if (str.equals(aVar.g())) {
                return aVar;
            }
        }
        return null;
    }

    public abstract String g();

    public abstract a[] h();
}
