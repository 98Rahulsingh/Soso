package c.i.a;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.util.Log;
import java.util.ArrayList;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
class d extends a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private Context f240a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private Uri f241b;

    d(a aVar, Context context, Uri uri) {
        super(aVar);
        this.f240a = context;
        this.f241b = uri;
    }

    private static void i(AutoCloseable autoCloseable) {
        if (autoCloseable != null) {
            try {
                autoCloseable.close();
            } catch (RuntimeException e) {
                throw e;
            } catch (Exception unused) {
            }
        }
    }

    private static Uri j(Context context, Uri uri, String str, String str2) {
        try {
            return DocumentsContract.createDocument(context.getContentResolver(), uri, str, str2);
        } catch (Exception unused) {
            return null;
        }
    }

    @Override // c.i.a.a
    public boolean a() {
        return b.a(this.f240a, this.f241b);
    }

    @Override // c.i.a.a
    public a b(String str) {
        Uri uriJ = j(this.f240a, this.f241b, "vnd.android.document/directory", str);
        if (uriJ != null) {
            return new d(this, this.f240a, uriJ);
        }
        return null;
    }

    @Override // c.i.a.a
    public a c(String str, String str2) {
        Uri uriJ = j(this.f240a, this.f241b, str, str2);
        if (uriJ != null) {
            return new d(this, this.f240a, uriJ);
        }
        return null;
    }

    @Override // c.i.a.a
    public String g() {
        return b.c(this.f240a, this.f241b);
    }

    @Override // c.i.a.a
    public a[] h() {
        ContentResolver contentResolver = this.f240a.getContentResolver();
        Uri uri = this.f241b;
        Uri uriBuildChildDocumentsUriUsingTree = DocumentsContract.buildChildDocumentsUriUsingTree(uri, DocumentsContract.getDocumentId(uri));
        ArrayList arrayList = new ArrayList();
        Cursor cursorQuery = null;
        try {
            try {
                cursorQuery = contentResolver.query(uriBuildChildDocumentsUriUsingTree, new String[]{"document_id"}, null, null, null);
                while (cursorQuery.moveToNext()) {
                    arrayList.add(DocumentsContract.buildDocumentUriUsingTree(this.f241b, cursorQuery.getString(0)));
                }
            } catch (Exception e) {
                Log.w("DocumentFile", "Failed query: " + e);
            }
            i(cursorQuery);
            Uri[] uriArr = (Uri[]) arrayList.toArray(new Uri[arrayList.size()]);
            a[] aVarArr = new a[uriArr.length];
            for (int i = 0; i < uriArr.length; i++) {
                aVarArr[i] = new d(this, this.f240a, uriArr[i]);
            }
            return aVarArr;
        } catch (Throwable th) {
            i(cursorQuery);
            throw th;
        }
    }
}
