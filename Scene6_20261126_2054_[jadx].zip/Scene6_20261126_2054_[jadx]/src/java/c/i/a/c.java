package c.i.a;

import android.content.Context;
import android.net.Uri;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
class c extends a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private Context f238a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private Uri f239b;

    c(a aVar, Context context, Uri uri) {
        super(aVar);
        this.f238a = context;
        this.f239b = uri;
    }

    @Override // c.i.a.a
    public boolean a() {
        return b.a(this.f238a, this.f239b);
    }

    @Override // c.i.a.a
    public a b(String str) {
        throw new UnsupportedOperationException();
    }

    @Override // c.i.a.a
    public a c(String str, String str2) {
        throw new UnsupportedOperationException();
    }

    @Override // c.i.a.a
    public String g() {
        return b.c(this.f238a, this.f239b);
    }

    @Override // c.i.a.a
    public a[] h() {
        throw new UnsupportedOperationException();
    }
}
