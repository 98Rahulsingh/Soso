package c.f.d.d;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.util.TypedValue;
import c.f.i.h;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import org.xmlpull.v1.XmlPullParserException;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class f {

    public static abstract class a {

        /* JADX INFO: renamed from: c.f.d.d.f$a$a, reason: collision with other inner class name */
        class RunnableC0009a implements Runnable {
            final /* synthetic */ Typeface f;

            RunnableC0009a(Typeface typeface) {
                this.f = typeface;
            }

            @Override // java.lang.Runnable
            public void run() {
                a.this.d(this.f);
            }
        }

        class b implements Runnable {
            final /* synthetic */ int f;

            b(int i) {
                this.f = i;
            }

            @Override // java.lang.Runnable
            public void run() {
                a.this.c(this.f);
            }
        }

        public final void a(int i, Handler handler) {
            if (handler == null) {
                handler = new Handler(Looper.getMainLooper());
            }
            handler.post(new b(i));
        }

        public final void b(Typeface typeface, Handler handler) {
            if (handler == null) {
                handler = new Handler(Looper.getMainLooper());
            }
            handler.post(new RunnableC0009a(typeface));
        }

        public abstract void c(int i);

        public abstract void d(Typeface typeface);
    }

    public static final class b {

        static class a {

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            private static final Object f84a = new Object();

            /* JADX INFO: renamed from: b, reason: collision with root package name */
            private static Method f85b;

            /* JADX INFO: renamed from: c, reason: collision with root package name */
            private static boolean f86c;

            /* JADX WARN: Code duplicated, block: B:30:0x0027 A[EXC_TOP_SPLITTER, SYNTHETIC] */
            static void a(Resources.Theme theme) {
                synchronized (f84a) {
                    if (!f86c) {
                        try {
                            Method declaredMethod = Resources.Theme.class.getDeclaredMethod("rebase", new Class[0]);
                            f85b = declaredMethod;
                            declaredMethod.setAccessible(true);
                        } catch (NoSuchMethodException e) {
                            Log.i("ResourcesCompat", "Failed to retrieve rebase() method", e);
                        }
                        f86c = true;
                        if (f85b != null) {
                            try {
                                f85b.invoke(theme, new Object[0]);
                            } catch (IllegalAccessException | InvocationTargetException e2) {
                                Log.i("ResourcesCompat", "Failed to invoke rebase() method via reflection", e2);
                                f85b = null;
                            }
                        }
                    } else if (f85b != null) {
                        f85b.invoke(theme, new Object[0]);
                    }
                    throw th;
                }
            }
        }

        /* JADX INFO: renamed from: c.f.d.d.f$b$b, reason: collision with other inner class name */
        static class C0010b {
            static void a(Resources.Theme theme) {
                theme.rebase();
            }
        }

        public static void a(Resources.Theme theme) {
            int i = Build.VERSION.SDK_INT;
            if (i >= 29) {
                C0010b.a(theme);
            } else if (i >= 23) {
                a.a(theme);
            }
        }
    }

    public static Drawable a(Resources resources, int i, Resources.Theme theme) {
        return Build.VERSION.SDK_INT >= 21 ? resources.getDrawable(i, theme) : resources.getDrawable(i);
    }

    public static Typeface b(Context context, int i) {
        if (context.isRestricted()) {
            return null;
        }
        return e(context, i, new TypedValue(), 0, null, null, false, false);
    }

    public static Typeface c(Context context, int i, TypedValue typedValue, int i2, a aVar) {
        if (context.isRestricted()) {
            return null;
        }
        return e(context, i, typedValue, i2, aVar, null, true, false);
    }

    public static void d(Context context, int i, a aVar, Handler handler) {
        h.c(aVar);
        if (context.isRestricted()) {
            aVar.a(-4, handler);
        } else {
            e(context, i, new TypedValue(), 0, aVar, handler, false, false);
        }
    }

    private static Typeface e(Context context, int i, TypedValue typedValue, int i2, a aVar, Handler handler, boolean z, boolean z2) {
        Resources resources = context.getResources();
        resources.getValue(i, typedValue, true);
        Typeface typefaceF = f(context, resources, typedValue, i, i2, aVar, handler, z, z2);
        if (typefaceF != null || aVar != null || z2) {
            return typefaceF;
        }
        throw new Resources.NotFoundException("Font resource ID #0x" + Integer.toHexString(i) + " could not be retrieved.");
    }

    /* JADX WARN: Code duplicated, block: B:38:0x0099  */
    private static Typeface f(Context context, Resources resources, TypedValue typedValue, int i, int i2, a aVar, Handler handler, boolean z, boolean z2) {
        StringBuilder sb;
        String str;
        CharSequence charSequence = typedValue.string;
        if (charSequence == null) {
            throw new Resources.NotFoundException("Resource \"" + resources.getResourceName(i) + "\" (" + Integer.toHexString(i) + ") is not a Font: " + typedValue);
        }
        String string = charSequence.toString();
        if (!string.startsWith("res/")) {
            if (aVar != null) {
                aVar.a(-3, handler);
            }
            return null;
        }
        Typeface typefaceF = androidx.core.graphics.d.f(resources, i, i2);
        if (typefaceF != null) {
            if (aVar != null) {
                aVar.b(typefaceF, handler);
            }
            return typefaceF;
        }
        if (z2) {
            return null;
        }
        try {
            if (!string.toLowerCase().endsWith(".xml")) {
                Typeface typefaceD = androidx.core.graphics.d.d(context, resources, i, string, i2);
                if (aVar != null) {
                    if (typefaceD != null) {
                        aVar.b(typefaceD, handler);
                    } else {
                        aVar.a(-3, handler);
                    }
                }
                return typefaceD;
            }
            c.a aVarB = c.b(resources.getXml(i), resources);
            if (aVarB != null) {
                return androidx.core.graphics.d.c(context, aVarB, resources, i, i2, aVar, handler, z);
            }
            Log.e("ResourcesCompat", "Failed to find font-family tag");
            if (aVar != null) {
                aVar.a(-3, handler);
            }
            return null;
        } catch (IOException e) {
            e = e;
            sb = new StringBuilder();
            str = "Failed to read xml resource ";
            sb.append(str);
            sb.append(string);
            Log.e("ResourcesCompat", sb.toString(), e);
            if (aVar != null) {
                aVar.a(-3, handler);
            }
            return null;
        } catch (XmlPullParserException e2) {
            e = e2;
            sb = new StringBuilder();
            str = "Failed to parse xml resource ";
            sb.append(str);
            sb.append(string);
            Log.e("ResourcesCompat", sb.toString(), e);
            if (aVar != null) {
                aVar.a(-3, handler);
            }
            return null;
        }
    }
}
