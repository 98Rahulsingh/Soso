package c.f.d.d;

import android.content.res.Resources;
import android.content.res.TypedArray;
import android.os.Build;
import android.util.Base64;
import android.util.TypedValue;
import android.util.Xml;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class c {

    public interface a {
    }

    public static final class b implements a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final C0008c[] f74a;

        public b(C0008c[] c0008cArr) {
            this.f74a = c0008cArr;
        }

        public C0008c[] a() {
            return this.f74a;
        }
    }

    /* JADX INFO: renamed from: c.f.d.d.c$c, reason: collision with other inner class name */
    public static final class C0008c {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final String f75a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private int f76b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private boolean f77c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        private String f78d;
        private int e;
        private int f;

        public C0008c(String str, int i, boolean z, String str2, int i2, int i3) {
            this.f75a = str;
            this.f76b = i;
            this.f77c = z;
            this.f78d = str2;
            this.e = i2;
            this.f = i3;
        }

        public String a() {
            return this.f75a;
        }

        public int b() {
            return this.f;
        }

        public int c() {
            return this.e;
        }

        public String d() {
            return this.f78d;
        }

        public int e() {
            return this.f76b;
        }

        public boolean f() {
            return this.f77c;
        }
    }

    public static final class d implements a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final c.f.g.a f79a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private final int f80b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private final int f81c;

        public d(c.f.g.a aVar, int i, int i2) {
            this.f79a = aVar;
            this.f81c = i;
            this.f80b = i2;
        }

        public int a() {
            return this.f81c;
        }

        public c.f.g.a b() {
            return this.f79a;
        }

        public int c() {
            return this.f80b;
        }
    }

    private static int a(TypedArray typedArray, int i) {
        if (Build.VERSION.SDK_INT >= 21) {
            return typedArray.getType(i);
        }
        TypedValue typedValue = new TypedValue();
        typedArray.getValue(i, typedValue);
        return typedValue.type;
    }

    public static a b(XmlPullParser xmlPullParser, Resources resources) throws XmlPullParserException, IOException {
        int next;
        do {
            next = xmlPullParser.next();
            if (next == 2) {
                break;
            }
        } while (next != 1);
        if (next == 2) {
            return d(xmlPullParser, resources);
        }
        throw new XmlPullParserException("No start tag found");
    }

    public static List<List<byte[]>> c(Resources resources, int i) {
        if (i == 0) {
            return Collections.emptyList();
        }
        TypedArray typedArrayObtainTypedArray = resources.obtainTypedArray(i);
        try {
            if (typedArrayObtainTypedArray.length() == 0) {
                return Collections.emptyList();
            }
            ArrayList arrayList = new ArrayList();
            if (a(typedArrayObtainTypedArray, 0) == 1) {
                for (int i2 = 0; i2 < typedArrayObtainTypedArray.length(); i2++) {
                    int resourceId = typedArrayObtainTypedArray.getResourceId(i2, 0);
                    if (resourceId != 0) {
                        arrayList.add(h(resources.getStringArray(resourceId)));
                    }
                }
            } else {
                arrayList.add(h(resources.getStringArray(i)));
            }
            return arrayList;
        } finally {
            typedArrayObtainTypedArray.recycle();
        }
    }

    private static a d(XmlPullParser xmlPullParser, Resources resources) throws XmlPullParserException, IOException {
        xmlPullParser.require(2, null, "font-family");
        if (xmlPullParser.getName().equals("font-family")) {
            return e(xmlPullParser, resources);
        }
        g(xmlPullParser);
        return null;
    }

    private static a e(XmlPullParser xmlPullParser, Resources resources) throws XmlPullParserException, IOException {
        TypedArray typedArrayObtainAttributes = resources.obtainAttributes(Xml.asAttributeSet(xmlPullParser), c.f.c.FontFamily);
        String string = typedArrayObtainAttributes.getString(c.f.c.FontFamily_fontProviderAuthority);
        String string2 = typedArrayObtainAttributes.getString(c.f.c.FontFamily_fontProviderPackage);
        String string3 = typedArrayObtainAttributes.getString(c.f.c.FontFamily_fontProviderQuery);
        int resourceId = typedArrayObtainAttributes.getResourceId(c.f.c.FontFamily_fontProviderCerts, 0);
        int integer = typedArrayObtainAttributes.getInteger(c.f.c.FontFamily_fontProviderFetchStrategy, 1);
        int integer2 = typedArrayObtainAttributes.getInteger(c.f.c.FontFamily_fontProviderFetchTimeout, 500);
        typedArrayObtainAttributes.recycle();
        if (string != null && string2 != null && string3 != null) {
            while (xmlPullParser.next() != 3) {
                g(xmlPullParser);
            }
            return new d(new c.f.g.a(string, string2, string3, c(resources, resourceId)), integer, integer2);
        }
        ArrayList arrayList = new ArrayList();
        while (xmlPullParser.next() != 3) {
            if (xmlPullParser.getEventType() == 2) {
                if (xmlPullParser.getName().equals("font")) {
                    arrayList.add(f(xmlPullParser, resources));
                } else {
                    g(xmlPullParser);
                }
            }
        }
        if (arrayList.isEmpty()) {
            return null;
        }
        return new b((C0008c[]) arrayList.toArray(new C0008c[arrayList.size()]));
    }

    private static C0008c f(XmlPullParser xmlPullParser, Resources resources) throws XmlPullParserException, IOException {
        TypedArray typedArrayObtainAttributes = resources.obtainAttributes(Xml.asAttributeSet(xmlPullParser), c.f.c.FontFamilyFont);
        int i = typedArrayObtainAttributes.getInt(typedArrayObtainAttributes.hasValue(c.f.c.FontFamilyFont_fontWeight) ? c.f.c.FontFamilyFont_fontWeight : c.f.c.FontFamilyFont_android_fontWeight, 400);
        boolean z = 1 == typedArrayObtainAttributes.getInt(typedArrayObtainAttributes.hasValue(c.f.c.FontFamilyFont_fontStyle) ? c.f.c.FontFamilyFont_fontStyle : c.f.c.FontFamilyFont_android_fontStyle, 0);
        int i2 = typedArrayObtainAttributes.hasValue(c.f.c.FontFamilyFont_ttcIndex) ? c.f.c.FontFamilyFont_ttcIndex : c.f.c.FontFamilyFont_android_ttcIndex;
        String string = typedArrayObtainAttributes.getString(typedArrayObtainAttributes.hasValue(c.f.c.FontFamilyFont_fontVariationSettings) ? c.f.c.FontFamilyFont_fontVariationSettings : c.f.c.FontFamilyFont_android_fontVariationSettings);
        int i3 = typedArrayObtainAttributes.getInt(i2, 0);
        int i4 = typedArrayObtainAttributes.hasValue(c.f.c.FontFamilyFont_font) ? c.f.c.FontFamilyFont_font : c.f.c.FontFamilyFont_android_font;
        int resourceId = typedArrayObtainAttributes.getResourceId(i4, 0);
        String string2 = typedArrayObtainAttributes.getString(i4);
        typedArrayObtainAttributes.recycle();
        while (xmlPullParser.next() != 3) {
            g(xmlPullParser);
        }
        return new C0008c(string2, i, z, string, i3, resourceId);
    }

    private static void g(XmlPullParser xmlPullParser) throws XmlPullParserException, IOException {
        int i = 1;
        while (i > 0) {
            int next = xmlPullParser.next();
            if (next == 2) {
                i++;
            } else if (next == 3) {
                i--;
            }
        }
    }

    private static List<byte[]> h(String[] strArr) {
        ArrayList arrayList = new ArrayList();
        for (String str : strArr) {
            arrayList.add(Base64.decode(str, 0));
        }
        return arrayList;
    }
}
