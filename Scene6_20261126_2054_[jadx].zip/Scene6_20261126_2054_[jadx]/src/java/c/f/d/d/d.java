package c.f.d.d;

import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.LinearGradient;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.util.AttributeSet;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
final class d {

    static final class a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final int[] f82a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final float[] f83b;

        a(int i, int i2) {
            this.f82a = new int[]{i, i2};
            this.f83b = new float[]{0.0f, 1.0f};
        }

        a(int i, int i2, int i3) {
            this.f82a = new int[]{i, i2, i3};
            this.f83b = new float[]{0.0f, 0.5f, 1.0f};
        }

        a(List<Integer> list, List<Float> list2) {
            int size = list.size();
            this.f82a = new int[size];
            this.f83b = new float[size];
            for (int i = 0; i < size; i++) {
                this.f82a[i] = list.get(i).intValue();
                this.f83b[i] = list2.get(i).floatValue();
            }
        }
    }

    /*  JADX ERROR: ConcurrentModificationException in pass: ConstructorVisitor
        java.util.ConcurrentModificationException
        	at java.util.ArrayList$Itr.checkForComodification(ArrayList.java:1112)
        	at java.util.ArrayList$Itr.next(ArrayList.java:1065)
        	at jadx.core.dex.visitors.ConstructorVisitor.insertPhiInsn(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:40)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:124)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:60)
        	at jadx.core.dex.visitors.ConstructorVisitor.visit(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:8)
        */
    private static c.f.d.d.d.a a(
    /*  JADX ERROR: ConcurrentModificationException in pass: ConstructorVisitor
        java.util.ConcurrentModificationException
        	at java.util.ArrayList$Itr.checkForComodification(ArrayList.java:1112)
        	at java.util.ArrayList$Itr.next(ArrayList.java:1065)
        	at jadx.core.dex.visitors.ConstructorVisitor.insertPhiInsn(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:40)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:124)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:60)
        */
    /*  JADX ERROR: Method generation error
        jadx.core.utils.exceptions.JadxRuntimeException: Code variable not set in r0v0 ??
        	at p61.o(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:3)
        	at jadx.core.dex.instructions.args.SSAVar.getCodeVar(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:16)
        	at jadx.core.codegen.MethodGen.addMethodArguments(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:77)
        	at jadx.core.codegen.MethodGen.addDefinition(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:335)
        	at jadx.core.codegen.ClassGen.addMethodCode(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:62)
        	at jadx.core.codegen.ClassGen.addMethod(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:23)
        	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$3(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:13)
        	at jadx.core.codegen.ClassGen.b(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:1)
        	at qx.accept(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:18)
        	at java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:186)
        	at java.util.stream.SortedOps$RefSortingSink$$ExternalSyntheticLambda0.accept(D8$$SyntheticClass:0)
        	at java.util.ArrayList.forEach(ArrayList.java:1621)
        	at java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
        	at java.util.stream.Sink$ChainedReference.end(Sink.java:263)
        	at java.util.stream.ReferencePipeline$7$1FlatMap.end(ReferencePipeline.java:301)
        	at java.util.stream.AbstractPipeline.copyInto(AbstractPipeline.java:575)
        	at java.util.stream.AbstractPipeline.wrapAndCopyInto(AbstractPipeline.java:564)
        	at java.util.stream.ForEachOps$ForEachOp.evaluateSequential(ForEachOps.java:153)
        	at java.util.stream.ForEachOps$ForEachOp.evaluateSequential(ForEachOps.java:135)
        	at java.util.stream.AbstractPipeline.evaluate(AbstractPipeline.java:267)
        	at java.util.stream.ReferencePipeline.forEach(ReferencePipeline.java:657)
        	at jadx.core.codegen.ClassGen.addInnerClsAndMethods(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:66)
        	at jadx.core.codegen.ClassGen.addClassBody(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:61)
        	at jadx.core.codegen.ClassGen.addClassBody(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:78)
        	at jadx.core.codegen.ClassGen.addClassCode(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:15)
        	at jadx.core.codegen.ClassGen.makeClass(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:26)
        	at py.call(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:155)
        	at jadx.core.codegen.CodeGen.wrapCodeGen(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:1)
        	at jadx.core.codegen.CodeGen.generateJavaCode(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:12)
        	at jadx.core.codegen.CodeGen.generate(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:50)
        	at jadx.core.ProcessClass.process(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:164)
        	at jadx.core.ProcessClass.generateCode(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:93)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:7)
        	at jadx.core.dex.nodes.ClassNode.decompile(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:38)
        	at jadx.core.dex.nodes.ClassNode.getCode(r8-map-id-aad343ec47fab9fa63afc8805acf596533df8b907855dbc73f6099ef88603c1a:2)
        */

    static Shader b(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) throws XmlPullParserException {
        String name = xmlPullParser.getName();
        if (!name.equals("gradient")) {
            throw new XmlPullParserException(xmlPullParser.getPositionDescription() + ": invalid gradient color tag " + name);
        }
        TypedArray typedArrayK = g.k(resources, theme, attributeSet, c.f.c.GradientColor);
        float f = g.f(typedArrayK, xmlPullParser, "startX", c.f.c.GradientColor_android_startX, 0.0f);
        float f2 = g.f(typedArrayK, xmlPullParser, "startY", c.f.c.GradientColor_android_startY, 0.0f);
        float f3 = g.f(typedArrayK, xmlPullParser, "endX", c.f.c.GradientColor_android_endX, 0.0f);
        float f4 = g.f(typedArrayK, xmlPullParser, "endY", c.f.c.GradientColor_android_endY, 0.0f);
        float f5 = g.f(typedArrayK, xmlPullParser, "centerX", c.f.c.GradientColor_android_centerX, 0.0f);
        float f6 = g.f(typedArrayK, xmlPullParser, "centerY", c.f.c.GradientColor_android_centerY, 0.0f);
        int iG = g.g(typedArrayK, xmlPullParser, "type", c.f.c.GradientColor_android_type, 0);
        int iB = g.b(typedArrayK, xmlPullParser, "startColor", c.f.c.GradientColor_android_startColor, 0);
        boolean zJ = g.j(xmlPullParser, "centerColor");
        int iB2 = g.b(typedArrayK, xmlPullParser, "centerColor", c.f.c.GradientColor_android_centerColor, 0);
        int iB3 = g.b(typedArrayK, xmlPullParser, "endColor", c.f.c.GradientColor_android_endColor, 0);
        int iG2 = g.g(typedArrayK, xmlPullParser, "tileMode", c.f.c.GradientColor_android_tileMode, 0);
        float f7 = g.f(typedArrayK, xmlPullParser, "gradientRadius", c.f.c.GradientColor_android_gradientRadius, 0.0f);
        typedArrayK.recycle();
        a aVarA = a(c(resources, xmlPullParser, attributeSet, theme), iB, iB3, zJ, iB2);
        if (iG != 1) {
            return iG != 2 ? new LinearGradient(f, f2, f3, f4, aVarA.f82a, aVarA.f83b, d(iG2)) : new SweepGradient(f5, f6, aVarA.f82a, aVarA.f83b);
        }
        if (f7 > 0.0f) {
            return new RadialGradient(f5, f6, f7, aVarA.f82a, aVarA.f83b, d(iG2));
        }
        throw new XmlPullParserException("<gradient> tag requires 'gradientRadius' attribute with radial type");
    }

    private static a c(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) throws XmlPullParserException, IOException {
        int depth;
        int depth2 = xmlPullParser.getDepth() + 1;
        ArrayList arrayList = new ArrayList(20);
        ArrayList arrayList2 = new ArrayList(20);
        while (true) {
            int next = xmlPullParser.next();
            if (next == 1 || ((depth = xmlPullParser.getDepth()) < depth2 && next == 3)) {
                break;
            }
            if (next == 2 && depth <= depth2 && xmlPullParser.getName().equals("item")) {
                TypedArray typedArrayK = g.k(resources, theme, attributeSet, c.f.c.GradientColorItem);
                boolean zHasValue = typedArrayK.hasValue(c.f.c.GradientColorItem_android_color);
                boolean zHasValue2 = typedArrayK.hasValue(c.f.c.GradientColorItem_android_offset);
                if (!zHasValue || !zHasValue2) {
                    throw new XmlPullParserException(xmlPullParser.getPositionDescription() + ": <item> tag requires a 'color' attribute and a 'offset' attribute!");
                }
                int color = typedArrayK.getColor(c.f.c.GradientColorItem_android_color, 0);
                float f = typedArrayK.getFloat(c.f.c.GradientColorItem_android_offset, 0.0f);
                typedArrayK.recycle();
                arrayList2.add(Integer.valueOf(color));
                arrayList.add(Float.valueOf(f));
            }
        }
        if (arrayList2.size() > 0) {
            return new a(arrayList2, arrayList);
        }
        return null;
    }

    private static Shader.TileMode d(int i) {
        if (i != 1) {
            return i != 2 ? Shader.TileMode.CLAMP : Shader.TileMode.MIRROR;
        }
        return Shader.TileMode.REPEAT;
    }
}
