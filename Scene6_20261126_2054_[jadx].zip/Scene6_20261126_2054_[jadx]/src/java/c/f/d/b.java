package c.f.d;

import android.content.LocusId;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class b {
    public abstract LocusId a();
}
