package c.f.h;

import java.util.Locale;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final c.f.h.d f136a = new C0015e(null, false);

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final c.f.h.d f137b = new C0015e(null, true);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final c.f.h.d f138c = new C0015e(b.f142a, false);

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final c.f.h.d f139d = new C0015e(b.f142a, true);

    private static class a implements c {

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        static final a f140b = new a(true);

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final boolean f141a;

        private a(boolean z) {
            this.f141a = z;
        }

        @Override // c.f.h.e.c
        public int a(CharSequence charSequence, int i, int i2) {
            int i3 = i2 + i;
            boolean z = false;
            while (i < i3) {
                int iA = e.a(Character.getDirectionality(charSequence.charAt(i)));
                if (iA != 0) {
                    if (iA != 1) {
                        continue;
                    } else if (!this.f141a) {
                        return 1;
                    }
                    i++;
                    z = z;
                } else if (this.f141a) {
                    return 0;
                }
                z = true;
                i++;
                z = z;
            }
            if (z) {
                return this.f141a ? 1 : 0;
            }
            return 2;
        }
    }

    private static class b implements c {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        static final b f142a = new b();

        private b() {
        }

        @Override // c.f.h.e.c
        public int a(CharSequence charSequence, int i, int i2) {
            int i3 = i2 + i;
            int iB = 2;
            while (i < i3 && iB == 2) {
                iB = e.b(Character.getDirectionality(charSequence.charAt(i)));
                i++;
            }
            return iB;
        }
    }

    private interface c {
        int a(CharSequence charSequence, int i, int i2);
    }

    private static abstract class d implements c.f.h.d {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final c f143a;

        d(c cVar) {
            this.f143a = cVar;
        }

        private boolean c(CharSequence charSequence, int i, int i2) {
            int iA = this.f143a.a(charSequence, i, i2);
            if (iA == 0) {
                return true;
            }
            if (iA != 1) {
                return b();
            }
            return false;
        }

        @Override // c.f.h.d
        public boolean a(CharSequence charSequence, int i, int i2) {
            if (charSequence == null || i < 0 || i2 < 0 || charSequence.length() - i2 < i) {
                throw new IllegalArgumentException();
            }
            return this.f143a == null ? b() : c(charSequence, i, i2);
        }

        protected abstract boolean b();
    }

    /* JADX INFO: renamed from: c.f.h.e$e, reason: collision with other inner class name */
    private static class C0015e extends d {

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private final boolean f144b;

        C0015e(c cVar, boolean z) {
            super(cVar);
            this.f144b = z;
        }

        @Override // c.f.h.e.d
        protected boolean b() {
            return this.f144b;
        }
    }

    private static class f extends d {

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        static final f f145b = new f();

        f() {
            super(null);
        }

        @Override // c.f.h.e.d
        protected boolean b() {
            return c.f.h.f.b(Locale.getDefault()) == 1;
        }
    }

    static {
        a aVar = a.f140b;
        f fVar = f.f145b;
    }

    static int a(int i) {
        if (i != 0) {
            return (i == 1 || i == 2) ? 0 : 2;
        }
        return 1;
    }

    static int b(int i) {
        if (i != 0) {
            if (i == 1 || i == 2) {
                return 0;
            }
            switch (i) {
                case 14:
                case 15:
                    break;
                case 16:
                case 17:
                    return 0;
                default:
                    return 2;
            }
        }
        return 1;
    }
}
