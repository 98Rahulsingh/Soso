package c.f.h;

import android.text.SpannableStringBuilder;
import java.util.Locale;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class a {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    static final d f115d = e.f138c;
    private static final String e = Character.toString(8206);
    private static final String f = Character.toString(8207);
    static final a g = new a(false, 2, f115d);
    static final a h = new a(true, 2, f115d);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final boolean f116a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final int f117b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final d f118c;

    /* JADX INFO: renamed from: c.f.h.a$a, reason: collision with other inner class name */
    public static final class C0013a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private boolean f119a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private int f120b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private d f121c;

        public C0013a() {
            c(a.e(Locale.getDefault()));
        }

        private static a b(boolean z) {
            return z ? a.h : a.g;
        }

        private void c(boolean z) {
            this.f119a = z;
            this.f121c = a.f115d;
            this.f120b = 2;
        }

        public a a() {
            return (this.f120b == 2 && this.f121c == a.f115d) ? b(this.f119a) : new a(this.f119a, this.f120b, this.f121c);
        }
    }

    private static class b {
        private static final byte[] f = new byte[1792];

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final CharSequence f122a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private final boolean f123b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private final int f124c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        private int f125d;
        private char e;

        static {
            for (int i = 0; i < 1792; i++) {
                f[i] = Character.getDirectionality(i);
            }
        }

        b(CharSequence charSequence, boolean z) {
            this.f122a = charSequence;
            this.f123b = z;
            this.f124c = charSequence.length();
        }

        private static byte c(char c2) {
            return c2 < 1792 ? f[c2] : Character.getDirectionality(c2);
        }

        private byte f() {
            char cCharAt;
            int i = this.f125d;
            do {
                int i2 = this.f125d;
                if (i2 <= 0) {
                    break;
                }
                CharSequence charSequence = this.f122a;
                int i3 = i2 - 1;
                this.f125d = i3;
                cCharAt = charSequence.charAt(i3);
                this.e = cCharAt;
                if (cCharAt == '&') {
                    return (byte) 12;
                }
            } while (cCharAt != ';');
            this.f125d = i;
            this.e = ';';
            return (byte) 13;
        }

        private byte g() {
            char cCharAt;
            do {
                int i = this.f125d;
                if (i >= this.f124c) {
                    return (byte) 12;
                }
                CharSequence charSequence = this.f122a;
                this.f125d = i + 1;
                cCharAt = charSequence.charAt(i);
                this.e = cCharAt;
            } while (cCharAt != ';');
            return (byte) 12;
        }

        private byte h() {
            char cCharAt;
            int i = this.f125d;
            while (true) {
                int i2 = this.f125d;
                if (i2 <= 0) {
                    break;
                }
                CharSequence charSequence = this.f122a;
                int i3 = i2 - 1;
                this.f125d = i3;
                char cCharAt2 = charSequence.charAt(i3);
                this.e = cCharAt2;
                if (cCharAt2 == '<') {
                    return (byte) 12;
                }
                if (cCharAt2 == '>') {
                    break;
                }
                if (cCharAt2 == '\"' || cCharAt2 == '\'') {
                    char c2 = this.e;
                    do {
                        int i4 = this.f125d;
                        if (i4 <= 0) {
                            break;
                        }
                        CharSequence charSequence2 = this.f122a;
                        int i5 = i4 - 1;
                        this.f125d = i5;
                        cCharAt = charSequence2.charAt(i5);
                        this.e = cCharAt;
                    } while (cCharAt != c2);
                }
            }
            this.f125d = i;
            this.e = '>';
            return (byte) 13;
        }

        private byte i() {
            char cCharAt;
            int i = this.f125d;
            while (true) {
                int i2 = this.f125d;
                if (i2 >= this.f124c) {
                    this.f125d = i;
                    this.e = '<';
                    return (byte) 13;
                }
                CharSequence charSequence = this.f122a;
                this.f125d = i2 + 1;
                char cCharAt2 = charSequence.charAt(i2);
                this.e = cCharAt2;
                if (cCharAt2 == '>') {
                    return (byte) 12;
                }
                if (cCharAt2 == '\"' || cCharAt2 == '\'') {
                    char c2 = this.e;
                    do {
                        int i3 = this.f125d;
                        if (i3 >= this.f124c) {
                            break;
                        }
                        CharSequence charSequence2 = this.f122a;
                        this.f125d = i3 + 1;
                        cCharAt = charSequence2.charAt(i3);
                        this.e = cCharAt;
                    } while (cCharAt != c2);
                }
            }
        }

        byte a() {
            char cCharAt = this.f122a.charAt(this.f125d - 1);
            this.e = cCharAt;
            if (Character.isLowSurrogate(cCharAt)) {
                int iCodePointBefore = Character.codePointBefore(this.f122a, this.f125d);
                this.f125d -= Character.charCount(iCodePointBefore);
                return Character.getDirectionality(iCodePointBefore);
            }
            this.f125d--;
            byte bC = c(this.e);
            if (!this.f123b) {
                return bC;
            }
            char c2 = this.e;
            if (c2 == '>') {
                return h();
            }
            return c2 == ';' ? f() : bC;
        }

        byte b() {
            char cCharAt = this.f122a.charAt(this.f125d);
            this.e = cCharAt;
            if (Character.isHighSurrogate(cCharAt)) {
                int iCodePointAt = Character.codePointAt(this.f122a, this.f125d);
                this.f125d += Character.charCount(iCodePointAt);
                return Character.getDirectionality(iCodePointAt);
            }
            this.f125d++;
            byte bC = c(this.e);
            if (!this.f123b) {
                return bC;
            }
            char c2 = this.e;
            if (c2 == '<') {
                return i();
            }
            return c2 == '&' ? g() : bC;
        }

        int d() {
            this.f125d = 0;
            int i = 0;
            int i2 = 0;
            int i3 = 0;
            while (this.f125d < this.f124c && i == 0) {
                byte b2 = b();
                if (b2 != 0) {
                    if (b2 == 1 || b2 == 2) {
                        if (i3 == 0) {
                            return 1;
                        }
                    } else if (b2 != 9) {
                        switch (b2) {
                            case 14:
                            case 15:
                                i3++;
                                i2 = -1;
                                continue;
                            case 16:
                            case 17:
                                i3++;
                                i2 = 1;
                                continue;
                            case 18:
                                i3--;
                                i2 = 0;
                                continue;
                        }
                    }
                } else if (i3 == 0) {
                    return -1;
                }
                i = i3;
            }
            if (i == 0) {
                return 0;
            }
            if (i2 != 0) {
                return i2;
            }
            while (this.f125d > 0) {
                switch (a()) {
                    case 14:
                    case 15:
                        if (i == i3) {
                            return -1;
                        }
                        break;
                    case 16:
                    case 17:
                        if (i == i3) {
                            return 1;
                        }
                        break;
                    case 18:
                        i3++;
                        continue;
                    default:
                        continue;
                }
                i3--;
            }
            return 0;
        }

        int e() {
            this.f125d = this.f124c;
            int i = 0;
            while (true) {
                int i2 = i;
                while (this.f125d > 0) {
                    byte bA = a();
                    if (bA == 0) {
                        if (i == 0) {
                            return -1;
                        }
                        if (i2 == 0) {
                        }
                    } else if (bA == 1 || bA == 2) {
                        if (i == 0) {
                            return 1;
                        }
                        if (i2 == 0) {
                        }
                    } else if (bA != 9) {
                        switch (bA) {
                            case 14:
                            case 15:
                                if (i2 == i) {
                                    return -1;
                                }
                                i--;
                                break;
                            case 16:
                            case 17:
                                if (i2 == i) {
                                    return 1;
                                }
                                i--;
                                break;
                            case 18:
                                i++;
                                break;
                            default:
                                if (i2 != 0) {
                                }
                                break;
                        }
                    } else {
                        continue;
                    }
                }
                return 0;
            }
        }
    }

    a(boolean z, int i, d dVar) {
        this.f116a = z;
        this.f117b = i;
        this.f118c = dVar;
    }

    private static int a(CharSequence charSequence) {
        return new b(charSequence, false).d();
    }

    private static int b(CharSequence charSequence) {
        return new b(charSequence, false).e();
    }

    public static a c() {
        return new C0013a().a();
    }

    static boolean e(Locale locale) {
        return f.b(locale) == 1;
    }

    private String f(CharSequence charSequence, d dVar) {
        boolean zA = dVar.a(charSequence, 0, charSequence.length());
        if (!this.f116a && (zA || b(charSequence) == 1)) {
            return e;
        }
        if (this.f116a) {
            return (!zA || b(charSequence) == -1) ? f : "";
        }
        return "";
    }

    private String g(CharSequence charSequence, d dVar) {
        boolean zA = dVar.a(charSequence, 0, charSequence.length());
        if (!this.f116a && (zA || a(charSequence) == 1)) {
            return e;
        }
        if (this.f116a) {
            return (!zA || a(charSequence) == -1) ? f : "";
        }
        return "";
    }

    public boolean d() {
        return (this.f117b & 2) != 0;
    }

    public CharSequence h(CharSequence charSequence) {
        return i(charSequence, this.f118c, true);
    }

    public CharSequence i(CharSequence charSequence, d dVar, boolean z) {
        if (charSequence == null) {
            return null;
        }
        boolean zA = dVar.a(charSequence, 0, charSequence.length());
        SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder();
        if (d() && z) {
            spannableStringBuilder.append((CharSequence) g(charSequence, zA ? e.f137b : e.f136a));
        }
        if (zA != this.f116a) {
            spannableStringBuilder.append(zA ? (char) 8235 : (char) 8234);
            spannableStringBuilder.append(charSequence);
            spannableStringBuilder.append((char) 8236);
        } else {
            spannableStringBuilder.append(charSequence);
        }
        if (z) {
            spannableStringBuilder.append((CharSequence) f(charSequence, zA ? e.f137b : e.f136a));
        }
        return spannableStringBuilder;
    }

    public String j(String str) {
        return k(str, this.f118c, true);
    }

    public String k(String str, d dVar, boolean z) {
        if (str == null) {
            return null;
        }
        return i(str, dVar, z).toString();
    }
}
