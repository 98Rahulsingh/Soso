package c.f.h;

import android.annotation.SuppressLint;
import android.os.Build;
import android.text.PrecomputedText;
import android.text.Spannable;
import android.text.TextDirectionHeuristic;
import android.text.TextDirectionHeuristics;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.style.MetricAffectingSpan;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class c implements Spannable {
    private final Spannable f;
    private final a g;
    private final PrecomputedText h;

    public static final class a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final TextPaint f128a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private final TextDirectionHeuristic f129b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private final int f130c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        private final int f131d;

        /* JADX INFO: renamed from: c.f.h.c$a$a, reason: collision with other inner class name */
        public static class C0014a {

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            private final TextPaint f132a;

            /* JADX INFO: renamed from: b, reason: collision with root package name */
            private TextDirectionHeuristic f133b;

            /* JADX INFO: renamed from: c, reason: collision with root package name */
            private int f134c;

            /* JADX INFO: renamed from: d, reason: collision with root package name */
            private int f135d;

            public C0014a(TextPaint textPaint) {
                this.f132a = textPaint;
                if (Build.VERSION.SDK_INT >= 23) {
                    this.f134c = 1;
                    this.f135d = 1;
                } else {
                    this.f135d = 0;
                    this.f134c = 0;
                }
                this.f133b = Build.VERSION.SDK_INT >= 18 ? TextDirectionHeuristics.FIRSTSTRONG_LTR : null;
            }

            public a a() {
                return new a(this.f132a, this.f133b, this.f134c, this.f135d);
            }

            public C0014a b(int i) {
                this.f134c = i;
                return this;
            }

            public C0014a c(int i) {
                this.f135d = i;
                return this;
            }

            public C0014a d(TextDirectionHeuristic textDirectionHeuristic) {
                this.f133b = textDirectionHeuristic;
                return this;
            }
        }

        public a(PrecomputedText.Params params) {
            this.f128a = params.getTextPaint();
            this.f129b = params.getTextDirection();
            this.f130c = params.getBreakStrategy();
            this.f131d = params.getHyphenationFrequency();
            int i = Build.VERSION.SDK_INT;
        }

        @SuppressLint({"NewApi"})
        a(TextPaint textPaint, TextDirectionHeuristic textDirectionHeuristic, int i, int i2) {
            if (Build.VERSION.SDK_INT >= 29) {
                new PrecomputedText.Params.Builder(textPaint).setBreakStrategy(i).setHyphenationFrequency(i2).setTextDirection(textDirectionHeuristic).build();
            }
            this.f128a = textPaint;
            this.f129b = textDirectionHeuristic;
            this.f130c = i;
            this.f131d = i2;
        }

        public boolean a(a aVar) {
            if ((Build.VERSION.SDK_INT >= 23 && (this.f130c != aVar.b() || this.f131d != aVar.c())) || this.f128a.getTextSize() != aVar.e().getTextSize() || this.f128a.getTextScaleX() != aVar.e().getTextScaleX() || this.f128a.getTextSkewX() != aVar.e().getTextSkewX()) {
                return false;
            }
            if ((Build.VERSION.SDK_INT >= 21 && (this.f128a.getLetterSpacing() != aVar.e().getLetterSpacing() || !TextUtils.equals(this.f128a.getFontFeatureSettings(), aVar.e().getFontFeatureSettings()))) || this.f128a.getFlags() != aVar.e().getFlags()) {
                return false;
            }
            int i = Build.VERSION.SDK_INT;
            if (i >= 24) {
                if (!this.f128a.getTextLocales().equals(aVar.e().getTextLocales())) {
                    return false;
                }
            } else if (i >= 17 && !this.f128a.getTextLocale().equals(aVar.e().getTextLocale())) {
                return false;
            }
            if (this.f128a.getTypeface() == null) {
                return aVar.e().getTypeface() == null;
            }
            return this.f128a.getTypeface().equals(aVar.e().getTypeface());
        }

        public int b() {
            return this.f130c;
        }

        public int c() {
            return this.f131d;
        }

        public TextDirectionHeuristic d() {
            return this.f129b;
        }

        public TextPaint e() {
            return this.f128a;
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof a)) {
                return false;
            }
            a aVar = (a) obj;
            if (a(aVar)) {
                return Build.VERSION.SDK_INT < 18 || this.f129b == aVar.d();
            }
            return false;
        }

        public int hashCode() {
            int i = Build.VERSION.SDK_INT;
            if (i >= 24) {
                return c.f.i.c.b(Float.valueOf(this.f128a.getTextSize()), Float.valueOf(this.f128a.getTextScaleX()), Float.valueOf(this.f128a.getTextSkewX()), Float.valueOf(this.f128a.getLetterSpacing()), Integer.valueOf(this.f128a.getFlags()), this.f128a.getTextLocales(), this.f128a.getTypeface(), Boolean.valueOf(this.f128a.isElegantTextHeight()), this.f129b, Integer.valueOf(this.f130c), Integer.valueOf(this.f131d));
            }
            if (i >= 21) {
                return c.f.i.c.b(Float.valueOf(this.f128a.getTextSize()), Float.valueOf(this.f128a.getTextScaleX()), Float.valueOf(this.f128a.getTextSkewX()), Float.valueOf(this.f128a.getLetterSpacing()), Integer.valueOf(this.f128a.getFlags()), this.f128a.getTextLocale(), this.f128a.getTypeface(), Boolean.valueOf(this.f128a.isElegantTextHeight()), this.f129b, Integer.valueOf(this.f130c), Integer.valueOf(this.f131d));
            }
            if (i < 18 && i < 17) {
                return c.f.i.c.b(Float.valueOf(this.f128a.getTextSize()), Float.valueOf(this.f128a.getTextScaleX()), Float.valueOf(this.f128a.getTextSkewX()), Integer.valueOf(this.f128a.getFlags()), this.f128a.getTypeface(), this.f129b, Integer.valueOf(this.f130c), Integer.valueOf(this.f131d));
            }
            return c.f.i.c.b(Float.valueOf(this.f128a.getTextSize()), Float.valueOf(this.f128a.getTextScaleX()), Float.valueOf(this.f128a.getTextSkewX()), Integer.valueOf(this.f128a.getFlags()), this.f128a.getTextLocale(), this.f128a.getTypeface(), this.f129b, Integer.valueOf(this.f130c), Integer.valueOf(this.f131d));
        }

        /* JADX WARN: Code duplicated, block: B:14:0x00e3  */
        /* JADX WARN: Instruction removed from duplicated block: B:14:0x00e3, please report this as an issue */
        public String toString() {
            StringBuilder sb;
            Object textLocale;
            StringBuilder sb2 = new StringBuilder("{");
            sb2.append("textSize=" + this.f128a.getTextSize());
            sb2.append(", textScaleX=" + this.f128a.getTextScaleX());
            sb2.append(", textSkewX=" + this.f128a.getTextSkewX());
            if (Build.VERSION.SDK_INT >= 21) {
                sb2.append(", letterSpacing=" + this.f128a.getLetterSpacing());
                sb2.append(", elegantTextHeight=" + this.f128a.isElegantTextHeight());
            }
            int i = Build.VERSION.SDK_INT;
            if (i < 24) {
                if (i >= 17) {
                    sb = new StringBuilder();
                    sb.append(", textLocale=");
                    textLocale = this.f128a.getTextLocale();
                }
                sb2.append(", typeface=" + this.f128a.getTypeface());
                if (Build.VERSION.SDK_INT >= 26) {
                    sb2.append(", variationSettings=" + this.f128a.getFontVariationSettings());
                }
                sb2.append(", textDir=" + this.f129b);
                sb2.append(", breakStrategy=" + this.f130c);
                sb2.append(", hyphenationFrequency=" + this.f131d);
                sb2.append("}");
                return sb2.toString();
            }
            sb = new StringBuilder();
            sb.append(", textLocale=");
            textLocale = this.f128a.getTextLocales();
            sb.append(textLocale);
            sb2.append(sb.toString());
            sb2.append(", typeface=" + this.f128a.getTypeface());
            if (Build.VERSION.SDK_INT >= 26) {
                sb2.append(", variationSettings=" + this.f128a.getFontVariationSettings());
            }
            sb2.append(", textDir=" + this.f129b);
            sb2.append(", breakStrategy=" + this.f130c);
            sb2.append(", hyphenationFrequency=" + this.f131d);
            sb2.append("}");
            return sb2.toString();
        }
    }

    public a a() {
        return this.g;
    }

    public PrecomputedText b() {
        Spannable spannable = this.f;
        if (spannable instanceof PrecomputedText) {
            return (PrecomputedText) spannable;
        }
        return null;
    }

    @Override // java.lang.CharSequence
    public char charAt(int i) {
        return this.f.charAt(i);
    }

    @Override // android.text.Spanned
    public int getSpanEnd(Object obj) {
        return this.f.getSpanEnd(obj);
    }

    @Override // android.text.Spanned
    public int getSpanFlags(Object obj) {
        return this.f.getSpanFlags(obj);
    }

    @Override // android.text.Spanned
    public int getSpanStart(Object obj) {
        return this.f.getSpanStart(obj);
    }

    @Override // android.text.Spanned
    @SuppressLint({"NewApi"})
    public <T> T[] getSpans(int i, int i2, Class<T> cls) {
        return Build.VERSION.SDK_INT >= 29 ? (T[]) this.h.getSpans(i, i2, cls) : (T[]) this.f.getSpans(i, i2, cls);
    }

    @Override // java.lang.CharSequence
    public int length() {
        return this.f.length();
    }

    @Override // android.text.Spanned
    public int nextSpanTransition(int i, int i2, Class cls) {
        return this.f.nextSpanTransition(i, i2, cls);
    }

    @Override // android.text.Spannable
    @SuppressLint({"NewApi"})
    public void removeSpan(Object obj) {
        if (obj instanceof MetricAffectingSpan) {
            throw new IllegalArgumentException("MetricAffectingSpan can not be removed from PrecomputedText.");
        }
        if (Build.VERSION.SDK_INT >= 29) {
            this.h.removeSpan(obj);
        } else {
            this.f.removeSpan(obj);
        }
    }

    @Override // android.text.Spannable
    @SuppressLint({"NewApi"})
    public void setSpan(Object obj, int i, int i2, int i3) {
        if (obj instanceof MetricAffectingSpan) {
            throw new IllegalArgumentException("MetricAffectingSpan can not be set to PrecomputedText.");
        }
        if (Build.VERSION.SDK_INT >= 29) {
            this.h.setSpan(obj, i, i2, i3);
        } else {
            this.f.setSpan(obj, i, i2, i3);
        }
    }

    @Override // java.lang.CharSequence
    public CharSequence subSequence(int i, int i2) {
        return this.f.subSequence(i, i2);
    }

    @Override // java.lang.CharSequence
    public String toString() {
        return this.f.toString();
    }
}
