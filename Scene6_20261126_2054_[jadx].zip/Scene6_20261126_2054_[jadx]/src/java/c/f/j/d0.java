package c.f.j;

import android.annotation.SuppressLint;
import android.graphics.Rect;
import android.os.Build;
import android.util.Log;
import android.view.View;
import android.view.WindowInsets;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Objects;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class d0 {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final d0 f165b;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final k f166a;

    public static final class a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final e f167a;

        public a() {
            int i = Build.VERSION.SDK_INT;
            this.f167a = i >= 30 ? new d() : i >= 29 ? new c() : i >= 20 ? new b() : new e();
        }

        public a(d0 d0Var) {
            int i = Build.VERSION.SDK_INT;
            this.f167a = i >= 30 ? new d(d0Var) : i >= 29 ? new c(d0Var) : i >= 20 ? new b(d0Var) : new e(d0Var);
        }

        public d0 a() {
            return this.f167a.b();
        }

        @Deprecated
        public a b(androidx.core.graphics.b bVar) {
            this.f167a.d(bVar);
            return this;
        }

        @Deprecated
        public a c(androidx.core.graphics.b bVar) {
            this.f167a.f(bVar);
            return this;
        }
    }

    private static class b extends e {

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        private static Field f168d;
        private static boolean e;
        private static Constructor<WindowInsets> f;
        private static boolean g;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private WindowInsets f169c;

        b() {
            this.f169c = h();
        }

        b(d0 d0Var) {
            this.f169c = d0Var.p();
        }

        private static WindowInsets h() {
            if (!e) {
                try {
                    f168d = WindowInsets.class.getDeclaredField("CONSUMED");
                } catch (ReflectiveOperationException e2) {
                    Log.i("WindowInsetsCompat", "Could not retrieve WindowInsets.CONSUMED field", e2);
                }
                e = true;
            }
            Field field = f168d;
            if (field != null) {
                try {
                    WindowInsets windowInsets = (WindowInsets) field.get(null);
                    if (windowInsets != null) {
                        return new WindowInsets(windowInsets);
                    }
                } catch (ReflectiveOperationException e3) {
                    Log.i("WindowInsetsCompat", "Could not get value from WindowInsets.CONSUMED field", e3);
                }
            }
            if (!g) {
                try {
                    f = WindowInsets.class.getConstructor(Rect.class);
                } catch (ReflectiveOperationException e4) {
                    Log.i("WindowInsetsCompat", "Could not retrieve WindowInsets(Rect) constructor", e4);
                }
                g = true;
            }
            Constructor<WindowInsets> constructor = f;
            if (constructor != null) {
                try {
                    return constructor.newInstance(new Rect());
                } catch (ReflectiveOperationException e5) {
                    Log.i("WindowInsetsCompat", "Could not invoke WindowInsets(Rect) constructor", e5);
                }
            }
            return null;
        }

        @Override // c.f.j.d0.e
        d0 b() {
            a();
            return d0.q(this.f169c);
        }

        @Override // c.f.j.d0.e
        void f(androidx.core.graphics.b bVar) {
            WindowInsets windowInsets = this.f169c;
            if (windowInsets != null) {
                this.f169c = windowInsets.replaceSystemWindowInsets(bVar.a, bVar.b, bVar.c, bVar.d);
            }
        }
    }

    private static class c extends e {

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        final WindowInsets.Builder f170c;

        c() {
            this.f170c = new WindowInsets.Builder();
        }

        c(d0 d0Var) {
            WindowInsets windowInsetsP = d0Var.p();
            this.f170c = windowInsetsP != null ? new WindowInsets.Builder(windowInsetsP) : new WindowInsets.Builder();
        }

        @Override // c.f.j.d0.e
        d0 b() {
            a();
            return d0.q(this.f170c.build());
        }

        @Override // c.f.j.d0.e
        void c(androidx.core.graphics.b bVar) {
            this.f170c.setMandatorySystemGestureInsets(bVar.e());
        }

        @Override // c.f.j.d0.e
        void d(androidx.core.graphics.b bVar) {
            this.f170c.setStableInsets(bVar.e());
        }

        @Override // c.f.j.d0.e
        void e(androidx.core.graphics.b bVar) {
            this.f170c.setSystemGestureInsets(bVar.e());
        }

        @Override // c.f.j.d0.e
        void f(androidx.core.graphics.b bVar) {
            this.f170c.setSystemWindowInsets(bVar.e());
        }

        @Override // c.f.j.d0.e
        void g(androidx.core.graphics.b bVar) {
            this.f170c.setTappableElementInsets(bVar.e());
        }
    }

    private static class d extends c {
        d() {
        }

        d(d0 d0Var) {
            super(d0Var);
        }
    }

    private static class e {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final d0 f171a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private androidx.core.graphics.b[] f172b;

        e() {
            this(new d0((d0) null));
        }

        e(d0 d0Var) {
            this.f171a = d0Var;
        }

        /* JADX WARN: Code duplicated, block: B:14:0x0034  */
        /* JADX WARN: Code duplicated, block: B:17:0x0043  */
        /* JADX WARN: Code duplicated, block: B:20:0x0052  */
        /* JADX WARN: Code duplicated, block: B:23:? A[RETURN, SYNTHETIC] */
        protected final void a() {
            androidx.core.graphics.b bVar;
            androidx.core.graphics.b bVar2;
            androidx.core.graphics.b bVar3;
            androidx.core.graphics.b[] bVarArr = this.f172b;
            if (bVarArr != null) {
                androidx.core.graphics.b bVarA = bVarArr[l.a(1)];
                androidx.core.graphics.b bVar4 = this.f172b[l.a(2)];
                if (bVarA == null || bVar4 == null) {
                    if (bVarA == null) {
                        if (bVar4 != null) {
                            f(bVar4);
                        }
                    }
                    bVar = this.f172b[l.a(16)];
                    if (bVar != null) {
                        e(bVar);
                    }
                    bVar2 = this.f172b[l.a(32)];
                    if (bVar2 != null) {
                        c(bVar2);
                    }
                    bVar3 = this.f172b[l.a(64)];
                    if (bVar3 != null) {
                        g(bVar3);
                    }
                }
                bVarA = androidx.core.graphics.b.a(bVarA, bVar4);
                f(bVarA);
                bVar = this.f172b[l.a(16)];
                if (bVar != null) {
                    e(bVar);
                }
                bVar2 = this.f172b[l.a(32)];
                if (bVar2 != null) {
                    c(bVar2);
                }
                bVar3 = this.f172b[l.a(64)];
                if (bVar3 != null) {
                    g(bVar3);
                }
            }
        }

        d0 b() {
            a();
            return this.f171a;
        }

        void c(androidx.core.graphics.b bVar) {
        }

        void d(androidx.core.graphics.b bVar) {
        }

        void e(androidx.core.graphics.b bVar) {
        }

        void f(androidx.core.graphics.b bVar) {
        }

        void g(androidx.core.graphics.b bVar) {
        }
    }

    private static class f extends k {
        private static boolean g;
        private static Method h;
        private static Class<?> i;
        private static Class<?> j;
        private static Field k;
        private static Field l;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        final WindowInsets f173c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        private androidx.core.graphics.b f174d;
        private d0 e;
        private androidx.core.graphics.b f;

        f(d0 d0Var, WindowInsets windowInsets) {
            super(d0Var);
            this.f174d = null;
            this.f173c = windowInsets;
        }

        f(d0 d0Var, f fVar) {
            this(d0Var, new WindowInsets(fVar.f173c));
        }

        private androidx.core.graphics.b o(View view) {
            if (Build.VERSION.SDK_INT >= 30) {
                throw new UnsupportedOperationException("getVisibleInsets() should not be called on API >= 30. Use WindowInsets.isVisible() instead.");
            }
            if (!g) {
                p();
            }
            Method method = h;
            if (method != null && j != null && k != null) {
                try {
                    Object objInvoke = method.invoke(view, new Object[0]);
                    if (objInvoke == null) {
                        Log.w("WindowInsetsCompat", "Failed to get visible insets. getViewRootImpl() returned null from the provided view. This means that the view is either not attached or the method has been overridden", new NullPointerException());
                        return null;
                    }
                    Rect rect = (Rect) k.get(l.get(objInvoke));
                    if (rect != null) {
                        return androidx.core.graphics.b.c(rect);
                    }
                    return null;
                } catch (IllegalAccessException | InvocationTargetException e) {
                    q(e);
                }
            }
            return null;
        }

        @SuppressLint({"PrivateApi"})
        private static void p() {
            try {
                h = View.class.getDeclaredMethod("getViewRootImpl", new Class[0]);
                i = Class.forName("android.view.ViewRootImpl");
                Class<?> cls = Class.forName("android.view.View$AttachInfo");
                j = cls;
                k = cls.getDeclaredField("mVisibleInsets");
                l = i.getDeclaredField("mAttachInfo");
                k.setAccessible(true);
                l.setAccessible(true);
            } catch (ClassNotFoundException | NoSuchFieldException | NoSuchMethodException e) {
                q(e);
            }
            g = true;
        }

        private static void q(Exception exc) {
            Log.e("WindowInsetsCompat", "Failed to get visible insets. (Reflection error). " + exc.getMessage(), exc);
        }

        @Override // c.f.j.d0.k
        void d(View view) {
            androidx.core.graphics.b bVarO = o(view);
            if (bVarO == null) {
                bVarO = androidx.core.graphics.b.e;
            }
            m(bVarO);
        }

        @Override // c.f.j.d0.k
        void e(d0 d0Var) {
            d0Var.o(this.e);
            d0Var.n(this.f);
        }

        @Override // c.f.j.d0.k
        final androidx.core.graphics.b i() {
            if (this.f174d == null) {
                this.f174d = androidx.core.graphics.b.b(this.f173c.getSystemWindowInsetLeft(), this.f173c.getSystemWindowInsetTop(), this.f173c.getSystemWindowInsetRight(), this.f173c.getSystemWindowInsetBottom());
            }
            return this.f174d;
        }

        @Override // c.f.j.d0.k
        d0 j(int i2, int i3, int i4, int i5) {
            a aVar = new a(d0.q(this.f173c));
            aVar.c(d0.k(i(), i2, i3, i4, i5));
            aVar.b(d0.k(h(), i2, i3, i4, i5));
            return aVar.a();
        }

        @Override // c.f.j.d0.k
        boolean l() {
            return this.f173c.isRound();
        }

        @Override // c.f.j.d0.k
        void m(androidx.core.graphics.b bVar) {
            this.f = bVar;
        }

        @Override // c.f.j.d0.k
        void n(d0 d0Var) {
            this.e = d0Var;
        }
    }

    private static class g extends f {
        private androidx.core.graphics.b m;

        g(d0 d0Var, WindowInsets windowInsets) {
            super(d0Var, windowInsets);
            this.m = null;
        }

        g(d0 d0Var, g gVar) {
            super(d0Var, gVar);
            this.m = null;
        }

        @Override // c.f.j.d0.k
        d0 b() {
            return d0.q(this.f173c.consumeStableInsets());
        }

        @Override // c.f.j.d0.k
        d0 c() {
            return d0.q(this.f173c.consumeSystemWindowInsets());
        }

        @Override // c.f.j.d0.k
        final androidx.core.graphics.b h() {
            if (this.m == null) {
                this.m = androidx.core.graphics.b.b(this.f173c.getStableInsetLeft(), this.f173c.getStableInsetTop(), this.f173c.getStableInsetRight(), this.f173c.getStableInsetBottom());
            }
            return this.m;
        }

        @Override // c.f.j.d0.k
        boolean k() {
            return this.f173c.isConsumed();
        }
    }

    private static class h extends g {
        h(d0 d0Var, WindowInsets windowInsets) {
            super(d0Var, windowInsets);
        }

        h(d0 d0Var, h hVar) {
            super(d0Var, hVar);
        }

        @Override // c.f.j.d0.k
        d0 a() {
            return d0.q(this.f173c.consumeDisplayCutout());
        }

        @Override // c.f.j.d0.k
        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj instanceof h) {
                return Objects.equals(this.f173c, ((h) obj).f173c);
            }
            return false;
        }

        @Override // c.f.j.d0.k
        c.f.j.c f() {
            return c.f.j.c.a(this.f173c.getDisplayCutout());
        }

        @Override // c.f.j.d0.k
        public int hashCode() {
            return this.f173c.hashCode();
        }
    }

    private static class i extends h {
        private androidx.core.graphics.b n;

        i(d0 d0Var, WindowInsets windowInsets) {
            super(d0Var, windowInsets);
            this.n = null;
        }

        i(d0 d0Var, i iVar) {
            super(d0Var, iVar);
            this.n = null;
        }

        @Override // c.f.j.d0.k
        androidx.core.graphics.b g() {
            if (this.n == null) {
                this.n = androidx.core.graphics.b.d(this.f173c.getMandatorySystemGestureInsets());
            }
            return this.n;
        }

        @Override // c.f.j.d0.f, c.f.j.d0.k
        d0 j(int i, int i2, int i3, int i4) {
            return d0.q(this.f173c.inset(i, i2, i3, i4));
        }
    }

    private static class j extends i {
        static final d0 o = d0.q(WindowInsets.CONSUMED);

        j(d0 d0Var, WindowInsets windowInsets) {
            super(d0Var, windowInsets);
        }

        j(d0 d0Var, j jVar) {
            super(d0Var, jVar);
        }

        @Override // c.f.j.d0.f, c.f.j.d0.k
        final void d(View view) {
        }
    }

    private static class k {

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        static final d0 f175b = new a().a().a().b().c();

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final d0 f176a;

        k(d0 d0Var) {
            this.f176a = d0Var;
        }

        d0 a() {
            return this.f176a;
        }

        d0 b() {
            return this.f176a;
        }

        d0 c() {
            return this.f176a;
        }

        void d(View view) {
        }

        void e(d0 d0Var) {
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof k)) {
                return false;
            }
            k kVar = (k) obj;
            return l() == kVar.l() && k() == kVar.k() && c.f.i.c.a(i(), kVar.i()) && c.f.i.c.a(h(), kVar.h()) && c.f.i.c.a(f(), kVar.f());
        }

        c.f.j.c f() {
            return null;
        }

        androidx.core.graphics.b g() {
            return i();
        }

        androidx.core.graphics.b h() {
            return androidx.core.graphics.b.e;
        }

        public int hashCode() {
            return c.f.i.c.b(Boolean.valueOf(l()), Boolean.valueOf(k()), i(), h(), f());
        }

        androidx.core.graphics.b i() {
            return androidx.core.graphics.b.e;
        }

        d0 j(int i, int i2, int i3, int i4) {
            return f175b;
        }

        boolean k() {
            return false;
        }

        boolean l() {
            return false;
        }

        void m(androidx.core.graphics.b bVar) {
        }

        void n(d0 d0Var) {
        }
    }

    public static final class l {
        static int a(int i) {
            if (i == 1) {
                return 0;
            }
            if (i == 2) {
                return 1;
            }
            if (i == 4) {
                return 2;
            }
            if (i == 8) {
                return 3;
            }
            if (i == 16) {
                return 4;
            }
            if (i == 32) {
                return 5;
            }
            if (i == 64) {
                return 6;
            }
            if (i == 128) {
                return 7;
            }
            if (i == 256) {
                return 8;
            }
            throw new IllegalArgumentException("type needs to be >= FIRST and <= LAST, type=" + i);
        }

        public static int b() {
            return 7;
        }
    }

    static {
        f165b = Build.VERSION.SDK_INT >= 30 ? j.o : k.f175b;
    }

    private d0(WindowInsets windowInsets) {
        k fVar;
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 30) {
            fVar = new j(this, windowInsets);
        } else if (i2 >= 29) {
            fVar = new i(this, windowInsets);
        } else if (i2 >= 28) {
            fVar = new h(this, windowInsets);
        } else if (i2 >= 21) {
            fVar = new g(this, windowInsets);
        } else {
            if (i2 < 20) {
                this.f166a = new k(this);
                return;
            }
            fVar = new f(this, windowInsets);
        }
        this.f166a = fVar;
    }

    public d0(d0 d0Var) {
        if (d0Var == null) {
            this.f166a = new k(this);
            return;
        }
        k kVar = d0Var.f166a;
        this.f166a = (Build.VERSION.SDK_INT < 30 || !(kVar instanceof j)) ? (Build.VERSION.SDK_INT < 29 || !(kVar instanceof i)) ? (Build.VERSION.SDK_INT < 28 || !(kVar instanceof h)) ? (Build.VERSION.SDK_INT < 21 || !(kVar instanceof g)) ? (Build.VERSION.SDK_INT < 20 || !(kVar instanceof f)) ? new k(this) : new f(this, (f) kVar) : new g(this, (g) kVar) : new h(this, (h) kVar) : new i(this, (i) kVar) : new j(this, (j) kVar);
        kVar.e(this);
    }

    static androidx.core.graphics.b k(androidx.core.graphics.b bVar, int i2, int i3, int i4, int i5) {
        int iMax = Math.max(0, bVar.a - i2);
        int iMax2 = Math.max(0, bVar.b - i3);
        int iMax3 = Math.max(0, bVar.c - i4);
        int iMax4 = Math.max(0, bVar.d - i5);
        return (iMax == i2 && iMax2 == i3 && iMax3 == i4 && iMax4 == i5) ? bVar : androidx.core.graphics.b.b(iMax, iMax2, iMax3, iMax4);
    }

    public static d0 q(WindowInsets windowInsets) {
        return r(windowInsets, null);
    }

    public static d0 r(WindowInsets windowInsets, View view) {
        c.f.i.h.c(windowInsets);
        d0 d0Var = new d0(windowInsets);
        if (view != null && view.isAttachedToWindow()) {
            d0Var.o(u.F(view));
            d0Var.d(view.getRootView());
        }
        return d0Var;
    }

    @Deprecated
    public d0 a() {
        return this.f166a.a();
    }

    @Deprecated
    public d0 b() {
        return this.f166a.b();
    }

    @Deprecated
    public d0 c() {
        return this.f166a.c();
    }

    void d(View view) {
        this.f166a.d(view);
    }

    @Deprecated
    public androidx.core.graphics.b e() {
        return this.f166a.g();
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof d0) {
            return c.f.i.c.a(this.f166a, ((d0) obj).f166a);
        }
        return false;
    }

    @Deprecated
    public int f() {
        return this.f166a.i().d;
    }

    @Deprecated
    public int g() {
        return this.f166a.i().a;
    }

    @Deprecated
    public int h() {
        return this.f166a.i().c;
    }

    public int hashCode() {
        k kVar = this.f166a;
        if (kVar == null) {
            return 0;
        }
        return kVar.hashCode();
    }

    @Deprecated
    public int i() {
        return this.f166a.i().b;
    }

    public d0 j(int i2, int i3, int i4, int i5) {
        return this.f166a.j(i2, i3, i4, i5);
    }

    public boolean l() {
        return this.f166a.k();
    }

    @Deprecated
    public d0 m(int i2, int i3, int i4, int i5) {
        a aVar = new a(this);
        aVar.c(androidx.core.graphics.b.b(i2, i3, i4, i5));
        return aVar.a();
    }

    void n(androidx.core.graphics.b bVar) {
        this.f166a.m(bVar);
    }

    void o(d0 d0Var) {
        this.f166a.n(d0Var);
    }

    public WindowInsets p() {
        k kVar = this.f166a;
        if (kVar instanceof f) {
            return ((f) kVar).f173c;
        }
        return null;
    }
}
