package c.f.j;

import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.ViewConfiguration;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final a f158a;

    interface a {
        boolean a(MotionEvent motionEvent);
    }

    static class b implements a {
        private static final int v = ViewConfiguration.getLongPressTimeout();
        private static final int w = ViewConfiguration.getTapTimeout();
        private static final int x = ViewConfiguration.getDoubleTapTimeout();

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private int f159a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private int f160b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private int f161c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        private int f162d;
        private final Handler e;
        final GestureDetector.OnGestureListener f;
        GestureDetector.OnDoubleTapListener g;
        boolean h;
        boolean i;
        private boolean j;
        private boolean k;
        private boolean l;
        MotionEvent m;
        private MotionEvent n;
        private boolean o;
        private float p;
        private float q;
        private float r;
        private float s;
        private boolean t;
        private VelocityTracker u;

        private class a extends Handler {
            a() {
            }

            a(Handler handler) {
                super(handler.getLooper());
            }

            @Override // android.os.Handler
            public void handleMessage(Message message) {
                int i = message.what;
                if (i == 1) {
                    b bVar = b.this;
                    bVar.f.onShowPress(bVar.m);
                    return;
                }
                if (i == 2) {
                    b.this.d();
                    return;
                }
                if (i != 3) {
                    throw new RuntimeException("Unknown message " + message);
                }
                b bVar2 = b.this;
                GestureDetector.OnDoubleTapListener onDoubleTapListener = bVar2.g;
                if (onDoubleTapListener != null) {
                    if (bVar2.h) {
                        bVar2.i = true;
                    } else {
                        onDoubleTapListener.onSingleTapConfirmed(bVar2.m);
                    }
                }
            }
        }

        b(Context context, GestureDetector.OnGestureListener onGestureListener, Handler handler) {
            if (handler != null) {
                this.e = new a(handler);
            } else {
                this.e = new a();
            }
            this.f = onGestureListener;
            if (onGestureListener instanceof GestureDetector.OnDoubleTapListener) {
                g((GestureDetector.OnDoubleTapListener) onGestureListener);
            }
            e(context);
        }

        private void b() {
            this.e.removeMessages(1);
            this.e.removeMessages(2);
            this.e.removeMessages(3);
            this.u.recycle();
            this.u = null;
            this.o = false;
            this.h = false;
            this.k = false;
            this.l = false;
            this.i = false;
            if (this.j) {
                this.j = false;
            }
        }

        private void c() {
            this.e.removeMessages(1);
            this.e.removeMessages(2);
            this.e.removeMessages(3);
            this.o = false;
            this.k = false;
            this.l = false;
            this.i = false;
            if (this.j) {
                this.j = false;
            }
        }

        private void e(Context context) {
            if (context == null) {
                throw new IllegalArgumentException("Context must not be null");
            }
            if (this.f == null) {
                throw new IllegalArgumentException("OnGestureListener must not be null");
            }
            this.t = true;
            ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
            int scaledTouchSlop = viewConfiguration.getScaledTouchSlop();
            int scaledDoubleTapSlop = viewConfiguration.getScaledDoubleTapSlop();
            this.f161c = viewConfiguration.getScaledMinimumFlingVelocity();
            this.f162d = viewConfiguration.getScaledMaximumFlingVelocity();
            this.f159a = scaledTouchSlop * scaledTouchSlop;
            this.f160b = scaledDoubleTapSlop * scaledDoubleTapSlop;
        }

        private boolean f(MotionEvent motionEvent, MotionEvent motionEvent2, MotionEvent motionEvent3) {
            if (!this.l || motionEvent3.getEventTime() - motionEvent2.getEventTime() > x) {
                return false;
            }
            int x2 = ((int) motionEvent.getX()) - ((int) motionEvent3.getX());
            int y = ((int) motionEvent.getY()) - ((int) motionEvent3.getY());
            return (x2 * x2) + (y * y) < this.f160b;
        }

        @Override // c.f.j.d.a
        public boolean a(MotionEvent motionEvent) {
            boolean zOnDoubleTap;
            MotionEvent motionEvent2;
            boolean zOnFling;
            GestureDetector.OnDoubleTapListener onDoubleTapListener;
            int action = motionEvent.getAction();
            if (this.u == null) {
                this.u = VelocityTracker.obtain();
            }
            this.u.addMovement(motionEvent);
            int i = action & 255;
            boolean z = i == 6;
            int actionIndex = z ? motionEvent.getActionIndex() : -1;
            int pointerCount = motionEvent.getPointerCount();
            float x2 = 0.0f;
            float y = 0.0f;
            for (int i2 = 0; i2 < pointerCount; i2++) {
                if (actionIndex != i2) {
                    x2 += motionEvent.getX(i2);
                    y += motionEvent.getY(i2);
                }
            }
            float f = z ? pointerCount - 1 : pointerCount;
            float f2 = x2 / f;
            float f3 = y / f;
            if (i == 0) {
                if (this.g == null) {
                    zOnDoubleTap = false;
                } else {
                    boolean zHasMessages = this.e.hasMessages(3);
                    if (zHasMessages) {
                        this.e.removeMessages(3);
                    }
                    MotionEvent motionEvent3 = this.m;
                    if (motionEvent3 == null || (motionEvent2 = this.n) == null || !zHasMessages || !f(motionEvent3, motionEvent2, motionEvent)) {
                        this.e.sendEmptyMessageDelayed(3, x);
                        zOnDoubleTap = false;
                    } else {
                        this.o = true;
                        zOnDoubleTap = this.g.onDoubleTap(this.m) | false | this.g.onDoubleTapEvent(motionEvent);
                    }
                }
                this.p = f2;
                this.r = f2;
                this.q = f3;
                this.s = f3;
                MotionEvent motionEvent4 = this.m;
                if (motionEvent4 != null) {
                    motionEvent4.recycle();
                }
                this.m = MotionEvent.obtain(motionEvent);
                this.k = true;
                this.l = true;
                this.h = true;
                this.j = false;
                this.i = false;
                if (this.t) {
                    this.e.removeMessages(2);
                    this.e.sendEmptyMessageAtTime(2, this.m.getDownTime() + ((long) w) + ((long) v));
                }
                this.e.sendEmptyMessageAtTime(1, this.m.getDownTime() + ((long) w));
                return zOnDoubleTap | this.f.onDown(motionEvent);
            }
            if (i == 1) {
                this.h = false;
                MotionEvent motionEventObtain = MotionEvent.obtain(motionEvent);
                if (this.o) {
                    zOnFling = this.g.onDoubleTapEvent(motionEvent) | false;
                } else {
                    if (this.j) {
                        this.e.removeMessages(3);
                        this.j = false;
                    } else if (this.k) {
                        boolean zOnSingleTapUp = this.f.onSingleTapUp(motionEvent);
                        if (this.i && (onDoubleTapListener = this.g) != null) {
                            onDoubleTapListener.onSingleTapConfirmed(motionEvent);
                        }
                        zOnFling = zOnSingleTapUp;
                    } else {
                        VelocityTracker velocityTracker = this.u;
                        int pointerId = motionEvent.getPointerId(0);
                        velocityTracker.computeCurrentVelocity(1000, this.f162d);
                        float yVelocity = velocityTracker.getYVelocity(pointerId);
                        float xVelocity = velocityTracker.getXVelocity(pointerId);
                        if (Math.abs(yVelocity) > this.f161c || Math.abs(xVelocity) > this.f161c) {
                            zOnFling = this.f.onFling(this.m, motionEvent, xVelocity, yVelocity);
                        }
                    }
                    zOnFling = false;
                }
                MotionEvent motionEvent5 = this.n;
                if (motionEvent5 != null) {
                    motionEvent5.recycle();
                }
                this.n = motionEventObtain;
                VelocityTracker velocityTracker2 = this.u;
                if (velocityTracker2 != null) {
                    velocityTracker2.recycle();
                    this.u = null;
                }
                this.o = false;
                this.i = false;
                this.e.removeMessages(1);
                this.e.removeMessages(2);
            } else {
                if (i != 2) {
                    if (i == 3) {
                        b();
                        return false;
                    }
                    if (i == 5) {
                        this.p = f2;
                        this.r = f2;
                        this.q = f3;
                        this.s = f3;
                        c();
                        return false;
                    }
                    if (i != 6) {
                        return false;
                    }
                    this.p = f2;
                    this.r = f2;
                    this.q = f3;
                    this.s = f3;
                    this.u.computeCurrentVelocity(1000, this.f162d);
                    int actionIndex2 = motionEvent.getActionIndex();
                    int pointerId2 = motionEvent.getPointerId(actionIndex2);
                    float xVelocity2 = this.u.getXVelocity(pointerId2);
                    float yVelocity2 = this.u.getYVelocity(pointerId2);
                    for (int i3 = 0; i3 < pointerCount; i3++) {
                        if (i3 != actionIndex2) {
                            int pointerId3 = motionEvent.getPointerId(i3);
                            if ((this.u.getXVelocity(pointerId3) * xVelocity2) + (this.u.getYVelocity(pointerId3) * yVelocity2) < 0.0f) {
                                this.u.clear();
                                return false;
                            }
                        }
                    }
                    return false;
                }
                if (this.j) {
                    return false;
                }
                float f4 = this.p - f2;
                float f5 = this.q - f3;
                if (this.o) {
                    return false | this.g.onDoubleTapEvent(motionEvent);
                }
                if (!this.k) {
                    if (Math.abs(f4) < 1.0f && Math.abs(f5) < 1.0f) {
                        return false;
                    }
                    boolean zOnScroll = this.f.onScroll(this.m, motionEvent, f4, f5);
                    this.p = f2;
                    this.q = f3;
                    return zOnScroll;
                }
                int i4 = (int) (f2 - this.r);
                int i5 = (int) (f3 - this.s);
                int i6 = (i4 * i4) + (i5 * i5);
                if (i6 > this.f159a) {
                    zOnFling = this.f.onScroll(this.m, motionEvent, f4, f5);
                    this.p = f2;
                    this.q = f3;
                    this.k = false;
                    this.e.removeMessages(3);
                    this.e.removeMessages(1);
                    this.e.removeMessages(2);
                } else {
                    zOnFling = false;
                }
                if (i6 > this.f159a) {
                    this.l = false;
                }
            }
            return zOnFling;
        }

        void d() {
            this.e.removeMessages(3);
            this.i = false;
            this.j = true;
            this.f.onLongPress(this.m);
        }

        public void g(GestureDetector.OnDoubleTapListener onDoubleTapListener) {
            this.g = onDoubleTapListener;
        }
    }

    static class c implements a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final GestureDetector f164a;

        c(Context context, GestureDetector.OnGestureListener onGestureListener, Handler handler) {
            this.f164a = new GestureDetector(context, onGestureListener, handler);
        }

        @Override // c.f.j.d.a
        public boolean a(MotionEvent motionEvent) {
            return this.f164a.onTouchEvent(motionEvent);
        }
    }

    public d(Context context, GestureDetector.OnGestureListener onGestureListener) {
        this(context, onGestureListener, null);
    }

    public d(Context context, GestureDetector.OnGestureListener onGestureListener, Handler handler) {
        this.f158a = Build.VERSION.SDK_INT > 17 ? new c(context, onGestureListener, handler) : new b(context, onGestureListener, handler);
    }

    public boolean a(MotionEvent motionEvent) {
        return this.f158a.a(motionEvent);
    }
}
