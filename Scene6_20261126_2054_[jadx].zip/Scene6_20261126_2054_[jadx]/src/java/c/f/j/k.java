package c.f.j;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public interface k {
    boolean isNestedScrollingEnabled();

    void stopNestedScroll();
}
