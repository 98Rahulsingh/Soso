package c.f.j;

import android.os.Build;
import android.view.View;
import android.view.Window;
import android.view.WindowInsetsController;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class c0 {

    private static class a {
        static e0 a(Window window) {
            WindowInsetsController insetsController = window.getInsetsController();
            if (insetsController != null) {
                return e0.b(insetsController);
            }
            return null;
        }
    }

    public static e0 a(Window window, View view) {
        return Build.VERSION.SDK_INT >= 30 ? a.a(window) : new e0(window, view);
    }
}
