package c.f.j;

import android.content.Context;
import android.util.Log;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public abstract class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private InterfaceC0017b f156a;

    public interface a {
    }

    /* JADX INFO: renamed from: c.f.j.b$b, reason: collision with other inner class name */
    public interface InterfaceC0017b {
        void onActionProviderVisibilityChanged(boolean z);
    }

    public b(Context context) {
    }

    public boolean a() {
        return false;
    }

    public boolean b() {
        return true;
    }

    public abstract View c();

    public View d(MenuItem menuItem) {
        return c();
    }

    public boolean e() {
        return false;
    }

    public void f(SubMenu subMenu) {
    }

    public boolean g() {
        return false;
    }

    public void h() {
        this.f156a = null;
    }

    public void i(a aVar) {
    }

    public void j(InterfaceC0017b interfaceC0017b) {
        if (this.f156a != null && interfaceC0017b != null) {
            Log.w("ActionProvider(support)", "setVisibilityListener: Setting a new ActionProvider.VisibilityListener when one is already set. Are you reusing this " + getClass().getSimpleName() + " instance while it is still in use somewhere else?");
        }
        this.f156a = interfaceC0017b;
    }
}
