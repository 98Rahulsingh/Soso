package c.f.j.f0;

import android.os.Bundle;
import android.view.View;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public interface f {

    public static abstract class a {
        public void a(Bundle bundle) {
        }
    }

    public static final class b extends a {
    }

    public static final class c extends a {
    }

    public static final class d extends a {
    }

    public static final class e extends a {
    }

    /* JADX INFO: renamed from: c.f.j.f0.f$f, reason: collision with other inner class name */
    public static final class C0019f extends a {
    }

    public static final class g extends a {
    }

    public static final class h extends a {
    }

    boolean a(View view, a aVar);
}
