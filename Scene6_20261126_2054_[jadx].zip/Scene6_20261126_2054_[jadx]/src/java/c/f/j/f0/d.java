package c.f.j.f0;

import android.os.Build;
import android.os.Bundle;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityNodeProvider;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final Object f194a;

    static class a extends AccessibilityNodeProvider {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final d f195a;

        a(d dVar) {
            this.f195a = dVar;
        }

        @Override // android.view.accessibility.AccessibilityNodeProvider
        public AccessibilityNodeInfo createAccessibilityNodeInfo(int i) {
            c.f.j.f0.c cVarB = this.f195a.b(i);
            if (cVarB == null) {
                return null;
            }
            return cVarB.C0();
        }

        @Override // android.view.accessibility.AccessibilityNodeProvider
        public List<AccessibilityNodeInfo> findAccessibilityNodeInfosByText(String str, int i) {
            List<c.f.j.f0.c> listC = this.f195a.c(str, i);
            if (listC == null) {
                return null;
            }
            ArrayList arrayList = new ArrayList();
            int size = listC.size();
            for (int i2 = 0; i2 < size; i2++) {
                arrayList.add(listC.get(i2).C0());
            }
            return arrayList;
        }

        @Override // android.view.accessibility.AccessibilityNodeProvider
        public boolean performAction(int i, int i2, Bundle bundle) {
            return this.f195a.f(i, i2, bundle);
        }
    }

    static class b extends a {
        b(d dVar) {
            super(dVar);
        }

        @Override // android.view.accessibility.AccessibilityNodeProvider
        public AccessibilityNodeInfo findFocus(int i) {
            c.f.j.f0.c cVarD = this.f195a.d(i);
            if (cVarD == null) {
                return null;
            }
            return cVarD.C0();
        }
    }

    static class c extends b {
        c(d dVar) {
            super(dVar);
        }

        @Override // android.view.accessibility.AccessibilityNodeProvider
        public void addExtraDataToAccessibilityNodeInfo(int i, AccessibilityNodeInfo accessibilityNodeInfo, String str, Bundle bundle) {
            this.f195a.a(i, c.f.j.f0.c.D0(accessibilityNodeInfo), str, bundle);
        }
    }

    public d() {
        int i = Build.VERSION.SDK_INT;
        this.f194a = i >= 26 ? new c(this) : i >= 19 ? new b(this) : i >= 16 ? new a(this) : null;
    }

    public d(Object obj) {
        this.f194a = obj;
    }

    public void a(int i, c.f.j.f0.c cVar, String str, Bundle bundle) {
    }

    public c.f.j.f0.c b(int i) {
        return null;
    }

    public List<c.f.j.f0.c> c(String str, int i) {
        return null;
    }

    public c.f.j.f0.c d(int i) {
        return null;
    }

    public Object e() {
        return this.f194a;
    }

    public boolean f(int i, int i2, Bundle bundle) {
        return false;
    }
}
