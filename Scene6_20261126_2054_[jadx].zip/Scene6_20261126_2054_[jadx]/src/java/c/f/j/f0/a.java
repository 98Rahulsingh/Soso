package c.f.j.f0;

import android.os.Bundle;
import android.text.style.ClickableSpan;
import android.view.View;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class a extends ClickableSpan {
    private final int f;
    private final c g;
    private final int h;

    public a(int i, c cVar, int i2) {
        this.f = i;
        this.g = cVar;
        this.h = i2;
    }

    @Override // android.text.style.ClickableSpan
    public void onClick(View view) {
        Bundle bundle = new Bundle();
        bundle.putInt("ACCESSIBILITY_CLICKABLE_SPAN_ID", this.f);
        this.g.Q(this.h, bundle);
    }
}
