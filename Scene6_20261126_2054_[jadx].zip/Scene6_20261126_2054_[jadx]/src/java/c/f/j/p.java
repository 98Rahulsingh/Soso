package c.f.j;

import android.view.View;
import android.view.ViewGroup;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class p {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private int f202a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private int f203b;

    public p(ViewGroup viewGroup) {
    }

    public int a() {
        return this.f202a | this.f203b;
    }

    public void b(View view, View view2, int i) {
        c(view, view2, i, 0);
    }

    public void c(View view, View view2, int i, int i2) {
        if (i2 == 1) {
            this.f203b = i;
        } else {
            this.f202a = i;
        }
    }

    public void d(View view, int i) {
        if (i == 1) {
            this.f203b = 0;
        } else {
            this.f202a = 0;
        }
    }
}
