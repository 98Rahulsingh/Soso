package c.f.j;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.os.Build;
import android.view.View;
import android.view.animation.Interpolator;
import java.lang.ref.WeakReference;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class y {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private WeakReference<View> f219a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    Runnable f220b = null;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    Runnable f221c = null;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    int f222d = -1;

    class a extends AnimatorListenerAdapter {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final /* synthetic */ z f223a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final /* synthetic */ View f224b;

        a(y yVar, z zVar, View view) {
            this.f223a = zVar;
            this.f224b = view;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationCancel(Animator animator) {
            this.f223a.c(this.f224b);
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            this.f223a.a(this.f224b);
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationStart(Animator animator) {
            this.f223a.b(this.f224b);
        }
    }

    class b implements ValueAnimator.AnimatorUpdateListener {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final /* synthetic */ b0 f225a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final /* synthetic */ View f226b;

        b(y yVar, b0 b0Var, View view) {
            this.f225a = b0Var;
            this.f226b = view;
        }

        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            this.f225a.a(this.f226b);
        }
    }

    static class c implements z {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        y f227a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        boolean f228b;

        c(y yVar) {
            this.f227a = yVar;
        }

        @Override // c.f.j.z
        @SuppressLint({"WrongConstant"})
        public void a(View view) {
            int i = this.f227a.f222d;
            if (i > -1) {
                view.setLayerType(i, null);
                this.f227a.f222d = -1;
            }
            if (Build.VERSION.SDK_INT >= 16 || !this.f228b) {
                y yVar = this.f227a;
                Runnable runnable = yVar.f221c;
                if (runnable != null) {
                    yVar.f221c = null;
                    runnable.run();
                }
                Object tag = view.getTag(2113929216);
                z zVar = tag instanceof z ? (z) tag : null;
                if (zVar != null) {
                    zVar.a(view);
                }
                this.f228b = true;
            }
        }

        @Override // c.f.j.z
        public void b(View view) {
            this.f228b = false;
            if (this.f227a.f222d > -1) {
                view.setLayerType(2, null);
            }
            y yVar = this.f227a;
            Runnable runnable = yVar.f220b;
            if (runnable != null) {
                yVar.f220b = null;
                runnable.run();
            }
            Object tag = view.getTag(2113929216);
            z zVar = tag instanceof z ? (z) tag : null;
            if (zVar != null) {
                zVar.b(view);
            }
        }

        @Override // c.f.j.z
        public void c(View view) {
            Object tag = view.getTag(2113929216);
            z zVar = tag instanceof z ? (z) tag : null;
            if (zVar != null) {
                zVar.c(view);
            }
        }
    }

    y(View view) {
        this.f219a = new WeakReference<>(view);
    }

    private void g(View view, z zVar) {
        if (zVar != null) {
            view.animate().setListener(new a(this, zVar, view));
        } else {
            view.animate().setListener(null);
        }
    }

    public y a(float f) {
        View view = this.f219a.get();
        if (view != null) {
            view.animate().alpha(f);
        }
        return this;
    }

    public void b() {
        View view = this.f219a.get();
        if (view != null) {
            view.animate().cancel();
        }
    }

    public long c() {
        View view = this.f219a.get();
        if (view != null) {
            return view.animate().getDuration();
        }
        return 0L;
    }

    public y d(long j) {
        View view = this.f219a.get();
        if (view != null) {
            view.animate().setDuration(j);
        }
        return this;
    }

    public y e(Interpolator interpolator) {
        View view = this.f219a.get();
        if (view != null) {
            view.animate().setInterpolator(interpolator);
        }
        return this;
    }

    public y f(z zVar) {
        View view = this.f219a.get();
        if (view != null) {
            if (Build.VERSION.SDK_INT < 16) {
                view.setTag(2113929216, zVar);
                zVar = new c(this);
            }
            g(view, zVar);
        }
        return this;
    }

    public y h(long j) {
        View view = this.f219a.get();
        if (view != null) {
            view.animate().setStartDelay(j);
        }
        return this;
    }

    public y i(b0 b0Var) {
        View view = this.f219a.get();
        if (view != null && Build.VERSION.SDK_INT >= 19) {
            view.animate().setUpdateListener(b0Var != null ? new b(this, b0Var, view) : null);
        }
        return this;
    }

    public void j() {
        View view = this.f219a.get();
        if (view != null) {
            view.animate().start();
        }
    }

    public y k(float f) {
        View view = this.f219a.get();
        if (view != null) {
            view.animate().translationY(f);
        }
        return this;
    }
}
