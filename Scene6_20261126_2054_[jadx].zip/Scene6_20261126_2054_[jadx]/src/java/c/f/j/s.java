package c.f.j;

import android.content.Context;
import android.os.Build;
import android.view.PointerIcon;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class s {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private Object f204a;

    private s(Object obj) {
        this.f204a = obj;
    }

    public static s b(Context context, int i) {
        return Build.VERSION.SDK_INT >= 24 ? new s(PointerIcon.getSystemIcon(context, i)) : new s(null);
    }

    public Object a() {
        return this.f204a;
    }
}
