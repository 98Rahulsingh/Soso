package c.f.j;

import android.view.View;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public interface z {
    void a(View view);

    void b(View view);

    void c(View view);
}
