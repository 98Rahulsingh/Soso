package c.f.j;

import android.view.View;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public interface n extends m {
    void m(View view, int i, int i2, int i3, int i4, int i5, int[] iArr);
}
