package c.f.j;

import android.view.View;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class a0 implements z {
    @Override // c.f.j.z
    public void b(View view) {
    }

    @Override // c.f.j.z
    public void c(View view) {
    }
}
