package c.f.j;

import android.view.View;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public interface m extends o {
    void h(View view, View view2, int i, int i2);

    void i(View view, int i);

    void j(View view, int i, int i2, int[] iArr, int i3);

    void n(View view, int i, int i2, int i3, int i4, int i5);

    boolean o(View view, View view2, int i, int i2);
}
