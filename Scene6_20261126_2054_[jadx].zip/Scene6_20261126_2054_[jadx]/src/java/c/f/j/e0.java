package c.f.j;

import android.os.Build;
import android.view.View;
import android.view.Window;
import android.view.WindowInsetsController;
import android.view.inputmethod.InputMethodManager;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class e0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final e f177a;

    private static class a extends e {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        protected final Window f178a;

        a(Window window, View view) {
            this.f178a = window;
        }

        private void b(int i) {
            if (i == 1) {
                c(4);
                d(1024);
            } else if (i == 2) {
                c(2);
            } else {
                if (i != 8) {
                    return;
                }
                ((InputMethodManager) this.f178a.getContext().getSystemService("input_method")).hideSoftInputFromWindow(this.f178a.getDecorView().getWindowToken(), 0);
            }
        }

        @Override // c.f.j.e0.e
        void a(int i) {
            for (int i2 = 1; i2 <= 256; i2 <<= 1) {
                if ((i & i2) != 0) {
                    b(i2);
                }
            }
        }

        protected void c(int i) {
            View decorView = this.f178a.getDecorView();
            decorView.setSystemUiVisibility(i | decorView.getSystemUiVisibility());
        }

        protected void d(int i) {
            this.f178a.addFlags(i);
        }
    }

    private static class b extends a {
        b(Window window, View view) {
            super(window, view);
        }
    }

    private static class c extends b {
        c(Window window, View view) {
            super(window, view);
        }
    }

    private static class d extends e {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final WindowInsetsController f179a;

        d(Window window) {
            this.f179a = window.getInsetsController();
        }

        d(WindowInsetsController windowInsetsController) {
            this.f179a = windowInsetsController;
        }

        @Override // c.f.j.e0.e
        void a(int i) {
            this.f179a.hide(i);
        }
    }

    private static class e {
        e() {
        }

        void a(int i) {
        }
    }

    public e0(Window window, View view) {
        e aVar;
        int i = Build.VERSION.SDK_INT;
        if (i >= 30) {
            this.f177a = new d(window);
            return;
        }
        if (i >= 26) {
            aVar = new c(window, view);
        } else if (i >= 23) {
            aVar = new b(window, view);
        } else {
            if (i < 20) {
                this.f177a = new e();
                return;
            }
            aVar = new a(window, view);
        }
        this.f177a = aVar;
    }

    private e0(WindowInsetsController windowInsetsController) {
        if (Build.VERSION.SDK_INT >= 30) {
            this.f177a = new d(windowInsetsController);
        } else {
            this.f177a = new e();
        }
    }

    public static e0 b(WindowInsetsController windowInsetsController) {
        return new e0(windowInsetsController);
    }

    public void a(int i) {
        this.f177a.a(i);
    }
}
