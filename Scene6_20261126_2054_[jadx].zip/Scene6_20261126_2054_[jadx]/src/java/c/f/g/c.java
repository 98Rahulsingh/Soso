package c.f.g;

import android.os.Handler;
import android.os.HandlerThread;
import android.os.Message;
import java.util.concurrent.Callable;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class c {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private HandlerThread f111b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private Handler f112c;
    private final int f;
    private final int g;
    private final String h;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final Object f110a = new Object();
    private Handler.Callback e = new a();

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private int f113d = 0;

    class a implements Handler.Callback {
        a() {
        }

        @Override // android.os.Handler.Callback
        public boolean handleMessage(Message message) {
            int i = message.what;
            if (i == 0) {
                c.this.a();
                return true;
            }
            if (i != 1) {
                return true;
            }
            c.this.b((Runnable) message.obj);
            return true;
        }
    }

    class b implements Runnable {
        final /* synthetic */ Callable f;
        final /* synthetic */ Handler g;
        final /* synthetic */ d h;

        class a implements Runnable {
            final /* synthetic */ Object f;

            a(Object obj) {
                this.f = obj;
            }

            @Override // java.lang.Runnable
            public void run() {
                b.this.h.a(this.f);
            }
        }

        b(c cVar, Callable callable, Handler handler, d dVar) {
            this.f = callable;
            this.g = handler;
            this.h = dVar;
        }

        @Override // java.lang.Runnable
        public void run() {
            Object objCall;
            try {
                objCall = this.f.call();
            } catch (Exception unused) {
                objCall = null;
            }
            this.g.post(new a(objCall));
        }
    }

    /* JADX INFO: renamed from: c.f.g.c$c, reason: collision with other inner class name */
    class RunnableC0012c implements Runnable {
        final /* synthetic */ AtomicReference f;
        final /* synthetic */ Callable g;
        final /* synthetic */ ReentrantLock h;
        final /* synthetic */ AtomicBoolean i;
        final /* synthetic */ Condition j;

        RunnableC0012c(c cVar, AtomicReference atomicReference, Callable callable, ReentrantLock reentrantLock, AtomicBoolean atomicBoolean, Condition condition) {
            this.f = atomicReference;
            this.g = callable;
            this.h = reentrantLock;
            this.i = atomicBoolean;
            this.j = condition;
        }

        @Override // java.lang.Runnable
        public void run() {
            try {
                this.f.set(this.g.call());
            } catch (Exception unused) {
            }
            this.h.lock();
            try {
                this.i.set(false);
                this.j.signal();
            } finally {
                this.h.unlock();
            }
        }
    }

    public interface d<T> {
        void a(T t);
    }

    public c(String str, int i, int i2) {
        this.h = str;
        this.g = i;
        this.f = i2;
    }

    private void c(Runnable runnable) {
        synchronized (this.f110a) {
            if (this.f111b == null) {
                HandlerThread handlerThread = new HandlerThread(this.h, this.g);
                this.f111b = handlerThread;
                handlerThread.start();
                this.f112c = new Handler(this.f111b.getLooper(), this.e);
                this.f113d++;
            }
            this.f112c.removeMessages(0);
            this.f112c.sendMessage(this.f112c.obtainMessage(1, runnable));
        }
    }

    void a() {
        synchronized (this.f110a) {
            if (this.f112c.hasMessages(1)) {
                return;
            }
            this.f111b.quit();
            this.f111b = null;
            this.f112c = null;
        }
    }

    void b(Runnable runnable) {
        runnable.run();
        synchronized (this.f110a) {
            this.f112c.removeMessages(0);
            this.f112c.sendMessageDelayed(this.f112c.obtainMessage(0), this.f);
        }
    }

    public <T> void d(Callable<T> callable, d<T> dVar) {
        c(new b(this, callable, new Handler(), dVar));
    }

    public <T> T e(Callable<T> callable, int i) {
        ReentrantLock reentrantLock = new ReentrantLock();
        Condition conditionNewCondition = reentrantLock.newCondition();
        AtomicReference atomicReference = new AtomicReference();
        AtomicBoolean atomicBoolean = new AtomicBoolean(true);
        c(new RunnableC0012c(this, atomicReference, callable, reentrantLock, atomicBoolean, conditionNewCondition));
        reentrantLock.lock();
        try {
            if (!atomicBoolean.get()) {
                T t = (T) atomicReference.get();
                reentrantLock.unlock();
                return t;
            }
            long nanos = TimeUnit.MILLISECONDS.toNanos(i);
            do {
                try {
                    nanos = conditionNewCondition.awaitNanos(nanos);
                } catch (InterruptedException unused) {
                }
                if (!atomicBoolean.get()) {
                    T t2 = (T) atomicReference.get();
                    reentrantLock.unlock();
                    return t2;
                }
            } while (nanos > 0);
            throw new InterruptedException("timeout");
        } catch (Throwable th) {
            reentrantLock.unlock();
            throw th;
        }
    }
}
