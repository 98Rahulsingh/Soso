package c.f.g;

import android.util.Base64;
import c.f.i.h;
import java.util.List;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final String f87a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final String f88b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final String f89c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private final List<List<byte[]>> f90d;
    private final int e;
    private final String f;

    public a(String str, String str2, String str3, List<List<byte[]>> list) {
        h.c(str);
        this.f87a = str;
        h.c(str2);
        this.f88b = str2;
        h.c(str3);
        this.f89c = str3;
        h.c(list);
        this.f90d = list;
        this.e = 0;
        this.f = this.f87a + "-" + this.f88b + "-" + this.f89c;
    }

    public List<List<byte[]>> a() {
        return this.f90d;
    }

    public int b() {
        return this.e;
    }

    public String c() {
        return this.f;
    }

    public String d() {
        return this.f87a;
    }

    public String e() {
        return this.f88b;
    }

    public String f() {
        return this.f89c;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("FontRequest {mProviderAuthority: " + this.f87a + ", mProviderPackage: " + this.f88b + ", mQuery: " + this.f89c + ", mCertificates:");
        for (int i = 0; i < this.f90d.size(); i++) {
            sb.append(" [");
            List<byte[]> list = this.f90d.get(i);
            for (int i2 = 0; i2 < list.size(); i2++) {
                sb.append(" \"");
                sb.append(Base64.encodeToString(list.get(i2), 0));
                sb.append("\"");
            }
            sb.append(" ]");
        }
        sb.append("}");
        sb.append("mCertificatesArray: " + this.e);
        return sb.toString();
    }
}
