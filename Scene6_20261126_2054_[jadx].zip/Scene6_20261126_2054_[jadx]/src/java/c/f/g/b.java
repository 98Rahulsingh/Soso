package c.f.g;

import android.content.ContentUris;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.ProviderInfo;
import android.content.pm.Signature;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.CancellationSignal;
import android.os.Handler;
import androidx.core.graphics.k;
import c.f.i.h;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    static final c.d.e<String, Typeface> f91a = new c.d.e<>(16);

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private static final c.f.g.c f92b = new c.f.g.c("fonts", 10, 10000);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    static final Object f93c = new Object();

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    static final c.d.g<String, ArrayList<c.f.g.c.d<g>>> f94d = new c.d.g<>();
    private static final Comparator<byte[]> e = new d();

    class a implements Callable<g> {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final /* synthetic */ Context f95a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final /* synthetic */ c.f.g.a f96b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        final /* synthetic */ int f97c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ String f98d;

        a(Context context, c.f.g.a aVar, int i, String str) {
            this.f95a = context;
            this.f96b = aVar;
            this.f97c = i;
            this.f98d = str;
        }

        @Override // java.util.concurrent.Callable
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public g call() {
            g gVarF = b.f(this.f95a, this.f96b, this.f97c);
            Typeface typeface = gVarF.f108a;
            if (typeface != null) {
                b.f91a.d(this.f98d, typeface);
            }
            return gVarF;
        }
    }

    /* JADX INFO: renamed from: c.f.g.b$b, reason: collision with other inner class name */
    class C0011b implements c.f.g.c.d<g> {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final /* synthetic */ c.f.d.d.f.a f99a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final /* synthetic */ Handler f100b;

        C0011b(c.f.d.d.f.a aVar, Handler handler) {
            this.f99a = aVar;
            this.f100b = handler;
        }

        @Override // c.f.g.c.d
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public void a(g gVar) {
            int i;
            c.f.d.d.f.a aVar;
            if (gVar == null) {
                aVar = this.f99a;
                i = 1;
            } else {
                i = gVar.f109b;
                if (i == 0) {
                    this.f99a.b(gVar.f108a, this.f100b);
                    return;
                }
                aVar = this.f99a;
            }
            aVar.a(i, this.f100b);
        }
    }

    class c implements c.f.g.c.d<g> {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final /* synthetic */ String f101a;

        c(String str) {
            this.f101a = str;
        }

        @Override // c.f.g.c.d
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public void a(g gVar) {
            synchronized (b.f93c) {
                ArrayList<c.f.g.c.d<g>> arrayList = b.f94d.get(this.f101a);
                if (arrayList == null) {
                    return;
                }
                b.f94d.remove(this.f101a);
                for (int i = 0; i < arrayList.size(); i++) {
                    arrayList.get(i).a(gVar);
                }
            }
        }
    }

    class d implements Comparator<byte[]> {
        d() {
        }

        @Override // java.util.Comparator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public int compare(byte[] bArr, byte[] bArr2) {
            int length;
            int length2;
            if (bArr.length == bArr2.length) {
                for (int i = 0; i < bArr.length; i++) {
                    if (bArr[i] != bArr2[i]) {
                        length = bArr[i];
                        length2 = bArr2[i];
                    }
                }
                return 0;
            }
            length = bArr.length;
            length2 = bArr2.length;
            return length - length2;
        }
    }

    public static class e {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final int f102a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private final f[] f103b;

        public e(int i, f[] fVarArr) {
            this.f102a = i;
            this.f103b = fVarArr;
        }

        public f[] a() {
            return this.f103b;
        }

        public int b() {
            return this.f102a;
        }
    }

    public static class f {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final Uri f104a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private final int f105b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private final int f106c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        private final boolean f107d;
        private final int e;

        public f(Uri uri, int i, int i2, boolean z, int i3) {
            h.c(uri);
            this.f104a = uri;
            this.f105b = i;
            this.f106c = i2;
            this.f107d = z;
            this.e = i3;
        }

        public int a() {
            return this.e;
        }

        public int b() {
            return this.f105b;
        }

        public Uri c() {
            return this.f104a;
        }

        public int d() {
            return this.f106c;
        }

        public boolean e() {
            return this.f107d;
        }
    }

    private static final class g {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final Typeface f108a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final int f109b;

        g(Typeface typeface, int i) {
            this.f108a = typeface;
            this.f109b = i;
        }
    }

    private static List<byte[]> a(Signature[] signatureArr) {
        ArrayList arrayList = new ArrayList();
        for (Signature signature : signatureArr) {
            arrayList.add(signature.toByteArray());
        }
        return arrayList;
    }

    private static boolean b(List<byte[]> list, List<byte[]> list2) {
        if (list.size() != list2.size()) {
            return false;
        }
        for (int i = 0; i < list.size(); i++) {
            if (!Arrays.equals(list.get(i), list2.get(i))) {
                return false;
            }
        }
        return true;
    }

    public static e c(Context context, CancellationSignal cancellationSignal, c.f.g.a aVar) throws PackageManager.NameNotFoundException {
        ProviderInfo providerInfoH = h(context.getPackageManager(), aVar, context.getResources());
        return providerInfoH == null ? new e(1, null) : new e(0, e(context, aVar, providerInfoH.authority, cancellationSignal));
    }

    private static List<List<byte[]>> d(c.f.g.a aVar, Resources resources) {
        return aVar.a() != null ? aVar.a() : c.f.d.d.c.c(resources, aVar.b());
    }

    static f[] e(Context context, c.f.g.a aVar, String str, CancellationSignal cancellationSignal) {
        ArrayList arrayList = new ArrayList();
        Uri uriBuild = new Uri.Builder().scheme("content").authority(str).build();
        Uri uriBuild2 = new Uri.Builder().scheme("content").authority(str).appendPath("file").build();
        Cursor cursorQuery = null;
        try {
            cursorQuery = Build.VERSION.SDK_INT > 16 ? context.getContentResolver().query(uriBuild, new String[]{"_id", "file_id", "font_ttc_index", "font_variation_settings", "font_weight", "font_italic", "result_code"}, "query = ?", new String[]{aVar.f()}, null, cancellationSignal) : context.getContentResolver().query(uriBuild, new String[]{"_id", "file_id", "font_ttc_index", "font_variation_settings", "font_weight", "font_italic", "result_code"}, "query = ?", new String[]{aVar.f()}, null);
            if (cursorQuery != null && cursorQuery.getCount() > 0) {
                int columnIndex = cursorQuery.getColumnIndex("result_code");
                ArrayList arrayList2 = new ArrayList();
                int columnIndex2 = cursorQuery.getColumnIndex("_id");
                int columnIndex3 = cursorQuery.getColumnIndex("file_id");
                int columnIndex4 = cursorQuery.getColumnIndex("font_ttc_index");
                int columnIndex5 = cursorQuery.getColumnIndex("font_weight");
                int columnIndex6 = cursorQuery.getColumnIndex("font_italic");
                while (cursorQuery.moveToNext()) {
                    int i = columnIndex != -1 ? cursorQuery.getInt(columnIndex) : 0;
                    arrayList2.add(new f(columnIndex3 == -1 ? ContentUris.withAppendedId(uriBuild, cursorQuery.getLong(columnIndex2)) : ContentUris.withAppendedId(uriBuild2, cursorQuery.getLong(columnIndex3)), columnIndex4 != -1 ? cursorQuery.getInt(columnIndex4) : 0, columnIndex5 != -1 ? cursorQuery.getInt(columnIndex5) : 400, columnIndex6 != -1 && cursorQuery.getInt(columnIndex6) == 1, i));
                }
                arrayList = arrayList2;
            }
            return (f[]) arrayList.toArray(new f[0]);
        } finally {
            if (cursorQuery != null) {
                cursorQuery.close();
            }
        }
    }

    static g f(Context context, c.f.g.a aVar, int i) {
        try {
            e eVarC = c(context, null, aVar);
            if (eVarC.b() != 0) {
                return new g(null, eVarC.b() == 1 ? -2 : -3);
            }
            Typeface typefaceB = androidx.core.graphics.d.b(context, (CancellationSignal) null, eVarC.a(), i);
            return new g(typefaceB, typefaceB != null ? 0 : -3);
        } catch (PackageManager.NameNotFoundException unused) {
            return new g(null, -1);
        }
    }

    public static Typeface g(Context context, c.f.g.a aVar, c.f.d.d.f.a aVar2, Handler handler, boolean z, int i, int i2) {
        String str = aVar.c() + "-" + i2;
        Typeface typefaceC = f91a.c(str);
        if (typefaceC != null) {
            if (aVar2 != null) {
                aVar2.d(typefaceC);
            }
            return typefaceC;
        }
        if (z && i == -1) {
            g gVarF = f(context, aVar, i2);
            if (aVar2 != null) {
                int i3 = gVarF.f109b;
                if (i3 == 0) {
                    aVar2.b(gVarF.f108a, handler);
                } else {
                    aVar2.a(i3, handler);
                }
            }
            return gVarF.f108a;
        }
        a aVar3 = new a(context, aVar, i2, str);
        if (z) {
            try {
                return ((g) f92b.e(aVar3, i)).f108a;
            } catch (InterruptedException unused) {
                return null;
            }
        }
        C0011b c0011b = aVar2 == null ? null : new C0011b(aVar2, handler);
        synchronized (f93c) {
            ArrayList<c.f.g.c.d<g>> arrayList = f94d.get(str);
            if (arrayList != null) {
                if (c0011b != null) {
                    arrayList.add(c0011b);
                }
                return null;
            }
            if (c0011b != null) {
                ArrayList<c.f.g.c.d<g>> arrayList2 = new ArrayList<>();
                arrayList2.add(c0011b);
                f94d.put(str, arrayList2);
            }
            f92b.d(aVar3, new c(str));
            return null;
        }
    }

    public static ProviderInfo h(PackageManager packageManager, c.f.g.a aVar, Resources resources) throws PackageManager.NameNotFoundException {
        String strD = aVar.d();
        ProviderInfo providerInfoResolveContentProvider = packageManager.resolveContentProvider(strD, 0);
        if (providerInfoResolveContentProvider == null) {
            throw new PackageManager.NameNotFoundException("No package found for authority: " + strD);
        }
        if (!providerInfoResolveContentProvider.packageName.equals(aVar.e())) {
            throw new PackageManager.NameNotFoundException("Found content provider " + strD + ", but package was not " + aVar.e());
        }
        List<byte[]> listA = a(packageManager.getPackageInfo(providerInfoResolveContentProvider.packageName, 64).signatures);
        Collections.sort(listA, e);
        List<List<byte[]>> listD = d(aVar, resources);
        for (int i = 0; i < listD.size(); i++) {
            ArrayList arrayList = new ArrayList(listD.get(i));
            Collections.sort(arrayList, e);
            if (b(listA, arrayList)) {
                return providerInfoResolveContentProvider;
            }
        }
        return null;
    }

    public static Map<Uri, ByteBuffer> i(Context context, f[] fVarArr, CancellationSignal cancellationSignal) {
        HashMap map = new HashMap();
        for (f fVar : fVarArr) {
            if (fVar.a() == 0) {
                Uri uriC = fVar.c();
                if (!map.containsKey(uriC)) {
                    map.put(uriC, k.f(context, cancellationSignal, uriC));
                }
            }
        }
        return Collections.unmodifiableMap(map);
    }
}
