package c.f.i;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class f<T> implements e<T> {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final Object[] f149a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private int f150b;

    public f(int i) {
        if (i <= 0) {
            throw new IllegalArgumentException("The max pool size must be > 0");
        }
        this.f149a = new Object[i];
    }

    private boolean c(T t) {
        for (int i = 0; i < this.f150b; i++) {
            if (this.f149a[i] == t) {
                return true;
            }
        }
        return false;
    }

    @Override // c.f.i.e
    public boolean a(T t) {
        if (c(t)) {
            throw new IllegalStateException("Already in the pool!");
        }
        int i = this.f150b;
        Object[] objArr = this.f149a;
        if (i >= objArr.length) {
            return false;
        }
        objArr[i] = t;
        this.f150b = i + 1;
        return true;
    }

    @Override // c.f.i.e
    public T b() {
        int i = this.f150b;
        if (i <= 0) {
            return null;
        }
        int i2 = i - 1;
        Object[] objArr = this.f149a;
        T t = (T) objArr[i2];
        objArr[i2] = null;
        this.f150b = i - 1;
        return t;
    }
}
