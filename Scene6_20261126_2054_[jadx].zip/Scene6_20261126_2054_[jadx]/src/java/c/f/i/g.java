package c.f.i;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class g<T> extends f<T> {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final Object f151c;

    public g(int i) {
        super(i);
        this.f151c = new Object();
    }

    @Override // c.f.i.f, c.f.i.e
    public boolean a(T t) {
        boolean zA;
        synchronized (this.f151c) {
            zA = super.a(t);
        }
        return zA;
    }

    @Override // c.f.i.f, c.f.i.e
    public T b() {
        T t;
        synchronized (this.f151c) {
            t = (T) super.b();
        }
        return t;
    }
}
