package c.f.i;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class d<F, S> {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final F f147a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final S f148b;

    public boolean equals(Object obj) {
        if (!(obj instanceof d)) {
            return false;
        }
        d dVar = (d) obj;
        return c.a(dVar.f147a, this.f147a) && c.a(dVar.f148b, this.f148b);
    }

    public int hashCode() {
        F f = this.f147a;
        int iHashCode = f == null ? 0 : f.hashCode();
        S s = this.f148b;
        return iHashCode ^ (s != null ? s.hashCode() : 0);
    }

    public String toString() {
        return "Pair{" + this.f147a + " " + this.f148b + "}";
    }
}
