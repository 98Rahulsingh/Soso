package c.h.b;

import android.graphics.Rect;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import c.d.h;
import c.f.j.f0.d;
import c.f.j.f0.e;
import c.f.j.u;
import c.f.j.x;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public abstract class a extends c.f.j.a {
    private static final Rect n = new Rect(Integer.MAX_VALUE, Integer.MAX_VALUE, Integer.MIN_VALUE, Integer.MIN_VALUE);
    private static final c.h.b.b.a<c.f.j.f0.c> o = new C0022a();
    private static final c.h.b.b.InterfaceC0023b<h<c.f.j.f0.c>, c.f.j.f0.c> p = new b();
    private final AccessibilityManager h;
    private final View i;
    private c j;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private final Rect f232d = new Rect();
    private final Rect e = new Rect();
    private final Rect f = new Rect();
    private final int[] g = new int[2];
    int k = Integer.MIN_VALUE;
    int l = Integer.MIN_VALUE;
    private int m = Integer.MIN_VALUE;

    /* JADX INFO: renamed from: c.h.b.a$a, reason: collision with other inner class name */
    static class C0022a implements c.h.b.b.a<c.f.j.f0.c> {
        C0022a() {
        }

        @Override // c.h.b.b.a
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public void a(c.f.j.f0.c cVar, Rect rect) {
            cVar.m(rect);
        }
    }

    static class b implements c.h.b.b.InterfaceC0023b<h<c.f.j.f0.c>, c.f.j.f0.c> {
        b() {
        }

        @Override // c.h.b.b.InterfaceC0023b
        /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
        public c.f.j.f0.c b(h<c.f.j.f0.c> hVar, int i) {
            return hVar.m(i);
        }

        @Override // c.h.b.b.InterfaceC0023b
        /* JADX INFO: renamed from: d, reason: merged with bridge method [inline-methods] */
        public int a(h<c.f.j.f0.c> hVar) {
            return hVar.l();
        }
    }

    private class c extends d {
        c() {
        }

        @Override // c.f.j.f0.d
        public c.f.j.f0.c b(int i) {
            return c.f.j.f0.c.P(a.this.H(i));
        }

        @Override // c.f.j.f0.d
        public c.f.j.f0.c d(int i) {
            int i2 = i == 2 ? a.this.k : a.this.l;
            if (i2 == Integer.MIN_VALUE) {
                return null;
            }
            return b(i2);
        }

        @Override // c.f.j.f0.d
        public boolean f(int i, int i2, Bundle bundle) {
            return a.this.P(i, i2, bundle);
        }
    }

    public a(View view) {
        if (view == null) {
            throw new IllegalArgumentException("View may not be null");
        }
        this.i = view;
        this.h = (AccessibilityManager) view.getContext().getSystemService("accessibility");
        view.setFocusable(true);
        if (u.w(view) == 0) {
            u.u0(view, 1);
        }
    }

    private static Rect D(View view, int i, Rect rect) {
        int width = view.getWidth();
        int height = view.getHeight();
        if (i == 17) {
            rect.set(width, 0, width, height);
        } else if (i == 33) {
            rect.set(0, height, width, height);
        } else if (i == 66) {
            rect.set(-1, 0, -1, height);
        } else {
            if (i != 130) {
                throw new IllegalArgumentException("direction must be one of {FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}.");
            }
            rect.set(0, -1, width, -1);
        }
        return rect;
    }

    private boolean E(Rect rect) {
        if (rect == null || rect.isEmpty() || this.i.getWindowVisibility() != 0) {
            return false;
        }
        View view = this.i;
        do {
            Object parent = view.getParent();
            if (!(parent instanceof View)) {
                return parent != null;
            }
            view = (View) parent;
            if (view.getAlpha() <= 0.0f) {
                break;
            }
        } while (view.getVisibility() == 0);
        return false;
    }

    private static int F(int i) {
        if (i == 19) {
            return 33;
        }
        if (i != 21) {
            return i != 22 ? 130 : 66;
        }
        return 17;
    }

    private boolean G(int i, Rect rect) {
        Object objD;
        h<c.f.j.f0.c> hVarY = y();
        int i2 = this.l;
        c.f.j.f0.c cVarE = i2 == Integer.MIN_VALUE ? null : hVarY.e(i2);
        if (i == 1 || i == 2) {
            objD = c.h.b.b.d(hVarY, p, o, cVarE, i, u.y(this.i) == 1, false);
        } else {
            if (i != 17 && i != 33 && i != 66 && i != 130) {
                throw new IllegalArgumentException("direction must be one of {FOCUS_FORWARD, FOCUS_BACKWARD, FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}.");
            }
            Rect rect2 = new Rect();
            int i3 = this.l;
            if (i3 != Integer.MIN_VALUE) {
                z(i3, rect2);
            } else if (rect != null) {
                rect2.set(rect);
            } else {
                D(this.i, i, rect2);
            }
            objD = c.h.b.b.c(hVarY, p, o, cVarE, rect2, i);
        }
        c.f.j.f0.c cVar = (c.f.j.f0.c) objD;
        return T(cVar != null ? hVarY.i(hVarY.h(cVar)) : Integer.MIN_VALUE);
    }

    private boolean Q(int i, int i2, Bundle bundle) {
        if (i2 == 1) {
            return T(i);
        }
        if (i2 == 2) {
            return o(i);
        }
        if (i2 != 64) {
            return i2 != 128 ? J(i, i2, bundle) : n(i);
        }
        return S(i);
    }

    private boolean R(int i, Bundle bundle) {
        return u.a0(this.i, i, bundle);
    }

    private boolean S(int i) {
        int i2;
        if (!this.h.isEnabled() || !this.h.isTouchExplorationEnabled() || (i2 = this.k) == i) {
            return false;
        }
        if (i2 != Integer.MIN_VALUE) {
            n(i2);
        }
        this.k = i;
        this.i.invalidate();
        U(i, 32768);
        return true;
    }

    private void V(int i) {
        int i2 = this.m;
        if (i2 == i) {
            return;
        }
        this.m = i;
        U(i, 128);
        U(i2, 256);
    }

    private boolean n(int i) {
        if (this.k != i) {
            return false;
        }
        this.k = Integer.MIN_VALUE;
        this.i.invalidate();
        U(i, 65536);
        return true;
    }

    private boolean p() {
        int i = this.l;
        return i != Integer.MIN_VALUE && J(i, 16, null);
    }

    private AccessibilityEvent q(int i, int i2) {
        return i != -1 ? r(i, i2) : s(i2);
    }

    private AccessibilityEvent r(int i, int i2) {
        AccessibilityEvent accessibilityEventObtain = AccessibilityEvent.obtain(i2);
        c.f.j.f0.c cVarH = H(i);
        accessibilityEventObtain.getText().add(cVarH.w());
        accessibilityEventObtain.setContentDescription(cVarH.r());
        accessibilityEventObtain.setScrollable(cVarH.J());
        accessibilityEventObtain.setPassword(cVarH.I());
        accessibilityEventObtain.setEnabled(cVarH.E());
        accessibilityEventObtain.setChecked(cVarH.C());
        L(i, accessibilityEventObtain);
        if (accessibilityEventObtain.getText().isEmpty() && accessibilityEventObtain.getContentDescription() == null) {
            throw new RuntimeException("Callbacks must add text or a content description in populateEventForVirtualViewId()");
        }
        accessibilityEventObtain.setClassName(cVarH.p());
        e.c(accessibilityEventObtain, this.i, i);
        accessibilityEventObtain.setPackageName(this.i.getContext().getPackageName());
        return accessibilityEventObtain;
    }

    private AccessibilityEvent s(int i) {
        AccessibilityEvent accessibilityEventObtain = AccessibilityEvent.obtain(i);
        this.i.onInitializeAccessibilityEvent(accessibilityEventObtain);
        return accessibilityEventObtain;
    }

    private c.f.j.f0.c t(int i) {
        c.f.j.f0.c cVarN = c.f.j.f0.c.N();
        cVarN.g0(true);
        cVarN.i0(true);
        cVarN.a0("android.view.View");
        cVarN.W(n);
        cVarN.X(n);
        cVarN.q0(this.i);
        N(i, cVarN);
        if (cVarN.w() == null && cVarN.r() == null) {
            throw new RuntimeException("Callbacks must add text or a content description in populateNodeForVirtualViewId()");
        }
        cVarN.m(this.e);
        if (this.e.equals(n)) {
            throw new RuntimeException("Callbacks must set parent bounds in populateNodeForVirtualViewId()");
        }
        int iK = cVarN.k();
        if ((iK & 64) != 0) {
            throw new RuntimeException("Callbacks must not add ACTION_ACCESSIBILITY_FOCUS in populateNodeForVirtualViewId()");
        }
        if ((iK & 128) != 0) {
            throw new RuntimeException("Callbacks must not add ACTION_CLEAR_ACCESSIBILITY_FOCUS in populateNodeForVirtualViewId()");
        }
        cVarN.o0(this.i.getContext().getPackageName());
        cVarN.y0(this.i, i);
        if (this.k == i) {
            cVarN.U(true);
            cVarN.a(128);
        } else {
            cVarN.U(false);
            cVarN.a(64);
        }
        boolean z = this.l == i;
        if (z) {
            cVarN.a(2);
        } else if (cVarN.F()) {
            cVarN.a(1);
        }
        cVarN.j0(z);
        this.i.getLocationOnScreen(this.g);
        cVarN.n(this.f232d);
        if (this.f232d.equals(n)) {
            cVarN.m(this.f232d);
            if (cVarN.f186b != -1) {
                c.f.j.f0.c cVarN2 = c.f.j.f0.c.N();
                for (int i2 = cVarN.f186b; i2 != -1; i2 = cVarN2.f186b) {
                    cVarN2.r0(this.i, -1);
                    cVarN2.W(n);
                    N(i2, cVarN2);
                    cVarN2.m(this.e);
                    Rect rect = this.f232d;
                    Rect rect2 = this.e;
                    rect.offset(rect2.left, rect2.top);
                }
                cVarN2.R();
            }
            this.f232d.offset(this.g[0] - this.i.getScrollX(), this.g[1] - this.i.getScrollY());
        }
        if (this.i.getLocalVisibleRect(this.f)) {
            this.f.offset(this.g[0] - this.i.getScrollX(), this.g[1] - this.i.getScrollY());
            if (this.f232d.intersect(this.f)) {
                cVarN.X(this.f232d);
                if (E(this.f232d)) {
                    cVarN.B0(true);
                }
            }
        }
        return cVarN;
    }

    private c.f.j.f0.c u() {
        c.f.j.f0.c cVarO = c.f.j.f0.c.O(this.i);
        u.Y(this.i, cVarO);
        ArrayList arrayList = new ArrayList();
        C(arrayList);
        if (cVarO.o() > 0 && arrayList.size() > 0) {
            throw new RuntimeException("Views cannot have both real and virtual children");
        }
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            cVarO.d(this.i, ((Integer) arrayList.get(i)).intValue());
        }
        return cVarO;
    }

    private h<c.f.j.f0.c> y() {
        ArrayList arrayList = new ArrayList();
        C(arrayList);
        h<c.f.j.f0.c> hVar = new h<>();
        for (int i = 0; i < arrayList.size(); i++) {
            hVar.j(i, t(i));
        }
        return hVar;
    }

    private void z(int i, Rect rect) {
        H(i).m(rect);
    }

    public final int A() {
        return this.l;
    }

    protected abstract int B(float f, float f2);

    protected abstract void C(List<Integer> list);

    c.f.j.f0.c H(int i) {
        return i == -1 ? u() : t(i);
    }

    public final void I(boolean z, int i, Rect rect) {
        int i2 = this.l;
        if (i2 != Integer.MIN_VALUE) {
            o(i2);
        }
        if (z) {
            G(i, rect);
        }
    }

    protected abstract boolean J(int i, int i2, Bundle bundle);

    protected void K(AccessibilityEvent accessibilityEvent) {
    }

    protected void L(int i, AccessibilityEvent accessibilityEvent) {
    }

    protected void M(c.f.j.f0.c cVar) {
    }

    protected abstract void N(int i, c.f.j.f0.c cVar);

    protected void O(int i, boolean z) {
    }

    boolean P(int i, int i2, Bundle bundle) {
        return i != -1 ? Q(i, i2, bundle) : R(i2, bundle);
    }

    public final boolean T(int i) {
        int i2;
        if ((!this.i.isFocused() && !this.i.requestFocus()) || (i2 = this.l) == i) {
            return false;
        }
        if (i2 != Integer.MIN_VALUE) {
            o(i2);
        }
        this.l = i;
        O(i, true);
        U(i, 8);
        return true;
    }

    public final boolean U(int i, int i2) {
        ViewParent parent;
        if (i == Integer.MIN_VALUE || !this.h.isEnabled() || (parent = this.i.getParent()) == null) {
            return false;
        }
        return x.h(parent, this.i, q(i, i2));
    }

    @Override // c.f.j.a
    public d b(View view) {
        if (this.j == null) {
            this.j = new c();
        }
        return this.j;
    }

    @Override // c.f.j.a
    public void f(View view, AccessibilityEvent accessibilityEvent) {
        super.f(view, accessibilityEvent);
        K(accessibilityEvent);
    }

    @Override // c.f.j.a
    public void g(View view, c.f.j.f0.c cVar) {
        super.g(view, cVar);
        M(cVar);
    }

    public final boolean o(int i) {
        if (this.l != i) {
            return false;
        }
        this.l = Integer.MIN_VALUE;
        O(i, false);
        U(i, 8);
        return true;
    }

    public final boolean v(MotionEvent motionEvent) {
        if (!this.h.isEnabled() || !this.h.isTouchExplorationEnabled()) {
            return false;
        }
        int action = motionEvent.getAction();
        if (action == 7 || action == 9) {
            int iB = B(motionEvent.getX(), motionEvent.getY());
            V(iB);
            return iB != Integer.MIN_VALUE;
        }
        if (action != 10 || this.m == Integer.MIN_VALUE) {
            return false;
        }
        V(Integer.MIN_VALUE);
        return true;
    }

    public final boolean w(KeyEvent keyEvent) {
        int i = 0;
        if (keyEvent.getAction() == 1) {
            return false;
        }
        int keyCode = keyEvent.getKeyCode();
        if (keyCode == 61) {
            if (keyEvent.hasNoModifiers()) {
                return G(2, null);
            }
            if (keyEvent.hasModifiers(1)) {
                return G(1, null);
            }
            return false;
        }
        if (keyCode != 66) {
            switch (keyCode) {
                case 19:
                case 20:
                case 21:
                case 22:
                    if (!keyEvent.hasNoModifiers()) {
                        return false;
                    }
                    int iF = F(keyCode);
                    int repeatCount = keyEvent.getRepeatCount() + 1;
                    boolean z = false;
                    while (i < repeatCount && G(iF, null)) {
                        i++;
                        z = true;
                    }
                    return z;
                case 23:
                    break;
                default:
                    return false;
            }
        }
        if (!keyEvent.hasNoModifiers() || keyEvent.getRepeatCount() != 0) {
            return false;
        }
        p();
        return true;
    }

    public final int x() {
        return this.k;
    }
}
