package c.g.a;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public abstract class c extends a {
    private int n;
    private int o;
    private LayoutInflater p;

    @Deprecated
    public c(Context context, int i, Cursor cursor, boolean z) {
        super(context, cursor, z);
        this.o = i;
        this.n = i;
        this.p = (LayoutInflater) context.getSystemService("layout_inflater");
    }

    @Override // c.g.a.a
    public View g(Context context, Cursor cursor, ViewGroup viewGroup) {
        return this.p.inflate(this.o, viewGroup, false);
    }

    @Override // c.g.a.a
    public View h(Context context, Cursor cursor, ViewGroup viewGroup) {
        return this.p.inflate(this.n, viewGroup, false);
    }
}
