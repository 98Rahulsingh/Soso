package c.m;

import android.view.ViewGroup;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public abstract class p {
    public abstract void a(s sVar);

    public abstract String[] b();

    public abstract long c(ViewGroup viewGroup, m mVar, s sVar, s sVar2);
}
