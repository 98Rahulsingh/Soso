package c.m;

import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.ViewOverlay;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
class a0 implements b0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final ViewOverlay f252a;

    a0(View view) {
        this.f252a = view.getOverlay();
    }

    @Override // c.m.b0
    public void b(Drawable drawable) {
        this.f252a.add(drawable);
    }

    @Override // c.m.b0
    public void d(Drawable drawable) {
        this.f252a.remove(drawable);
    }
}
