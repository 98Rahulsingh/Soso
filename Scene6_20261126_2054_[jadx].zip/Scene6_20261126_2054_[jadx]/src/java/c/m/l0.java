package c.m;

import android.view.View;
import android.view.WindowId;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
class l0 implements m0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final WindowId f304a;

    l0(View view) {
        this.f304a = view.getWindowId();
    }

    public boolean equals(Object obj) {
        return (obj instanceof l0) && ((l0) obj).f304a.equals(this.f304a);
    }

    public int hashCode() {
        return this.f304a.hashCode();
    }
}
