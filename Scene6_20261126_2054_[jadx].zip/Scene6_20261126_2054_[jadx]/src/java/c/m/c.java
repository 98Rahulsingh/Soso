package c.m;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.util.Property;
import android.view.View;
import android.view.ViewGroup;
import java.util.Map;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class c extends m {
    private static final String[] R = {"android:changeBounds:bounds", "android:changeBounds:clip", "android:changeBounds:parent", "android:changeBounds:windowX", "android:changeBounds:windowY"};
    private static final Property<Drawable, PointF> S = new b(PointF.class, "boundsOrigin");
    private static final Property<k, PointF> T = new C0027c(PointF.class, "topLeft");
    private static final Property<k, PointF> U = new d(PointF.class, "bottomRight");
    private static final Property<View, PointF> V = new e(PointF.class, "bottomRight");
    private static final Property<View, PointF> W = new f(PointF.class, "topLeft");
    private static final Property<View, PointF> X = new g(PointF.class, "position");
    private static c.m.k Y = new c.m.k();
    private int[] O = new int[2];
    private boolean P = false;
    private boolean Q = false;

    class a extends AnimatorListenerAdapter {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final /* synthetic */ ViewGroup f253a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final /* synthetic */ BitmapDrawable f254b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        final /* synthetic */ View f255c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ float f256d;

        a(c cVar, ViewGroup viewGroup, BitmapDrawable bitmapDrawable, View view, float f) {
            this.f253a = viewGroup;
            this.f254b = bitmapDrawable;
            this.f255c = view;
            this.f256d = f;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            c0.b(this.f253a).d(this.f254b);
            c0.g(this.f255c, this.f256d);
        }
    }

    static class b extends Property<Drawable, PointF> {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private Rect f257a;

        b(Class cls, String str) {
            super(cls, str);
            this.f257a = new Rect();
        }

        @Override // android.util.Property
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public PointF get(Drawable drawable) {
            drawable.copyBounds(this.f257a);
            Rect rect = this.f257a;
            return new PointF(rect.left, rect.top);
        }

        @Override // android.util.Property
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public void set(Drawable drawable, PointF pointF) {
            drawable.copyBounds(this.f257a);
            this.f257a.offsetTo(Math.round(pointF.x), Math.round(pointF.y));
            drawable.setBounds(this.f257a);
        }
    }

    /* JADX INFO: renamed from: c.m.c$c, reason: collision with other inner class name */
    static class C0027c extends Property<k, PointF> {
        C0027c(Class cls, String str) {
            super(cls, str);
        }

        @Override // android.util.Property
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public PointF get(k kVar) {
            return null;
        }

        @Override // android.util.Property
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public void set(k kVar, PointF pointF) {
            kVar.c(pointF);
        }
    }

    static class d extends Property<k, PointF> {
        d(Class cls, String str) {
            super(cls, str);
        }

        @Override // android.util.Property
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public PointF get(k kVar) {
            return null;
        }

        @Override // android.util.Property
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public void set(k kVar, PointF pointF) {
            kVar.a(pointF);
        }
    }

    static class e extends Property<View, PointF> {
        e(Class cls, String str) {
            super(cls, str);
        }

        @Override // android.util.Property
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public PointF get(View view) {
            return null;
        }

        @Override // android.util.Property
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public void set(View view, PointF pointF) {
            c0.f(view, view.getLeft(), view.getTop(), Math.round(pointF.x), Math.round(pointF.y));
        }
    }

    static class f extends Property<View, PointF> {
        f(Class cls, String str) {
            super(cls, str);
        }

        @Override // android.util.Property
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public PointF get(View view) {
            return null;
        }

        @Override // android.util.Property
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public void set(View view, PointF pointF) {
            c0.f(view, Math.round(pointF.x), Math.round(pointF.y), view.getRight(), view.getBottom());
        }
    }

    static class g extends Property<View, PointF> {
        g(Class cls, String str) {
            super(cls, str);
        }

        @Override // android.util.Property
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public PointF get(View view) {
            return null;
        }

        @Override // android.util.Property
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public void set(View view, PointF pointF) {
            int iRound = Math.round(pointF.x);
            int iRound2 = Math.round(pointF.y);
            c0.f(view, iRound, iRound2, view.getWidth() + iRound, view.getHeight() + iRound2);
        }
    }

    class h extends AnimatorListenerAdapter {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final /* synthetic */ k f258a;
        private k mViewBounds;

        h(c cVar, k kVar) {
            this.f258a = kVar;
            this.mViewBounds = this.f258a;
        }
    }

    class i extends AnimatorListenerAdapter {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private boolean f259a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final /* synthetic */ View f260b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        final /* synthetic */ Rect f261c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ int f262d;
        final /* synthetic */ int e;
        final /* synthetic */ int f;
        final /* synthetic */ int g;

        i(c cVar, View view, Rect rect, int i, int i2, int i3, int i4) {
            this.f260b = view;
            this.f261c = rect;
            this.f262d = i;
            this.e = i2;
            this.f = i3;
            this.g = i4;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationCancel(Animator animator) {
            this.f259a = true;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            if (this.f259a) {
                return;
            }
            c.f.j.u.q0(this.f260b, this.f261c);
            c0.f(this.f260b, this.f262d, this.e, this.f, this.g);
        }
    }

    class j extends n {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        boolean f263a = false;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final /* synthetic */ ViewGroup f264b;

        j(c cVar, ViewGroup viewGroup) {
            this.f264b = viewGroup;
        }

        @Override // c.m.n, c.m.m.f
        public void a(m mVar) {
            x.c(this.f264b, false);
        }

        @Override // c.m.n, c.m.m.f
        public void b(m mVar) {
            x.c(this.f264b, true);
        }

        @Override // c.m.n, c.m.m.f
        public void d(m mVar) {
            x.c(this.f264b, false);
            this.f263a = true;
        }

        @Override // c.m.m.f
        public void e(m mVar) {
            if (!this.f263a) {
                x.c(this.f264b, false);
            }
            mVar.P(this);
        }
    }

    private static class k {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private int f265a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private int f266b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private int f267c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        private int f268d;
        private View e;
        private int f;
        private int g;

        k(View view) {
            this.e = view;
        }

        private void b() {
            c0.f(this.e, this.f265a, this.f266b, this.f267c, this.f268d);
            this.f = 0;
            this.g = 0;
        }

        void a(PointF pointF) {
            this.f267c = Math.round(pointF.x);
            this.f268d = Math.round(pointF.y);
            int i = this.g + 1;
            this.g = i;
            if (this.f == i) {
                b();
            }
        }

        void c(PointF pointF) {
            this.f265a = Math.round(pointF.x);
            this.f266b = Math.round(pointF.y);
            int i = this.f + 1;
            this.f = i;
            if (i == this.g) {
                b();
            }
        }
    }

    private void c0(s sVar) {
        View view = sVar.f323b;
        if (!c.f.j.u.Q(view) && view.getWidth() == 0 && view.getHeight() == 0) {
            return;
        }
        sVar.f322a.put("android:changeBounds:bounds", new Rect(view.getLeft(), view.getTop(), view.getRight(), view.getBottom()));
        sVar.f322a.put("android:changeBounds:parent", sVar.f323b.getParent());
        if (this.Q) {
            sVar.f323b.getLocationInWindow(this.O);
            sVar.f322a.put("android:changeBounds:windowX", Integer.valueOf(this.O[0]));
            sVar.f322a.put("android:changeBounds:windowY", Integer.valueOf(this.O[1]));
        }
        if (this.P) {
            sVar.f322a.put("android:changeBounds:clip", c.f.j.u.r(view));
        }
    }

    private boolean d0(View view, View view2) {
        if (!this.Q) {
            return true;
        }
        s sVarT = t(view, true);
        if (sVarT == null) {
            if (view == view2) {
                return true;
            }
        } else if (view2 == sVarT.f323b) {
            return true;
        }
        return false;
    }

    @Override // c.m.m
    public String[] D() {
        return R;
    }

    @Override // c.m.m
    public void g(s sVar) {
        c0(sVar);
    }

    @Override // c.m.m
    public void j(s sVar) {
        c0(sVar);
    }

    @Override // c.m.m
    public Animator n(ViewGroup viewGroup, s sVar, s sVar2) {
        int i2;
        View view;
        ObjectAnimator objectAnimatorA;
        int i3;
        Rect rect;
        ObjectAnimator objectAnimator;
        Animator animatorC;
        Path pathA;
        Property<View, PointF> property;
        if (sVar == null || sVar2 == null) {
            return null;
        }
        Map<String, Object> map = sVar.f322a;
        Map<String, Object> map2 = sVar2.f322a;
        ViewGroup viewGroup2 = (ViewGroup) map.get("android:changeBounds:parent");
        ViewGroup viewGroup3 = (ViewGroup) map2.get("android:changeBounds:parent");
        if (viewGroup2 == null || viewGroup3 == null) {
            return null;
        }
        View view2 = sVar2.f323b;
        if (!d0(viewGroup2, viewGroup3)) {
            int iIntValue = ((Integer) sVar.f322a.get("android:changeBounds:windowX")).intValue();
            int iIntValue2 = ((Integer) sVar.f322a.get("android:changeBounds:windowY")).intValue();
            int iIntValue3 = ((Integer) sVar2.f322a.get("android:changeBounds:windowX")).intValue();
            int iIntValue4 = ((Integer) sVar2.f322a.get("android:changeBounds:windowY")).intValue();
            if (iIntValue == iIntValue3 && iIntValue2 == iIntValue4) {
                return null;
            }
            viewGroup.getLocationInWindow(this.O);
            Bitmap bitmapCreateBitmap = Bitmap.createBitmap(view2.getWidth(), view2.getHeight(), Bitmap.Config.ARGB_8888);
            view2.draw(new Canvas(bitmapCreateBitmap));
            BitmapDrawable bitmapDrawable = new BitmapDrawable(bitmapCreateBitmap);
            float fC = c0.c(view2);
            c0.g(view2, 0.0f);
            c0.b(viewGroup).b(bitmapDrawable);
            c.m.g gVarV = v();
            int[] iArr = this.O;
            ObjectAnimator objectAnimatorOfPropertyValuesHolder = ObjectAnimator.ofPropertyValuesHolder(bitmapDrawable, c.m.i.a(S, gVarV.a(iIntValue - iArr[0], iIntValue2 - iArr[1], iIntValue3 - iArr[0], iIntValue4 - iArr[1])));
            objectAnimatorOfPropertyValuesHolder.addListener(new a(this, viewGroup, bitmapDrawable, view2, fC));
            return objectAnimatorOfPropertyValuesHolder;
        }
        Rect rect2 = (Rect) sVar.f322a.get("android:changeBounds:bounds");
        Rect rect3 = (Rect) sVar2.f322a.get("android:changeBounds:bounds");
        int i4 = rect2.left;
        int i5 = rect3.left;
        int i6 = rect2.top;
        int i7 = rect3.top;
        int i8 = rect2.right;
        int i9 = rect3.right;
        int i10 = rect2.bottom;
        int i11 = rect3.bottom;
        int i12 = i8 - i4;
        int i13 = i10 - i6;
        int i14 = i9 - i5;
        int i15 = i11 - i7;
        Rect rect4 = (Rect) sVar.f322a.get("android:changeBounds:clip");
        Rect rect5 = (Rect) sVar2.f322a.get("android:changeBounds:clip");
        if ((i12 == 0 || i13 == 0) && (i14 == 0 || i15 == 0)) {
            i2 = 0;
        } else {
            i2 = (i4 == i5 && i6 == i7) ? 0 : 1;
            if (i8 != i9 || i10 != i11) {
                i2++;
            }
        }
        if ((rect4 != null && !rect4.equals(rect5)) || (rect4 == null && rect5 != null)) {
            i2++;
        }
        if (i2 <= 0) {
            return null;
        }
        if (this.P) {
            c0.f(view, i4, i6, Math.max(i12, i14) + i4, Math.max(i13, i15) + i6);
            if (i4 == i5 && i6 == i7) {
                objectAnimatorA = null;
            } else {
                view = view2;
                objectAnimatorA = c.m.f.a(view, X, v().a(i4, i6, i5, i7));
            }
            if (rect4 == null) {
                i3 = 0;
                rect = new Rect(0, 0, i12, i13);
            } else {
                i3 = 0;
                rect = rect4;
            }
            Rect rect6 = rect5 == null ? new Rect(i3, i3, i14, i15) : rect5;
            if (rect.equals(rect6)) {
                objectAnimator = null;
            } else {
                c.f.j.u.q0(view, rect);
                c.m.k kVar = Y;
                Object[] objArr = new Object[2];
                objArr[i3] = rect;
                objArr[1] = rect6;
                ObjectAnimator objectAnimatorOfObject = ObjectAnimator.ofObject(view, "clipBounds", kVar, objArr);
                objectAnimatorOfObject.addListener(new i(this, view, rect5, i5, i7, i9, i11));
                objectAnimator = objectAnimatorOfObject;
            }
            animatorC = r.c(objectAnimatorA, objectAnimator);
        } else {
            c0.f(view, i4, i6, i8, i10);
            if (i2 == 2) {
                if (i12 == i14 && i13 == i15) {
                    pathA = v().a(i4, i6, i5, i7);
                    property = X;
                } else {
                    k kVar2 = new k(view);
                    ObjectAnimator objectAnimatorA2 = c.m.f.a(kVar2, T, v().a(i4, i6, i5, i7));
                    ObjectAnimator objectAnimatorA3 = c.m.f.a(kVar2, U, v().a(i8, i10, i9, i11));
                    AnimatorSet animatorSet = new AnimatorSet();
                    animatorSet.playTogether(objectAnimatorA2, objectAnimatorA3);
                    animatorSet.addListener(new h(this, kVar2));
                    animatorC = animatorSet;
                }
            } else if (i4 == i5 && i6 == i7) {
                pathA = v().a(i8, i10, i9, i11);
                property = V;
            } else {
                pathA = v().a(i4, i6, i5, i7);
                property = W;
            }
            animatorC = c.m.f.a(view, property, pathA);
        }
        if (view.getParent() instanceof ViewGroup) {
            ViewGroup viewGroup4 = (ViewGroup) view.getParent();
            x.c(viewGroup4, true);
            a(new j(this, viewGroup4));
        }
        return animatorC;
    }
}
