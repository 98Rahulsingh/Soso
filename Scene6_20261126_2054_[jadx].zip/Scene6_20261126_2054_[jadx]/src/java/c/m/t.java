package c.m;

import android.util.SparseArray;
import android.view.View;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
class t {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    final c.d.a<View, s> f325a = new c.d.a<>();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    final SparseArray<View> f326b = new SparseArray<>();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    final c.d.d<View> f327c = new c.d.d<>();

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    final c.d.a<String, View> f328d = new c.d.a<>();

    t() {
    }
}
