package c.m;

import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroupOverlay;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
class v implements w {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final ViewGroupOverlay f329a;

    v(ViewGroup viewGroup) {
        this.f329a = viewGroup.getOverlay();
    }

    @Override // c.m.w
    public void a(View view) {
        this.f329a.add(view);
    }

    @Override // c.m.b0
    public void b(Drawable drawable) {
        this.f329a.add(drawable);
    }

    @Override // c.m.w
    public void c(View view) {
        this.f329a.remove(view);
    }

    @Override // c.m.b0
    public void d(Drawable drawable) {
        this.f329a.remove(drawable);
    }
}
