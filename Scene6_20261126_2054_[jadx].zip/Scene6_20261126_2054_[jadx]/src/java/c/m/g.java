package c.m;

import android.graphics.Path;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public abstract class g {
    public abstract Path a(float f, float f2, float f3, float f4);
}
