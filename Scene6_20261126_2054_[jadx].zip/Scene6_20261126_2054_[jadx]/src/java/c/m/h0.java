package c.m;

import android.graphics.Matrix;
import android.view.View;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
class h0 extends g0 {
    h0() {
    }

    @Override // c.m.d0, c.m.i0
    public float c(View view) {
        return view.getTransitionAlpha();
    }

    @Override // c.m.f0, c.m.i0
    public void e(View view, int i, int i2, int i3, int i4) {
        view.setLeftTopRightBottom(i, i2, i3, i4);
    }

    @Override // c.m.d0, c.m.i0
    public void f(View view, float f) {
        view.setTransitionAlpha(f);
    }

    @Override // c.m.g0, c.m.i0
    public void g(View view, int i) {
        view.setTransitionVisibility(i);
    }

    @Override // c.m.e0, c.m.i0
    public void h(View view, Matrix matrix) {
        view.transformMatrixToGlobal(matrix);
    }

    @Override // c.m.e0, c.m.i0
    public void i(View view, Matrix matrix) {
        view.transformMatrixToLocal(matrix);
    }
}
