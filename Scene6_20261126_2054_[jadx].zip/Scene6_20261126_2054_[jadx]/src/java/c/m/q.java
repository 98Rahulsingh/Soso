package c.m;

import android.animation.TimeInterpolator;
import android.util.AndroidRuntimeException;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.Iterator;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class q extends m {
    int Q;
    private ArrayList<m> O = new ArrayList<>();
    private boolean P = true;
    boolean R = false;
    private int S = 0;

    class a extends n {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final /* synthetic */ m f317a;

        a(q qVar, m mVar) {
            this.f317a = mVar;
        }

        @Override // c.m.m.f
        public void e(m mVar) {
            this.f317a.T();
            mVar.P(this);
        }
    }

    static class b extends n {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        q f318a;

        b(q qVar) {
            this.f318a = qVar;
        }

        @Override // c.m.n, c.m.m.f
        public void c(m mVar) {
            q qVar = this.f318a;
            if (qVar.R) {
                return;
            }
            qVar.a0();
            this.f318a.R = true;
        }

        @Override // c.m.m.f
        public void e(m mVar) {
            q qVar = this.f318a;
            int i = qVar.Q - 1;
            qVar.Q = i;
            if (i == 0) {
                qVar.R = false;
                qVar.p();
            }
            mVar.P(this);
        }
    }

    private void f0(m mVar) {
        this.O.add(mVar);
        mVar.w = this;
    }

    private void o0() {
        b bVar = new b(this);
        Iterator<m> it = this.O.iterator();
        while (it.hasNext()) {
            it.next().a(bVar);
        }
        this.Q = this.O.size();
    }

    @Override // c.m.m
    public void N(View view) {
        super.N(view);
        int size = this.O.size();
        for (int i = 0; i < size; i++) {
            this.O.get(i).N(view);
        }
    }

    @Override // c.m.m
    public void R(View view) {
        super.R(view);
        int size = this.O.size();
        for (int i = 0; i < size; i++) {
            this.O.get(i).R(view);
        }
    }

    @Override // c.m.m
    protected void T() {
        if (this.O.isEmpty()) {
            a0();
            p();
            return;
        }
        o0();
        if (this.P) {
            Iterator<m> it = this.O.iterator();
            while (it.hasNext()) {
                it.next().T();
            }
            return;
        }
        for (int i = 1; i < this.O.size(); i++) {
            this.O.get(i - 1).a(new a(this, this.O.get(i)));
        }
        m mVar = this.O.get(0);
        if (mVar != null) {
            mVar.T();
        }
    }

    @Override // c.m.m
    public /* bridge */ /* synthetic */ m U(long j) {
        k0(j);
        return this;
    }

    @Override // c.m.m
    public void V(m.e eVar) {
        super.V(eVar);
        this.S |= 8;
        int size = this.O.size();
        for (int i = 0; i < size; i++) {
            this.O.get(i).V(eVar);
        }
    }

    @Override // c.m.m
    public void X(g gVar) {
        super.X(gVar);
        this.S |= 4;
        if (this.O != null) {
            for (int i = 0; i < this.O.size(); i++) {
                this.O.get(i).X(gVar);
            }
        }
    }

    @Override // c.m.m
    public void Y(p pVar) {
        super.Y(pVar);
        this.S |= 2;
        int size = this.O.size();
        for (int i = 0; i < size; i++) {
            this.O.get(i).Y(pVar);
        }
    }

    @Override // c.m.m
    String b0(String str) {
        String strB0 = super.b0(str);
        for (int i = 0; i < this.O.size(); i++) {
            StringBuilder sb = new StringBuilder();
            sb.append(strB0);
            sb.append("\n");
            sb.append(this.O.get(i).b0(str + "  "));
            strB0 = sb.toString();
        }
        return strB0;
    }

    @Override // c.m.m
    /* JADX INFO: renamed from: c0, reason: merged with bridge method [inline-methods] */
    public q a(m.f fVar) {
        super.a(fVar);
        return this;
    }

    @Override // c.m.m
    /* JADX INFO: renamed from: d0, reason: merged with bridge method [inline-methods] */
    public q b(View view) {
        for (int i = 0; i < this.O.size(); i++) {
            this.O.get(i).b(view);
        }
        super.b(view);
        return this;
    }

    public q e0(m mVar) {
        f0(mVar);
        long j = this.h;
        if (j >= 0) {
            mVar.U(j);
        }
        if ((this.S & 1) != 0) {
            mVar.W(s());
        }
        if ((this.S & 2) != 0) {
            mVar.Y(w());
        }
        if ((this.S & 4) != 0) {
            mVar.X(v());
        }
        if ((this.S & 8) != 0) {
            mVar.V(r());
        }
        return this;
    }

    @Override // c.m.m
    protected void f() {
        super.f();
        int size = this.O.size();
        for (int i = 0; i < size; i++) {
            this.O.get(i).f();
        }
    }

    @Override // c.m.m
    public void g(s sVar) {
        if (G(sVar.f323b)) {
            for (m mVar : this.O) {
                if (mVar.G(sVar.f323b)) {
                    mVar.g(sVar);
                    sVar.f324c.add(mVar);
                }
            }
        }
    }

    public m g0(int i) {
        if (i < 0 || i >= this.O.size()) {
            return null;
        }
        return this.O.get(i);
    }

    public int h0() {
        return this.O.size();
    }

    @Override // c.m.m
    void i(s sVar) {
        super.i(sVar);
        int size = this.O.size();
        for (int i = 0; i < size; i++) {
            this.O.get(i).i(sVar);
        }
    }

    @Override // c.m.m
    /* JADX INFO: renamed from: i0, reason: merged with bridge method [inline-methods] */
    public q P(m.f fVar) {
        super.P(fVar);
        return this;
    }

    @Override // c.m.m
    public void j(s sVar) {
        if (G(sVar.f323b)) {
            for (m mVar : this.O) {
                if (mVar.G(sVar.f323b)) {
                    mVar.j(sVar);
                    sVar.f324c.add(mVar);
                }
            }
        }
    }

    @Override // c.m.m
    /* JADX INFO: renamed from: j0, reason: merged with bridge method [inline-methods] */
    public q Q(View view) {
        for (int i = 0; i < this.O.size(); i++) {
            this.O.get(i).Q(view);
        }
        super.Q(view);
        return this;
    }

    public q k0(long j) {
        ArrayList<m> arrayList;
        super.U(j);
        if (this.h >= 0 && (arrayList = this.O) != null) {
            int size = arrayList.size();
            for (int i = 0; i < size; i++) {
                this.O.get(i).U(j);
            }
        }
        return this;
    }

    @Override // c.m.m
    /* JADX INFO: renamed from: l0, reason: merged with bridge method [inline-methods] */
    public q W(TimeInterpolator timeInterpolator) {
        this.S |= 1;
        ArrayList<m> arrayList = this.O;
        if (arrayList != null) {
            int size = arrayList.size();
            for (int i = 0; i < size; i++) {
                this.O.get(i).W(timeInterpolator);
            }
        }
        super.W(timeInterpolator);
        return this;
    }

    @Override // c.m.m
    /* JADX INFO: renamed from: m */
    public m clone() {
        q qVar = (q) super.clone();
        qVar.O = new ArrayList<>();
        int size = this.O.size();
        for (int i = 0; i < size; i++) {
            qVar.f0(this.O.get(i).clone());
        }
        return qVar;
    }

    public q m0(int i) {
        if (i == 0) {
            this.P = true;
        } else {
            if (i != 1) {
                throw new AndroidRuntimeException("Invalid parameter for TransitionSet ordering: " + i);
            }
            this.P = false;
        }
        return this;
    }

    @Override // c.m.m
    /* JADX INFO: renamed from: n0, reason: merged with bridge method [inline-methods] */
    public q Z(long j) {
        super.Z(j);
        return this;
    }

    @Override // c.m.m
    protected void o(ViewGroup viewGroup, t tVar, t tVar2, ArrayList<s> arrayList, ArrayList<s> arrayList2) {
        long jY = y();
        int size = this.O.size();
        for (int i = 0; i < size; i++) {
            m mVar = this.O.get(i);
            if (jY > 0 && (this.P || i == 0)) {
                long jY2 = mVar.y();
                if (jY2 > 0) {
                    mVar.Z(jY2 + jY);
                } else {
                    mVar.Z(jY);
                }
            }
            mVar.o(viewGroup, tVar, tVar2, arrayList, arrayList2);
        }
    }
}
