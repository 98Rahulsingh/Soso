package c.m;

import android.os.IBinder;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
class k0 implements m0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final IBinder f301a;

    k0(IBinder iBinder) {
        this.f301a = iBinder;
    }

    public boolean equals(Object obj) {
        return (obj instanceof k0) && ((k0) obj).f301a.equals(this.f301a);
    }

    public int hashCode() {
        return this.f301a.hashCode();
    }
}
