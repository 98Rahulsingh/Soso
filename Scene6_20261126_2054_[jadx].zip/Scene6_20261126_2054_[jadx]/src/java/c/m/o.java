package c.m;

import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class o {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private static m f312a = new b();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private static ThreadLocal<WeakReference<c.d.a<ViewGroup, ArrayList<m>>>> f313b = new ThreadLocal<>();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    static ArrayList<ViewGroup> f314c = new ArrayList<>();

    private static class a implements ViewTreeObserver.OnPreDrawListener, View.OnAttachStateChangeListener {
        m f;
        ViewGroup g;

        /* JADX INFO: renamed from: c.m.o$a$a, reason: collision with other inner class name */
        class C0028a extends n {

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            final /* synthetic */ c.d.a f315a;

            C0028a(c.d.a aVar) {
                this.f315a = aVar;
            }

            /* JADX WARN: Multi-variable type inference failed */
            @Override // c.m.m.f
            public void e(m mVar) {
                ((ArrayList) this.f315a.get(a.this.g)).remove(mVar);
                mVar.P(this);
            }
        }

        a(m mVar, ViewGroup viewGroup) {
            this.f = mVar;
            this.g = viewGroup;
        }

        private void a() {
            this.g.getViewTreeObserver().removeOnPreDrawListener(this);
            this.g.removeOnAttachStateChangeListener(this);
        }

        @Override // android.view.ViewTreeObserver.OnPreDrawListener
        public boolean onPreDraw() {
            a();
            if (!o.f314c.remove(this.g)) {
                return true;
            }
            c.d.a<ViewGroup, ArrayList<m>> aVarB = o.b();
            ArrayList<m> arrayList = aVarB.get(this.g);
            ArrayList arrayList2 = null;
            if (arrayList == null) {
                arrayList = new ArrayList<>();
                aVarB.put(this.g, arrayList);
            } else if (arrayList.size() > 0) {
                arrayList2 = new ArrayList(arrayList);
            }
            arrayList.add(this.f);
            this.f.a(new C0028a(aVarB));
            this.f.k(this.g, false);
            if (arrayList2 != null) {
                Iterator it = arrayList2.iterator();
                while (it.hasNext()) {
                    ((m) it.next()).R(this.g);
                }
            }
            this.f.O(this.g);
            return true;
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewAttachedToWindow(View view) {
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewDetachedFromWindow(View view) {
            a();
            o.f314c.remove(this.g);
            ArrayList<m> arrayList = o.b().get(this.g);
            if (arrayList != null && arrayList.size() > 0) {
                Iterator<m> it = arrayList.iterator();
                while (it.hasNext()) {
                    it.next().R(this.g);
                }
            }
            this.f.l(true);
        }
    }

    public static void a(ViewGroup viewGroup, m mVar) {
        if (f314c.contains(viewGroup) || !c.f.j.u.Q(viewGroup)) {
            return;
        }
        f314c.add(viewGroup);
        if (mVar == null) {
            mVar = f312a;
        }
        m mVarClone = mVar.clone();
        d(viewGroup, mVarClone);
        l.c(viewGroup, null);
        c(viewGroup, mVarClone);
    }

    static c.d.a<ViewGroup, ArrayList<m>> b() {
        c.d.a<ViewGroup, ArrayList<m>> aVar;
        WeakReference<c.d.a<ViewGroup, ArrayList<m>>> weakReference = f313b.get();
        if (weakReference != null && (aVar = weakReference.get()) != null) {
            return aVar;
        }
        c.d.a<ViewGroup, ArrayList<m>> aVar2 = new c.d.a<>();
        f313b.set(new WeakReference<>(aVar2));
        return aVar2;
    }

    private static void c(ViewGroup viewGroup, m mVar) {
        if (mVar == null || viewGroup == null) {
            return;
        }
        a aVar = new a(mVar, viewGroup);
        viewGroup.addOnAttachStateChangeListener(aVar);
        viewGroup.getViewTreeObserver().addOnPreDrawListener(aVar);
    }

    private static void d(ViewGroup viewGroup, m mVar) {
        ArrayList<m> arrayList = b().get(viewGroup);
        if (arrayList != null && arrayList.size() > 0) {
            Iterator<m> it = arrayList.iterator();
            while (it.hasNext()) {
                it.next().N(viewGroup);
            }
        }
        if (mVar != null) {
            mVar.k(viewGroup, true);
        }
        l lVarB = l.b(viewGroup);
        if (lVarB != null) {
            lVarB.a();
        }
    }
}
