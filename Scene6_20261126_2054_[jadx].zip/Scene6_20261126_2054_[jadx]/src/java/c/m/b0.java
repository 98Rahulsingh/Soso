package c.m;

import android.graphics.drawable.Drawable;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
interface b0 {
    void b(Drawable drawable);

    void d(Drawable drawable);
}
