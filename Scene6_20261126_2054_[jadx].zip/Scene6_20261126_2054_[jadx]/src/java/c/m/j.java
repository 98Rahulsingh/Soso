package c.m;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class j {
    public static final int action_container = 2131361899;
    public static final int action_divider = 2131361902;
    public static final int action_image = 2131361905;
    public static final int action_text = 2131361923;
    public static final int actions = 2131361924;
    public static final int async = 2131362009;
    public static final int blocking = 2131362055;
    public static final int chronometer = 2131362175;
    public static final int forever = 2131362390;
    public static final int ghost_view = 2131362442;
    public static final int ghost_view_holder = 2131362443;
    public static final int icon = 2131362493;
    public static final int icon_group = 2131362494;
    public static final int info = 2131362499;
    public static final int italic = 2131362502;
    public static final int line1 = 2131362577;
    public static final int line3 = 2131362578;
    public static final int normal = 2131362715;
    public static final int notification_background = 2131362716;
    public static final int notification_main_column = 2131362717;
    public static final int notification_main_column_container = 2131362718;
    public static final int parent_matrix = 2131362750;
    public static final int right_icon = 2131362811;
    public static final int right_side = 2131362812;
    public static final int save_non_transition_alpha = 2131362817;
    public static final int save_overlay_view = 2131362818;
    public static final int tag_transition_group = 2131362985;
    public static final int tag_unhandled_key_event_manager = 2131362986;
    public static final int tag_unhandled_key_listeners = 2131362987;
    public static final int text = 2131362999;
    public static final int text2 = 2131363000;
    public static final int time = 2131363028;
    public static final int title = 2131363030;
    public static final int transition_current_scene = 2131363044;
    public static final int transition_layout_save = 2131363045;
    public static final int transition_position = 2131363046;
    public static final int transition_scene_layoutid_cache = 2131363047;
    public static final int transition_transform = 2131363048;
}
