package c.m;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class n implements m.f {
    @Override // c.m.m.f
    public void a(m mVar) {
    }

    @Override // c.m.m.f
    public void b(m mVar) {
    }

    @Override // c.m.m.f
    public void c(m mVar) {
    }

    @Override // c.m.m.f
    public void d(m mVar) {
    }
}
