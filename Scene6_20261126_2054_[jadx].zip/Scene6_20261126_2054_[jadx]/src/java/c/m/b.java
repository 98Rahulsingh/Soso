package c.m;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class b extends q {
    public b() {
        p0();
    }

    private void p0() {
        m0(1);
        e0(new d(2));
        e0(new c());
        e0(new d(1));
    }
}
