package c.m;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.TimeInterpolator;
import android.graphics.Path;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public abstract class m implements Cloneable {
    private static final int[] L = {2, 1, 3, 4};
    private static final g M = new a();
    private static ThreadLocal<c.d.a<Animator, d>> N = new ThreadLocal<>();
    p H;
    private e I;
    private c.d.a<String, String> J;
    private ArrayList<s> y;
    private ArrayList<s> z;
    private String f = getClass().getName();
    private long g = -1;
    long h = -1;
    private TimeInterpolator i = null;
    ArrayList<Integer> j = new ArrayList<>();
    ArrayList<View> k = new ArrayList<>();
    private ArrayList<String> l = null;
    private ArrayList<Class<?>> m = null;
    private ArrayList<Integer> n = null;
    private ArrayList<View> o = null;
    private ArrayList<Class<?>> p = null;
    private ArrayList<String> q = null;
    private ArrayList<Integer> r = null;
    private ArrayList<View> s = null;
    private ArrayList<Class<?>> t = null;
    private t u = new t();
    private t v = new t();
    q w = null;
    private int[] x = L;
    boolean A = false;
    ArrayList<Animator> B = new ArrayList<>();
    private int C = 0;
    private boolean D = false;
    private boolean E = false;
    private ArrayList<f> F = null;
    private ArrayList<Animator> G = new ArrayList<>();
    private g K = M;

    static class a extends g {
        a() {
        }

        @Override // c.m.g
        public Path a(float f, float f2, float f3, float f4) {
            Path path = new Path();
            path.moveTo(f, f2);
            path.lineTo(f3, f4);
            return path;
        }
    }

    class b extends AnimatorListenerAdapter {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final /* synthetic */ c.d.a f305a;

        b(c.d.a aVar) {
            this.f305a = aVar;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            this.f305a.remove(animator);
            m.this.B.remove(animator);
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationStart(Animator animator) {
            m.this.B.add(animator);
        }
    }

    class c extends AnimatorListenerAdapter {
        c() {
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            m.this.p();
            animator.removeListener(this);
        }
    }

    private static class d {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        View f308a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        String f309b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        s f310c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        m0 f311d;
        m e;

        d(View view, String str, m mVar, m0 m0Var, s sVar) {
            this.f308a = view;
            this.f309b = str;
            this.f310c = sVar;
            this.f311d = m0Var;
            this.e = mVar;
        }
    }

    public static abstract class e {
    }

    public interface f {
        void a(m mVar);

        void b(m mVar);

        void c(m mVar);

        void d(m mVar);

        void e(m mVar);
    }

    private static boolean H(s sVar, s sVar2, String str) {
        Object obj = sVar.f322a.get(str);
        Object obj2 = sVar2.f322a.get(str);
        if (obj == null && obj2 == null) {
            return false;
        }
        if (obj == null || obj2 == null) {
            return true;
        }
        return true ^ obj.equals(obj2);
    }

    private void I(c.d.a<View, s> aVar, c.d.a<View, s> aVar2, SparseArray<View> sparseArray, SparseArray<View> sparseArray2) {
        View view;
        int size = sparseArray.size();
        for (int i = 0; i < size; i++) {
            View viewValueAt = sparseArray.valueAt(i);
            if (viewValueAt != null && G(viewValueAt) && (view = sparseArray2.get(sparseArray.keyAt(i))) != null && G(view)) {
                s sVar = aVar.get(viewValueAt);
                s sVar2 = aVar2.get(view);
                if (sVar != null && sVar2 != null) {
                    this.y.add(sVar);
                    this.z.add(sVar2);
                    aVar.remove(viewValueAt);
                    aVar2.remove(view);
                }
            }
        }
    }

    private void J(c.d.a<View, s> aVar, c.d.a<View, s> aVar2) {
        s sVarRemove;
        for (int size = aVar.size() - 1; size >= 0; size--) {
            View viewJ = aVar.j(size);
            if (viewJ != null && G(viewJ) && (sVarRemove = aVar2.remove(viewJ)) != null && G(sVarRemove.f323b)) {
                this.y.add(aVar.l(size));
                this.z.add(sVarRemove);
            }
        }
    }

    private void K(c.d.a<View, s> aVar, c.d.a<View, s> aVar2, c.d.d<View> dVar, c.d.d<View> dVar2) {
        View viewE;
        int iL = dVar.l();
        for (int i = 0; i < iL; i++) {
            View viewM = dVar.m(i);
            if (viewM != null && G(viewM) && (viewE = dVar2.e(dVar.h(i))) != null && G(viewE)) {
                s sVar = aVar.get(viewM);
                s sVar2 = aVar2.get(viewE);
                if (sVar != null && sVar2 != null) {
                    this.y.add(sVar);
                    this.z.add(sVar2);
                    aVar.remove(viewM);
                    aVar2.remove(viewE);
                }
            }
        }
    }

    private void L(c.d.a<View, s> aVar, c.d.a<View, s> aVar2, c.d.a<String, View> aVar3, c.d.a<String, View> aVar4) {
        View view;
        int size = aVar3.size();
        for (int i = 0; i < size; i++) {
            View viewN = aVar3.n(i);
            if (viewN != null && G(viewN) && (view = aVar4.get(aVar3.j(i))) != null && G(view)) {
                s sVar = aVar.get(viewN);
                s sVar2 = aVar2.get(view);
                if (sVar != null && sVar2 != null) {
                    this.y.add(sVar);
                    this.z.add(sVar2);
                    aVar.remove(viewN);
                    aVar2.remove(view);
                }
            }
        }
    }

    private void M(t tVar, t tVar2) {
        c.d.a<View, s> aVar = new c.d.a<>(tVar.f325a);
        c.d.a<View, s> aVar2 = new c.d.a<>(tVar2.f325a);
        int i = 0;
        while (true) {
            int[] iArr = this.x;
            if (i >= iArr.length) {
                c(aVar, aVar2);
                return;
            }
            int i2 = iArr[i];
            if (i2 == 1) {
                J(aVar, aVar2);
            } else if (i2 == 2) {
                L(aVar, aVar2, tVar.f328d, tVar2.f328d);
            } else if (i2 == 3) {
                I(aVar, aVar2, tVar.f326b, tVar2.f326b);
            } else if (i2 == 4) {
                K(aVar, aVar2, tVar.f327c, tVar2.f327c);
            }
            i++;
        }
    }

    private void S(Animator animator, c.d.a<Animator, d> aVar) {
        if (animator != null) {
            animator.addListener(new b(aVar));
            e(animator);
        }
    }

    private void c(c.d.a<View, s> aVar, c.d.a<View, s> aVar2) {
        for (int i = 0; i < aVar.size(); i++) {
            s sVarN = aVar.n(i);
            if (G(sVarN.f323b)) {
                this.y.add(sVarN);
                this.z.add(null);
            }
        }
        for (int i2 = 0; i2 < aVar2.size(); i2++) {
            s sVarN2 = aVar2.n(i2);
            if (G(sVarN2.f323b)) {
                this.z.add(sVarN2);
                this.y.add(null);
            }
        }
    }

    private static void d(t tVar, View view, s sVar) {
        tVar.f325a.put(view, sVar);
        int id = view.getId();
        if (id >= 0) {
            if (tVar.f326b.indexOfKey(id) >= 0) {
                tVar.f326b.put(id, null);
            } else {
                tVar.f326b.put(id, view);
            }
        }
        String strH = c.f.j.u.H(view);
        if (strH != null) {
            if (tVar.f328d.containsKey(strH)) {
                tVar.f328d.put(strH, null);
            } else {
                tVar.f328d.put(strH, view);
            }
        }
        if (view.getParent() instanceof ListView) {
            ListView listView = (ListView) view.getParent();
            if (listView.getAdapter().hasStableIds()) {
                long itemIdAtPosition = listView.getItemIdAtPosition(listView.getPositionForView(view));
                if (tVar.f327c.g(itemIdAtPosition) < 0) {
                    c.f.j.u.t0(view, true);
                    tVar.f327c.i(itemIdAtPosition, view);
                    return;
                }
                View viewE = tVar.f327c.e(itemIdAtPosition);
                if (viewE != null) {
                    c.f.j.u.t0(viewE, false);
                    tVar.f327c.i(itemIdAtPosition, null);
                }
            }
        }
    }

    private void h(View view, boolean z) {
        if (view == null) {
            return;
        }
        int id = view.getId();
        ArrayList<Integer> arrayList = this.n;
        if (arrayList == null || !arrayList.contains(Integer.valueOf(id))) {
            ArrayList<View> arrayList2 = this.o;
            if (arrayList2 == null || !arrayList2.contains(view)) {
                ArrayList<Class<?>> arrayList3 = this.p;
                if (arrayList3 != null) {
                    int size = arrayList3.size();
                    for (int i = 0; i < size; i++) {
                        if (this.p.get(i).isInstance(view)) {
                            return;
                        }
                    }
                }
                if (view.getParent() instanceof ViewGroup) {
                    s sVar = new s(view);
                    if (z) {
                        j(sVar);
                    } else {
                        g(sVar);
                    }
                    sVar.f324c.add(this);
                    i(sVar);
                    d(z ? this.u : this.v, view, sVar);
                }
                if (view instanceof ViewGroup) {
                    ArrayList<Integer> arrayList4 = this.r;
                    if (arrayList4 == null || !arrayList4.contains(Integer.valueOf(id))) {
                        ArrayList<View> arrayList5 = this.s;
                        if (arrayList5 == null || !arrayList5.contains(view)) {
                            ArrayList<Class<?>> arrayList6 = this.t;
                            if (arrayList6 != null) {
                                int size2 = arrayList6.size();
                                for (int i2 = 0; i2 < size2; i2++) {
                                    if (this.t.get(i2).isInstance(view)) {
                                        return;
                                    }
                                }
                            }
                            ViewGroup viewGroup = (ViewGroup) view;
                            for (int i3 = 0; i3 < viewGroup.getChildCount(); i3++) {
                                h(viewGroup.getChildAt(i3), z);
                            }
                        }
                    }
                }
            }
        }
    }

    private static c.d.a<Animator, d> x() {
        c.d.a<Animator, d> aVar = N.get();
        if (aVar != null) {
            return aVar;
        }
        c.d.a<Animator, d> aVar2 = new c.d.a<>();
        N.set(aVar2);
        return aVar2;
    }

    public List<String> A() {
        return this.l;
    }

    public List<Class<?>> B() {
        return this.m;
    }

    public List<View> C() {
        return this.k;
    }

    public String[] D() {
        return null;
    }

    public s E(View view, boolean z) {
        q qVar = this.w;
        if (qVar != null) {
            return qVar.E(view, z);
        }
        return (z ? this.u : this.v).f325a.get(view);
    }

    public boolean F(s sVar, s sVar2) {
        if (sVar == null || sVar2 == null) {
            return false;
        }
        String[] strArrD = D();
        if (strArrD == null) {
            Iterator<String> it = sVar.f322a.keySet().iterator();
            while (it.hasNext()) {
                if (H(sVar, sVar2, it.next())) {
                }
            }
            return false;
        }
        for (String str : strArrD) {
            if (!H(sVar, sVar2, str)) {
            }
        }
        return false;
        return true;
    }

    boolean G(View view) {
        ArrayList<Class<?>> arrayList;
        ArrayList<String> arrayList2;
        int id = view.getId();
        ArrayList<Integer> arrayList3 = this.n;
        if (arrayList3 != null && arrayList3.contains(Integer.valueOf(id))) {
            return false;
        }
        ArrayList<View> arrayList4 = this.o;
        if (arrayList4 != null && arrayList4.contains(view)) {
            return false;
        }
        ArrayList<Class<?>> arrayList5 = this.p;
        if (arrayList5 != null) {
            int size = arrayList5.size();
            for (int i = 0; i < size; i++) {
                if (this.p.get(i).isInstance(view)) {
                    return false;
                }
            }
        }
        if (this.q != null && c.f.j.u.H(view) != null && this.q.contains(c.f.j.u.H(view))) {
            return false;
        }
        if ((this.j.size() == 0 && this.k.size() == 0 && (((arrayList = this.m) == null || arrayList.isEmpty()) && ((arrayList2 = this.l) == null || arrayList2.isEmpty()))) || this.j.contains(Integer.valueOf(id)) || this.k.contains(view)) {
            return true;
        }
        ArrayList<String> arrayList6 = this.l;
        if (arrayList6 != null && arrayList6.contains(c.f.j.u.H(view))) {
            return true;
        }
        if (this.m != null) {
            for (int i2 = 0; i2 < this.m.size(); i2++) {
                if (this.m.get(i2).isInstance(view)) {
                    return true;
                }
            }
        }
        return false;
    }

    public void N(View view) {
        if (this.E) {
            return;
        }
        c.d.a<Animator, d> aVarX = x();
        int size = aVarX.size();
        m0 m0VarD = c0.d(view);
        for (int i = size - 1; i >= 0; i--) {
            d dVarN = aVarX.n(i);
            if (dVarN.f308a != null && m0VarD.equals(dVarN.f311d)) {
                c.m.a.b(aVarX.j(i));
            }
        }
        ArrayList<f> arrayList = this.F;
        if (arrayList != null && arrayList.size() > 0) {
            ArrayList arrayList2 = (ArrayList) this.F.clone();
            int size2 = arrayList2.size();
            for (int i2 = 0; i2 < size2; i2++) {
                ((f) arrayList2.get(i2)).a(this);
            }
        }
        this.D = true;
    }

    void O(ViewGroup viewGroup) {
        d dVar;
        this.y = new ArrayList<>();
        this.z = new ArrayList<>();
        M(this.u, this.v);
        c.d.a<Animator, d> aVarX = x();
        int size = aVarX.size();
        m0 m0VarD = c0.d(viewGroup);
        for (int i = size - 1; i >= 0; i--) {
            Animator animatorJ = aVarX.j(i);
            if (animatorJ != null && (dVar = aVarX.get(animatorJ)) != null && dVar.f308a != null && m0VarD.equals(dVar.f311d)) {
                s sVar = dVar.f310c;
                View view = dVar.f308a;
                s sVarE = E(view, true);
                s sVarT = t(view, true);
                if (sVarE == null && sVarT == null) {
                    sVarT = this.v.f325a.get(view);
                }
                if (!(sVarE == null && sVarT == null) && dVar.e.F(sVar, sVarT)) {
                    if (animatorJ.isRunning() || animatorJ.isStarted()) {
                        animatorJ.cancel();
                    } else {
                        aVarX.remove(animatorJ);
                    }
                }
            }
        }
        o(viewGroup, this.u, this.v, this.y, this.z);
        T();
    }

    public m P(f fVar) {
        ArrayList<f> arrayList = this.F;
        if (arrayList == null) {
            return this;
        }
        arrayList.remove(fVar);
        if (this.F.size() == 0) {
            this.F = null;
        }
        return this;
    }

    public m Q(View view) {
        this.k.remove(view);
        return this;
    }

    public void R(View view) {
        if (this.D) {
            if (!this.E) {
                c.d.a<Animator, d> aVarX = x();
                int size = aVarX.size();
                m0 m0VarD = c0.d(view);
                for (int i = size - 1; i >= 0; i--) {
                    d dVarN = aVarX.n(i);
                    if (dVarN.f308a != null && m0VarD.equals(dVarN.f311d)) {
                        c.m.a.c(aVarX.j(i));
                    }
                }
                ArrayList<f> arrayList = this.F;
                if (arrayList != null && arrayList.size() > 0) {
                    ArrayList arrayList2 = (ArrayList) this.F.clone();
                    int size2 = arrayList2.size();
                    for (int i2 = 0; i2 < size2; i2++) {
                        ((f) arrayList2.get(i2)).b(this);
                    }
                }
            }
            this.D = false;
        }
    }

    protected void T() {
        a0();
        c.d.a<Animator, d> aVarX = x();
        for (Animator animator : this.G) {
            if (aVarX.containsKey(animator)) {
                a0();
                S(animator, aVarX);
            }
        }
        this.G.clear();
        p();
    }

    public m U(long j) {
        this.h = j;
        return this;
    }

    public void V(e eVar) {
        this.I = eVar;
    }

    public m W(TimeInterpolator timeInterpolator) {
        this.i = timeInterpolator;
        return this;
    }

    public void X(g gVar) {
        if (gVar == null) {
            gVar = M;
        }
        this.K = gVar;
    }

    public void Y(p pVar) {
        this.H = pVar;
    }

    public m Z(long j) {
        this.g = j;
        return this;
    }

    public m a(f fVar) {
        if (this.F == null) {
            this.F = new ArrayList<>();
        }
        this.F.add(fVar);
        return this;
    }

    protected void a0() {
        if (this.C == 0) {
            ArrayList<f> arrayList = this.F;
            if (arrayList != null && arrayList.size() > 0) {
                ArrayList arrayList2 = (ArrayList) this.F.clone();
                int size = arrayList2.size();
                for (int i = 0; i < size; i++) {
                    ((f) arrayList2.get(i)).c(this);
                }
            }
            this.E = false;
        }
        this.C++;
    }

    public m b(View view) {
        this.k.add(view);
        return this;
    }

    String b0(String str) {
        String str2 = str + getClass().getSimpleName() + "@" + Integer.toHexString(hashCode()) + ": ";
        if (this.h != -1) {
            str2 = str2 + "dur(" + this.h + ") ";
        }
        if (this.g != -1) {
            str2 = str2 + "dly(" + this.g + ") ";
        }
        if (this.i != null) {
            str2 = str2 + "interp(" + this.i + ") ";
        }
        if (this.j.size() <= 0 && this.k.size() <= 0) {
            return str2;
        }
        String str3 = str2 + "tgts(";
        if (this.j.size() > 0) {
            for (int i = 0; i < this.j.size(); i++) {
                if (i > 0) {
                    str3 = str3 + ", ";
                }
                str3 = str3 + this.j.get(i);
            }
        }
        if (this.k.size() > 0) {
            for (int i2 = 0; i2 < this.k.size(); i2++) {
                if (i2 > 0) {
                    str3 = str3 + ", ";
                }
                str3 = str3 + this.k.get(i2);
            }
        }
        return str3 + ")";
    }

    protected void e(Animator animator) {
        if (animator == null) {
            p();
            return;
        }
        if (q() >= 0) {
            animator.setDuration(q());
        }
        if (y() >= 0) {
            animator.setStartDelay(y() + animator.getStartDelay());
        }
        if (s() != null) {
            animator.setInterpolator(s());
        }
        animator.addListener(new c());
        animator.start();
    }

    protected void f() {
        for (int size = this.B.size() - 1; size >= 0; size--) {
            this.B.get(size).cancel();
        }
        ArrayList<f> arrayList = this.F;
        if (arrayList == null || arrayList.size() <= 0) {
            return;
        }
        ArrayList arrayList2 = (ArrayList) this.F.clone();
        int size2 = arrayList2.size();
        for (int i = 0; i < size2; i++) {
            ((f) arrayList2.get(i)).d(this);
        }
    }

    public abstract void g(s sVar);

    void i(s sVar) {
        String[] strArrB;
        if (this.H == null || sVar.f322a.isEmpty() || (strArrB = this.H.b()) == null) {
            return;
        }
        boolean z = false;
        int i = 0;
        while (true) {
            if (i >= strArrB.length) {
                z = true;
                break;
            } else if (!sVar.f322a.containsKey(strArrB[i])) {
                break;
            } else {
                i++;
            }
        }
        if (z) {
            return;
        }
        this.H.a(sVar);
    }

    public abstract void j(s sVar);

    void k(ViewGroup viewGroup, boolean z) {
        ArrayList<String> arrayList;
        ArrayList<Class<?>> arrayList2;
        c.d.a<String, String> aVar;
        l(z);
        if ((this.j.size() > 0 || this.k.size() > 0) && (((arrayList = this.l) == null || arrayList.isEmpty()) && ((arrayList2 = this.m) == null || arrayList2.isEmpty()))) {
            for (int i = 0; i < this.j.size(); i++) {
                View viewFindViewById = viewGroup.findViewById(this.j.get(i).intValue());
                if (viewFindViewById != null) {
                    s sVar = new s(viewFindViewById);
                    if (z) {
                        j(sVar);
                    } else {
                        g(sVar);
                    }
                    sVar.f324c.add(this);
                    i(sVar);
                    d(z ? this.u : this.v, viewFindViewById, sVar);
                }
            }
            for (int i2 = 0; i2 < this.k.size(); i2++) {
                View view = this.k.get(i2);
                s sVar2 = new s(view);
                if (z) {
                    j(sVar2);
                } else {
                    g(sVar2);
                }
                sVar2.f324c.add(this);
                i(sVar2);
                d(z ? this.u : this.v, view, sVar2);
            }
        } else {
            h(viewGroup, z);
        }
        if (z || (aVar = this.J) == null) {
            return;
        }
        int size = aVar.size();
        ArrayList arrayList3 = new ArrayList(size);
        for (int i3 = 0; i3 < size; i3++) {
            arrayList3.add(this.u.f328d.remove(this.J.j(i3)));
        }
        for (int i4 = 0; i4 < size; i4++) {
            View view2 = (View) arrayList3.get(i4);
            if (view2 != null) {
                this.u.f328d.put(this.J.n(i4), view2);
            }
        }
    }

    void l(boolean z) {
        t tVar;
        if (z) {
            this.u.f325a.clear();
            this.u.f326b.clear();
            tVar = this.u;
        } else {
            this.v.f325a.clear();
            this.v.f326b.clear();
            tVar = this.v;
        }
        tVar.f327c.b();
    }

    @Override // 
    /* JADX INFO: renamed from: m, reason: merged with bridge method [inline-methods] */
    public m clone() {
        try {
            m mVar = (m) super.clone();
            mVar.G = new ArrayList<>();
            mVar.u = new t();
            mVar.v = new t();
            mVar.y = null;
            mVar.z = null;
            return mVar;
        } catch (CloneNotSupportedException unused) {
            return null;
        }
    }

    public Animator n(ViewGroup viewGroup, s sVar, s sVar2) {
        return null;
    }

    /* JADX WARN: Code duplicated, block: B:15:0x0043  */
    protected void o(ViewGroup viewGroup, t tVar, t tVar2, ArrayList<s> arrayList, ArrayList<s> arrayList2) {
        Animator animatorN;
        int i;
        int i2;
        View view;
        Animator animator;
        s sVar;
        Animator animator2;
        s sVar2;
        c.d.a<Animator, d> aVarX = x();
        SparseIntArray sparseIntArray = new SparseIntArray();
        int size = arrayList.size();
        long jMin = Long.MAX_VALUE;
        int i3 = 0;
        while (i3 < size) {
            s sVar3 = arrayList.get(i3);
            s sVar4 = arrayList2.get(i3);
            if (sVar3 != null && !sVar3.f324c.contains(this)) {
                sVar3 = null;
            }
            if (sVar4 != null && !sVar4.f324c.contains(this)) {
                sVar4 = null;
            }
            if (sVar3 == null && sVar4 == null) {
                i = size;
                i2 = i3;
            } else if (!(sVar3 == null || sVar4 == null || F(sVar3, sVar4)) || (animatorN = n(viewGroup, sVar3, sVar4)) == null) {
                i = size;
                i2 = i3;
            } else {
                if (sVar4 != null) {
                    view = sVar4.f323b;
                    String[] strArrD = D();
                    if (strArrD != null && strArrD.length > 0) {
                        sVar2 = new s(view);
                        i = size;
                        s sVar5 = tVar2.f325a.get(view);
                        if (sVar5 != null) {
                            int i4 = 0;
                            while (i4 < strArrD.length) {
                                sVar2.f322a.put(strArrD[i4], sVar5.f322a.get(strArrD[i4]));
                                i4++;
                                i3 = i3;
                                sVar5 = sVar5;
                            }
                        }
                        i2 = i3;
                        int size2 = aVarX.size();
                        int i5 = 0;
                        while (true) {
                            if (i5 >= size2) {
                                animator2 = animatorN;
                                break;
                            }
                            d dVar = aVarX.get(aVarX.j(i5));
                            if (dVar.f310c != null && dVar.f308a == view && dVar.f309b.equals(u()) && dVar.f310c.equals(sVar2)) {
                                animator2 = null;
                                break;
                            }
                            i5++;
                        }
                    } else {
                        i = size;
                        i2 = i3;
                        animator2 = animatorN;
                        sVar2 = null;
                    }
                    animator = animator2;
                    sVar = sVar2;
                } else {
                    i = size;
                    i2 = i3;
                    view = sVar3.f323b;
                    animator = animatorN;
                    sVar = null;
                }
                if (animator != null) {
                    p pVar = this.H;
                    if (pVar != null) {
                        long jC = pVar.c(viewGroup, this, sVar3, sVar4);
                        sparseIntArray.put(this.G.size(), (int) jC);
                        jMin = Math.min(jC, jMin);
                    }
                    aVarX.put(animator, new d(view, u(), this, c0.d(viewGroup), sVar));
                    this.G.add(animator);
                    jMin = jMin;
                }
            }
            i3 = i2 + 1;
            size = i;
        }
        if (sparseIntArray.size() != 0) {
            for (int i6 = 0; i6 < sparseIntArray.size(); i6++) {
                Animator animator3 = this.G.get(sparseIntArray.keyAt(i6));
                animator3.setStartDelay((((long) sparseIntArray.valueAt(i6)) - jMin) + animator3.getStartDelay());
            }
        }
    }

    protected void p() {
        int i = this.C - 1;
        this.C = i;
        if (i == 0) {
            ArrayList<f> arrayList = this.F;
            if (arrayList != null && arrayList.size() > 0) {
                ArrayList arrayList2 = (ArrayList) this.F.clone();
                int size = arrayList2.size();
                for (int i2 = 0; i2 < size; i2++) {
                    ((f) arrayList2.get(i2)).e(this);
                }
            }
            for (int i3 = 0; i3 < this.u.f327c.l(); i3++) {
                View viewM = this.u.f327c.m(i3);
                if (viewM != null) {
                    c.f.j.u.t0(viewM, false);
                }
            }
            for (int i4 = 0; i4 < this.v.f327c.l(); i4++) {
                View viewM2 = this.v.f327c.m(i4);
                if (viewM2 != null) {
                    c.f.j.u.t0(viewM2, false);
                }
            }
            this.E = true;
        }
    }

    public long q() {
        return this.h;
    }

    public e r() {
        return this.I;
    }

    public TimeInterpolator s() {
        return this.i;
    }

    s t(View view, boolean z) {
        q qVar = this.w;
        if (qVar != null) {
            return qVar.t(view, z);
        }
        ArrayList<s> arrayList = z ? this.y : this.z;
        if (arrayList == null) {
            return null;
        }
        int size = arrayList.size();
        int i = -1;
        for (int i2 = 0; i2 < size; i2++) {
            s sVar = arrayList.get(i2);
            if (sVar == null) {
                return null;
            }
            if (sVar.f323b == view) {
                i = i2;
                break;
            }
        }
        if (i >= 0) {
            return (z ? this.z : this.y).get(i);
        }
        return null;
    }

    public String toString() {
        return b0("");
    }

    public String u() {
        return this.f;
    }

    public g v() {
        return this.K;
    }

    public p w() {
        return this.H;
    }

    public long y() {
        return this.g;
    }

    public List<Integer> z() {
        return this.j;
    }
}
