package c.m;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.view.View;
import android.view.ViewGroup;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class d extends j0 {

    class a extends n {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final /* synthetic */ View f271a;

        a(d dVar, View view) {
            this.f271a = view;
        }

        @Override // c.m.m.f
        public void e(m mVar) {
            c0.g(this.f271a, 1.0f);
            c0.a(this.f271a);
            mVar.P(this);
        }
    }

    private static class b extends AnimatorListenerAdapter {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final View f272a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private boolean f273b = false;

        b(View view) {
            this.f272a = view;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            c0.g(this.f272a, 1.0f);
            if (this.f273b) {
                this.f272a.setLayerType(0, null);
            }
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationStart(Animator animator) {
            if (c.f.j.u.M(this.f272a) && this.f272a.getLayerType() == 0) {
                this.f273b = true;
                this.f272a.setLayerType(2, null);
            }
        }
    }

    public d(int i) {
        i0(i);
    }

    private Animator j0(View view, float f, float f2) {
        if (f == f2) {
            return null;
        }
        c0.g(view, f);
        ObjectAnimator objectAnimatorOfFloat = ObjectAnimator.ofFloat(view, c0.f270b, f2);
        objectAnimatorOfFloat.addListener(new b(view));
        a(new a(this, view));
        return objectAnimatorOfFloat;
    }

    private static float k0(s sVar, float f) {
        Float f2;
        return (sVar == null || (f2 = (Float) sVar.f322a.get("android:fade:transitionAlpha")) == null) ? f : f2.floatValue();
    }

    @Override // c.m.j0
    public Animator e0(ViewGroup viewGroup, View view, s sVar, s sVar2) {
        float fK0 = k0(sVar, 0.0f);
        return j0(view, fK0 != 1.0f ? fK0 : 0.0f, 1.0f);
    }

    @Override // c.m.j0
    public Animator g0(ViewGroup viewGroup, View view, s sVar, s sVar2) {
        c0.e(view);
        return j0(view, k0(sVar, 1.0f), 0.0f);
    }

    @Override // c.m.j0, c.m.m
    public void j(s sVar) {
        super.j(sVar);
        sVar.f322a.put("android:fade:transitionAlpha", Float.valueOf(c0.c(sVar.f323b)));
    }
}
