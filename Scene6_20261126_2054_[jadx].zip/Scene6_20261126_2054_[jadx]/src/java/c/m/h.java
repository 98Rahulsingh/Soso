package c.m;

import android.graphics.Path;
import android.graphics.PathMeasure;
import android.graphics.PointF;
import android.util.Property;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
class h<T> extends Property<T, Float> {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final Property<T, PointF> f280a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final PathMeasure f281b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final float f282c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private final float[] f283d;
    private final PointF e;
    private float f;

    h(Property<T, PointF> property, Path path) {
        super(Float.class, property.getName());
        this.f283d = new float[2];
        this.e = new PointF();
        this.f280a = property;
        PathMeasure pathMeasure = new PathMeasure(path, false);
        this.f281b = pathMeasure;
        this.f282c = pathMeasure.getLength();
    }

    @Override // android.util.Property
    /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
    public Float get(T t) {
        return Float.valueOf(this.f);
    }

    @Override // android.util.Property
    /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
    public void set(T t, Float f) {
        this.f = f.floatValue();
        this.f281b.getPosTan(this.f282c * f.floatValue(), this.f283d, null);
        PointF pointF = this.e;
        float[] fArr = this.f283d;
        pointF.x = fArr[0];
        pointF.y = fArr[1];
        this.f280a.set(t, pointF);
    }
}
