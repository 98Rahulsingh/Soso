package c.m;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;
import android.view.ViewGroup;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public abstract class j0 extends m {
    private static final String[] P = {"android:visibility:visibility", "android:visibility:parent"};
    private int O = 3;

    class a extends n {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final /* synthetic */ ViewGroup f288a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final /* synthetic */ View f289b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        final /* synthetic */ View f290c;

        a(ViewGroup viewGroup, View view, View view2) {
            this.f288a = viewGroup;
            this.f289b = view;
            this.f290c = view2;
        }

        @Override // c.m.n, c.m.m.f
        public void a(m mVar) {
            x.a(this.f288a).c(this.f289b);
        }

        @Override // c.m.n, c.m.m.f
        public void b(m mVar) {
            if (this.f289b.getParent() == null) {
                x.a(this.f288a).a(this.f289b);
            } else {
                j0.this.f();
            }
        }

        @Override // c.m.m.f
        public void e(m mVar) {
            this.f290c.setTag(j.save_overlay_view, null);
            x.a(this.f288a).c(this.f289b);
            mVar.P(this);
        }
    }

    private static class b extends AnimatorListenerAdapter implements m.f, c.m.a.InterfaceC0026a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final View f292a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private final int f293b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private final ViewGroup f294c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        private final boolean f295d;
        private boolean e;
        boolean f = false;

        b(View view, int i, boolean z) {
            this.f292a = view;
            this.f293b = i;
            this.f294c = (ViewGroup) view.getParent();
            this.f295d = z;
            g(true);
        }

        private void f() {
            if (!this.f) {
                c0.h(this.f292a, this.f293b);
                ViewGroup viewGroup = this.f294c;
                if (viewGroup != null) {
                    viewGroup.invalidate();
                }
            }
            g(false);
        }

        private void g(boolean z) {
            ViewGroup viewGroup;
            if (!this.f295d || this.e == z || (viewGroup = this.f294c) == null) {
                return;
            }
            this.e = z;
            x.c(viewGroup, z);
        }

        @Override // c.m.m.f
        public void a(m mVar) {
            g(false);
        }

        @Override // c.m.m.f
        public void b(m mVar) {
            g(true);
        }

        @Override // c.m.m.f
        public void c(m mVar) {
        }

        @Override // c.m.m.f
        public void d(m mVar) {
        }

        @Override // c.m.m.f
        public void e(m mVar) {
            f();
            mVar.P(this);
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationCancel(Animator animator) {
            this.f = true;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            f();
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorPauseListener, c.m.a.InterfaceC0026a
        public void onAnimationPause(Animator animator) {
            if (this.f) {
                return;
            }
            c0.h(this.f292a, this.f293b);
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationRepeat(Animator animator) {
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorPauseListener, c.m.a.InterfaceC0026a
        public void onAnimationResume(Animator animator) {
            if (this.f) {
                return;
            }
            c0.h(this.f292a, 0);
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationStart(Animator animator) {
        }
    }

    private static class c {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        boolean f296a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        boolean f297b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        int f298c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        int f299d;
        ViewGroup e;
        ViewGroup f;

        c() {
        }
    }

    private void c0(s sVar) {
        sVar.f322a.put("android:visibility:visibility", Integer.valueOf(sVar.f323b.getVisibility()));
        sVar.f322a.put("android:visibility:parent", sVar.f323b.getParent());
        int[] iArr = new int[2];
        sVar.f323b.getLocationOnScreen(iArr);
        sVar.f322a.put("android:visibility:screenLocation", iArr);
    }

    /* JADX WARN: Code duplicated, block: B:41:0x0097  */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x0079, code lost:
    
        if (r9 == 0) goto L36;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x0083, code lost:
    
        if (r0.e == null) goto L36;
     */
    /* JADX WARN: Code restructure failed: missing block: B:40:0x0095, code lost:
    
        if (r0.f298c == 0) goto L41;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private c.m.j0.c d0(c.m.s r8, c.m.s r9) {
        /*
            r7 = this;
            c.m.j0$c r0 = new c.m.j0$c
            r0.<init>()
            r1 = 0
            r0.f296a = r1
            r0.f297b = r1
            java.lang.String r2 = "android:visibility:parent"
            r3 = 0
            r4 = -1
            java.lang.String r5 = "android:visibility:visibility"
            if (r8 == 0) goto L33
            java.util.Map<java.lang.String, java.lang.Object> r6 = r8.f322a
            boolean r6 = r6.containsKey(r5)
            if (r6 == 0) goto L33
            java.util.Map<java.lang.String, java.lang.Object> r6 = r8.f322a
            java.lang.Object r6 = r6.get(r5)
            java.lang.Integer r6 = (java.lang.Integer) r6
            int r6 = r6.intValue()
            r0.f298c = r6
            java.util.Map<java.lang.String, java.lang.Object> r6 = r8.f322a
            java.lang.Object r6 = r6.get(r2)
            android.view.ViewGroup r6 = (android.view.ViewGroup) r6
            r0.e = r6
            goto L37
        L33:
            r0.f298c = r4
            r0.e = r3
        L37:
            if (r9 == 0) goto L5a
            java.util.Map<java.lang.String, java.lang.Object> r6 = r9.f322a
            boolean r6 = r6.containsKey(r5)
            if (r6 == 0) goto L5a
            java.util.Map<java.lang.String, java.lang.Object> r3 = r9.f322a
            java.lang.Object r3 = r3.get(r5)
            java.lang.Integer r3 = (java.lang.Integer) r3
            int r3 = r3.intValue()
            r0.f299d = r3
            java.util.Map<java.lang.String, java.lang.Object> r3 = r9.f322a
            java.lang.Object r2 = r3.get(r2)
            android.view.ViewGroup r2 = (android.view.ViewGroup) r2
            r0.f = r2
            goto L5e
        L5a:
            r0.f299d = r4
            r0.f = r3
        L5e:
            r2 = 1
            if (r8 == 0) goto L86
            if (r9 == 0) goto L86
            int r8 = r0.f298c
            int r9 = r0.f299d
            if (r8 != r9) goto L70
            android.view.ViewGroup r8 = r0.e
            android.view.ViewGroup r9 = r0.f
            if (r8 != r9) goto L70
            return r0
        L70:
            int r8 = r0.f298c
            int r9 = r0.f299d
            if (r8 == r9) goto L7c
            if (r8 != 0) goto L79
            goto L97
        L79:
            if (r9 != 0) goto L9a
            goto L8c
        L7c:
            android.view.ViewGroup r8 = r0.f
            if (r8 != 0) goto L81
            goto L97
        L81:
            android.view.ViewGroup r8 = r0.e
            if (r8 != 0) goto L9a
            goto L8c
        L86:
            if (r8 != 0) goto L91
            int r8 = r0.f299d
            if (r8 != 0) goto L91
        L8c:
            r0.f297b = r2
        L8e:
            r0.f296a = r2
            goto L9a
        L91:
            if (r9 != 0) goto L9a
            int r8 = r0.f298c
            if (r8 != 0) goto L9a
        L97:
            r0.f297b = r1
            goto L8e
        L9a:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: c.m.j0.d0(c.m.s, c.m.s):c.m.j0$c");
    }

    @Override // c.m.m
    public String[] D() {
        return P;
    }

    @Override // c.m.m
    public boolean F(s sVar, s sVar2) {
        if (sVar == null && sVar2 == null) {
            return false;
        }
        if (sVar != null && sVar2 != null && sVar2.f322a.containsKey("android:visibility:visibility") != sVar.f322a.containsKey("android:visibility:visibility")) {
            return false;
        }
        c cVarD0 = d0(sVar, sVar2);
        if (cVarD0.f296a) {
            return cVarD0.f298c == 0 || cVarD0.f299d == 0;
        }
        return false;
    }

    public abstract Animator e0(ViewGroup viewGroup, View view, s sVar, s sVar2);

    public Animator f0(ViewGroup viewGroup, s sVar, int i, s sVar2, int i2) {
        if ((this.O & 1) != 1 || sVar2 == null) {
            return null;
        }
        if (sVar == null) {
            View view = (View) sVar2.f323b.getParent();
            if (d0(t(view, false), E(view, false)).f296a) {
                return null;
            }
        }
        return e0(viewGroup, sVar2.f323b, sVar, sVar2);
    }

    @Override // c.m.m
    public void g(s sVar) {
        c0(sVar);
    }

    public abstract Animator g0(ViewGroup viewGroup, View view, s sVar, s sVar2);

    /* JADX WARN: Code duplicated, block: B:25:0x003b  */
    public Animator h0(ViewGroup viewGroup, s sVar, int i, s sVar2, int i2) {
        View view;
        boolean z;
        boolean z2;
        View view2;
        if ((this.O & 2) != 2 || sVar == null) {
            return null;
        }
        View view3 = sVar.f323b;
        View viewA = sVar2 != null ? sVar2.f323b : null;
        View view4 = (View) view3.getTag(j.save_overlay_view);
        if (view4 != null) {
            view2 = null;
            z2 = true;
        } else {
            if (viewA == null || viewA.getParent() == null) {
                if (viewA != null) {
                    view = null;
                    z = false;
                } else {
                    viewA = null;
                    view = null;
                    z = true;
                }
            } else if (i2 == 4 || view3 == viewA) {
                view = viewA;
                z = false;
                viewA = null;
            } else {
                viewA = null;
                view = null;
                z = true;
            }
            if (z) {
                if (view3.getParent() != null) {
                    if (view3.getParent() instanceof View) {
                        View view5 = (View) view3.getParent();
                        if (d0(E(view5, true), t(view5, true)).f296a) {
                            int id = view5.getId();
                            if (view5.getParent() != null || id == -1 || viewGroup.findViewById(id) == null || !this.A) {
                            }
                        } else {
                            viewA = r.a(viewGroup, view3, view5);
                        }
                    }
                    z2 = false;
                    View view6 = view;
                    view4 = viewA;
                    view2 = view6;
                }
                view2 = view;
                z2 = false;
                view4 = view3;
            } else {
                z2 = false;
                View view7 = view;
                view4 = viewA;
                view2 = view7;
            }
        }
        if (view4 == null) {
            if (view2 == null) {
                return null;
            }
            int visibility = view2.getVisibility();
            c0.h(view2, 0);
            Animator animatorG0 = g0(viewGroup, view2, sVar, sVar2);
            if (animatorG0 != null) {
                b bVar = new b(view2, i2, true);
                animatorG0.addListener(bVar);
                c.m.a.a(animatorG0, bVar);
                a(bVar);
            } else {
                c0.h(view2, visibility);
            }
            return animatorG0;
        }
        if (!z2) {
            int[] iArr = (int[]) sVar.f322a.get("android:visibility:screenLocation");
            int i3 = iArr[0];
            int i4 = iArr[1];
            int[] iArr2 = new int[2];
            viewGroup.getLocationOnScreen(iArr2);
            view4.offsetLeftAndRight((i3 - iArr2[0]) - view4.getLeft());
            view4.offsetTopAndBottom((i4 - iArr2[1]) - view4.getTop());
            x.a(viewGroup).a(view4);
        }
        Animator animatorG1 = g0(viewGroup, view4, sVar, sVar2);
        if (!z2) {
            if (animatorG1 == null) {
                x.a(viewGroup).c(view4);
            } else {
                view3.setTag(j.save_overlay_view, view4);
                a(new a(viewGroup, view4, view3));
            }
        }
        return animatorG1;
    }

    public void i0(int i) {
        if ((i & (-4)) != 0) {
            throw new IllegalArgumentException("Only MODE_IN and MODE_OUT flags are allowed");
        }
        this.O = i;
    }

    @Override // c.m.m
    public void j(s sVar) {
        c0(sVar);
    }

    @Override // c.m.m
    public Animator n(ViewGroup viewGroup, s sVar, s sVar2) {
        c cVarD0 = d0(sVar, sVar2);
        if (!cVarD0.f296a) {
            return null;
        }
        if (cVarD0.e == null && cVarD0.f == null) {
            return null;
        }
        return cVarD0.f297b ? f0(viewGroup, sVar, cVarD0.f298c, sVar2, cVarD0.f299d) : h0(viewGroup, sVar, cVarD0.f298c, sVar2, cVarD0.f299d);
    }
}
