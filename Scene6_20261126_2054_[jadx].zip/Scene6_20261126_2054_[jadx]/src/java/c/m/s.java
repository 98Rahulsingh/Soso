package c.m;

import android.view.View;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class s {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public View f323b;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Map<String, Object> f322a = new HashMap();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    final ArrayList<m> f324c = new ArrayList<>();

    @Deprecated
    public s() {
    }

    public s(View view) {
        this.f323b = view;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof s)) {
            return false;
        }
        s sVar = (s) obj;
        return this.f323b == sVar.f323b && this.f322a.equals(sVar.f322a);
    }

    public int hashCode() {
        return (this.f323b.hashCode() * 31) + this.f322a.hashCode();
    }

    public String toString() {
        String str = (("TransitionValues@" + Integer.toHexString(hashCode()) + ":\n") + "    view = " + this.f323b + "\n") + "    values:";
        for (String str2 : this.f322a.keySet()) {
            str = str + "    " + str2 + ": " + this.f322a.get(str2) + "\n";
        }
        return str;
    }
}
