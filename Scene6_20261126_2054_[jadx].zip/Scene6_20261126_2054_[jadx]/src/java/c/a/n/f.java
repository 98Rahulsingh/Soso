package c.a.n;

import android.content.Context;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import androidx.appcompat.view.menu.j;
import androidx.appcompat.view.menu.o;
import java.util.ArrayList;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class f extends ActionMode {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    final Context f27a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    final b f28b;

    public static class a implements b.a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final ActionMode.Callback f29a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final Context f30b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        final ArrayList<f> f31c = new ArrayList<>();

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final c.d.g<Menu, Menu> f32d = new c.d.g<>();

        public a(Context context, ActionMode.Callback callback) {
            this.f30b = context;
            this.f29a = callback;
        }

        private Menu f(Menu menu) {
            Menu menu2 = this.f32d.get(menu);
            if (menu2 != null) {
                return menu2;
            }
            Menu oVar = new o(this.f30b, (c.f.e.a.a) menu);
            this.f32d.put(menu, oVar);
            return oVar;
        }

        @Override // c.a.n.b.a
        public boolean a(b bVar, Menu menu) {
            return this.f29a.onPrepareActionMode(e(bVar), f(menu));
        }

        @Override // c.a.n.b.a
        public boolean b(b bVar, MenuItem menuItem) {
            return this.f29a.onActionItemClicked(e(bVar), new j(this.f30b, (c.f.e.a.b) menuItem));
        }

        @Override // c.a.n.b.a
        public boolean c(b bVar, Menu menu) {
            return this.f29a.onCreateActionMode(e(bVar), f(menu));
        }

        @Override // c.a.n.b.a
        public void d(b bVar) {
            this.f29a.onDestroyActionMode(e(bVar));
        }

        public ActionMode e(b bVar) {
            int size = this.f31c.size();
            for (int i = 0; i < size; i++) {
                f fVar = this.f31c.get(i);
                if (fVar != null && fVar.f28b == bVar) {
                    return fVar;
                }
            }
            f fVar2 = new f(this.f30b, bVar);
            this.f31c.add(fVar2);
            return fVar2;
        }
    }

    public f(Context context, b bVar) {
        this.f27a = context;
        this.f28b = bVar;
    }

    @Override // android.view.ActionMode
    public void finish() {
        this.f28b.c();
    }

    @Override // android.view.ActionMode
    public View getCustomView() {
        return this.f28b.d();
    }

    @Override // android.view.ActionMode
    public Menu getMenu() {
        return new o(this.f27a, (c.f.e.a.a) this.f28b.e());
    }

    @Override // android.view.ActionMode
    public MenuInflater getMenuInflater() {
        return this.f28b.f();
    }

    @Override // android.view.ActionMode
    public CharSequence getSubtitle() {
        return this.f28b.g();
    }

    @Override // android.view.ActionMode
    public Object getTag() {
        return this.f28b.h();
    }

    @Override // android.view.ActionMode
    public CharSequence getTitle() {
        return this.f28b.i();
    }

    @Override // android.view.ActionMode
    public boolean getTitleOptionalHint() {
        return this.f28b.j();
    }

    @Override // android.view.ActionMode
    public void invalidate() {
        this.f28b.k();
    }

    @Override // android.view.ActionMode
    public boolean isTitleOptional() {
        return this.f28b.l();
    }

    @Override // android.view.ActionMode
    public void setCustomView(View view) {
        this.f28b.m(view);
    }

    @Override // android.view.ActionMode
    public void setSubtitle(int i) {
        this.f28b.n(i);
    }

    @Override // android.view.ActionMode
    public void setSubtitle(CharSequence charSequence) {
        this.f28b.o(charSequence);
    }

    @Override // android.view.ActionMode
    public void setTag(Object obj) {
        this.f28b.p(obj);
    }

    @Override // android.view.ActionMode
    public void setTitle(int i) {
        this.f28b.q(i);
    }

    @Override // android.view.ActionMode
    public void setTitle(CharSequence charSequence) {
        this.f28b.r(charSequence);
    }

    @Override // android.view.ActionMode
    public void setTitleOptionalHint(boolean z) {
        this.f28b.s(z);
    }
}
