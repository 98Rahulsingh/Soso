package c.a.n;

import android.view.View;
import android.view.animation.Interpolator;
import c.f.j.a0;
import c.f.j.y;
import c.f.j.z;
import java.util.ArrayList;
import java.util.Iterator;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class h {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private Interpolator f46c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    z f47d;
    private boolean e;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private long f45b = -1;
    private final a0 f = new a();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    final ArrayList<y> f44a = new ArrayList<>();

    class a extends a0 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private boolean f48a = false;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private int f49b = 0;

        a() {
        }

        @Override // c.f.j.z
        public void a(View view) {
            int i = this.f49b + 1;
            this.f49b = i;
            if (i == h.this.f44a.size()) {
                z zVar = h.this.f47d;
                if (zVar != null) {
                    zVar.a(null);
                }
                d();
            }
        }

        @Override // c.f.j.a0, c.f.j.z
        public void b(View view) {
            if (this.f48a) {
                return;
            }
            this.f48a = true;
            z zVar = h.this.f47d;
            if (zVar != null) {
                zVar.b(null);
            }
        }

        void d() {
            this.f49b = 0;
            this.f48a = false;
            h.this.b();
        }
    }

    public void a() {
        if (this.e) {
            Iterator<y> it = this.f44a.iterator();
            while (it.hasNext()) {
                it.next().b();
            }
            this.e = false;
        }
    }

    void b() {
        this.e = false;
    }

    public h c(y yVar) {
        if (!this.e) {
            this.f44a.add(yVar);
        }
        return this;
    }

    public h d(y yVar, y yVar2) {
        this.f44a.add(yVar);
        yVar2.h(yVar.c());
        this.f44a.add(yVar2);
        return this;
    }

    public h e(long j) {
        if (!this.e) {
            this.f45b = j;
        }
        return this;
    }

    public h f(Interpolator interpolator) {
        if (!this.e) {
            this.f46c = interpolator;
        }
        return this;
    }

    public h g(z zVar) {
        if (!this.e) {
            this.f47d = zVar;
        }
        return this;
    }

    public void h() {
        if (this.e) {
            return;
        }
        for (y yVar : this.f44a) {
            long j = this.f45b;
            if (j >= 0) {
                yVar.d(j);
            }
            Interpolator interpolator = this.f46c;
            if (interpolator != null) {
                yVar.e(interpolator);
            }
            if (this.f47d != null) {
                yVar.f(this.f);
            }
            yVar.j();
        }
        this.e = true;
    }
}
