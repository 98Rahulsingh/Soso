package c.a.n;

import android.content.Context;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import androidx.appcompat.widget.ActionBarContextView;
import java.lang.ref.WeakReference;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class e extends b implements androidx.appcompat.view.menu.g.a {
    private Context h;
    private ActionBarContextView i;
    private b.a j;
    private WeakReference<View> k;
    private boolean l;
    private androidx.appcompat.view.menu.g m;

    public e(Context context, ActionBarContextView actionBarContextView, b.a aVar, boolean z) {
        this.h = context;
        this.i = actionBarContextView;
        this.j = aVar;
        androidx.appcompat.view.menu.g gVar = new androidx.appcompat.view.menu.g(actionBarContextView.getContext());
        gVar.S(1);
        this.m = gVar;
        gVar.R(this);
    }

    public boolean a(androidx.appcompat.view.menu.g gVar, MenuItem menuItem) {
        return this.j.b(this, menuItem);
    }

    public void b(androidx.appcompat.view.menu.g gVar) {
        k();
        this.i.l();
    }

    @Override // c.a.n.b
    public void c() {
        if (this.l) {
            return;
        }
        this.l = true;
        this.i.sendAccessibilityEvent(32);
        this.j.d(this);
    }

    @Override // c.a.n.b
    public View d() {
        WeakReference<View> weakReference = this.k;
        if (weakReference != null) {
            return weakReference.get();
        }
        return null;
    }

    @Override // c.a.n.b
    public Menu e() {
        return this.m;
    }

    @Override // c.a.n.b
    public MenuInflater f() {
        return new g(this.i.getContext());
    }

    @Override // c.a.n.b
    public CharSequence g() {
        return this.i.getSubtitle();
    }

    @Override // c.a.n.b
    public CharSequence i() {
        return this.i.getTitle();
    }

    @Override // c.a.n.b
    public void k() {
        this.j.a(this, this.m);
    }

    @Override // c.a.n.b
    public boolean l() {
        return this.i.j();
    }

    @Override // c.a.n.b
    public void m(View view) {
        this.i.setCustomView(view);
        this.k = view != null ? new WeakReference<>(view) : null;
    }

    @Override // c.a.n.b
    public void n(int i) {
        o(this.h.getString(i));
    }

    @Override // c.a.n.b
    public void o(CharSequence charSequence) {
        this.i.setSubtitle(charSequence);
    }

    @Override // c.a.n.b
    public void q(int i) {
        r(this.h.getString(i));
    }

    @Override // c.a.n.b
    public void r(CharSequence charSequence) {
        this.i.setTitle(charSequence);
    }

    @Override // c.a.n.b
    public void s(boolean z) {
        super.s(z);
        this.i.setTitleOptional(z);
    }
}
