package c.a;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class b {
    public static final int abc_action_bar_embed_tabs = 2131034112;
    public static final int abc_allow_stacked_button_bar = 2131034113;
    public static final int abc_config_actionMenuItemAllCaps = 2131034114;
}
