package c.a.m;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public final class a {
    public static final int abc_vector_test = 2131230811;
    public static final int notification_action_background = 2131231069;
    public static final int notification_bg = 2131231070;
    public static final int notification_bg_low = 2131231071;
    public static final int notification_bg_low_normal = 2131231072;
    public static final int notification_bg_low_pressed = 2131231073;
    public static final int notification_bg_normal = 2131231074;
    public static final int notification_bg_normal_pressed = 2131231075;
    public static final int notification_icon_background = 2131231076;
    public static final int notification_template_icon_bg = 2131231077;
    public static final int notification_template_icon_low_bg = 2131231078;
    public static final int notification_tile_bg = 2131231079;
    public static final int notify_panel_notification_icon_bg = 2131231080;
}
