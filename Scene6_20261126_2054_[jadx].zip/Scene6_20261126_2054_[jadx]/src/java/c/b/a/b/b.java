package c.b.a.b;

import java.util.Iterator;
import java.util.Map;
import java.util.WeakHashMap;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class b<K, V> implements Iterable<Map.Entry<K, V>> {
    c<K, V> f;
    private c<K, V> g;
    private WeakHashMap<f<K, V>, Boolean> h = new WeakHashMap<>();
    private int i = 0;

    static class a<K, V> extends e<K, V> {
        a(c<K, V> cVar, c<K, V> cVar2) {
            super(cVar, cVar2);
        }

        @Override // c.b.a.b.b.e
        c<K, V> b(c<K, V> cVar) {
            return cVar.i;
        }

        @Override // c.b.a.b.b.e
        c<K, V> c(c<K, V> cVar) {
            return cVar.h;
        }
    }

    /* JADX INFO: renamed from: c.b.a.b.b$b, reason: collision with other inner class name */
    private static class C0006b<K, V> extends e<K, V> {
        C0006b(c<K, V> cVar, c<K, V> cVar2) {
            super(cVar, cVar2);
        }

        @Override // c.b.a.b.b.e
        c<K, V> b(c<K, V> cVar) {
            return cVar.h;
        }

        @Override // c.b.a.b.b.e
        c<K, V> c(c<K, V> cVar) {
            return cVar.i;
        }
    }

    static class c<K, V> implements Map.Entry<K, V> {
        final K f;
        final V g;
        c<K, V> h;
        c<K, V> i;

        c(K k, V v) {
            this.f = k;
            this.g = v;
        }

        @Override // java.util.Map.Entry
        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof c)) {
                return false;
            }
            c cVar = (c) obj;
            return this.f.equals(cVar.f) && this.g.equals(cVar.g);
        }

        @Override // java.util.Map.Entry
        public K getKey() {
            return this.f;
        }

        @Override // java.util.Map.Entry
        public V getValue() {
            return this.g;
        }

        @Override // java.util.Map.Entry
        public int hashCode() {
            return this.f.hashCode() ^ this.g.hashCode();
        }

        @Override // java.util.Map.Entry
        public V setValue(V v) {
            throw new UnsupportedOperationException("An entry modification is not supported");
        }

        public String toString() {
            return this.f + "=" + this.g;
        }
    }

    private class d implements Iterator<Map.Entry<K, V>>, f<K, V> {
        private c<K, V> f;
        private boolean g = true;

        d() {
        }

        @Override // c.b.a.b.b.f
        public void a(c<K, V> cVar) {
            c<K, V> cVar2 = this.f;
            if (cVar == cVar2) {
                c<K, V> cVar3 = cVar2.i;
                this.f = cVar3;
                this.g = cVar3 == null;
            }
        }

        @Override // java.util.Iterator
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public Map.Entry<K, V> next() {
            c<K, V> cVar;
            if (this.g) {
                this.g = false;
                cVar = b.this.f;
            } else {
                c<K, V> cVar2 = this.f;
                cVar = cVar2 != null ? cVar2.h : null;
            }
            this.f = cVar;
            return this.f;
        }

        @Override // java.util.Iterator
        public boolean hasNext() {
            if (this.g) {
                return b.this.f != null;
            }
            c<K, V> cVar = this.f;
            return (cVar == null || cVar.h == null) ? false : true;
        }
    }

    private static abstract class e<K, V> implements Iterator<Map.Entry<K, V>>, f<K, V> {
        c<K, V> f;
        c<K, V> g;

        e(c<K, V> cVar, c<K, V> cVar2) {
            this.f = cVar2;
            this.g = cVar;
        }

        private c<K, V> e() {
            c<K, V> cVar = this.g;
            c<K, V> cVar2 = this.f;
            if (cVar == cVar2 || cVar2 == null) {
                return null;
            }
            return c(cVar);
        }

        @Override // c.b.a.b.b.f
        public void a(c<K, V> cVar) {
            if (this.f == cVar && cVar == this.g) {
                this.g = null;
                this.f = null;
            }
            c<K, V> cVar2 = this.f;
            if (cVar2 == cVar) {
                this.f = b(cVar2);
            }
            if (this.g == cVar) {
                this.g = e();
            }
        }

        abstract c<K, V> b(c<K, V> cVar);

        abstract c<K, V> c(c<K, V> cVar);

        @Override // java.util.Iterator
        /* JADX INFO: renamed from: d, reason: merged with bridge method [inline-methods] */
        public Map.Entry<K, V> next() {
            c<K, V> cVar = this.g;
            this.g = e();
            return cVar;
        }

        @Override // java.util.Iterator
        public boolean hasNext() {
            return this.g != null;
        }
    }

    interface f<K, V> {
        void a(c<K, V> cVar);
    }

    public Iterator<Map.Entry<K, V>> a() {
        C0006b c0006b = new C0006b(this.g, this.f);
        this.h.put(c0006b, Boolean.FALSE);
        return c0006b;
    }

    public Map.Entry<K, V> b() {
        return this.f;
    }

    protected c<K, V> c(K k) {
        c<K, V> cVar = this.f;
        while (cVar != null && !cVar.f.equals(k)) {
            cVar = cVar.h;
        }
        return cVar;
    }

    public b<K, V>.d d() {
        b<K, V>.d dVar = new d();
        this.h.put(dVar, Boolean.FALSE);
        return dVar;
    }

    public Map.Entry<K, V> e() {
        return this.g;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof b)) {
            return false;
        }
        b bVar = (b) obj;
        if (size() != bVar.size()) {
            return false;
        }
        Iterator<Map.Entry<K, V>> it = iterator();
        Iterator<Map.Entry<K, V>> it2 = bVar.iterator();
        while (it.hasNext() && it2.hasNext()) {
            Map.Entry<K, V> next = it.next();
            Map.Entry<K, V> next2 = it2.next();
            if ((next == null && next2 != null) || (next != null && !next.equals(next2))) {
                return false;
            }
        }
        return (it.hasNext() || it2.hasNext()) ? false : true;
    }

    protected c<K, V> f(K k, V v) {
        c<K, V> cVar = new c<>(k, v);
        this.i++;
        c<K, V> cVar2 = this.g;
        if (cVar2 == null) {
            this.f = cVar;
        } else {
            cVar2.h = cVar;
            cVar.i = cVar2;
        }
        this.g = cVar;
        return cVar;
    }

    public V g(K k, V v) {
        c<K, V> cVarC = c(k);
        if (cVarC != null) {
            return cVarC.g;
        }
        f(k, v);
        return null;
    }

    public V h(K k) {
        c<K, V> cVarC = c(k);
        if (cVarC == null) {
            return null;
        }
        this.i--;
        if (!this.h.isEmpty()) {
            Iterator<f<K, V>> it = this.h.keySet().iterator();
            while (it.hasNext()) {
                it.next().a(cVarC);
            }
        }
        c<K, V> cVar = cVarC.i;
        if (cVar != null) {
            cVar.h = cVarC.h;
        } else {
            this.f = cVarC.h;
        }
        c<K, V> cVar2 = cVarC.h;
        if (cVar2 != null) {
            cVar2.i = cVarC.i;
        } else {
            this.g = cVarC.i;
        }
        cVarC.h = null;
        cVarC.i = null;
        return cVarC.g;
    }

    public int hashCode() {
        Iterator<Map.Entry<K, V>> it = iterator();
        int iHashCode = 0;
        while (it.hasNext()) {
            iHashCode += it.next().hashCode();
        }
        return iHashCode;
    }

    @Override // java.lang.Iterable
    public Iterator<Map.Entry<K, V>> iterator() {
        a aVar = new a(this.f, this.g);
        this.h.put(aVar, Boolean.FALSE);
        return aVar;
    }

    public int size() {
        return this.i;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        Iterator<Map.Entry<K, V>> it = iterator();
        while (it.hasNext()) {
            sb.append(it.next().toString());
            if (it.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append("]");
        return sb.toString();
    }
}
