package c.b.a.b;

import java.util.HashMap;
import java.util.Map;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class a<K, V> extends b<K, V> {
    private HashMap<K, b.c<K, V>> j = new HashMap<>();

    @Override // c.b.a.b.b
    protected b.c<K, V> c(K k) {
        return this.j.get(k);
    }

    public boolean contains(K k) {
        return this.j.containsKey(k);
    }

    @Override // c.b.a.b.b
    public V g(K k, V v) {
        b.c<K, V> cVarC = c(k);
        if (cVarC != null) {
            return cVarC.g;
        }
        this.j.put(k, f(k, v));
        return null;
    }

    @Override // c.b.a.b.b
    public V h(K k) {
        V v = (V) super.h(k);
        this.j.remove(k);
        return v;
    }

    public Map.Entry<K, V> i(K k) {
        if (contains(k)) {
            return this.j.get(k).i;
        }
        return null;
    }
}
