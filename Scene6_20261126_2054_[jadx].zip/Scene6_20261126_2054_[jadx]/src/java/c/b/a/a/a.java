package c.b.a.a;

/* JADX INFO: loaded from: /storage/emulated/0/Download/APK Decompiler Pro/sources/Scene6_20261126_2054_[jadx]/dex-files/0.dex */
public class a extends c {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private static volatile a f51c;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private c f52a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private c f53b;

    private a() {
        b bVar = new b();
        this.f53b = bVar;
        this.f52a = bVar;
    }

    public static a b() {
        if (f51c != null) {
            return f51c;
        }
        synchronized (a.class) {
            if (f51c == null) {
                f51c = new a();
            }
        }
        return f51c;
    }

    @Override // c.b.a.a.c
    public boolean a() {
        return this.f52a.a();
    }
}
